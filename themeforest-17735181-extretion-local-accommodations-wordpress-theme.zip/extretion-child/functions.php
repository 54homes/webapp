<?php
add_action( 'wp_enqueue_scripts', 'extretion_enqueue_styles' );
function extretion_enqueue_styles() {
    wp_enqueue_style( 'extretion_style', get_template_directory_uri() . '/style.css' );

}