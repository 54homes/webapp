<?php
/*
* This is a template for room
*/

get_header();

if( have_posts() ):

	while( have_posts() ): the_post();

		$layout = get_option( 'options_room_layout' );

		// Count room view
		extretion_track_post_views( $post->ID );

		if( empty( $layout ) || $layout == 1 ){
			get_template_part( 'template-parts/single-layout' , 'withoutTab' );
		} else {
			get_template_part( 'template-parts/single-layout' , 'withTab' );
		}
								
	endwhile;

endif;

get_footer();