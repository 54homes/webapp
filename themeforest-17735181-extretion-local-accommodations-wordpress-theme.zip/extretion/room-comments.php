<?php

/**
 * The template for displaying comments.
 *
 * This is the template that displays the area of the page that contains both the current comments
 * and the comment form.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package extretion
 */

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */

if ( post_password_required() ) {
	return;
}

$layout = get_option( 'options_room_layout' );
?>

<div id="<?php echo ( $layout == 1 ? 'detail-content-sticky-nav-03' : 'review-nav-03' ); ?>" class="<?php echo ( $layout == 1 ? 'pt-30' : '' ); ?>">

	<?php 
	// Display on without tab page
	if( $layout == 1 ){ ?>
		<div class="section-title-3">
			<h3><?php esc_html_e( 'Reviews' , 'extretion' ); ?></h3>
		</div>
		<?php 
	} 

	// You can start editing here -- including this comment!
	if ( have_comments() ) : 

		$get_all_avg_rating = extretion_get_all_avg_rating( $post->ID ); 

		$recommend_percent = extretion_get_recommend_percentage( $post->ID )?>

		<div class="review-score-wrapper border mb-30">
					
			<div class="row row-same-height">
			
				<div class="col-xs-12 col-sm-3 col-sm-height col-middle">
					
					<div class="review-score-heading">
					
						<h4 class="caps"><?php echo extretion_get_individual_rating_words(  number_format( $get_all_avg_rating , 1 ) ); ?></h4>
						
						<p class="score">
						
							<span class="this text-primary block mb-5">

								<?php echo number_format( $get_all_avg_rating , 1 ); ?>
								
							</span>
							<span class="font16">/ <span class="of"><?php esc_html_e( '5.0' , 'extretion' ); ?></span></span>
						</p>
						
						<p class="recommend-this"><span class="block font22"><?php echo number_format($recommend_percent , 0 ); ?>%</span><?php esc_html_e( 'recommend' , 'extretion' ); ?></p>
						
					</div>

				</div>
				
				<div class="col-xs-12 col-sm-9 col-sm-height col-middle">
					
					<div class="gap-20">
					
						<div class="col-xs-12 col-sm-7">
							
							<h4 class="mb-10 font400 mb-15 font16">

								<?php 
								printf( 
									esc_html__( 'Score Breakdown from %d reviews' , 'extretion' ), extretion_count_published_comments( $post->ID ) 
								); ?>
								
							</h4>
							
							<ul class="review-score-list with-progress clearfix mb-0">
								
								<?php 

								extretion_show_score_breakdown( $post->ID );

								?>
							
							</ul>
							
						</div>
						
						<div class="col-xs-12 col-sm-5">
						
							<h4 class="mb-10 mt-20-xs font400 mb-15 font16"><?php esc_html_e( 'Average Rating For:' , 'extretion' ); ?></h4>
							<ul class="review-score-list clearfix mb-0">
								
								<?php 
								extretion_get_averating_for_meta_value( $post->ID );
								?>
							
							</ul>
							
						</div>
						
					</div>
					
				</div>
				
			</div>
			
		</div>
		
		<div class="mb-30"></div>

			<?php 
			wp_list_comments( array(
				'walker' => new room_comment_walker(),
				'max_depth' => '1',
			) );
			
			echo '<div class="navigation_comment result-paging-wrapper">';
			  paginate_comments_links(); 
			echo '</div>';

			?>

		<div class="mb-30"></div>

		<?php

	else:

		$mb_review_info = is_user_logged_in() ? 'mb-20' : '';
		echo '<div class="alert alert-info ' . $mb_review_info . '">' . esc_html__( 'No reviews to show.' , 'extretion' ) . '</div>';

	endif; // Check for have_comments().


	// If comments are closed and there are comments, let's leave a little note, shall we?
	if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) : ?>

		<p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'extretion' ); ?></p>
	<?php
	endif;

	/**
	* Only users who have booked the room can write a review
	*/
	
	$args = array(
		'post_type' => 'lmh_invoice',
		'post_status' => 'publish',
		'author' => get_current_user_id(),
		'meta_query' => array(
			'relation' => 'AND',
			array(
				'key'     => 'payment_status',
				'value'   => 'payment_successful',
				'compare' => '=',
			),
			array(
				'key'     => 'related_room_id',
				'value'   => $post->ID,
				'type'    => 'numeric',
				'compare' => '=',
			),
		),
	);

	$comment_query = new WP_Query( $args );

	if( is_user_logged_in() && $comment_query->have_posts() ){
		comment_form();
	} ?>

</div><!-- #comments -->
