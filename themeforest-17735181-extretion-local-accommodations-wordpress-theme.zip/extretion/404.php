<?php
get_header();  ?>

	<div <?php post_class( "error-404-wrapper" ); ?>>
			
		<div class="container">
		
			<h2 class="text-primary"><?php esc_attr_e( '404' , 'extretion' ); ?></h2>
			<h3><?php esc_attr_e( 'Sorry, the page could not be found' , 'extretion' ); ?></h3>
			<p class="lead"><?php esc_attr_e( 'The page you are looking does not exist.' , 'extretion' ); ?></p>
			
			<div class="mb-40"></div>
			
			<?php 
			extretion_get404Search(); 
			extretion_helpfulLinks(); ?>			
			
		</div>
		
	</div>

<?php
get_footer();
