<div class="edit_room_basic_details">
	
	<form id="listYourRoomForm" method="POST" action="" enctype="multipart/form-data">

		<?php 
		extretion_saveListYourProperty( $edit = true );
		extretion_listYourProperty( $edit = true , $user_meta = false , $post_meta = true );
		?>

	</form>

</div>