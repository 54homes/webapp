<?php 
$args = array(
	'post_type' => 'lmh_slider',
	'post_status' => 'publish',
	'posts_per_page' => -1
);

$slider_query = new WP_Query( $args ); 

if( $slider_query->have_posts() ): ?>
	
	<div class="slick-hero-slider-wrapper">
				
		<div class="slider slick-hero-slider slick-slider-center-mode slick-animation slick-inner-dot alt-dot-position">

			<?php
			while( $slider_query->have_posts() ): $slider_query->the_post(); 

				$post_thumbnail_id = get_post_thumbnail_id( $post->ID ); 

				$image_attr = wp_get_attachment_image_src( $post_thumbnail_id , 'full' ); 

				$read_more_text =  get_post_meta( $post->ID , 'read_more_text' , true ); 
				$read_more_text = !empty( $read_more_text ) ? esc_html( $read_more_text ) : esc_html__( 'More Details' , 'extretion' ); ?>

				<div class="slick-item">
		
					<div class="image-bg" style="background-image:url( '<?php echo esc_url( $image_attr[0] ); ?>' );">
					
						<div class="container">
						
							<div class="row">
			
								<div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
					
									<div class="slick-hero-slider-caption">
										<h2 class="animation fromBottom transitionDelay2 transitionDuration4"><?php the_title(); ?></h2>
										<p class="animation fromBottom transitionDelay4 transitionDuration6"><?php echo sanitize_text_field( get_post_meta( $post->ID , 'sub_title' , true ) ); ?></p>

										<?php 
										if( get_post_meta( $post->ID , 'read_more_link' , true ) ){ 

											$page_id = get_post_meta( $post->ID , 'read_more_link' , true ); 
											$page_url = get_permalink( $page_id );?>

											<a href="<?php echo esc_url( $page_url ); ?>" class="animation fromBottom transitionDelay6 transitionDuration8">
												<span>
													<?php echo esc_html( $read_more_text ); ?>
												</span>
											</a>
											<?php 
										
										}

										$another_read_more_link = esc_url( get_post_meta( $post->ID , 'another_read_more_link' , true ) );
										$another_read_more_text = esc_html( get_post_meta( $post->ID , 'another_read_more_text' , true ) );
										
										if( !empty( $another_read_more_link ) && !empty( $another_read_more_text ) ){ ?>

											<a href="<?php echo esc_url( $another_read_more_link ); ?>" class="animation fromBottom transitionDelay6 transitionDuration8">
												<span class="bg-primary">
													<?php echo esc_html( $another_read_more_text ); ?>
												</span>
											</a>

											<?php 

										} ?>

									</div>
									
								</div>
								
							</div>
						
						</div>
						
					</div>
					
				</div>

			<?php
			endwhile; ?>

		</div>

	</div>

	<?php

endif;
?>

<div class="main-search-wrapper-2 absolute-in-hero-slider">

	<div class="container">

		<form class="row gap-20 search_page_form_home" method="get" action="#">
					
			<div class="col-xss-12 col-xs-12 col-sm-12">
			
				<div class="row gap-20">
					
					<div class="col-xss-12 col-xs-12 col-sm-12 col-md-4">
												
						<div class="typeahead-field form-group">
							<input id="destination-search-homepage" name="s" type="search" autocomplete="off" class="form-control" placeholder="<?php echo esc_html( $defaults['homepage']['destination-search-homepage'] ); ?>" value="">
						</div>
						<div class="error_label error_label_home hidden-lg hidden-md hidden-sm"></div>
						<div class="search_place_attr" style="display:none">

				        	<input data-geo="lat" name="lat" value="" type="hidden" >
					        <input data-geo="lng" name="lng" value="" type="hidden">
					        <input data-geo="formatted_address" name="formatted_address" value="" type="hidden">
					        <input data-geo="name" name="place" value="" type="hidden">
				
					    </div>

					</div>

					<div class="col-xss-12 col-xs-12 col-sm-4 col-md-2">
						<div class="form-group form-icon-right"> 
							<input name="arrival_date" class="form-control" id="arrival_date" placeholder="<?php echo esc_html( $defaults['homepage']['check_in'] ); ?>" type="text" readonly value="">
							<i class="fa fa-calendar"></i>
						</div>
					</div>
					
					<div class="col-xss-12 col-xs-12 col-sm-4 col-md-2">
						<div class="form-group form-icon-right"> 
							<input name="departure_date" class="form-control" id="departure_date" placeholder="<?php echo esc_html( $defaults['homepage']['check_out'] ); ?>" type="text" readonly  value="">
							<i class="fa fa-calendar"></i>
						</div>
					</div>

					<div class="col-xss-12 col-xs-12 col-sm-4 col-md-2">
					
						<div class="form-group">
							<select name="guests" class="custom-select" id="change-search-room" autocomplete="off">
								<option value="all"><?php echo esc_html( $defaults['homepage']['guests'] ); ?></option>

								<?php 
								$guests = extretion_guestAccomodate(); 
								foreach( $guests as $guest ){ ?>

									<option value="<?php echo (int) $guest; ?>"><?php echo (int) $guest; ?></option>

										<?php
									} 
								?>
								
							</select>
						</div>
						
					</div>

					<div class="col-xss-12 col-xs-12 col-sm-12 col-md-2">
						<button class="btn btn-block btn-primary"><?php esc_html_e( 'Search' , 'extretion' ); ?> <span class="icon"><i class="fa fa-search"></i></span></button>
					</div>
				
				</div>

			</div>
			
		</form>

	</div>
	
</div>

<div class="clear"></div>