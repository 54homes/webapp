<?php 
if( !empty( $_GET['status'] ) && $_GET['status'] == 'success' ){ ?>
	<div class="alert alert-success mb-25 text-center">
		<?php esc_html_e( 'Your availabilities has been successfully changed.' , 'extretion' ); ?>
	</div>
	<?php 
} ?>

<div class="alert alert-info mb-25 text-center">
	<?php esc_html_e( ' Click on the first and the last date of the period you wish to edit. You can change these dates anytime. ' , 'extretion' ); ?>
</div>
<div class="room_dates_calendar"></div>
<input type="hidden" id="calendar_start_date" value="" autocomplete="off">
<input type="hidden" id="calendar_end_date" value="" autocomplete="off">
<ul class="map-neighbour-label calendar-label clearfix col-xs-12 col-md-12">
	<li class="color-01 col-xs-6 col-md-3">
		<?php esc_html_e( 'Booking Available Dates' , 'extretion' ); ?>
	</li>
	<li class="color-02 col-xs-6 col-md-3">
		<?php esc_html_e( 'Booking Unavailable Dates' , 'extretion' ); ?>
	</li>
</ul>