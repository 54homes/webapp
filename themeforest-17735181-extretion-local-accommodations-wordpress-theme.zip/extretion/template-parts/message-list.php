<div class="dashboard-content">

		<div class="row">
		
			<div class="col-xs-12 col-sm-10 col-md-9">
				
				<div class="dashboard-heading">
				
					<h3><?php esc_html_e( 'Message Lists' , 'extretion' ); ?></h3>
			
				</div>
				
			</div>

		</div>

	</div>

	<?php 
	do_action( 'extretion_after_message_list_title' );
	$message_page_id = get_option( 'options_select_messages_page' );
	?>

	<div class="hotel-message-wrapper mt-5">

		<div class="message_inbox_sent_btn mb-15">

			<a class="btn btn-primary inbox_message <?php echo empty( $_GET['page'] ) ? 'active' : ''; ?>" href="<?php echo get_permalink( $message_page_id ); ?>">
				<?php 
				esc_html_e( 'Inbox' , 'extretion' ); 

				$count_inbox = count_inbox_notification();
				echo '<spen class="count_individual_message">' . $count_inbox . '</span>';
				?>
					
			</a>
			<a class="btn btn-danger sent_message <?php echo ( !empty( $_GET['page'] ) && $_GET['page'] == 'sent' ) ? 'active' : ''; ?>" href="<?php echo get_permalink( $message_page_id ); ?>?page=sent">
				<?php 
				esc_html_e( 'Sent' , 'extretion' ); 

				$count_sent = count_sent_notification();
				echo '<span class="count_individual_message count_sent">' . $count_sent . '</span>';

				?>
					
			</a>

		</div>

		<div class="clear"></div>												

		<ul class="hotel-message-list inbox_messages_wrapper" style="<?php echo empty( $_GET['page'] ) ? '' : 'display:none;'; ?>">
		
			<?php 

			extretion_get_messages();

			?>										
			
		</ul>

		<ul class="hotel-message-list sent_messages_wrapper" style="<?php echo ( !empty( $_GET['page'] ) && $_GET['page'] == 'sent' ) ? '' : 'display:none;'; ?>">
			<?php extretion_get_messages( true ); ?>
		</ul>
		
	</div>