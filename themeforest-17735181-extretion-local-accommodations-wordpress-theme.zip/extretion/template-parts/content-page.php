<?php
/**
 * Template part for displaying page content in page.php.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package extretion
 */

?>

<div class="content-wrapper page-wrapper">

	<div class="section-title mb-20">
		<h2 class="mb-15 text-left"><?php the_title(); ?></h2>
	</div>
	
	<div class="bb"></div>
	<div class="bb"></div>

	<div class="mb-25"></div>
	
	<?php 
	if( has_post_thumbnail() ){ ?>
		<div class="image">
			<?php the_post_thumbnail( 'extretion_blog-page' );?>
		</div>
		<?php 
	} 
	?>

	<div class="mb-25"></div>
	
	<?php 
	the_content(); 
	
	wp_link_pages( array(
			'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'extretion' ),
			'after'  => '</div>',
		) );

	?>
	
	<div class="mb-40"></div>

	<?php	
	if ( comments_open() || get_comments_number() ) :
		comments_template( '/comments.php', true );
	endif; ?>

</div>