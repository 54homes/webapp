<!-- start hero-header -->
<div class="hero extretion_banner_homepage" style="background-image:url( <?php echo extretion_get_banner_image(); ?> );">
	
	<div class="container">
		
		<div class="hero-texting">

			<!-- Hero heading -->
			<h1><?php echo extretion_get_banner_title(); ?></h1>

			<!-- Hero subheading -->
			<p class="extretion_banner_subtitle"><?php echo extretion_get_banner_subtitle(); ?></p>
			
		</div>

		<div class="main-search-wrapper">

			<div class="inner animated fadeInUp delay_1">
						
				<form class="row gap-20 search_page_form_home" method="get" action="#">
					
					<div class="col-xss-12 col-xs-12 col-sm-12">
					
						<div class="row gap-20">
							
							<div class="col-xss-12 col-xs-12 col-sm-12 col-md-4">
														
								<div class="typeahead-field form-group">
									<input id="destination-search-homepage" name="s" type="search" autocomplete="off" class="form-control" placeholder="<?php echo esc_html( $defaults['homepage']['destination-search-homepage'] ); ?>" value="">
								</div>
								<div class="error_label error_label_home"></div>
								<div class="search_place_attr" style="display:none">

						        	<input data-geo="lat" name="lat" value="" type="hidden" >
							        <input data-geo="lng" name="lng" value="" type="hidden">
							        <input data-geo="formatted_address" name="formatted_address" value="" type="hidden">
							        <input data-geo="name" name="place" value="" type="hidden">
						
							    </div>

							</div>

							<div class="col-xss-12 col-xs-12 col-sm-4 col-md-2">
								<div class="form-group form-icon-right"> 
									<input name="arrival_date" class="form-control" id="arrival_date" placeholder="<?php echo esc_html( $defaults['homepage']['check_in'] ); ?>" type="text" readonly value="">
									<i class="fa fa-calendar"></i>
								</div>
							</div>
							
							<div class="col-xss-12 col-xs-12 col-sm-4 col-md-2">
								<div class="form-group form-icon-right"> 
									<input name="departure_date" class="form-control" id="departure_date" placeholder="<?php echo esc_html( $defaults['homepage']['check_out'] ); ?>" type="text" readonly  value="">
									<i class="fa fa-calendar"></i>
								</div>
							</div>

							<div class="col-xss-12 col-xs-12 col-sm-4 col-md-2">
							
								<div class="form-group">
									<select name="guests" class="custom-select" id="change-search-room" autocomplete="off">
										<option value="all"><?php echo esc_html( $defaults['homepage']['guests'] ); ?></option>

										<?php 
										$guests = extretion_guestAccomodate(); 
										foreach( $guests as $guest ){ ?>

											<option value="<?php echo (int) $guest; ?>"><?php echo (int) $guest; ?></option>

												<?php
											} 
										?>
										
									</select>
								</div>
								
							</div>

							<div class="col-xss-12 col-xs-12 col-sm-12 col-md-2">
								<button class="btn btn-block btn-primary"><?php esc_html_e( 'Search' , 'extretion' ); ?> <span class="icon"><i class="fa fa-search"></i></span></button>
							</div>
						
						</div>

					</div>
					
				</form>
			
			</div>
			
		</div>
		
	</div>
	
</div>
<!-- end hero-header -->