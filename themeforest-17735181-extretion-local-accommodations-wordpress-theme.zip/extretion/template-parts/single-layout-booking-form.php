<?php 
if( $post->post_author != get_current_user_id() ): ?>

	<div id="sticky-sidebar-booking" class="sidebar-wrapper ">

		<aside>
			
			<!-- <div class="mb-10 mb-5-sm"></div> -->
			
			<div class="detail-right-sidebar">
			
				<div class="price">
					
					<div class="round_circle">			

						<?php esc_html_e( 'Starting from' , 'extretion' ); ?> 

						<span class="number">

							<?php 
							echo get_per_night_price( $post->ID );
							?>
							
						</span>

						<?php esc_html_e( 'Per Night' , 'extretion' ); ?>
						
					</div>
					
					<div class="or-text"><span></span></div>
					
				</div>

				<div class="detail-search-form">
					<div class="inner">
						<form class="gap-10">

							<div class="col-xs-6 col-sm-6">
								<div class="form-group form-icon-right mb-10"> 
									<label><?php esc_html_e( 'Check In' , 'extretion' ); ?></label>
									<input name="arrival_date" class="form-control mb-0" id="dpd1" autocomplete="off" type="text">
								</div>
							</div>
							<div class="col-xs-6 col-sm-6">
								<div class="form-group form-icon-right mb-10"> 
									<label><?php esc_html_e( 'Check Out' , 'extretion' ); ?></label>
									<input name="departure_date" class="form-control mb-0" id="dpd2" autocomplete="off" type="text">
								</div>
							</div>
							<div class="col-xs-12 col-sm-12">
								<div class="form-group">
									<label><?php esc_html_e( 'Guest' , 'extretion' ); ?></label>
									<select class="custom-select" id="change-search-room">

										<?php 
										extretion_check_room_accomodates( $post->ID );
										?>

									</select>
								</div>
							</div>

							<div class="clear"></div>

							<div class="content content-price content_price_sidebar" style="display:none">
							
								<div class="preloader">
									<img class="loader" src="<?php echo get_template_directory_uri() . '/images/balls.svg' ; ?>" style="display:none" alt="loader">
								</div>

								<div class="price-subtotal price-subtotal-new mb-10 error_booking_msg" style="display:none">
									<p></p>
								</div>

								<div class="booking_prices_details"></div>
								
							</div>

							<div class="clear"></div>
							
							<div class="col-sm-12">
								<button class="btn btn-block btn-icon btn-primary book_now_step_1" type="button" disabled="disabled">

									<?php 												
									echo '<i class="fa fa-bolt instant_book_color"></i><span class="booking_type_wrapper">';
									esc_html_e( 'Request to Book' , 'extretion' );
									echo '</span>';
									?>

									<span class="icon">
										<i class="fa fa-long-arrow-right"></i>
									</span>

								</button>
							</div>
							
							<div class="clear"></div>

							<div class="col-sm-12">

								<div class="single_page_message_wrapper">

									<p class="text-center mt-20 mb-10"><?php esc_html_e( 'or send the host a message', 'extretion' ); ?></p>

									<button class="btn btn-block btn-icon btn-danger send_message_btn_wrapper" type="button">

										<?php 												
										echo '<i class="fa fa-envelope-o message_icon_single_page"></i><span class="send_message_wrapper">';
										esc_html_e( 'Send Message' , 'extretion' );
										echo '</span>';
										?>

										<span class="icon">
											<i class="fa fa-long-arrow-right"></i>
										</span>

									</button>

									<p class="text-center mt-10"><?php esc_html_e( 'Ask your questions before you rent. No obligations, just have a friendly conversation!' , 'extretion' ); ?></p>

								</div>

							</div>

							<div class="clear"></div>

							<div class="col-sm-12">
								
								<div class="report_room_listing">
									<a href="javascript:void(0)" class="report_btn">
										<i class="fa fa-flag-o" aria-hidden="true"></i><?php esc_html_e( 'Report this listing' , 'extretion' ); ?>
									</a>
								</div>

							</div>

							<div class="clear"></div>

						</form>
					</div>
				
				</div>
				
			</div>

			<div class="mb-30 mb-5-sm"></div>
			
		</aside>

	</div>

	<?php

else: ?>

	<div class="sidebar-wrapper ">
		<?php extretion_roomDetailSidebar(); ?>
	</div>

	<?php

endif;