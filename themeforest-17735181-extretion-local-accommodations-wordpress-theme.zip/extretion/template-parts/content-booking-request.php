<div class="confirm-summary clearfix">
	
	<?php 
	$photos = get_post_meta( $post_id, 'room_photos', true );
	
	$image_attr = wp_get_attachment_image( $photos[0], 'extretion_booking_page_thumbnail' ); 

	if( $image_attr ){
		echo '<div class="image">' . $image_attr . '</div>';
	} ?>

	<div class="heading">

		<div class="raty-wrapper sp-2 mb-10">

			<?php 		
			$get_all_avg_rating = extretion_get_all_avg_rating( $post_id );?>
			
			<?php extretion_title_star_width( $get_all_avg_rating ); ?>

		</div>

		<h4><?php echo get_the_title( $post_id ); ?></h4>

		<p>
			<?php echo sanitize_text_field( get_post_meta( $post_id, 'form_place_located_formatted_address', true ) ); ?>
			
		</p>
	</div>
	<div class="content mt-20">
		
		<div class="confirm-date">
		
			<div class="icon">
				<i class="fa fa-calendar"></i>
			</div>
			
			<div class="content">
				<ul>
					<li>
						<span class="absolute">
							<?php echo esc_html( $defaults['billing_info_check_in'] ); ?> 
						</span>
						<?php echo date( 'D , jS \of F Y' , strtotime( $order_id['check_in'] ) ); ?>
					</li>
					<li>
						<span class="absolute">
							<?php echo esc_html( $defaults['billing_info_check_out'] ); ?> 
						</span>
						<?php echo date( 'D , jS \of F Y' , strtotime( $order_id['check_out'] ) ); ?>
					</li>
				</ul>
			</div>
			
		</div>
		
	</div>

</div>

<div class="row mt-30">

	<div class="col-sm-12 col-md-6 mb-30 billing_price_details" data-match-height="confirm">

		<div class="metro-box-wrapper equal-height1">
				
			<div class="heading">
				<h3><?php echo esc_html( $defaults['billing_info_label'] ); ?></h3>
			</div>

			<div class="content">
			
				<ul class="confirm-list">
				
					<li>
						<span class="absolute font600">
							<?php echo esc_html( $defaults['confirmation_fname'] ); ?>
						</span> 
						<?php 
						echo sanitize_text_field( $order_id['step_2_attributes']['firstname'] ); ?>
					</li>

					<li>
						<span class="absolute font600">
							<?php echo esc_html( $defaults['confirmation_lname'] ); ?>
						</span> 
						<?php 
						echo sanitize_text_field( $order_id['step_2_attributes']['lastname'] ); ?>
					</li>

					<li>
						<span class="absolute font600">
							<?php echo esc_html( $defaults['confirmation_email'] ); ?>
						</span> 
						<?php 
						echo get_the_author_meta( 'user_email', $order_id['booking_request_by'] ); 
						?>
					</li>

					<li>
						<span class="absolute font600">
							<?php echo esc_html( $defaults['confirmation_street'] ); ?>
						</span> 
						<?php 
						echo sanitize_text_field( $order_id['step_2_attributes']['street_address'] ); ?>
					</li>

					<li>
						<span class="absolute font600">
							<?php echo esc_html( $defaults['confirmation_postal'] ); ?>
						</span> 
						<?php 
						echo sanitize_text_field( $order_id['step_2_attributes']['postal_code'] ); ?>
					</li>

					<li>
						<span class="absolute font600">
							<?php echo esc_html( $defaults['confirmation_city'] ); ?>
						</span> 
						<?php 
						echo sanitize_text_field( $order_id['step_2_attributes']['city'] ); ?>
					</li>

					<li>
						<span class="absolute font600">
							<?php echo esc_html( $defaults['confirmation_country'] ); ?>
						</span> 
						<?php 
						echo sanitize_text_field( $order_id['step_2_attributes']['country'] ); ?>
					</li>

					<li>
						<span class="absolute font600">
							<?php echo esc_html( $defaults['confirmation_phone'] ); ?>
						</span> 
						<?php 
						echo sanitize_text_field( $order_id['step_2_attributes']['phone'] ); ?>
					</li>

				</ul>
				
			</div>
		
		</div>
		
	</div>
	
	<div class="col-sm-12 col-md-6 mb-30 billing_price_details" data-match-height="confirm">
	
		<div class="metro-box-wrapper equal-height1">
				
			<div class="heading">
				<h3><?php echo esc_html( $defaults['confirmation_price_lable'] ); ?></h3>
			</div>

			<div class="content">
			
				<ul class="confirm-list inverse">
					
					<?php 
					$currency_symbol = extretion_currency_symbol( $order_id['currency'] );
					$guests_no = !empty( $order_id['step_2_attributes']['guest_fname'] ) ? count( $order_id['step_2_attributes']['guest_fname'] ) : 0;

					if( $guests_no > 0 ){

						for ($i=1; $i <= $guests_no; $i++) { ?>
							
							<li>
								<span class="font600">
									<?php 
									esc_html_e( 'Guest' , 'extretion' ); 
									echo ' '.$i . ':'; 
									?>
									
								</span>
								<br/>
								<?php 
								$first_name = empty( $order_id['step_2_attributes']['guest_fname'][$i] ) ? '' : $order_id['step_2_attributes']['guest_fname'][$i];

								$last_name = empty( $order_id['step_2_attributes']['guest_lname'][$i] ) ? '' : $order_id['step_2_attributes']['guest_lname'][$i];

								echo esc_html( $first_name );
								echo ' ';
								echo esc_html( $last_name ); ?>
							</li>

							<?php
						}

					} else { ?>

						<li>
							<span class="font600">
								<?php esc_html_e( 'Guest information not available.', 'extretion' ); ?>
							</span>
						</li>

						<?php
					}
					?>

					<div class="mt-20 bt pt-15 pb-0">
						<?php echo extretion_get_html_price_booking($order_id); ?>
					</div>
					<li class="total bt mb-20">
						<span class="absolute">
							<span class="text-primary">
								<?php 
								echo '<span class="currency_symbol">' . $currency_symbol . '</span> '. number_format( extretion_get_first_installment_price( $order_id ) , 2, '.', ','); ?>								
							</span>
						</span> 
						<strong>
							<?php echo esc_html( $defaults['confirmation_total'] ); ?>
						</strong>
						
					</li>
					<li class="price_breakdown">
						<a href="javascript:void(0)" class="price_breakdown_btn"><?php esc_html_e( 'Price Breakdown' , 'extretion' ); ?><i class="fa fa-caret-right" aria-hidden="true"></i></a>
					</li>

				</ul>
				
			</div>
		
		</div>
		
	</div>

</div>