<article class="blog-item-full">

	<?php

	if( is_sticky( $post->ID ) ){ ?>

		<div class="extretion_sticky">
			<?php esc_html_e( 'Featured Post' , 'extretion' ); ?>
		</div>

		<?php
	}

	if( has_post_thumbnail() && extretion_blogListingFeaturedImage() ){ ?>
		<div class="image">
			<a href="<?php the_permalink(); ?>">
				<?php the_post_thumbnail( 'extretion_blog-page' );?>
			</a>
		</div>
		<?php 
	} ?>
	<div class="content">
	
		<div class="meta">

			<?php
			
			/**
			* @param blogListingPublishedDate() ( boolen )
			*/ 

			if( extretion_blogListingPublishedDate() ){ ?>

				<i class="fa fa-calendar"></i> 
				<a href="<?php echo site_url(); ?>/<?php echo date( 'Y/m' , strtotime( get_the_date() ) ); ?>"><?php echo get_the_date(); ?></a>
				

				<?php 
			} 

			if( extretion_blogListingAuthor() ){ ?>

				<span class="mh-5">|</span> 
				<i class="fa fa-user"></i> 
				<a href="<?php echo get_author_posts_url( $post->post_author ); ?>"><?php echo get_the_author_meta( 'user_login' , $post->post_author ); ?></a> 

				<?php 
			} 

			if( extretion_blogListingCategory() ){
				echo '<span class="mh-5"> | </span>';
				extretion_getCategories( $post->ID , 'category' );
			} ?>

		</div>
		
		<h3 class="blog-title">
			<a href="<?php the_permalink(); ?>">
				<?php the_title(); ?>	
			</a>
		</h3>
		
		<?php 
		if( has_excerpt( $post->ID ) ){
			the_excerpt();
		} else {
			the_content();	
		}
		?>
		
		<a href="<?php the_permalink(); ?>" class="btn-read-more"><?php esc_html_e( 'read more' , 'extretion' ); ?></a>
		
	</div>
</article>