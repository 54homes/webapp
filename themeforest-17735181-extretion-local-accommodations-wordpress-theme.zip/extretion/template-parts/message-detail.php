<?php 
$message_id = (int) $_GET['reply'];
$room_id = get_post_meta( $message_id, 'related_room_id', true );
$current_user_id = get_current_user_id();
$message_details_unsort = get_post_meta( $message_id, 'message_detail' , true );
?>

<div class="hotel-message-wrapper">
								
	<ul class="hotel-message-list">
	
		<li>
		
			<div class="cleaffix relative">
							
				<div class="image">
					<img src="<?php echo extretion_get_first_image_room( $room_id ); ?>">
				</div>
				
				<div class="content">

					<h4><?php echo get_the_title( $room_id ); ?></h4>
					<?php 
					$address = get_post_meta( $room_id, 'place_located', true );
					
					if( !empty( $address ) ){ ?>

						<p class="location">
							<i class="fa fa-map-marker text-primary"></i> 
							<?php echo mb_strimwidth( $address , 0, 50, ' ...'); ?>
						</p>

						<?php 
					} ?>
					
					<div class="man">
						<div class="avatar">
							<?php 

							$sender_id = get_post_meta( $message_id, 'sender_id', true );
							$receiver_id = get_post_meta( $message_id, 'receiver_id', true );

							/**
							* If user is Host then show traveler details
							* If user is Traveler then show host details
							*/

							if( $current_user_id == $sender_id ){
								$user_id = $receiver_id;
								$role = 'host';
							} else {
								$user_id = $sender_id;
								$role = 'traveler';
							}
							
						  	echo get_avatar( 
						  		$user_id, 
						  		'100', 
						  		false,
						  		false, 
						  		array( 
						  			'class' => 'img-circle' 
						  		) 
						  	); ?>
						</div>
						<div class="info">
							<h5>
								<?php echo get_user_display_name( $user_id ); ?>
								<span class="label label-warning ml-5 user_role">

									<?php 
									if( $role == 'host' ){
										esc_html_e( 'Property Owner' , 'extretion' );
									} else {
										esc_html_e( 'Traveler' , 'extretion' );
									} ?>
									
								</span>
							</h5>
							<p>
								<strong>
									<?php esc_html_e( 'Speaks' , 'extretion' ); ?>		
								</strong> : <?php echo extretion_get_spoken_language( $user_id ); ?>
							</p>
						</div>
					</div>
					
				</div>
				
			</div>
		
		</li>
		
	</ul>
	
</div>

<div class="message-wrapper mt-40">
	
	<div class="message-item">
	
		<div class="row">
		
			<div class="col-xs-12 col-sm-4 col-md-3">
			
				<div class="message-author">
					
					<div class="avatar">
						<?php 
					  	echo get_avatar( 
					  		$current_user_id, 
					  		'100', 
					  		false,
					  		false, 
					  		array( 
					  			'class' => 'img-circle' 
					  		) 
					  	); ?>
					</div>
					<div class="info">
						<h5><?php echo get_user_display_name( $current_user_id ); ?></h5>
						<p><i class="fa fa-clock-o"></i> <?php echo date( 'M d, Y, H:i A' ); ?></p>
					</div>
					
				</div>
			
			</div>
			
			<div class="col-xs-12 col-sm-8 col-md-9">
			
				<div class="message-entry">
					
					<form id="message_reply_form">
					
						<div class="form-group">
							<textarea autocomplete="off" class="form-control mb-10" rows="5" placeholder="<?php esc_html_e( 'Your Message', 'extretion' ); ?>" name="reply_message"></textarea>
						</div>

						<input type="submit" class="btn btn-primary btn-sm reply_message_btn" value="<?php esc_html_e( 'Reply', 'extretion' ); ?>">
						
					</form>				
				
				</div>
				
			</div>
			
		</div>
		
	</div>
	
	<?php 

	// Get the latest messages first 
	$message_details_sort = array_reverse( $message_details_unsort );

	// Get the first five messages
	$first_five_message = array_slice( $message_details_sort, 0, 5 ); 

	//echo '<pre>'; print_r($first_five_message); echo '</pre>';

	// Display the messages
	extretion_get_the_message( $first_five_message , $message_id );

	// Show pagination
	$total_msg = count( $message_details_sort ); // Count all messages

	if( $total_msg > 5 ){
		echo '<div class="detail_message_load_more"><a href="javascript:void(0);" class="btn btn-danger btn-sm">' . esc_html__( 'Load More' , 'extretion' ) . '<i class="fa fa-refresh fa-spin" style="display:none"></i></a></div>';
	}
	?>
	
</div>