<?php 

/**
* Blog Listing Page
*/

$blogListingLayout = extretion_blogListingLayout();
?>
<div id="post-<?php the_ID(); ?>" <?php post_class("two-tone-layout {$blogListingLayout}"); ?>>

	<div class="equal-content-sidebar">
	
		<div class="container">
			
			<div class="content-wrapper">
				
				<div class="mb-10"></div>

				<div class="blog-wrapper">
				
					<?php 

					if ( have_posts() ) :

						while ( have_posts() ) : the_post();

							get_template_part( 'template-parts/content', 'blogcontent' ); 

						endwhile;
						
						extretion_blogListingPagination();

					else:

						get_template_part( 'template-parts/content', 'none' ); 	

					endif; ?>
				
				</div>
				
				<div class="mb-40"></div>
				
			</div>

			<div class="sidebar-wrapper">
				
				<?php 
				extretion_blogListingSidebar();
				?>					
			
			</div>

		</div>

	</div>

</div>