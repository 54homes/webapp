<div id="post-<?php the_ID(); ?>" <?php post_class("two-tone-layout"); ?>>
			
	<div class="equal-content-sidebar">
	
		<div class="container">
		
			<?php 
			get_template_part( 'template-parts/single-layout' , 'booking-form' );
			?>
			
			<div class="content-wrapper">
				
				<div class="mb-10"></div>
				
				<div class="detail-header">

					<div class="row gap-5">
						<div class="col-xs-12 col-sm-8 col-md-9">
							<h2>
								<?php 
								the_title(); 
								$get_all_avg_rating = extretion_get_all_avg_rating( $post->ID );?>
								
								<?php extretion_title_star_width( $get_all_avg_rating ); ?>
							</h2>
							<p class="mb-0">
								<?php echo sanitize_text_field( get_post_meta( $post->ID, 'form_place_located_formatted_address', true ) ); ?> - <a href="#detail-content-sticky-nav-04" class="font13 anchor without_tab_layout" data-toggle="tab">
								<i class="fa fa-map-marker"></i> 
								<?php esc_html_e( 'Show on map' , 'extretion' ); ?></a>
							</p>
						</div>
						<div class="col-xs-12 col-sm-4 col-md-3">

							<?php 
							if( $get_all_avg_rating > 0 ){ ?>

								<a href="#detail-content-sticky-nav-03" class="tripadvisor-module text-right anchor">
									<div class="raty-wrapper">
										<div class="texting text-uppercase">
											<?php 
											
											echo number_format( $get_all_avg_rating , 1 ); 
											echo ' ' . extretion_get_individual_rating_words( number_format( $get_all_avg_rating ) );?></div>
									</div>
									<div class="hover-underline text-muted">
										<?php printf( esc_html__( '%d reviews'  , 'extretion' ) , extretion_count_published_comments( $post->ID ) ) ?>
									</div>
								</a>

								<?php 
							} ?>
							
						</div>
					</div>
				
				</div>

				<div class="multiple-sticky hidden-sm hidden-xs">
				
					<div class="multiple-sticky-inner">
					
						<div class="multiple-sticky-container">
							
							<div class="multiple-sticky-item clearfix">
									
								<ul id="multiple-sticky-menu" class="multiple-sticky-nav clearfix">
									<li>
										<a href="#detail-content-sticky-nav-01"><?php esc_html_e( 'Gallery' , 'extretion' ); ?></a>
									</li>
									<li>
										<a href="#detail-content-sticky-nav-02"><?php esc_html_e( 'Room Info' , 'extretion' ); ?></a>
									</li>
									<li>
										<a href="#detail-content-sticky-nav-03"><?php esc_html_e( 'Reviews' , 'extretion' ); ?></a>
									</li>
									<li>
										<a href="#detail-content-sticky-nav-04"><?php esc_html_e( 'Map &amp; Neighbors' , 'extretion' ); ?></a>
									</li>

									<?php 
									$count_listings = extretion_get_similar_rooms( $post->ID , true );
									if( $count_listings > 0 ) { ?>
										<li>
											<a href="#detail-content-sticky-nav-05"><?php esc_html_e( 'Similar Listings' , 'extretion' ); ?></a>
										</li>
										<?php 
									} ?>
									
								</ul>

							</div>

						</div>
						
					</div>
					
				</div>
				
				<div class="detail-content-for-sticky-menu mb-30">

					<div class="clear"></div>
					
					<?php extretion_get_room_gallery( $post->ID ); ?>

					<div id="detail-content-sticky-nav-02" class="pt-30">
					
						<div class="section-title-3 mb-40">
							<h3><?php esc_html_e( 'Room Info' , 'extretion' ); ?></h3>
						</div>
						
						<h5 class="font400 text-uppercase mb-15 font16">
							<?php esc_html_e( 'About This Room' , 'extretion' ); ?>
						</h5>
						
						<?php the_content(); ?>
						
						<div class="mb-30"></div>
								
						<h5 class="font400 text-uppercase mb-15 font16"><?php esc_html_e( 'Room key facts' , 'extretion' ); ?></h5>
						
						<ul class="hotel-featured-list">

							<?php 
							foreach( extretion_room_key_facts( $post->ID ) as $value ){ 
								
								$array_keys = array_keys( $value['fields'] );

								if( !empty( $value['fields'][$array_keys[0]] ) ){  ?>

									<li>

										<span class="absolute"><?php echo sanitize_text_field( $value['title'] ); ?></span>

										<?php
										echo ( !empty( $value['outer_wrapper_start'] ) ? $value['outer_wrapper_start'] : '' ); 

										foreach( $value['fields'] as $fields ){

											echo ( !empty( $value['inner_wrapper_start'] ) ? $value['inner_wrapper_start'] : '' );

											echo wp_kses( 
												$fields,
												array(
													'strong' => array(),
													'br' => array(),
													'a' => array(
														'href' => array(),
														'class' => array()
													),
													'span' => array(
														'class' => array()
													)
												) 
											);

											echo ( !empty( $value['inner_wrapper_end'] ) ? $value['inner_wrapper_end'] : '' );

										}

										echo ( !empty( $value['outer_wrapper_end'] ) ? $value['outer_wrapper_end'] : '' ); ?>

									</li>

									<?php
								}

							} ?>
							
						</ul>
						
						<div class="mb-20"></div>

						<div class=" row gap-20 clearfix">

							<div class="col-xs-12 col-sm-12">
								<h5 class="font400 text-uppercase mb-15 font16">
									<?php esc_html_e( 'Main amenities' , 'extretion' ); ?>
								</h5>
								<ul class="list-col-3 list-with-icon">

									<?php 
									$facility = extretion_get_post_facilities( $post->ID );
									$getAllTermsArray = extretion_getAllTermsArray( 'facility' );

									if( !empty( $getAllTermsArray ) ){

										foreach( $getAllTermsArray as $term_id => $term_name ){

											if( in_array( $term_id , $facility ) ){
												echo '<li><i class="fa fa-check text-primary"></i>' . sanitize_text_field( $term_name ) . '</li>';
											} else {
												echo '<li class="amenities_not_available"><i class="fa fa-times text-danger"></i>' . sanitize_text_field( $term_name ) . '</li>';
											}

										}

									}
									?>
									
								</ul>
							</div>
							
						</div>

						<?php extretion_whats_around( $post ); ?>

						<div class="bb mt-10"></div>
						
					</div>

					<?php 
					comments_template( '/room-comments.php' );
					?>

					<div id="detail-content-sticky-nav-04" class="pt-30">
					
						<div class="section-title-3">
							<h3><?php esc_html_e( 'Map &amp; Neighbors' , 'extretion' ); ?></h3>
						</div>
						
						<div id="map-and-friends"></div>						
						
						<div class="clear"></div>
						
						<div class="bb mt-30"></div>
						
					</div>

					<?php 
					if( $count_listings > 0 ){ ?>
						<div id="detail-content-sticky-nav-05" class="pt-30">
							<div class="section-title-3">
								<h3><?php esc_html_e( 'Similar Listings' , 'extretion' ); ?></h3>
							</div>
							<?php extretion_get_similar_rooms( $post->ID , false , 3 ); ?>
						</div>
						<?php 
					} ?>

				</div>
			
				<div class="multiple-sticky hidden-sm hidden-xs">&#032;</div> <!-- is used to stop the above stick menu -->
								
			</div>
		
		</div>

	</div>

</div>