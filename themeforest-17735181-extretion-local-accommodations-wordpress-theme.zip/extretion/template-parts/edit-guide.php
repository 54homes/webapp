<div class="guide_page_wrapper mb-25 clearfix">
	
	<?php 
	if( !empty( $_GET['status'] ) && $_GET['status'] == 'updated' ){ ?>
		<div class="alert alert-success mb-25">
			<?php esc_html_e( 'Congratualtion!!! You have successfully edited your guide.', 'extretion' ); ?>
		</div>
		<?php 
	}

	if( !empty( $_GET['status'] ) && $_GET['status'] == 'added' ){ ?>
		<div class="alert alert-success mb-25">
			<?php esc_html_e( 'Congratualtion!!! You have successfully added your guide.', 'extretion' ); ?>
		</div>
		<?php 
	} ?>

	<div class="guide_title_wrap">
		<h4><?php esc_html_e( 'Guide Your Guest!' , 'extretion' ); ?></h4>
		<p><?php esc_html_e( 'Your recommendations will appear on the map on your public listing page.' , 'extretion' ); ?></p>
	</div>

	<div id="guide_google_map"></div>

	<div class="guide_form_wrapper col-sm-7 col-md-7 col-xs-12">

		<div class="heading_style_1">

			<h4><?php esc_html_e( 'Add Location' , 'extretion' ); ?></h4>

			<div class="">
					
				<form id="guide_location_add" action="" method="post">
					
					<div class="form-horizontal">

						<div class="form-group row gap-15">
							<div class="col-sm-12 col-md-12">
								<div role="alert" class="alert alert-info mb-10">
									<div class="icon">
										<i class="fa fa-lightbulb-o font12"></i>
									</div>
									<div class="content">
										<h4 class="text-primary2"><?php esc_html_e( 'Guiding tips' , 'extretion' ); ?></h4>
										<ul>
											<li>
											<?php esc_html_e( 'Move the marker to the place you would like to add or enter the place name below.' , 'extretion' ); ?></li>
											<li><?php esc_html_e( 'After that fill all the informations below.' , 'extretion' ); ?></li>			
										</ul>
									</div>
								</div>
							</div>
						</div>

						<ul class="alert alert-danger mb-25 guide_error_msg" style="display:none">
						</ul>

						<div class="guide_lat_lng">

							<?php 
							$post_id = !empty( $_GET['id'] ) ? sanitize_text_field( $_GET['id'] ) : ''; ?>

							<input type="hidden" value="<?php echo esc_html( get_post_meta( $post_id, 'form_place_located_lat' , true )); ?>" name="lat" class="form-control mb-0" autocomplete="off">

							<input type="hidden" value="<?php echo esc_html( get_post_meta( $post_id, 'form_place_located_lng' , true )); ?>" name="lng" class="form-control mb-0" id="lng" autocomplete="off">
						
						</div>

						<div class="form-group row gap-15">

							<div class="col-sm-12 col-md-12">
								<input type="text" placeholder="<?php esc_html_e( 'Enter the place name' , 'extretion' ); ?>" name="guide_place_name" class="form-control mb-0 guide_place_name" id="lng" autocomplete="off">
								<div class="error_label"></div>
							</div>

						</div>

						<div class="form-group row gap-15">

							<div class="col-sm-12 col-md-12">
								<select class="selectpicker form-control guide_cat" autocomplete="off">
									<?php extretion_get_guide_categories(); ?>
								</select>
								<div class="error_label"></div>
							</div>
							
						</div>

						<?php /* ?>
						<div class="form-group row gap-15">

							<div class="col-sm-12 col-md-12">
								<textarea cols="10" name="why_recommend" class="form-control" placeholder="<?php esc_html_e( 'Why do you recommend it ?' , 'extretion' ); ?>" autocomplete="off"></textarea>
								<div class="error_label"></div>
							</div>
							
						</div>
						<?php */ ?>

						<div class="form-group row gap-15">

							<div class="col-sm-12 col-md-12">
								<input type="file" name="guide_image" class="guide_input" autocomplete="off" id="guide_image">
								<div class="error_label"></div>
							</div>
							
						</div>

						<div class="form-group row gap-15">

							<div class="col-sm-12 col-md-12">
								<input type="button" value="<?php esc_html_e( 'Save' , 'extretion' ); ?>" class="btn btn-primary save_guide">
							</div>
							
						</div>

					</div>

				</form>

			</div>

		</div>

	</div>

	<div class="guide_form_wrapper col-sm-5 col-md-5 col-xs-12">
		<div class="heading_style_1">

			<h4><?php esc_html_e( 'Create a guide for your guest' , 'extretion' ); ?></h4>

			<div class="">
					
				<div class="guide-info">

                	<p><?php esc_html_e( 'The guide is a collection of recommended places and services near your rental destination.' , 'extretion' ); ?></p>

                    <p><?php esc_html_e( 'Tell them where to buy groceries, eat some food even park their car safely during their stay.' , 'extretion' ); ?></p>

                    <p><?php esc_html_e( 'Why not share your favourite activites, what does your neighborhood offer your guests?' , 'extretion' ); ?></p>

                    <p><?php esc_html_e( 'Enter the name or address of places nearby, then add category and write a short recommendation.' , 'extretion' ); ?></p>

                    <p><?php esc_html_e( 'Your recommendaed places will appear on the map on your public listing page.' , 'extretion' ); ?></p>

	            </div>

			</div>

		</div>
	</div>

	<?php 
	$args = array(
		'post_type' => 'guide',
		'post_status' => 'publish',
		'posts_per_page' => -1,
		'author' => get_current_user_id(),
		'meta_query' => array(
			array(
				'key'     => 'parent_post',
				'value'   => !empty( $_GET['id'] ) ? sanitize_text_field( $_GET['id'] ) : '',
				'compare' => '=',
			),
		),
	);

	$guide_query = new WP_Query( $args );

	if( $guide_query->have_posts() ): ?>

		<div class="col-sm-12 col-md-12 col-xs-12">

			<div class="heading_style_1">
			
				<h4><?php esc_html_e( 'Edit Location' , 'extretion' ); ?></h4>

				<div class="row guide_delete_info" style="display:none">
					<div class="col-sm-12 col-md-12">
						<div class="alert alert-info mb-10" role="alert">
							<div class="content">
								<ul>			
								</ul>
							</div>
						</div>
					</div>
				</div>

				<ul class="edit_guide_wrapper">

					<?php
					$i = 0;
					while( $guide_query->have_posts() ): $guide_query->the_post(); ?>

						<li>

							<div class="guide_img">
								<?php 
								if( has_post_thumbnail() ){
									the_post_thumbnail( 'thumbnail' );
								} else {
									echo '<img src="' . get_template_directory_uri() . '/images/no-image-square.jpg' . '">';
								} ?>
							</div>

							<div class="guide_content">
								
								<h3><?php 
								$title = explode( ',' , get_the_title() );

								echo esc_html( $title[0] );

								if( count( $title ) > 1 ){
									echo ' , ' . $title[1];
								}

								?></h3>
								<div class="guide_category">
									<?php 

									$term = wp_get_post_terms( $post->ID, 'guide_cat' );
									printf( 
										esc_html__( 'Category : %s', 'extretion' ),
										$term ? $term[0]->name : esc_html__( 'none', 'extretion' )
									); ?>
								</div>
								<div class="guide_far_away">
									<?php 

									$parent_post_id = get_post_meta( $post->ID , 'parent_post' , true );
									$hotel_lat = get_post_meta( $parent_post_id , 'form_place_located_lat' , true );
									$hotel_lng = get_post_meta( $parent_post_id , 'form_place_located_lng' , true );
									$guide_lat = get_post_meta( $post->ID , 'latitude' , true );
									$guide_lng = get_post_meta( $post->ID , 'longitude' , true );

									$distance = extretion_distanceCalculator( $guide_lat , $guide_lng , $hotel_lat , $hotel_lng ,"M" ); 

									printf( esc_html__( ' %d metres far away from your location', 'extretion' ) , $distance );  ?>
								</div>
								
								<div class="edit_guide_btn_wrapper">
									
									<a class="label label-info edit_guide" edit_id="<?php echo (int) $post->ID; ?>"><?php esc_html_e( 'Edit', 'extretion' ); ?></a>

									<a 
									class="label label-danger2 delete_guide" 
									delete_id="<?php echo (int) $post->ID; ?>"><?php esc_html_e( 'Delete', 'extretion' ); ?></a>

									<a 
									class="label label-success show_on_map" 
									lat="<?php echo sanitize_text_field( $guide_lat ); ?>" 
									lng="<?php echo sanitize_text_field( $guide_lng ); ?>">
										<?php esc_html_e( 'Show on Map', 'extretion' ); ?>
											
									</a>

								</div>
								

							</div>
							<!-- <div class="break_line"></div> -->

						</li>

						<?php

					endwhile; ?>

				</ul>

			</div>

		</div>

		<?php

	endif;
	?>

</div>