<?php if( !is_user_logged_in() ): ?>
<div class="modal fade modal-login modal-border-transparent" id="loginModal" tabindex="-1" role="dialog" aria-hidden="true" >
	<div class="modal-dialog">
		<div class="modal-content">
			
			<button type="button" class="btn btn-close close" data-dismiss="modal" aria-label="Close">
				<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
			</button>
			
			<div class="clear"></div>
			
			<!-- Begin # DIV Form -->
			<div id="modal-login-form-wrapper">
				
				<!-- Begin # Login Form -->
				<form id="login-form" action="#" method="POST">
				
					<div class="modal-body pb-10">
				
						<h4 class="text-center mb-15"><?php esc_html_e( 'Sign In' , 'extretion' ); ?></h4>

						<!-- Error Message Display -->
						<ul class="login_modal_error"></ul>

						<div class="form-group mb-0"> 
							<input id="login_username" class="form-control mb-5" placeholder="<?php esc_html_e( 'Username / Email Address' , 'extretion' ); ?>" type="text" name="login_username"> 
						</div>
						<div class="form-group mb-0"> 
							<input id="login_password" class="form-control mb-5" placeholder="<?php esc_html_e( 'Password' , 'extretion' ); ?>" type="password" name="login_password"> 
						</div>
						<div class="form-group mb-0"> 
							<input class="form-control mb-5" type="hidden" name="login_user_lmh" value="1"> 
							<input type="hidden" value="<?php echo wp_create_nonce( 'login_user_nonce' ); ?>" name="login_nonce">
						</div>
		
						<div class="form-group mb-0 mt-10">
							<div class="row gap-5">
								<div class="col-xs-6 col-sm-6 col-md-6">
									<div class="checkbox-block font-icon-checkbox"> 
										<input id="remember_me_checkbox" name="remember_me_checkbox" class="checkbox" value="1" type="checkbox"> 
										<label class="" for="remember_me_checkbox">
											<?php esc_html_e( 'Remember Me' , 'extretion' ); ?>
										</label>
									</div>
								</div>
								<div class="col-xs-6 col-sm-6 col-md-6 text-right"> 
									<button id="login_lost_btn" type="button" class="btn btn-link"><?php esc_html_e( 'Forgot Pass?' , 'extretion' ); ?></button>
								</div>
							</div>
						</div>
					
					</div>
					
					<div class="modal-footer pt-25 pb-5">
					
						<div class="row gap-10">
							<div class="col-xs-6 col-sm-6 mb-10">
								<button type="submit" class="btn btn-primary btn-block modal_login_in"><?php esc_html_e( 'Sign-in' , 'extretion' ); ?></button>
							</div>
							<div class="col-xs-6 col-sm-6 mb-10">
								<button type="submit" class="btn btn-danger btn-block" data-dismiss="modal" aria-label="Close"><?php esc_html_e( 'Cancel' , 'extretion' ); ?></button>
							</div>
						</div>
						<div class="text-left">
							<?php esc_html_e( 'No account?' , 'extretion' ); ?> 
							<button id="login_register_btn" type="button" class="btn btn-link"><?php esc_html_e( 'Register' , 'extretion' ); ?></button>
						</div>
						
					</div>
				</form>
				<!-- End # Login Form -->
							
				<!-- Begin | Lost Password Form -->
				<form id="lost-form" style="display:none;">
					<div class="modal-body pb-0">
						
						<h4 class="text-center mb-15">
							<?php esc_html_e( 'Forgot password' , 'extretion' ); ?>					
						</h4>

						<!-- Error Message Display -->
						<ul class="login_modal_error forgot_modal_error"></ul>
						
						<div class="form-group mb-0"> 
							<input name="lost_email" id="lost_email" class="form-control mb-5" type="text" placeholder="<?php esc_html_e( 'Enter Your Email' , 'extretion' ); ?>" autocomplete="off">
						</div>
						
						<div class="text-center">
							<button id="lost_login_btn" type="button" class="btn btn-link"><?php esc_html_e( 'Sign-in' , 'extretion' ); ?></button> or 
							<button id="lost_register_btn" type="button" class="btn btn-link"><?php esc_html_e( 'Register' , 'extretion' ); ?></button>
						</div>
						
					</div>
					
					<div class="modal-footer pt-25 pb-5">
						
						<div class="row gap-10">
							<div class="col-xs-6 col-sm-6 mb-10">
								<button type="submit" class="btn btn-primary btn-block lmh_forgot_pass"><?php esc_html_e( 'Submit' , 'extretion' ); ?></button>
							</div>
							<div class="col-xs-6 col-sm-6 mb-10">
								<button type="submit" class="btn btn-danger btn-block" data-dismiss="modal" aria-label="Close"><?php esc_html_e( 'Cancel' , 'extretion' ); ?></button>
							</div>
						</div>
						
					</div>
					
				</form>
				<!-- End | Lost Password Form -->
							
				<!-- Begin | Register Form -->
				<form id="register-form" style="display:none;" class="register_form_modal" method="POST">
				
					<div class="modal-body pb-20">

						<h4 class="text-center mb-15">
							<?php esc_html_e( 'Register' , 'extretion' ); ?>	
						</h4>

						<!-- Error Message Display -->
						<ul class="registration_modal_error"></ul>
						
						<?php 
						
						extretion_getRegisterModalFields(); ?>

					</div>
						
					<div class="modal-footer pt-25 pb-5">
					
						<div class="row gap-10">
							<div class="col-xs-6 col-sm-6 mb-10">
								<button type="submit" class="btn btn-primary btn-block register_modal">
									<?php esc_html_e( 'Register' , 'extretion' ); ?>
								</button>
							</div>
							<div class="col-xs-6 col-sm-6 mb-10">
								<button type="submit" class="btn btn-danger btn-block" data-dismiss="modal" aria-label="Close"><?php esc_html_e( 'Cancel' , 'extretion' ); ?></button>
							</div>
						</div>
						
						<div class="text-left">
								<?php esc_html_e( 'Already have account?' , 'extretion' ); ?> <button id="register_login_btn" type="button" class="btn btn-link"><?php esc_html_e( 'Sign In' , 'extretion' ); ?></button>
						</div>
						
					</div>
						
				</form>
				<!-- End | Register Form -->
							
			</div>
			<!-- End # DIV Form -->
							
		</div>
	</div>
</div>

<?php endif; ?>

<!-- 
	Start Successfully verified message 
-->

<div class="modal fade modal-login modal-border-transparent" id="userVerifiedMsg" tabindex="-1" role="dialog" aria-hidden="true" >
	<div class="modal-dialog">
		<div class="modal-content">
			
			<button type="button" class="btn btn-close close" data-dismiss="modal" aria-label="Close">
				<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
			</button>
			
			<div class="clear"></div>
			
			<!-- Begin # DIV Form -->
			<div id="modal-user-verified-wrapper">

				<div class="modal-body pb-10">
				
					<div class="text-center mb-15">
						<h5><?php extretion_verificationMsg(); ?></h5>
					</div>
					
				</div>
				
				<div class="modal-footer pt-25 pb-5">
				
					<div class="row gap-10">

						<?php 
						if( !is_user_logged_in() ){ ?>
							<div class="col-xs-6 col-sm-6 mb-10">
								<button type="submit" class="btn btn-primary btn-block verification_sign_in"><?php esc_html_e('Sign-in' , 'extretion'); ?></button>
							</div>
							<?php 
							$cancel_class = 'col-xs-6 col-sm-6';
						} else {
							$cancel_class = 'col-xs-12 col-sm-12';
						}?>
						<div class="<?php echo esc_html( $cancel_class ); ?> mb-10">
							<button type="submit" class="btn btn-danger btn-block" data-dismiss="modal" aria-label="Close"><?php esc_html_e( 'Cancel' , 'extretion' ); ?></button>
						</div>
					</div>
					
				</div>

			</div>
		</div>
	</div>
</div>

<!-- 
	End Successfully verified message 
-->

<!-- 
	Start Reset Password Form 
-->

<?php if( !is_user_logged_in() ): ?>
<div class="modal fade modal-login modal-border-transparent" id="userResetForm" tabindex="-1" role="dialog" aria-hidden="true" >
	<div class="modal-dialog">
		<div class="modal-content">
			
			<button type="button" class="btn btn-close close" data-dismiss="modal" aria-label="Close">
				<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
			</button>
			
			<div class="clear"></div>
			
			<!-- Begin # DIV Form -->
			<div id="modal-user-reset-pass-wrapper">

				<!-- Begin # Login Form -->
				<form id="user-reset-pass">
				
					<div class="modal-body pb-10">
				
						<h4 class="text-center mb-15"><?php esc_html_e( 'Reset Password' , 'extretion' ); ?></h4>

						<!-- Error Message Display -->
						<ul class="login_modal_error reset_error_modal"></ul>

						<div class="form-group mb-0"> 
							<input id="reset_pass" class="form-control mb-5" placeholder="<?php esc_html_e( 'Password' , 'extretion' ); ?>" type="password" name="reset_pass" autocomplete="off"> 
						</div>

						<div class="form-group mb-0"> 
							<input id="confirm_reset_pass" class="form-control mb-5" placeholder="<?php esc_html_e( 'Confirm Password' , 'extretion' ); ?>" type="password" name="confirm_reset_pass" autocomplete="off"> 
						</div>

						<input id="browser_reset_pass" type="hidden" name="browser_reset_pass" value="<?php echo ( !empty( $_GET['reset_pass_key'] ) ? sanitize_text_field( $_GET['reset_pass_key'] ) : '' ); ?>">
						<input id="browser_reset_user_id" type="hidden" name="browser_reset_user_id" value="<?php echo ( !empty( $_GET['user_id'] ) ? sanitize_text_field( $_GET['user_id'] ) : '' ); ?>">
						<input id="reset_pass_nonce" type="hidden" name="reset_pass_nonce" value="<?php echo wp_create_nonce( 'reset_pass_nonce' ); ?>">

					</div>

					<div class="modal-footer pt-25 pb-5">
				
						<div class="row gap-10">

							<div class="col-xs-6 col-sm-6 mb-10">
								<button type="submit" class="btn btn-primary btn-block reset_password_btn"><?php esc_html_e( 'Reset' , 'extretion'); ?></button>
							</div>
								
							<div class="col-xs-6 col-sm-6 mb-10">
								<button type="submit" class="btn btn-danger btn-block" data-dismiss="modal" aria-label="Close"><?php esc_html_e( 'Cancel' , 'extretion' ); ?></button>
							</div>

						</div>
						
					</div>

				</form>				

			</div>
		</div>
	</div>
</div>
<?php endif; ?>

<!-- 
	End Start Reset Password Form 
-->

<!-- 
	Start Successfully Registration message 
-->

<?php if( !is_user_logged_in() ): ?>
<div class="modal fade modal-login modal-border-transparent" id="userRegistrationMsg" tabindex="-1" role="dialog" aria-hidden="true" >
	<div class="modal-dialog">
		<div class="modal-content">
			
			<button type="button" class="btn btn-close close" data-dismiss="modal" aria-label="Close">
				<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
			</button>
			
			<div class="clear"></div>
			
			<!-- Begin # DIV Form -->
			<div id="modal-registration-verified-wrapper">

				<div class="modal-body pb-10">
				
					<div class="text-center mb-15">
						<h5><?php extretion_successRegistrationMsg(); ?></h5>
					</div>
					
				</div>
				
				<div class="modal-footer pt-25 pb-5">
				
					<div class="row gap-10">

						<div class="col-xs-6 col-sm-6 mb-10">
							<button type="submit" class="btn btn-primary btn-block verification_sign_in"><?php esc_html_e('Sign-in' , 'extretion'); ?></button>
						</div>
							
						<div class="col-xs-6 col-sm-6 mb-10">
							<button type="submit" class="btn btn-danger btn-block" data-dismiss="modal" aria-label="Close"><?php esc_html_e( 'Cancel' , 'extretion' ); ?></button>
						</div>
					</div>
					
				</div>

			</div>
		</div>
	</div>
</div>
<?php endif; ?>

<!-- End Successfully Registration message -->

<!-- Start Loader -->

<div class="modal fade modal-login" id="ballloader" tabindex="-1" role="dialog" aria-hidden="true" >
	<div class="modal-dialog">
		<div class="modal-content">	
			<div class="cssload-fond"><div class="cssload-container-general"><div class="cssload-internal"><div class="cssload-ballcolor cssload-ball_1"></div></div><div class="cssload-internal"><div class="cssload-ballcolor cssload-ball_2"></div></div><div class="cssload-internal"><div class="cssload-ballcolor cssload-ball_3"></div></div><div class="cssload-internal"><div class="cssload-ballcolor cssload-ball_4"></div></div></div></div>
		</div>
	</div>
</div>

<!-- End Loader -->

<?php if( is_user_logged_in() ): ?>

	<!-- 
		Start Room Calendar 
	-->

	<div class="modal fade modal-login modal-border-transparent" id="room_calendar_modal" tabindex="-1" role="dialog" aria-hidden="true" >
		<div class="modal-dialog">
			<div class="modal-content">
				
				<div class="clear"></div>
				
				<!-- Begin # DIV Form -->
				<div id="room_calendar_modal_wrapper">

					<!-- Begin # Login Form -->
					<form id="user_room_calendar_modal">
					
						<div class="modal-body pb-10">
					
							<h4 class="text-center mb-15"><?php esc_html_e( 'Room Availability' , 'extretion' ); ?></h4>

							<!-- Error Message Display -->
							<!-- <ul class="login_modal_error reset_error_modal"></ul> -->

							<div class="form-group mb-5"> 
								<strong><?php esc_html_e( 'Start Date :' , 'extretion' ); ?></strong>
								<span class="chosen_start_date"></span>
							</div>

							<div class="form-group mb-15"> 
								<strong><?php esc_html_e( 'End Date :' , 'extretion' ); ?></strong>
								<span class="chosen_end_date"></span>
							</div>

							<div class="form-group mb-5">
								
								<div class="another-toggle-content">

									<div class="another-toggle-inner">

										<div class="radio-block font-icon-radio">
											<input autocomplete="off" id="date-availability" name="room_dates_option" type="radio" class="radio" value="1" checked="checked" />
											<label class="" for="date-availability">
												<?php esc_html_e( 'Available' , 'extretion' ); ?>
											</label>
										</div>

										<div class="radio-block font-icon-radio">
											<input autocomplete="off" id="date-unavailability" name="room_dates_option" type="radio" class="radio" value="0"/>
											<label class="" for="date-unavailability">
												<?php esc_html_e( 'Not available' , 'extretion' ); ?>
											</label>
										</div>

									</div>
								</div>

							</div>

						</div>

						<div class="modal-footer pt-25 pb-5">
					
							<div class="row gap-10">

								<div class="col-xs-6 col-sm-6 mb-10">
									<input type="button" class="btn btn-primary btn-block save_calendar_btn" value="<?php esc_html_e( 'Save' , 'extretion'); ?>" autocomplete="off">
								</div>
									
								<div class="col-xs-6 col-sm-6 mb-10">
									<input type="submit" class="btn btn-danger btn-block save_calendar_btn_cancel" data-dismiss="modal" aria-label="Close" value="<?php esc_html_e( 'Cancel' , 'extretion' ); ?>"></button>
								</div>

							</div>
							
						</div>

					</form>				

				</div>
			</div>
		</div>
	</div>

	<!-- 
		Start reset pass modal 
	-->

	<div class="modal fade modal-login modal-border-transparent" id="success_changed_password" tabindex="-1" role="dialog" aria-hidden="true" >
		<div class="modal-dialog">
			<div class="modal-content">
				
				<!-- Begin # DIV Form -->
				<div id="modal_success_changed_password">

					<div class="modal-body pb-10">
					
						<div class="text-center mb-15">
							<h5><?php esc_html_e( 'Congratulation!!! You have successfully changed your password. Please sign-in again to continue.' , 'extretion' ); ?></h5>
						</div>
						
					</div>
					
					<div class="modal-footer pt-20 pb-5">
					
						<div class="row gap-10">
								
							<div class="col-xs-12 col-sm-12 mb-10">
								<a href="<?php echo site_url(); ?>" class="btn btn-danger btn-block"><?php esc_html_e( 'Go to Homepage' , 'extretion' ); ?></a>
							</div>
						</div>
						
					</div>

				</div>
			</div>
		</div>
	</div>

<?php endif; ?>

<?php 
if( is_page_template( 'page-templates/booking-approval.php' ) ): ?>
	

	<!-- 
		Start Cancel Booking Modal By Traveller
	-->

	<div class="modal fade modal-login modal-border-transparent" id="traveller_cancel_booking" tabindex="-1" role="dialog" aria-hidden="true" >
		<div class="modal-dialog">
			<div class="modal-content">
				
				<!-- Begin # DIV Form -->
				<div id="modal-registration-verified-wrapper">

					<div class="modal-body pb-10">
					
						<div class="text-center mb-15">
							<h5><?php esc_html_e( 'Are you sure you want to cancel this booking ? You cannot undo this later.' , 'extretion' ); ?></h5>
						</div>
						
					</div>
					
					<div class="modal-footer pt-25 pb-5">
					
						<div class="row gap-10">

							<div class="col-xs-6 col-sm-6 mb-10">
								<button type="submit" class="btn btn-primary btn-block confirm_cancel_booking_traveller"><?php esc_html_e('Yes' , 'extretion'); ?></button>
							</div>
								
							<div class="col-xs-6 col-sm-6 mb-10">
								<button type="submit" class="btn btn-danger btn-block" data-dismiss="modal" aria-label="Close"><?php esc_html_e( 'No' , 'extretion' ); ?></button>
							</div>
						</div>
						
					</div>

				</div>
			</div>
		</div>
	</div>

	<!-- 
		End Cancel Booking Modal By Traveller
	-->

	<!-- 
		Start Cancel Booking Modal By Hotel Owner
	-->

	<div class="modal fade modal-login modal-border-transparent" id="hotel_cancel_booking" tabindex="-1" role="dialog" aria-hidden="true" >
		<div class="modal-dialog">
			<div class="modal-content">
				
				<!-- Begin # DIV Form -->
				<div id="modal-registration-verified-wrapper">

					<div class="modal-body pb-10">
					
						<div class="text-center mb-15">
							<h5><?php esc_html_e( 'Are you sure you want to reject this booking ? You cannot undo this later.' , 'extretion' ); ?></h5>
						</div>
						
					</div>
					
					<div class="modal-footer pt-25 pb-5">
					
						<div class="row gap-10">

							<div class="col-xs-6 col-sm-6 mb-10">
								<button type="submit" class="btn btn-primary btn-block confirm_cancel_booking_hotel"><?php esc_html_e('Yes' , 'extretion'); ?></button>
							</div>
								
							<div class="col-xs-6 col-sm-6 mb-10">
								<button type="submit" class="btn btn-danger btn-block" data-dismiss="modal" aria-label="Close"><?php esc_html_e( 'No' , 'extretion' ); ?></button>
							</div>
						</div>
						
					</div>

				</div>
			</div>
		</div>
	</div>

	<!-- 
		End Cancel Booking Modal By Hotel Owner
	-->

	<?php 

endif; 

if( is_page_template( 'page-templates/booking-confirmation.php' ) ): ?>
	
	<!-- 
		Start Confirm Payment
	-->

	<div class="modal fade modal-login modal-border-transparent" id="confirm_payment_for_room" tabindex="-1" role="dialog" aria-hidden="true" >
		<div class="modal-dialog">
			<div class="modal-content">
				
				<!-- Begin # DIV Form -->
				<div id="modal-payment-complete-wrapper">

					<div class="modal-body pb-10">
					
						<div class="text-center mb-15">
							<h5><?php esc_html_e( 'Congratulation!!! You have successfully booked this room.' , 'extretion' ); ?></h5>
							<p><?php esc_html_e( "Below you can find the hotel owner's information. Please consult with the owner for more details on your stay." , 'extretion' ); ?></p>
						</div>
						
					</div>
					
					<div class="modal-footer pt-20 pb-5">
					
						<div class="row gap-10">
								
							<div class="col-xs-12 col-sm-12 mb-10">
								<button type="submit" class="btn btn-danger btn-block" data-dismiss="modal" aria-label="Close"><?php esc_html_e( 'Close' , 'extretion' ); ?></button>
							</div>
						</div>
						
					</div>

				</div>
			</div>
		</div>
	</div>

	<!-- 
		End Confirm Payment
	-->

	<?php
endif;

if( is_page_template( 'page-templates/room-edit.php' ) ): ?>
	
	<!-- 
		Delete Guide confirmation modal
	-->

	<div class="modal fade modal-login modal-border-transparent" id="deleteGuide" tabindex="-1" role="dialog" aria-hidden="true" >
		<div class="modal-dialog">
			<div class="modal-content">
				
				<button type="button" class="btn btn-close close" data-dismiss="modal" aria-label="Close">
					<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
				</button>
				
				<div class="clear"></div>
				
				<!-- Begin # DIV Form -->
				<div id="modal-delete-guide-wrapper">

					<div class="modal-body pb-10">
					
						<div class="text-center mb-15">
							<h5><?php esc_html_e( 'Are you sure you want to delete this guide ?', 'extretion' ); ?></h5>
						</div>
						
					</div>
					
					<div class="modal-footer pt-25 pb-5">
					
						<div class="row gap-10">

							<div class="col-xs-6 col-sm-6 mb-10">
								<button type="submit" class="btn btn-primary btn-block confirm_delete_guide" delete_id=""><?php esc_html_e('Yes' , 'extretion'); ?></button>
							</div>
								
							<div class="col-xs-6 col-sm-6 mb-10">
								<button type="submit" class="btn btn-danger btn-block" data-dismiss="modal" aria-label="Close"><?php esc_html_e( 'No' , 'extretion' ); ?></button>
							</div>
						</div>
						
					</div>

				</div>
			</div>
		</div>
	</div>

	<!-- 
		Edit Guide
	-->

	<div class="modal fade modal-login modal-border-transparent" id="editGuide" tabindex="-1" role="dialog" aria-hidden="true" >
		<div class="modal-dialog">
			<div class="modal-content">
				
				<button type="button" class="btn btn-close close" data-dismiss="modal" aria-label="Close">
					<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
				</button>
				
				<div class="clear"></div>
				
				<!-- Begin # DIV Form -->
				<div id="modal-edit-guide-wrapper">

					<div class="modal-body pb-10">
					
						<div class="text-center mb-15">
							<h5><?php esc_html_e( 'Edit Your Guide', 'extretion' ); ?></h5>
						</div>

						<ul class="guide_error_modal" style="display: block;"></ul>

						<div class="edit_content_wrapper">
							
							<div class="edit_guide_loader">
								<img class="img-responsive" src="<?php echo get_template_directory_uri() . '/images/loader.gif' ; ?>">
							</div>

							<div class="edit_guide_form">
								
							</div>

						</div>
						
					</div>
					
					<div class="modal-footer pt-25 pb-5">
					
						<div class="row gap-10">

							<div class="col-xs-6 col-sm-6 mb-10">
								<button type="submit" class="btn btn-primary btn-block confirm_edit_guide" edit_id=""><?php esc_html_e( 'Update' , 'extretion'); ?></button>
							</div>
								
							<div class="col-xs-6 col-sm-6 mb-10">
								<button type="submit" class="btn btn-danger btn-block" data-dismiss="modal" aria-label="Close"><?php esc_html_e( 'Cancel' , 'extretion' ); ?></button>
							</div>
						</div>
						
					</div>

				</div>
			</div>
		</div>
	</div>

	<?php

endif;

if( is_page_template( 'page-templates/my-listings.php' ) ): ?>


	<!-- 
		Delete Guide confirmation modal
	-->

	<div class="modal fade modal-login modal-border-transparent" id="deleteRoom" tabindex="-1" role="dialog" aria-hidden="true" >
		<div class="modal-dialog">
			<div class="modal-content">
				
				<button type="button" class="btn btn-close close" data-dismiss="modal" aria-label="Close">
					<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
				</button>
				
				<div class="clear"></div>
				
				<!-- Begin # DIV Form -->
				<div id="modal-delete-room-wrapper">

					<div class="modal-body pb-10">
					
						<div class="text-center mb-15">
							<h5><?php esc_html_e( 'Are you sure you want to delete this room? You cannot undo this later.', 'extretion' ); ?></h5>
						</div>
						
					</div>
					
					<div class="modal-footer pt-25 pb-5">
					
						<div class="row gap-10">

							<div class="col-xs-6 col-sm-6 mb-10">
								<button type="submit" class="btn btn-primary btn-block confirm_delete_room" delete_id=""><?php esc_html_e('Yes' , 'extretion'); ?></button>
							</div>
								
							<div class="col-xs-6 col-sm-6 mb-10">
								<button type="submit" class="btn btn-danger btn-block" data-dismiss="modal" aria-label="Close"><?php esc_html_e( 'No' , 'extretion' ); ?></button>
							</div>
						</div>
						
					</div>

				</div>
			</div>
		</div>
	</div>

	<?php

endif; 

extretion_price_breakdown_pop_up();

/**
* Report listing modal
*/ 
?>

<div class="modal fade modal-login modal-border-transparent" id="report_listing_modal" tabindex="-1" role="dialog" aria-hidden="true" >
	<div class="modal-dialog">
		<div class="modal-content">
			
			<button type="button" class="btn btn-close close" data-dismiss="modal" aria-label="Close">
				<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
			</button>
			
			<div class="clear"></div>
			
			<!-- Begin # DIV Form -->
			<form id="modal-report-listing-wrapper">

				<div class="modal-header">
			        <div class="text-center">
						<h5 class="mt-0 mb-0"><?php esc_html_e( 'Report Listing Anonymously', 'extretion' ); ?></h5>
					</div>
			    </div>

				<div class="modal-body pb-10 pt-10">

					<div class="alert alert-success report_listing_success_message" style="display: none;">
						
						<?php 
						esc_html_e( 'Thanks for taking the time to report this listing. We will check and take necessary steps.' , 'extretion' );
						?>

					</div>
					
					<div class="report_btn_wrapper">

						<?php 
						$report_msg = get_option( 'options_report_listings_messages' , "This listing should't be on this site\nThis is not an accomodation\nInappropriate content or spam\nInappropriate or deceptive photo" ); 
						$report_messages = preg_split('/[\r\n]+/', $report_msg, -1, PREG_SPLIT_NO_EMPTY);

						foreach( $report_messages as $value ){

							echo '<a data-value="' . $value . '" href="javascript:void(0)" class="btn btn-default report_message">' . $value . '</a>';

						}

						echo '<a data-value="' . esc_html__( 'Other' , 'extretion' )  . '" href="javascript:void(0)" class="btn btn-default report_message report_message_other">' . esc_html__( 'Other' , 'extretion' ) . '</a>';

						//echo '<pre>'; print_r($report_messages); echo '</pre>'; ?>

					</div>

					<div class="other_reason_wrapper" style="display: none;">
						<textarea autocomplete="off" name="other_reason" class="form-control" placeholder="<?php esc_html_e( 'Please describe a reason' , 'extretion' ); ?>"></textarea>
					</div>
					
				</div>
				
				<div class="modal-footer pt-25 pb-5 report_btn_footer" style="display: none;">
				
					<div class="row gap-10">

						<div class="col-xs-12 col-sm-12 mb-10">
							<input type="submit" class="btn btn-primary btn-block confirm_other_reason" value="<?php esc_html_e( 'Submit' , 'extretion'); ?>">
						</div>
							
					</div>
					
				</div>

			</form>

		</div>
	</div>
</div>

