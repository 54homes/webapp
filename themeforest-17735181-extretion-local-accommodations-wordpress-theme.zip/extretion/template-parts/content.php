<div class="blog-wrapper blog-single">

	<article class="blog-item-full">

		<?php 
		if( has_post_thumbnail() ){ ?>
			<div class="image">
				<?php the_post_thumbnail( 'extretion_blog-page' ); ?>
			</div>
			<?php 
		} ?>

		<div class="content">
		
			<div class="meta">
				
				<i class="fa fa-calendar"></i> 
				<a href="<?php echo site_url(); ?>/<?php echo date( 'Y/m' , strtotime( get_the_date() ) ); ?>"><?php echo get_the_date(); ?></a>

				<span class="mh-5">|</span> 
				<i class="fa fa-user"></i> 
				<a href="<?php echo get_author_posts_url( $post->post_author ); ?>"><?php echo get_the_author_meta( 'user_login' , $post->post_author ); ?></a>

				<?php 
				echo '<span class="mh-5"> | </span>';
				extretion_getCategories( $post->ID , 'category' );
				?>

			</div>
			
			<h3 class="blog-title">
				<?php the_title(); ?> 
			</h3>
		
			<div class="blog-entry">
	
				<?php 
				the_content(); 
				?>
				
			</div>

			<div class="paginate_links_post">
				<?php 
				wp_link_pages(
					array(
						'before'           => '<span>' . esc_html__( 'Pages:' , 'extretion' ),
						'after'            => '</span>',
						'link_before'      => '<span class="paginate_links_anchor">',
						'link_after'       => '</span>',
					)
				); ?>
			</div>
			
			<div class="clear mb-40"></div>
		
			<?php extretion_get_the_tags(); 

			if ( comments_open() || get_comments_number() ) :
				comments_template( '/comments.php', true );
			endif; ?>
			
		</div>
		
	</article>

</div>