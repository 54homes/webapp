<div id="post-<?php the_ID(); ?>" <?php post_class("two-tone-layout"); ?>>
			
	<div class="equal-content-sidebar">
	
		<div class="container">
		
			<?php 
			get_template_part( 'template-parts/single-layout' , 'booking-form' );
			?>
			
			<div class="content-wrapper">
				
				<div class="mb-10"></div>
				
				<div class="detail-header">

					<div class="row gap-5">
						<div class="col-xs-12 col-sm-8 col-md-9">
							<h2>
								<?php 
								the_title(); 
								$get_all_avg_rating = extretion_get_all_avg_rating( $post->ID );?>
								
								<?php extretion_title_star_width( $get_all_avg_rating ); ?>
							</h2>
							<p class="mb-0">
								<?php echo sanitize_text_field( get_post_meta( $post->ID, 'form_place_located_formatted_address', true ) ); ?>
							</p>
						</div>
						<div class="col-xs-12 col-sm-4 col-md-3">

							<?php 
							if( $get_all_avg_rating > 0 ){ ?>
								<a href="#detail-content-sticky-nav-03" class="tripadvisor-module text-right anchor">
									<div class="raty-wrapper">
										<div class="texting text-uppercase">
											<?php 
												echo number_format( $get_all_avg_rating , 1 ); 
												echo ' ' . extretion_get_individual_rating_words( number_format( $get_all_avg_rating ) );
											?>
											
										</div>
									</div>
									<div class="hover-underline text-muted">
										<?php printf( esc_html__( '%d reviews'  , 'extretion' ) , extretion_count_published_comments( $post->ID ) ) ?>
									</div>
								</a>
								<?php 
							} ?>
							
						</div>
					</div>
				
				</div>
				
				<div class="tab-style-01-wrapper mb-40">
						
					<ul id="detailTab" class="tab-nav clearfix">
						<li class="active"><a href="#detailTab1" data-toggle="tab"><?php esc_html_e( 'Gallery' , 'extretion' ); ?></a></li>
						<li><a href="#detailTab2" data-toggle="tab"><?php esc_html_e( 'Room Info' , 'extretion' ); ?></a></li>
						<li><a href="#detailTab3" data-toggle="tab"><?php esc_html_e( 'Reviews' , 'extretion' ); ?></a></li>
						<li><a class="tab_maps_neighbour" href="#detailTab4" data-toggle="tab"><?php esc_html_e( 'Map &amp; Neighbors' , 'extretion' ); ?></a></li>
						
						<?php
						if( extretion_get_similar_rooms( $post->ID , $count = true ) > 0 ) { ?>
							<li><a  class="tab_similar_listings" href="#detailTab5" data-toggle="tab">	<?php esc_html_e( 'Similar Listings' , 'extretion' ); ?></a></li>
							<?php
						}?>

					</ul>
					
					<div id="myTabContent" class="tab-content" >
						
						<div class="tab-pane fade in active" id="detailTab1">
						
							<div class="tab-content-inner">
								
								<?php extretion_get_room_gallery( $post->ID , true ); ?>

							</div>
							
						</div>
						
						<div class="tab-pane fade" id="detailTab2">
						
							<div class="tab-content-inner">
							
								<h5 class="font400 text-uppercase mb-15 font15"><?php esc_html_e( 'About This Room' , 'extretion' ); ?></h5>
							
								<?php the_content(); ?>

								<div class="mb-30"></div>
								
								<h5 class="font400 text-uppercase mb-15 font15"><?php esc_html_e( 'Room key facts' , 'extretion' ); ?></h5>
						
								<ul class="hotel-featured-list">
									
									<?php 
									foreach( extretion_room_key_facts( $post->ID ) as $value ){ 
										
										$array_keys = array_keys( $value['fields'] );

										if( !empty( $value['fields'][$array_keys[0]] ) ){  ?>

											<li>

												<span class="absolute"><?php echo sanitize_text_field( $value['title'] ); ?></span>

												<?php
												echo ( !empty( $value['outer_wrapper_start'] ) ? $value['outer_wrapper_start'] : '' ); 

												foreach( $value['fields'] as $fields ){

													echo ( !empty( $value['inner_wrapper_start'] ) ? $value['inner_wrapper_start'] : '' );

													echo wp_kses( 
														$fields, 
														array(
															'strong' => array(),
															'br' => array(),
															'a' => array(
																'href' => array(),
																'class' => array()
															),
															'span' => array(
																'class' => array()
															)
														) 
													);

													echo ( !empty( $value['inner_wrapper_end'] ) ? $value['inner_wrapper_end'] : '' );

												}

												echo ( !empty( $value['outer_wrapper_end'] ) ? $value['outer_wrapper_end'] : '' ); ?>

											</li>

											<?php
										}

									} ?>

								</ul>
								
								<div class="mb-20"></div>
								
								<div class="gap-20 clearfix row">
									<div class="col-xs-12 col-sm-12">
										<h5 class="font400 text-uppercase mb-15 font15"><?php esc_html_e( 'Main amenities' , 'extretion' ); ?></h5>
										<ul class="list-col-3 list-with-icon">
											
											<?php 
											$facility = extretion_get_post_facilities( $post->ID );
											$getAllTermsArray = extretion_getAllTermsArray( 'facility' );

											if( !empty( $getAllTermsArray ) ){

												foreach( $getAllTermsArray as $term_id => $term_name ){

													if( in_array( $term_id , $facility ) ){
														echo '<li><i class="fa fa-check text-primary"></i>' . sanitize_text_field( $term_name ) . '</li>';
													} else {
														echo '<li class="amenities_not_available"><i class="fa fa-times text-danger"></i>' . sanitize_text_field( $term_name ) . '</li>';
													}

												}

											}
											?>

										</ul>
									</div>
									
								</div>
									
							</div>
							
						</div>

						<div class="tab-pane fade" id="detailTab3">
						
							<div class="tab-content-inner">
							
								<div class="detail-review-wrapper">
									
									<?php 
									comments_template( '/room-comments.php' );
									?>
									
								</div>

							</div>
							
						</div>
						
						<div class="tab-pane fade" id="detailTab4">
						
							<div class="tab-content-inner">
							
								<div id="map-and-friends"></div>

								<div class="clear"></div>
								
							</div>
							
						</div>

						<div class="tab-pane fade" id="detailTab5">
							<div class="tab-content-inner">

								<?php extretion_get_similar_rooms( $post->ID ); ?>

							</div>
						</div>
						
					</div>
					
				</div>
								
			</div>
		
		</div>

	</div>

</div>