<div class="edit_room_photos">
	
	<div class="alert alert-info drag_photos_message">
		<?php esc_html_e( 'Drag the photos around to reorder them. The first photo appears in the search results.' , 'extretion' ); ?>
	</div>

	<div class="image_upload_wrapper">
		
		<input type="file" class="add_more_room_photos" name="tmp_name[]" multiple="multiple">

	</div>

	<div class="confirm_sort" style="display:none">
		<button class="btn btn-primary confirm_sort_btn">
			<?php esc_html_e( 'Confirm Sort' , 'extretion' ); ?>
		</button>
	</div>

</div>