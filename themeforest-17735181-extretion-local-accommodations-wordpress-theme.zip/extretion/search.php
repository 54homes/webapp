<?php
get_header(); 
$defaults = extretion_default_labels(); 
$search_filters = get_option( 'options_search_filters' ); 
$search_filters = empty( $search_filters ) ? array() : $search_filters;
$all_rooms_count = extretion_count_total_rooms_search(); ?>
	
<div <?php post_class("two-tone-layout left-sidebar"); ?>>
		
	<div class="equal-content-sidebar">
	
		<div class="container">
		
			<div class="sidebar-wrapper ">
				<aside>
					
					<div class="mb-10"></div>
					
					<div class="result-search-form-wrapper clearfix">
					
						<h3><?php echo esc_html( $defaults['search_page']['search_again'] ); ?></h3>

						<div class="inner">
							<form class="gap-10 search_page_form" method="get">
								<div class="col-xs-12 col-sm-12">
									<div class="form-group form-icon-right mb-10">

										<label>
											<?php echo esc_html( $defaults['search_page']['where_to_go'] ); ?>
											
										</label>

										<input 
										name="s" 
										id="search_page_type_place" 
										type="text" 
										class="form-control mb-0" 
										placeholder="<?php echo esc_html( $defaults['search_page']['type_a_place'] ); ?>" 
										autocomplete="off" 
										value="<?php echo ( !empty( $_GET['s'] ) ? sanitize_text_field( $_GET['s'] ) : '' ); ?>">

										<i class="fa fa-map-marker"></i>

										<div class="search_place_attr" style="display:none">

											<?php 
											$lat = ( !empty( $_GET['lat'] ) ? sanitize_text_field( $_GET['lat'] ) : '' );
											$lng = ( !empty( $_GET['lng'] ) ? sanitize_text_field( $_GET['lng'] ) : '' );
											$formatted_address = ( !empty( $_GET['formatted_address'] ) ? sanitize_text_field( $_GET['formatted_address'] ) : '' );
											$place = ( !empty( $_GET['place'] ) ? sanitize_text_field( $_GET['place'] ) : '' ); 
											$search_view = ( !empty( $_GET['view'] ) ? sanitize_text_field( $_GET['view'] ) : 'grid' ); ?>

								        	<input data-geo="lat" name="lat" value="<?php echo esc_html( $lat ); ?>" type="hidden" >
									        <input data-geo="lng" name="lng" value="<?php echo esc_html( $lng ); ?>" type="hidden">
									        <input data-geo="formatted_address" name="formatted_address" value="<?php echo esc_html( $formatted_address ); ?>" type="hidden">
									        <input data-geo="name" name="place" value="<?php echo esc_html( $place ); ?>" type="hidden">
								
									    </div>
									</div>
									<div class="error_label"></div>
								</div>

								<?php
								if( empty( $_GET['arrival_date'] ) || empty( $_GET['departure_date'] ) ){

									$arrival_date = date( 'd-m-Y' );
									$departure_date = date('d-m-Y',strtotime( $arrival_date . "+1 days") );

								} else {
									$arrival_date = sanitize_text_field( $_GET['arrival_date'] );
									$departure_date = sanitize_text_field( $_GET['departure_date'] );
								}
								?>

								<div class="col-xs-6 col-sm-6">
									<div class="form-group form-icon-right mb-10"> 
										<label>
											<?php echo esc_html( $defaults['search_page']['check_in'] ); ?>
											
										</label>
										<input 
										name="arrival_date" 
										class="form-control mb-0" 
										id="arrival_date" 
										placeholder="<?php echo esc_html( $defaults['search_page']['check_in'] ); ?>" type="text" 
										autocomplete="off" 
										value="<?php echo esc_html( $arrival_date ); ?>">
									</div>
								</div>
								<div class="col-xs-6 col-sm-6">
									<div class="form-group form-icon-right mb-10"> 
										<label><?php echo esc_html( $defaults['search_page']['check_out'] ); ?></label>
										<input 
										name="departure_date" 
										class="form-control mb-0" 
										id="departure_date" 
										placeholder="<?php echo esc_html( $defaults['search_page']['check_out'] ); ?>" 
										type="text" 
										autocomplete="off" 
										value="<?php echo esc_html( $departure_date ); ?>">
									</div>
								</div>
								<div class="col-xs-12 col-sm-12">
									<div class="form-group">
										<label><?php echo esc_html( $defaults['search_page']['rooms'] ); ?></label>
										
										<select name="guests" class="custom-select" id="change-search-room">
											<?php 
											$guests = extretion_guestAccomodate();

											$selected_guests = !empty( $_GET['guests'] ) ? sanitize_text_field( $_GET['guests'] ) : '';

											foreach( $guests as $guest ){ ?>
												<option <?php selected( $selected_guests, $guest ); ?> value="<?php echo esc_html( $guest ); ?>"><?php echo esc_html( $guest ); ?></option>
												<?php
											} 
											?>
										</select>
									</div>
								</div>
								
								<div class="clear"></div>
								
								<div class="col-sm-12">
									 <input name="view" value="<?php echo esc_html( $search_view ); ?>" type="hidden">
									<button class="btn btn-block btn-primary btn-icon mt-5"><?php echo esc_html( $defaults['search_page']['search'] ); ?> <span class="icon"><i class="fa fa-search"></i></span></button>
								</div>
																	
								<div class="clear"></div>

							</form>
						</div>
					</div>
					
					<?php 
					if( $all_rooms_count > 0 ){ ?>

						<div class="result-filter-wrapper clearfix">
						
							<h3><span class="icon"><i class="fa fa-sliders"></i></span> <?php echo esc_html( $defaults['search_page']['filter'] ); ?></h3>
							
							<?php 

							/**
							* Get all "space_offered" taxonomy terms
							*/

							$room_type = extretion_getAllTermsArray('space_offered'); 

							if( in_array( 'room_type' , $search_filters ) && !empty( $room_type ) ){ ?>

								<div class="another-toggle filter-toggle">
									<h4 class="active"><?php echo esc_html( $defaults['search_page']['room_type'] ); ?></h4>
									<div class="another-toggle-content">
										<div class="another-toggle-inner">
											<div class="form-group mb-0">
												<select class="custom-select room_type" autocomplete="off">
													<option value="all" selected="selected">
														<?php 
														echo esc_html( $defaults['search_page']['show_all'] ); ?>
													</option>

													<?php
													foreach( $room_type as $key => $value ){
														echo '<option value="' . $key . '">' . $value . '</option>';
													} ?>

												</select>
											</div>
										</div>
									</div>
								</div>

								<?php 

							} ?>

							<div class="another-toggle filter-toggle">
								<h4 class="active">
									<?php echo esc_html( $defaults['search_page']['price'] ); ?>
										
								</h4>
								<div class="another-toggle-content">
									<div class="another-toggle-inner">
										<div class="range-slider-wrapper">
											<input id="price_range" />
										</div>
									</div>
								</div>
							</div>
						
							<?php

							if( in_array( 'bedrooms' , $search_filters ) || in_array( 'bathrooms' , $search_filters ) || in_array( 'beds' , $search_filters ) ){ ?>

								<div class="another-toggle filter-toggle">
									<h4 class="active"><?php echo esc_html( $defaults['search_page']['size'] ); ?></h4>
									<div class="another-toggle-content">
										<div class="another-toggle-inner">

											<?php 

											/**
											* If Bedrooms filter is selected
											*/

											if( in_array( 'bedrooms' , $search_filters ) ){ ?>

												<select class="custom-select bedroom_filter" autocomplete="off">
													<option value="all"><?php echo esc_html( $defaults['search_page']['bedrooms'] ); ?></option>
													<?php extretion_search_filter_no_of_bedrooms(); ?>
												</select>

												<?php 

											}

											/**
											* If Bathrooms filter is selected
											*/

											if( in_array( 'bathrooms' , $search_filters ) ){ ?>

												<div class="mb-15"></div>
												<select class="custom-select bathroom_filter" autocomplete="off">
													<option value="all"><?php echo esc_html( $defaults['search_page']['bathrooms'] ); ?></option>
													<?php extretion_search_filter_no_of_bathrooms(); ?>
												</select>

												<?php 

											}

											/**
											* If Beds filter is selected
											*/

											if( in_array( 'beds' , $search_filters ) ){ ?>

												<div class="mb-15"></div>
												<select class="custom-select beds_filter" autocomplete="off">
													<option value="all"><?php echo esc_html( $defaults['search_page']['beds'] ); ?></option>
													<?php extretion_search_filter_no_of_beds(); ?>
												</select>

												<?php 
											} ?>

										</div>
									</div>
								</div>

								<?php 

							}
							
							/**
							* Get all "facility" taxonomy terms
							*/

							$facility = extretion_getAllTermsArray('facility'); 

							if( in_array( 'facilities' , $search_filters ) && !empty( $facility ) ){ ?>

								<div class="another-toggle filter-toggle">
									<h4 class="active">
										<?php echo esc_html( $defaults['search_page']['facilities'] ); ?>
										
									</h4>
									<div class="another-toggle-content">
										<div class="another-toggle-inner facility_search">

											<?php
											$last_facility = count( $facility ) -1 ;
											$count_facilities = 0;

											foreach( $facility as $key => $value ){ 
												
												if(	$count_facilities == 5 ){
													echo '<div id="facilities-more-less" class="collapse"> 
													<div class="inner">';
												} ?>

												<div class="checkbox-block font-icon-checkbox">
													<input autocomplete="off" id="filter_amenities-<?php echo esc_html( $key ); ?>" name="filter_amenities" type="checkbox" class="checkbox" value="<?php echo esc_html( $key ); ?>"/>
													<label class="" for="filter_amenities-<?php echo esc_html( $key ); ?>">
														<?php echo esc_html( $value ); ?>
													</label>
												</div>

												<?php

												if( $last_facility == $count_facilities && $count_facilities >= 5 ){
													echo '</div></div>';
													echo '<button class="btn btn-more-less" data-toggle="collapse" data-target="#facilities-more-less">' . esc_html__( 'Show more', 'extretion' ) . '</button>';
												}

												$count_facilities++;

											} ?>

										</div>
									</div>
								</div>

								<?php
							} 

							/**
							* Get all "type_of_place" taxonomy terms
							*/

							$type_of_place = extretion_getAllTermsArray('type_of_place'); 

							if( in_array( 'type_of_place' , $search_filters ) && !empty( $type_of_place ) ){ ?>
									
								<div class="another-toggle filter-toggle">
									<h4 class="active"><?php echo esc_html( $defaults['search_page']['type_of_place'] ); ?></h4>
									<div class="another-toggle-content">

										<div class="another-toggle-inner type_of_place_filter">

											<?php

											$last_type_of_place = count( $type_of_place ) -1 ;
											$count_type_of_place = 0;

											foreach( $type_of_place as $key => $value ){ 

												if(	$count_type_of_place == 5 ){
													echo '<div id="type_of_place_more_less" class="collapse"> 
													<div class="inner">';
												} ?>

												<div class="radio-block font-icon-radio">
													<input autocomplete="off" id="filter_place-<?php echo esc_html( $key ); ?>" name="filter_place" type="radio" class="radio" value="<?php echo esc_html( $key ); ?>"/>
													<label class="" for="filter_place-<?php echo esc_html( $key ); ?>">
														<?php echo esc_html( $value ); ?>
													</label>
												</div>

												<?php

												if( $last_type_of_place == $count_type_of_place && $count_type_of_place >= 5 ){
													echo '</div></div>';
													echo '<button class="btn btn-more-less" data-toggle="collapse" data-target="#type_of_place_more_less">' . esc_html__( 'Show more', 'extretion' ) . '</button>';
												}
												
												$count_type_of_place++;
											} ?>
											
										</div>
									</div>
								</div>

								<?php 
							} ?>
							
						</div>

						<?php 

					} ?>

					<div class="mb-20"></div>
					
				</aside>
			</div>
			
			<div class="content-wrapper">
				
				<div class="mb-10"></div>
				
				<div class="result-status">

					<p>
						<?php 

						if( extretion_check_search_sort_view() == true ){

							$place_name = !empty( $_GET['place'] ) ? sanitize_text_field( $_GET['place'] ) : '';

							printf( esc_html__( 'We found %1$s hosts with availability in %2$s.', 'extretion' ),
    							'<span class="found_hotels text-primary font700">' . esc_html( $all_rooms_count ) . '</span>',
    							'<span class="text-primary font700">' . esc_html( $place_name ) . '</span>' );


						} else {
							esc_attr_e( 'Loading ... Please wait' , 'extretion' );
						} ?>
							
					</p>
					
					<?php 
					$search_val = !empty( $_GET['s'] ) ? sanitize_text_field( $_GET['s'] ) : '';
					$lat = !empty( $_GET['lat'] ) ? sanitize_text_field( $_GET['lat'] ) : '';
					$lng = !empty( $_GET['lng'] ) ? sanitize_text_field( $_GET['lng'] ) : '';
					$formatted_address = !empty( $_GET['formatted_address'] ) ? sanitize_text_field( $_GET['formatted_address'] ) : '';
					$place = !empty( $_GET['place'] ) ? sanitize_text_field( $_GET['place'] ) : '';
					$arrival_date = !empty( $_GET['arrival_date'] ) ? sanitize_text_field( $_GET['arrival_date'] ) : ''; 
					$departure_date = !empty( $_GET['departure_date'] ) ? sanitize_text_field( $_GET['departure_date'] ) : '';
					$guests = !empty( $_GET['guests'] ) ? sanitize_text_field( $_GET['guests'] ) : '';

					$search_list_link =  site_url() . '?s=' . urlencode( $search_val ) . '&lat=' . $lat . '&lng=' . $lng . '&formatted_address=' . urlencode( $formatted_address ) . '&place=' . $place . '&arrival_date=' . $arrival_date . '&departure_date=' . $departure_date . '&guests=' . $guests . '&view=list';

					$search_grid_link = site_url() . '?s=' . urlencode( $search_val ) . '&lat=' . $lat . '&lng=' . $lng . '&formatted_address=' . urlencode( $formatted_address ) . '&place=' . $place . '&arrival_date=' . $arrival_date . '&departure_date=' . $departure_date . '&guests=' . $guests . '&view=grid';

					if( empty( $_GET['view'] ) || $_GET['view'] == 'grid' ){
						$search_grid = 'search_view';
						$search_list = '';
					} else {
						$search_grid = '';
						$search_list = 'search_view';
					}

					/**
					* Show on Grid and List view
					*/

					if( empty( $_GET['view'] ) || $_GET['view'] == 'list' || $_GET['view'] == 'grid' ){ ?>

						<a href="<?php echo site_url() . '?s=' . urlencode($search_val) . '&lat=' . $lat . '&lng=' . $lng . '&formatted_address=' . urlencode($formatted_address) . '&place=' . $place . '&arrival_date=' . $arrival_date . '&departure_date=' . $departure_date . '&guests=' . $guests . '&view=map'; ?>" class="show-on-map" style="background-image:url('<?php echo get_template_directory_uri(); ?>/images/show-on-map.gif');">
							<span>
								<img src="<?php echo get_template_directory_uri(); ?>/images/show-map-marker.png" alt="images" class="block"/>
								<span class="bg-primary absolute"><?php echo esc_html( $defaults['search_page']['show_on_map'] ); ?></span>
							</span>
						</a>

						<?php

					} else { 

						/**
						* Show on Map view
						*/ 

						?>

						<div class="back-to-list">
							<span><?php esc_html_e( 'Back to' , 'extretion' ); ?></span>
							<a href="<?php echo esc_url( $search_list_link ); ?>">
								<i class="fa fa-align-justify"></i>
							</a>
							<a href="<?php echo esc_url( $search_grid_link ); ?>">
								<i class="fa fa-th-large"></i>
							</a>
						</div>

						<?php
					}
					?>

				</div>
				
				<?php 
				if( $all_rooms_count > 0 && extretion_check_search_sort_view() == true ){ ?>
					<div class="sort-wrapper">
				
						<ul class="clearfix">
						
							<li class="text"><?php echo esc_html( $defaults['search_page']['sort_by'] ); ?></li>
							
							<li class="active">
								<a href="javascript:void(0)" title="ASC" data-sort_by="distance" class="sort_by_distance">
									<?php echo esc_html( $defaults['search_page']['distance'] ); ?> <i class="fa fa-sort-amount-asc"></i>
								</a>
							</li>

							<li>
								<a href="javascript:void(0)" title="ASC" data-sort_by="price" class="sort_by_price"><?php echo esc_html( $defaults['search_page']['price'] ); ?> <i class="fa  fa-sort-numeric-asc "></i></a>
							</li>
							<li>
								<a href="javascript:void(0)" title="ASC" data-sort_by="name" class="sort_by_name"><?php echo esc_html( $defaults['search_page']['name'] ); ?> <i class="fa fa-sort-alpha-asc"></i></a>
							</li>

							<li class="list-grid <?php echo esc_html( $search_list ); ?>">
								<a href="<?php echo esc_url( $search_list_link ); ?>"><i class="fa fa-align-justify"></i></a>
							</li>
							<li class="list-grid <?php echo esc_html( $search_grid ); ?>">
								<a href="<?php echo esc_url( $search_grid_link ); ?>"><i class="fa fa-th-large"></i></a>
							</li>
						</ul>
					
					</div>
					<?php 
				} 

				echo '<div class="search_content_wrapper">';

				if( extretion_check_search_sort_view() == true ){
					extretion_get_searched_rooms(); 
				} else {

					echo '<div class="map-wrapper mt-20">
								<div class="move_marker_option">
									<label>
										<input checked type="checkbox" class="move_marker" value="1" style="display:block;opacity:1">
										' . esc_html__( 'Search as I move the map' , 'extretion' ) . '
									</label>
								</div>
									<a class="redo_search_here" href="javascript:void(0)" style="display:none">' . esc_html__( 'Redo Search Here' , 'extretion' ) . '<i class="fa fa-refresh" aria-hidden="true"></i></a>

								
								<div id="bali-map"></div>
							</div>';

				}
				echo '</div>';

				if( $all_rooms_count > 0 && extretion_check_search_sort_view() == true ){ ?>

					<div class="result-paging-wrapper">
					
						<div class="row">
						
							<div class="col-sm-6">
								<div class="text-holder">
								</div>
							</div>
							
							<div class="col-sm-6">
								
								<ul class="paging">
									<?php 
									extretion_pagination_html( 1 , $all_rooms_count ); ?>
								</ul>
							
							</div>
						
						</div>
						
					</div>
			
					<div class="mb-20"></div>

					<?php 
				
				} ?>
				
			</div>
		
		</div>

	</div>

</div>

<?php
get_footer();