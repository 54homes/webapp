<?php
class comment_walker extends Walker_Comment {

	var $tree_type = 'comment';
	var $db_fields = array( 'parent' => 'comment_parent', 'id' => 'comment_ID' );

	// constructor wrapper for the comments list
	function __construct() { ?>

		<ul class="comment-item">

	<?php }

	// start_lvl wrapper for child comments list
	function start_lvl( &$output, $depth = 0, $args = array() ) {
		$GLOBALS['comment_depth'] = $depth + 2; ?>
		
		<ul class="child-comments comment-item">

	<?php }

	// end_lvl closing wrapper for child comments list
	function end_lvl( &$output, $depth = 0, $args = array() ) {
		$GLOBALS['comment_depth'] = $depth + 2; ?>

		</ul>

	<?php }

	// start_el HTML for comment template
	function start_el( &$output, $comment, $depth = 0, $args = array(), $id = 0 ) {
		$depth++;
		$GLOBALS['comment_depth'] = $depth;
		$GLOBALS['comment'] = $comment;
		$parent_class = ( empty( $args['has_children'] ) ? '' : 'parent' ); 

		if ( 'article' == $args['style'] ) {
			$tag = 'article';
			$add_below = 'comment';
		} else {
			$tag = 'article';
			$add_below = 'comment';
		} ?>

		<li <?php comment_class(empty( $args['has_children'] ) ? '' :'parent') ?> id="comment-<?php comment_ID() ?>">

			<?php 
			$avatar = get_avatar( $comment, 65, '', 'Author gravatar' ); 

			if( !empty( $avatar ) ){ 
				$margin = ''; ?>
				<div class="comment-avatar">
					<?php 
					echo wp_kses(
						$avatar,
						array( 
							'img' => array( 
								'class' => array(),
								'alt' => array(),
								'src' => array(),
								'width' => array(),
								'height' => array(),
							) 
						) 
					); 
					?>
				</div>
				<?php 
			} else {
				$margin = 'margin-left: 0;';
			} ?>

			<div class="comment-header" style="<?php echo sanitize_text_field( $margin ); ?>">
				<!-- <a href="#" class="comment-reply">reply</a> -->
				<?php 

				$myclass = 'comment-reply';
				echo preg_replace( '/comment-reply-link/', 'comment-reply-link ' . $myclass, get_comment_reply_link(array_merge( $args, array('add_below' => $add_below, 'depth' => $depth, 'max_depth' => $args['max_depth']))), 1 ); ?>

				<a href="<?php comment_author_url(); ?>" class="font600 font16" target="blank"><?php comment_author(); ?></a>
				<span class="comment-time"><?php comment_date('jS F Y') ?>, <a href="#comment-<?php comment_ID() ?>"><?php comment_time() ?></a></span>
			</div>

			<div class="comment-content">
				<?php comment_text() ?>
				<?php edit_comment_link('<p class="comment-meta-item">' . esc_html__( 'Edit this comment' , 'extretion' ) . '</p>','',''); ?>

				<?php if ($comment->comment_approved == '0') : ?>
					<p class="comment-meta-item"><?php esc_html_e( 'Your comment is awaiting moderation.' , 'extretion' ); ?></p>
				<?php endif; ?>

			</div>

	<?php }

	// end_el closing HTML for comment template
	function end_el(&$output, $comment, $depth = 0, $args = array() ) { ?>

		</li>

	<?php }

	// destructor closing wrapper for the comments list
	function __destruct() { ?>

		</ul>
	
	<?php }

}

class room_comment_walker extends Walker_Comment {
	
	var $tree_type = 'comment';
	var $db_fields = array( 'parent' => 'comment_parent', 'id' => 'comment_ID' );

	// constructor wrapper for the comments list
	function __construct() { ?>

		<div class="review-item-wrapper" id="comments">

	<?php }

	// start_lvl wrapper for child comments list
	function start_lvl( &$output, $depth = 0, $args = array() ) {
		$GLOBALS['comment_depth'] = $depth + 2; ?>
		
		<ul class="child-comments comment-item">

	<?php }

	// end_lvl closing wrapper for child comments list
	function end_lvl( &$output, $depth = 0, $args = array() ) {
		$GLOBALS['comment_depth'] = $depth + 2; ?>

		</ul>

	<?php }

	// start_el HTML for comment template
	function start_el( &$output, $comment, $depth = 0, $args = array(), $id = 0 ) {
		$depth++;
		$GLOBALS['comment_depth'] = $depth;
		$GLOBALS['comment'] = $comment;
		$parent_class = ( empty( $args['has_children'] ) ? '' : 'parent' ); 

		if ( 'article' == $args['style'] ) {
			$tag = 'article';
			$add_below = 'comment';
		} else {
			$tag = 'article';
			$add_below = 'comment';
		} ?>

		<div <?php comment_class( 'review-item' ) ?> id="comment-<?php comment_ID() ?>">

			<?php 
			$avatar = get_avatar( $comment, 65, '', 'Author gravatar' ); 
			?>

			<div class="content-left">
				<div class="image clearfix">
					<?php 
					echo wp_kses(
						$avatar,
						array( 
							'img' => array( 
								'class' => array(),
								'alt' => array(),
								'src' => array(),
								'width' => array(),
								'height' => array(),
							) 
						) 
					); 
					?>
				</div>
				<h4 class="review-man upper"><?php comment_author(); ?></h4>
				<p class="date"><?php comment_date('jS F Y') ?></p>
			</div>

			<div class="content">
				<h5><?php echo get_comment_meta( $comment->comment_ID , 'comment_title', true );?></h5>
				<?php comment_text() ?>

				<?php if ($comment->comment_approved == '0') : ?>
					<p class="comment-meta-item"><?php esc_html_e( 'Your comment is awaiting moderation.' , 'extretion' ); ?></p>
				<?php endif; ?>

			</div>

			<div class="content-right">
				
				<?php 
				$individual_rating = extretion_get_individual_avg_rating( $comment->comment_ID ); 
				?>

				<div class="outer">
					<div class="inner">
						<div class="tripadvisor-module">
							<div class="tripadvisor-rate">

								<?php 
								for( $i = 1 ; $i <= 5 ; $i++ ){ 

									if( $i <= $individual_rating ){
										echo '<i class="fa fa-certificate rated"></i>';
									} else {
										echo '<i class="fa fa-certificate"></i>';
									}

								} ?>

							</div>
							<p>
								<span>
									<?php echo sanitize_text_field( $individual_rating ); ?>
								</span>

								<?php

								echo extretion_get_individual_rating_words( $individual_rating );
								
								?>
							</p>
						</div>
					</div>
				</div>
				
			</div>

	<?php }

	// end_el closing HTML for comment template
	function end_el(&$output, $comment, $depth = 0, $args = array() ) { ?>

		</div>

	<?php }

	// destructor closing wrapper for the comments list
	function __destruct() { ?>

		</div>
	
	<?php }

}