<?php
get_header();

$defaults = extretion_default_labels(); 

$room_category_sidebar = get_option( 'options_room_category_sidebar' ); 
$room_category_sidebar = !empty( $room_category_sidebar ) ? sanitize_text_field( $room_category_sidebar ) : 'left-sidebar'; ?>
	
<div <?php post_class("two-tone-layout {$room_category_sidebar}"); ?>>
		
	<div class="equal-content-sidebar">

		<div class="container">
		
			<?php 
			$queried_object = get_queried_object();

			$args = array(
				'post_type' => 'room',
				'post_status' => 'publish',
				'order' => 'DESC',
				'order_by' => 'date',
				'paged' => (get_query_var('paged') ? get_query_var('paged') : 1),
				'tax_query' => array(
					array(
						'taxonomy' => $queried_object->taxonomy,
						'field'    => 'slug',
						'terms'    => $queried_object->slug,
					),
				),
			);

			$no_of_rooms_category_page = get_option( 'options_no_of_rooms_category_page' );
			$args['posts_per_page'] = $no_of_rooms_category_page;

			$args = apply_filters( 'extretion_taxonomy_query' , $args );

			$rooms_query = new WP_Query( $args ); ?>

			<div class="content-wrapper">
				
				<div class="mb-10"></div>
				
				<div class="result-status result-status-taxonomy">

					<p>
						<?php 
						printf( esc_html__( 'We found %1$s hosts with availability in %2$s', 'extretion' ),
							'<span class="found_hotels text-primary font700">' . $rooms_query->found_posts . '</span>',
							'<span class="text-primary font700">' . $queried_object->name . '</span>' );
						?>
					</p>

				</div>
				
				<?php 
				
				echo '<div class="search_content_wrapper">';
				$filter_rooms = array();

				// Layout
				$view = get_option( 'options_room_category_page_layout' );
				$view = !empty( $view ) ? $view : 'grid';

				if( $rooms_query->have_posts() ):

					while( $rooms_query->have_posts() ): $rooms_query->the_post();

						$filter_rooms[]['postid'] = $post->ID;

					endwhile;

				endif;

				if( !empty( $filter_rooms ) ){

					extretion_get_room_list( $filter_rooms , $view );
					extretion_blogListingPagination();

				} else {

				}
					
				echo '</div>'; ?>
				
				<div class="clear"></div>
				<div class="mb-40"></div>

			</div>

			<div class="sidebar-wrapper ">
				<aside>
					
					<?php extretion_getSidebar( 'room_cat_sidebar' ); ?>
					
				</aside>
			</div>
		
		</div>

	</div>

</div>

<?php
get_footer();