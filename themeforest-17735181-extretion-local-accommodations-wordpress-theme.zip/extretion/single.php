<?php
extretion_set_post_type_404_error( $post );
get_header(); 
$single_layout = extretion_blogDetailLayout();?>

<div class="clear"></div>
<div id="post-<?php the_ID(); ?>" <?php post_class("equal-content-sidebar-wrapper {$single_layout}"); ?>>

	<div class="equal-content-sidebar-by-js right-sidebar">
	
		<div class="container">
		
			<div class="content-wrapper">
				
				<div class="mb-10"></div>

				<div class="blog-wrapper">
				
					<?php 

					if ( have_posts() ) :

						while ( have_posts() ) : the_post();

							get_template_part( 'template-parts/content' ); 

						endwhile;
						
					endif; ?>
				
				</div>
				
				<div class="mb-40"></div>
				
			</div>

			<div class="sidebar-wrapper">
				
				<?php 
				extretion_blogDetailSidebar();
				?>					
			
			</div>
		
		</div>

	</div>

</div>

<?php
get_footer();
