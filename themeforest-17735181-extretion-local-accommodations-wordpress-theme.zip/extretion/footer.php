
			<div class="clear"></div>
			
			<footer class="main-footer">
			
				<div class="container">
				
					<div class="row">
					
						<div class="col-sm-12 col-sm-5 col-md-6 footer_1">
						
							<div class="row">
								<div class="footer-about col-sm-10 col-md-8">
									<?php dynamic_sidebar( 'footer_1' ); ?>
								</div>
							</div>
						
						</div>
						
						<div class="col-sm-12 col-sm-7 col-md-6">

							<div class="row gap-20">
							
								<div class="col-xss-6 col-xs-4 col-sm-4 mt-30-xs">
								
									<?php dynamic_sidebar( 'footer_2' ); ?>
									
								</div>
								
								<div class="col-xss-6 col-xs-4 col-sm-4 mt-30-xs">
								
									<?php dynamic_sidebar( 'footer_3' ); ?>
									
								</div>
								
								<div class="col-xss-12 col-xs-4 col-sm-4 mt-30-xs">
								
									<?php dynamic_sidebar( 'footer_4' ); ?>
									
								</div>
							
							</div>
						
						</div>
						
					</div>
					
				</div>
				
			</footer>
			
		</div>
		<!-- end Main Wrapper -->

	</div> <!-- / .wrapper -->
	<!-- end Container Wrapper -->

 <!-- start Back To Top -->
<div id="back-to-top">
   <a href="#"><i class="ion-ios-arrow-up"></i></a>
</div>
<!-- end Back To Top -->
<?php wp_footer(); ?>

</body>
</html>
