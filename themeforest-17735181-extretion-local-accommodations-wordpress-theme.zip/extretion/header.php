<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

	<?php
	if ( !function_exists( 'has_site_icon' ) || !has_site_icon() ) { ?>
		<link rel="shortcut icon" href="<?php echo extretion_get_fav_icon(); ?>" >
		<?php 
	}?>

<?php wp_head(); ?>
</head>

<body <?php body_class( 'with-navbar-top-bottom' ); ?>>

	<?php 
	extretion_get_preloader();
	$current_user = get_current_user_id();
	$defaults = extretion_default_labels(); 
	
	extretion_addNew();
	extretion_verify_user_email();
	extretion_resetPasswordForm();

	get_template_part( 'template-parts/content-access' , 'modal' ); ?>

	<!-- start Container Wrapper -->
	<div class="container-wrapper colored-navbar-brand">

		<!-- start Header -->
		<header id="header" class="overflow-x-hidden-xss">
	  		
	  		<?php 
	  		$header_option = get_option( 'options_header_logo_text' );
	  		if( $header_option == 1 ){
	  			$text_class = 'logo_text';
	  		} else {
	  			$text_class = 'logo_image';
	  		}
	  		?>
	  		
			<!-- start Navbar (Header) -->
			<nav class="navbar navbar-default navbar-fixed-top with-slicknav">
				
				<div class="navbar-top">
				
					<div class="container">
							
						<?php 
						
						if( empty( $header_option ) ){ ?>

							<div class="navbar-header">
								<a class="navbar-brand text-uppercase" href="<?php echo site_url(); ?>"><?php echo get_bloginfo( 'name' ); ?></a>
							</div>

							<?php
						} else {

							if( $header_option == 1){ ?>

								<div class="navbar-header">
									<a class="navbar-brand text-uppercase" href="<?php echo site_url(); ?>">
										<?php echo esc_html( get_option( 'options_header_text' ) ); ?>
									</a>
								</div>

								<?php
							} else { 

								$logo_url = get_option( 'options_header_logo' ); ?>

								<!-- For Mobile devices -->
								<div class="navbar-image-mobile hidden-lg">
									<a href="<?php echo site_url(); ?>">
										<img src="<?php echo esc_url( $logo_url ); ?>" class="logo_image_extretion">
									</a>
								</div>

								<!-- For Desktop devices -->
								<div class="navbar-image hidden-xs hidden-sm">
									<a href="<?php echo site_url(); ?>">
										<img src="<?php echo esc_url( $logo_url ); ?>" class="logo_image_extretion">
									</a>
								</div>

								<?php
							}

						} ?>
							
						<div class="pull-right">
						
							<div class="navbar-mini">
								<ul class="clearfix">
									<li class="dropdown bt-dropdown-click">
										<a id="currency-dropdown" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
											<?php 

											if( empty( $_COOKIE['currency'] ) ){
												echo esc_html( $defaults['homepage']['currency'] );
											} else {
												echo sanitize_text_field( $_COOKIE['currency'] );
											}
											?>
											<span class="caret"></span>
										</a>
										<ul class="dropdown-menu currency-dropdown-menu" aria-labelledby="currency-dropdown">

											<?php 
											$currency_header = extretion_currency_symbol();

											foreach( $currency_header as $key => $value ){ 
												echo '<li><a href="javascript:void(0)" title="' . $key . '">' . $key . '</a></li>';				
											}?>

										</ul>
									</li>

									<li class="user-action">

										<?php 
										if( !is_user_logged_in() ){ ?>
											<a data-toggle="modal" href="javascript:void(0)" class="register_sign_up btn"><?php _e( 'Sign up' , 'extretion' ); ?></a> 
											<a data-toggle="modal" href="javascript:void(0)" class="login_modal_lmh btn"><?php _e( 'Log in' , 'extretion' ); ?></a> 
											<?php 
										} else { 

											$dashboard_menu = wp_nav_menu( 
												array(
												    'theme_location' => 'dashboard',
												    'items_wrap'     => '<ul class="dropdown-menu dashboard-dropdown-menu">%3$s</ul>',
												    'depth' => 1, 
												    'fallback_cb' => false,
												    'echo' => false
												) 
											); ?>

											<ul class="clearfix ml-0">
												<li class="dropdown bt-dropdown-click">
													<a 
													id="header-deshboard-menu" 
													class="dropdown-toggle" 
													data-toggle="dropdown" 
													role="button" 
													aria-haspopup="true" 
													aria-expanded="false" 
													style="<?php echo ( empty( $dashboard_menu ) ? 'cursor:default' : 'cursor:pointer' ); ?>">
													
														<?php 

														$current_user_info = get_userdata( $current_user );
														$current_user_name = get_the_author_meta( 'first_name' , $current_user );

														// User image for desktop
														echo '<span class="user_avatar_wrap">';
														echo get_avatar( $current_user , $size = 40, null , null , array( 'class' => 'hidden-sm hidden-xs user_avatar_header' ) );
														echo '</span>';

														echo '<span class="user_name_wrap">';
														printf( esc_html__( 'Welcome, %s', 'extretion' ), 
														$current_user_name ? $current_user_name : $current_user_info->user_login );
														echo '</span>';
														
														// If no dashboard menu do not show the drop down arrow
														if( !empty( $dashboard_menu ) ){ ?>
															<span class="caret"></span>
															<?php 
														} ?>

													</a>

													<?php echo $dashboard_menu; ?>

												</li>
											</ul>

											<?php
										}?>
									</li>

									<?php 
									extretion_header_notification();
									extretion_message_notification();
									?>
									
								</ul>
							</div>
							
						</div>
					
					</div>
				
				</div>
				
				<div class="navbar-bottom">
				
					<div class="container">
						
						<div id="navbar" class="collapse navbar-collapse navbar-arrow pull-left">

							<?php 
							wp_nav_menu( array(
							    //'menu' => 'primary',
							    'theme_location' => 'primary',
							    'items_wrap'     => '<ul id="responsive-menu" class="nav navbar-nav">%3$s</ul>',
							    'fallback_cb' => false
							) );
							?>
						
						</div><!--/.nav-collapse -->
						
					</div>
					
				</div>
				
				<div id="slicknav-mobile"></div>
				
			</nav>
			<!-- end Navbar (Header) -->

		</header>

		<div class="clear"></div>

		<!-- start Main Wrapper -->
		<div class="main-wrapper">

			<?php 
			
			if( extretion_check_page_template_breadcrum( 'page-templates/booking-request.php' )  == true || extretion_check_page_template_breadcrum( 'page-templates/booking-details.php' ) == true || extretion_check_page_template_breadcrum( 'page-templates/booking-approval.php' ) == true || extretion_check_page_template_breadcrum( 'page-templates/booking-confirmation.php' ) == true ): ?>
			
				<div class="breadcrumb-wrapper">
			
					<div class="container booking-step">

						<div class="row gap-0">

							<div class="col-xs-12 col-sm-3">
								<div class="step-item <?php extretion_check_active_booking_page( 'page-templates/booking-details.php' ); ?>">
								
									<div class="line"></div>
									<div class="step-item">
										<div class="number"><div class="inner">
											<?php _e( '1' , 'extretion' ); ?>
										</div></div>
										<p><?php _e( 'Booking Details' , 'extretion' ); ?></p>
									</div>
										
								</div>
								
							</div>
							
							<div class="col-xs-12 col-sm-3">
								<div class="step-item <?php extretion_check_active_booking_page( 'page-templates/booking-request.php' ); ?>">
								
									<div class="line"></div>
									<div class="step-item">
										<div class="number"><div class="inner"><?php _e( '2' , 'extretion' ); ?></div></div>
										<p><?php _e( 'Booking Request' , 'extretion' ); ?></p>
									</div>
										
								</div>
								
							</div>
							
							<div class="col-xs-12 col-sm-3">
								<div class="step-item <?php extretion_check_active_booking_page( 'page-templates/booking-approval.php' ); ?>">
								
									<div class="line"></div>
									<div class="step-item">
										<div class="number"><div class="inner"><?php _e( '3' , 'extretion' ); ?></div></div>
										<p><?php _e( 'Booking Approval' , 'extretion' ); ?></p>
									</div>
										
								</div>
								
							</div>

							<div class="col-xs-12 col-sm-3">
								<div class="step-item <?php extretion_check_active_booking_page( 'page-templates/booking-confirmation.php' ); ?>">
								
									<div class="line"></div>
									<div class="step-item">
										<div class="number"><div class="inner"><?php _e( '4' , 'extretion' ); ?></div></div>
										<p><?php _e( 'Payment & Confirmation' , 'extretion' ); ?></p>
									</div>
										
								</div>
								
							</div>
							
						</div>
						
					</div>


				</div>
				
				<?php
			elseif( is_home() && ! is_front_page() ):
				extretion_custom_breadcrumbs();
			elseif( !is_front_page() ):
				extretion_custom_breadcrumbs();
			endif; ?>

