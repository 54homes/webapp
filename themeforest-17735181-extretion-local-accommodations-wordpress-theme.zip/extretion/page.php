<?php

get_header(); 

if( have_posts() ): 

	while ( have_posts() ) : the_post(); ?>
	
		<div id="post-<?php the_ID(); ?>" <?php post_class( "two-tone-layout size-2 left-sidebar" ); ?>>
					
			<div class="equal-content-sidebar">
			
				<div class="container">
				
					<?php 
					get_template_part( 'template-parts/content', 'page' ); ?>

					<div class="sidebar-wrapper">
					
						<?php extretion_pageSidebar(); ?>

					</div>
				
				</div>

			</div>

		</div>
		
		<?php

	endwhile;

endif;

get_footer();
