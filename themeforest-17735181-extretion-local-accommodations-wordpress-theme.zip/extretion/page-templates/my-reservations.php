<?php
/* Template Name: Reservations */

if( !is_user_logged_in() ){
	extretion_set404Page();
}

get_header();

$args = array(
	'post_type' => 'lmh_invoice',
	'post_status' => 'publish',
	'posts_per_page' => 5,
	'paged' => (get_query_var('paged')) ? get_query_var('paged') : 1,
	'meta_query' => array(
		array(
			'key'     => 'hotel_owner',
			'value'   => get_current_user_id(),
			'compare' => '=',
		),
	),
);

// Start for pagination
$args2 = array(
	'post_type' => 'lmh_invoice',
	'post_status' => 'publish',
	'posts_per_page' => -1,
	'meta_query' => array(
		array(
			'key'     => 'hotel_owner',
			'value'   => get_current_user_id(),
			'compare' => '=',
		),
	),
);
$all_query = new WP_Query( $args2 );
// End for pagination

$reservation_query = new WP_Query( $args ); ?>

<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					
	<div class="equal-content-sidebar-by-gridLex">
	
		<div class="container">

			<div class="GridLex-grid-noGutter-equalHeight">
		
				<div class="GridLex-col-3_sm-4_xs-12_xss-12">
					
					<?php extretion_dashboard_sidebar(); ?>
					
				</div>
				
				<div class="GridLex-col-9_sm-8_xs-12_xss-12">

					<div class="content-wrapper">

						<div class="dashboard-content">

							<div class="row">
							
								<div class="col-xs-12 col-sm-10 col-md-9">
									
									<div class="dashboard-heading">
									
										<h3><?php esc_html_e( 'My Reservations' , 'extretion' ); ?></h3>
								
									</div>
									
								</div>

							</div>

							<?php extretion_paypal_email_error_message(); ?>

						</div>

						<?php 

						if( !empty( $_GET['status'] ) && $_GET['status'] == 'approved' ){
						?>
							<div class="alert alert-success mb-20">
								<?php 
								esc_html_e( 'Congratulation!!! Booking request has been approved and notified to the traveler for payment.' , 'extretion' );
								?>
							</div>

							<?php 
						}
					
						if( $reservation_query->have_posts() ): ?>

							<div class="hotel-item-wrapper-2">

								<?php
								while( $reservation_query->have_posts() ): $reservation_query->the_post();
									
									$invoice_details = get_post_meta( $post->ID, 'invoice_details' , true );

									// Booking approval page link
									$contract_page = esc_url( get_permalink( get_option( 'options_select_booking_approval_page' ) ) );

									// Booking approval page link
									$payment_page = get_permalink( get_option( 'options_select_booking_confirmation_n_payment' ) );

									$payment_status = get_post_meta( $post->ID, 'payment_status' , true );

									// Sent to booking approval page
									if( $payment_status == 'booking_request_accepted' || $payment_status == 'payment_successful' ){

										$link = $payment_page . $post->ID;

									} 
									// Sent to payment page
									else {
										
										$link = $contract_page . $post->ID;

									}?>

									<div class="hotel-item-list-2 clearfix">
							
										<div class="image">
											<img src="<?php echo extretion_get_first_image_room( $invoice_details['post_id'] ); ?>">
										</div>
										
										<div class="content">
											<div class="heading">
												
												<a href="<?php echo get_permalink( $invoice_details['post_id'] ); ?>" title="<?php the_title(); ?>">
													<h4><?php echo mb_strimwidth( get_the_title( $post ) , 0, 39, '...'); ?></h4>
												</a>

												
												<div class="trip_address">
													<i class="fa fa-map-marker text-primary"></i>
													<?php 
													$address = get_post_meta( $invoice_details['post_id'] , 'form_place_located_formatted_address' , true );
													$arr_address = explode( ',', $address );

													if( !empty( $arr_address ) ){
														echo esc_html( $arr_address[0] );
													}

													if( count( $arr_address ) > 1 ){
														echo ',' . esc_html( $arr_address[1] );
													}

													?>
												</div>

												<?php 
												$get_all_avg_rating = extretion_get_all_avg_rating( $invoice_details['post_id'] ); 

												echo '<div class="trip_rating">';
												extretion_title_star_width( $get_all_avg_rating , $invoice_details['post_id'] );
												echo '</div>';
												?>

											</div>
											<div class="short-info">
												<span class="absolute">
													<?php esc_html_e( 'Status :', 'extretion' ); ?> 
												</span> 
												<span class="block">

													<?php 
													$invoice_status = get_post_meta( $post->ID , 'payment_status', true );

													switch ( $invoice_status ) {

														case 'pending_approval': ?>
															
															<span class="label-info label">
																<?php esc_html_e( 'Pending Approval' , 'extretion' ); ?>
															</span>

															<?php
															break;

														case 'booking_request_accepted': ?>

															<span class="label-warning label">
																<?php 
																esc_html_e( 'Pending Payment' , 'extretion' ); ?>
															</span>

															<?php
															break;

														case 'payment_successful': ?>

															<span class="label-success label">
																<?php 
																esc_html_e( 'Payment Successful' , 'extretion' ); ?>
															</span>

															<?php
															break;
														
														default:
															# code...
															break;

													}												?>

												</span>
											</div>
										</div>
										
										<div class="total-price">
											<?php esc_html_e( 'Total price :', 'extretion' ); ?> 
											<span class="price">
												<?php 

												$security_deposit = !empty( $invoice_details['security_deposit'] ) ? $invoice_details['security_deposit'] : 0;

												$total_price_after_security_deposit = $invoice_details['total_price'] + $security_deposit;

												echo '<span class="currency_symbol">' . extretion_currency_symbol( $invoice_details['currency'] ) . '</span> ';
												echo number_format( $total_price_after_security_deposit , 2, '.', ',' ) . ' ';
												echo esc_html( $invoice_details['currency'] );
												?>
											</span>
										</div>
										
										<div class="absolute-right-top">
										
											<ul class="check-in-out clearfix">
														
												<li>
													<div class="check-in-out-item">
														<?php 
														esc_html_e( 'Check-in', 'extretion' ); 

														$check_in = $invoice_details['check_in']; ?>
														<span class="date">
															<?php 
															echo date( 'd' , strtotime( $check_in ) ); ?>
														</span>
														<span class="day">
															<?php 
															echo date( 'l' , strtotime( $check_in ) ); ?>
														</span>
														<span class="month-year">
															<?php 
															echo date( 'M Y' , strtotime( $check_in ) ); ?>
														</span>
													</div>
												</li>
												
												<li>
													<div class="check-in-out-item">
														<?php 
														esc_html_e( 'Check-out', 'extretion' ); 
														$check_out = $invoice_details['check_out']; ?>
														<span class="date">
															<?php 
															echo date( 'd' , strtotime( $check_out ) ); ?>
														</span>
														<span class="day">
															<?php 
															echo date( 'l' , strtotime( $check_out ) ); ?>
														</span>
														<span class="month-year">
															<?php 
															echo date( 'M Y' , strtotime( $check_out ) ); ?>
														</span>
													</div>
												</li>
												
											</ul>
											
										</div>
										
										<div class="absolute-right-bottom">
																					
											<a href="<?php echo esc_url( $link ); ?>" class="btn btn-danger btn-sm">
												<?php esc_html_e( 'Open Request' , 'extretion' ); ?>
											</a>
										
										</div>
										
									</div>

									<?php

								endwhile; ?>

							</div>

							<div class="mt-40">
							
								<?php 
								//$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
								listMyHotelPagination( ceil( $all_query->found_posts/5 ) ); ?>
								
							</div>

							<?php

						else:
							echo '<div class="alert alert-info">';
							esc_html_e( 'You do not have any reservations.', 'extretion' );
							echo '</div>';
						endif;
						?>

					</div>

				</div>

			</div>

		</div>

	</div>

</div>

<?php
get_footer();