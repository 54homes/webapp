<?php
/* Template Name: My Listings */

if( !is_user_logged_in() ){
	extretion_set404Page();
}

get_header();

$args = array(
	'post_type' => 'room',
	'post_status' => array( 'publish' , 'pending' ),
	'posts_per_page' => 5,
	'author' => get_current_user_id(),
	'paged' => (get_query_var('paged')) ? get_query_var('paged') : 1
);

$my_listings = new WP_Query( $args ); 

//echo '<pre>'; print_r($my_listings); echo '</pre>';

// Start for pagination
$args2 = array(
	'post_type' => 'room',
	'post_status' => array( 'publish' , 'pending' ),
	'author' => get_current_user_id(),
	'posts_per_page' => -1,
);
$all_query = new WP_Query( $args2 );
// End for pagination
?>
	
<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
				
	<div class="equal-content-sidebar-by-gridLex">
	
		<div class="container">

			<div class="GridLex-grid-noGutter-equalHeight">
		
				<div class="GridLex-col-3_sm-4_xs-12_xss-12">
					
					<?php extretion_dashboard_sidebar(); ?>
					
				</div>
				
				<div class="GridLex-col-9_sm-8_xs-12_xss-12">

					<div class="content-wrapper">

						<div class="dashboard-content">

							<div class="row">
							
								<div class="col-xs-12 col-sm-10 col-md-9">
									
									<div class="dashboard-heading">
									
										<h3><?php esc_html_e( 'My Listings' , 'extretion' ); ?></h3>
								
									</div>
									
								</div>

							</div>

							<?php extretion_paypal_email_error_message(); ?>

						</div>

						<?php 
						if( !empty( $_GET['status'] ) && $_GET['status'] == 'deleted' ){
						?>
							<div class="alert alert-success mb-20">
								<?php 
								esc_html_e( 'Congratulation!!! Your room has been deleted.' , 'extretion' );
								?>
							</div>

							<?php 
						}

						if( $my_listings->have_posts() ): ?>

							<div class="hotel-item-list-wrapper my_listings_wrapper mb-40">

								<?php

								while( $my_listings->have_posts() ): $my_listings->the_post(); 

									$image = extretion_get_first_image_room( $post->ID );
									$defaults = extretion_default_labels();

									extretion_my_listings_list_view( $image , $post , $defaults );

								endwhile; ?>

							</div>

							<div class="mt-40">
							
								<?php 
								listMyHotelPagination( ceil( $all_query->found_posts/5 ) ); ?>
								
							</div>

							<?php

						else:
							echo '<div class="alert alert-info">';
							esc_html_e( 'You do not have any rooms listed.', 'extretion' );
							echo '</div>';
						endif;
						?>

					</div>

				</div>

			</div>

		</div>

	</div>

</div>

<?php

get_footer();