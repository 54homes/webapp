<?php
/* Template Name: Booking Confirmation & Payment */

// If payment successful then run this
//extretion_check_room_payment_status();

$invoice_id = get_query_var( 'post_id' , null ); // Get invoice id
$hotel_id = get_post_meta( $invoice_id, 'hotel_owner', true ); // Get hotel owner id
$order_id = get_post_meta( $invoice_id, 'invoice_details', true ); // Get invoice details
$user_id = get_current_user_id();
$invoice_details = get_post( $invoice_id ); // Get invoice objects
$payment_status = get_post_meta( $invoice_id, 'payment_status', true );
$allow_pages = array( 'booking_request_accepted' , 'payment_successful' );

if( !is_user_logged_in() || !is_object( $invoice_details ) || extretion_booking_page_privelage( $invoice_details , $user_id , $hotel_id ) == false ||  !in_array( $payment_status, $allow_pages ) ){
	extretion_set404Page(); // Set 404 error
}

$post_id = $order_id['post_id']; // Get room id
$defaults = extretion_default_labels(); // Get defaults labels

//echo '<pre>'; print_r($order_id); echo '</pre>';

get_header();

$payment_status = get_post_meta( $invoice_id, 'payment_status', true ); ?>

<div id="post-<?php the_ID(); ?>" <?php post_class( "container" ); ?>>

	<?php 

	require_once( get_template_directory() . '/template-parts/content-booking-request.php' ); 
	
	if( $invoice_details->post_author == $user_id ){ 

		if( $payment_status == 'booking_request_accepted' ): ?>

			<div class="metro-box-wrapper mb-40">
										
				<div class="heading">
					<h3><?php esc_html_e( 'Payment Information', 'extretion' ); ?></h3>
				</div>

				<div class="content pt-25">
								
					<div id="paymentOption" class="payment-option-wrapper ml-0 payment-select">

						<div class="row">
							
							<label class="col-sm-12 col-md-12 mb-20">
								<?php esc_html_e( 'Choose your payment method', 'extretion' ); ?>
							</label>

							<?php 

							$host_paypal_id = get_user_meta( $hotel_id , 'paypal_email' , true );
							$stripe_details = get_user_meta( $hotel_id, 'stripe_details' , true );

							if( get_option( 'options_paypal_status' ) != 1 && is_email( $host_paypal_id ) ){ ?>

								<div class="col-sm-12">
									<div class="radio-block font-icon-radio">
										<input id="payments2" name="payments" type="radio" class="radio" value="paymentPaypal" checked="checked" autocomplete="off" />
										<label class="" for="payments2">
											<img src="<?php echo get_template_directory_uri(); ?>/images/payment-paypal.jpg" alt="Paypal Image">
										</label>
									</div>
								</div>

								<div class="clear mb-10"></div>

								<?php 

							} 

							if( get_option( 'options_stripe_status' ) != 1 && !empty( $stripe_details ) ){ ?>

								<div class="col-sm-12">
									<div class="radio-block font-icon-radio">
										<input id="payment_stripe" name="payments" type="radio" class="radio" value="payment_stripe" autocomplete="off"/>
										<label class="" for="payment_stripe">
											<img src="<?php echo get_template_directory_uri(); ?>/images/stripe.png" alt="Stripe Image">
										</label>
									</div>
								</div>

								<?php 

							} ?>
							
						</div>
						
						<?php 

						$user_chosen_amt = extretion_currency_symbol( $order_id['currency'] ) . ' ' . number_format( extretion_get_first_installment_price( $order_id ) , 2, '.', ',' );	

						$total_payment_title =  sprintf(
							esc_html__( 'Your Total Payment at Booking: %s ( %s )', 'extretion' ),
							extretion_get_amount_in_usd( $order_id ),
							$user_chosen_amt
						);

						if( get_option( 'options_paypal_status' ) != 1 && is_email( $host_paypal_id ) ){ ?>

							<div id="paymentPaypal" class="payment-option-form">

								<div class="inner">
								
									<h4 class="mb-20">
										<?php 
										echo $total_payment_title;
										?>
									</h4>
									<p><?php esc_html_e( 'All transactions will be handled in USD.', 'extretion' ); ?></p>
									<p><?php esc_html_e( 'The booking amount will be debited from your account once the booking is completed.' , 'extretion' ); ?></p>
									<p>
										<?php esc_html_e( "After clicking 'Book Now' you will be redirected to PayPal to complete payment." , 'extretion' ); ?> 
										<strong><?php esc_html_e( 'You must complete the process or the booking will not occur' , 'extretion' ); ?> </strong>. 
										<?php 
										printf( 
											esc_html__( 'Afterwards you will be redirected to %s.', 'extretion' ),
											get_bloginfo( 'name' ) 
										) ?>
									</p>
									<input autocomplete="off" class="btn btn-danger confirm_payment_paypal" type="button" value="<?php esc_html_e( 'Book Now' , 'extretion' ); ?>">

									<p class="payment-term mt-15">
										<?php
										echo wp_kses(
											$defaults['book_now_rules_step_2'],
											array(
												'a' => array(
													'href' => array(),
													'class' => array(),
												)
											)
										); ?> 
									</p>

								</div>
								
							</div>

							<?php 
						} 

						if( get_option( 'options_stripe_status' ) != 1 && !empty( $stripe_details ) ){ ?>

							<div id="payment_stripe_content" style="display: none;" class="payment-option-form">
								<div class="inner">
									<h4 class="mb-20"><?php echo $total_payment_title; ?></h4>
									<p><?php esc_html_e( 'All transactions will be handled in USD.', 'extretion' ); ?></p>
									<p><?php esc_html_e( 'The booking amount will be debited from your account once the booking is completed.' , 'extretion' ); ?></p>

									<div class="form-horizontal">
										<form action="#" method="POST" id="payment-form">
										  	
										  	<span class="payment-errors alert alert-danger" style="display: none;"></span>

										  	<div class="form-group">
										  		<label class="col-sm-2 col-md-2 control-label"><?php esc_html_e( 'Card Number', 'extretion' ); ?> </label>
												<div class="col-sm-4 col-md-4">
													<input type="text" class="form-control mb-0" data-stripe="number">
												</div>
										  	</div>

										  	<div class="form-group card_expiry_date" >
										  		<label class="col-sm-2 col-md-2 control-label"><?php esc_html_e( 'Expiration (MM/YY)', 'extretion' ); ?> </label>
												<div class="col-sm-4 col-md-4">
													<input type="text" class="form-control mb-0" data-stripe="exp_month">
													<span> / </span>
										    		<input type="text" class="form-control mb-0" data-stripe="exp_year">
												</div>									    	
										  	</div>

										  	<div class="form-group">
									      		<label class="col-sm-2 col-md-2 control-label"><?php esc_html_e( 'CVC', 'extretion' ); ?> </label>
									      		<div class="col-sm-4 col-md-4">
									      			<input type="text" class="form-control mb-0" data-stripe="cvc">
									      		</div>
										  	</div>

										  	<div class="form-group">
										  		<label class="col-sm-2 col-md-2 control-label"></label>
										  		<div class="col-sm-4 col-md-4">
										  			<input type="submit" class="btn btn-danger stripe_book_now_btn" value="<?php esc_html_e( 'Book Now' , 'extretion' ); ?>" autocomplete="off">
										  		</div>
										  	</div>
										  
										</form>
									</div>

								</div>
							</div>

							<?php 

						} ?>

					</div>

				</div>

			</div>

			<?php 

		endif;

	} else { 

		if( $payment_status == 'booking_request_accepted' ):  ?>

			<div class="alert alert-info mb-25">
				<?php esc_html_e( 'Status : Pending Payment from Traveller' , 'extretion' ); ?>
			</div>

			<?php

		endif;

	} 

	extretion_show_users_details_after_payment( $payment_status , $hotel_id , $invoice_details->post_author ); ?>

	<div class="clear"></div>

</div>

<?php
get_footer();