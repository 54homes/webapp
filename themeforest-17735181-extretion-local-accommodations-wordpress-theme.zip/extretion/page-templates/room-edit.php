<?php
/* Template Name: Edit Room */
$room = extretion_check_user_room();
get_header();

$pagename = get_query_var( 'pagename' );
$current_page = site_url() . '/' . $pagename;

$basic_link = add_query_arg( array( 'id' => $room->ID,'page' => 'basic', ) , $current_page );
$photos_link = add_query_arg( array( 'id' => $room->ID,'page' => 'photos', ) , $current_page );
$calendar_link = add_query_arg( array( 'id' => $room->ID,'page' => 'calendar', ) , $current_page );
$guide_link = add_query_arg( array( 'id' => $room->ID,'page' => 'guide', ) , $current_page );

if( have_posts() ): 

	while ( have_posts() ) : the_post(); ?>
		
		<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					
			<div class="equal-content-sidebar-by-gridLex">
			
				<div class="container">

					<div class="GridLex-grid-noGutter-equalHeight">
				
						<div class="GridLex-col-3_sm-4_xs-12_xss-12">
						
							<?php extretion_dashboard_sidebar(); ?>

						</div>
						
						<div class="GridLex-col-9_sm-8_xs-12_xss-12">
							
							<div class="content-wrapper">

								<div class="section-title mb-20">
									<h2 class="mb-15 text-left"><?php esc_html_e( 'Edit Room' , 'extretion' ); ?></h2>
								</div>

								<div class="bb"></div>
								<div class="bb"></div>

								<div class="mb-20"></div>

								<div class="row">
									
									<ul class="col-xs-12 col-md-12 col-sm-12 room-edit-options">
										<li class="col-xs-3 col-md-2 col-sm-3 nopadding">
											<a href="<?php echo esc_url( $basic_link ); ?>" <?php selected( $_GET['page'], 'basic' ); ?>>
												<?php esc_html_e( 'Basic' , 'extretion' ); ?>
											</a>
										</li>
										<li class="col-xs-3 col-md-2 col-sm-3 nopadding">
											<a href="<?php echo esc_url( $photos_link ); ?>" <?php selected( $_GET['page'], 'photos' ); ?>>
												<?php esc_html_e( 'Photos' , 'extretion' ); ?>
											</a>
										</li>
										<li class="col-xs-3 col-md-2 col-sm-3 nopadding">
											<a href="<?php echo esc_url( $calendar_link ); ?>" <?php selected( $_GET['page'], 'calendar' ); ?>>
												<?php esc_html_e( 'Calendar' , 'extretion' ); ?>
											</a>
										</li>
										<li class="col-xs-3 col-md-2 col-sm-3 nopadding">
											<a href="<?php echo esc_url( $guide_link ); ?>" <?php selected( $_GET['page'], 'guide' ); ?>>
												<?php esc_html_e( 'Guide' , 'extretion' ); ?>
											</a>
										</li>
										<li class="col-xs-6 col-md-2 col-sm-6 nopadding switch_listings">
											<div class="dropdown">

											  	<a id="dLabel" data-target="#" href="http://example.com" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
											    	<?php esc_html_e( 'Switch Listing' , 'extretion' ); ?>
											    	<span class="caret"></span>
											  	</a>

											  	<ul class="dropdown-menu user_listings_dropdown" aria-labelledby="dLabel">
											    	<li><a href="javascript:coid(0)" class="btn-info"><?php echo get_the_title( $room ); ?></a></li>							
											    	<?php extretion_get_other_user_posts( $room->ID  ,$pagename ); ?>
											  	</ul>

											</div>
										</li>
										<li class="col-xs-6 col-md-2 col-sm-6 nopadding preview_room">
											<a target="blank" href="<?php echo get_permalink( $room->ID ); ?>">
												<?php esc_html_e( 'Preview' , 'extretion' ); ?>
													
											</a>
										</li>
										
									</ul>

								</div>

								<?php extretion_paypal_email_error_message(); ?>

								<?php 

								switch ( $_GET['page'] ) {
									
									case 'photos':
										get_template_part( 'template-parts/edit' , 'photos' );
										break;

									case 'calendar':
										get_template_part( 'template-parts/edit' , 'calendar' );
										break;

									case 'guide':
										get_template_part( 'template-parts/edit' , 'guide' );
										break;
									
									default:
										get_template_part( 'template-parts/edit' , 'basic' );
										break;
								}
								?>

							</div>

						</div>

					</div>

				</div>

			</div>

		</div>

	<?php

	endwhile;

endif;

get_footer();