<?php
/* Template Name: Edit Profile */

extretion_checkLoggedInUser();
get_header();

$consumerKey = get_option( 'options_consumerKey' , '123456789' );
$digitStatus = get_option( 'digits_status' );
$mobileVerificationPage = ( !empty( $_GET['action'] ) && $_GET['action'] == 'add_mobile_number' ) ? true : false;

if( have_posts() ): 

	while ( have_posts() ) : the_post(); ?>
	
		<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					
			<div class="equal-content-sidebar-by-gridLex">
			
				<div class="container">

					<div class="GridLex-grid-noGutter-equalHeight">
				
						<div class="GridLex-col-3_sm-4_xs-12_xss-12">
							
							<?php extretion_dashboard_sidebar(); ?>
							
						</div>
						
						<div class="GridLex-col-9_sm-8_xs-12_xss-12">

							<div class="content-wrapper">

								<div class="dashboard-content">

									<div class="row">
									
										<div class="col-xs-12 col-sm-10 col-md-9">
											
											<div class="dashboard-heading">
											
												<h3><?php 

												if( $mobileVerificationPage == true ){
													esc_html_e( 'Edit Mobile Number' , 'extretion' ); 
												} else {
													esc_html_e( 'Profile' , 'extretion' );
												}?></h3>											
										
											</div>

											<div class="alert alert-danger mb-20 mobileNumberTakenWarning" style="display:none;">
												<?php esc_html_e( 'The mobile number you have entered is already taken. Please enter another mobile number.' , 'extretion' ); ?>
											</div>

											<div class="alert alert-success mb-20 mobileNumberSuccessfullyChanged" style="display:none;">
												<?php esc_html_e( 'Your mobile number has been added successfully. Go to your profile page to see the changes.' , 'extretion' ); ?>
											</div>
											
										</div>

									</div>

									<?php 
									if( $mobileVerificationPage == true && $digitStatus == 'enable' ){ ?>

										<div class="mobile-digits-container"></div>

										<script>
  										
  										jQuery( document ).ready( function(){

  											Digits.init({ consumerKey: "<?php echo $consumerKey; ?>" });

											/* Embed the Digits widget. */

											Digits.embed({
											  	container: '.mobile-digits-container',
											}).fail( verificationFail ).done( verificationSuccess );

  										});

  										// If verification failed reload the page
  										function verificationFail( loginResponse ){
  											location.reload();
  										}

  										// If success
  										function verificationSuccess( loginResponse ){

  											// Send headers to your server and validate user by calling Digits API
		  									var oAuthHeaders = loginResponse.oauth_echo_headers;

		  									jQuery.ajax({

												url : lmhAjax.ajaxUrl,
												type : 'post',
												dataType : 'json',
												data : {
													action : 'extretion_change_mobile_number',
													authHeader: oAuthHeaders['X-Verify-Credentials-Authorization'],
										    		apiUrl: oAuthHeaders['X-Auth-Service-Provider']
												},
												beforeSend : function(){
													jQuery('.mobileNumberTakenWarning').hide();
												},
												success : function( data ){

													if( data.status == 'mobile_no_exists' ){

														jQuery('.mobile-digits-container').empty();
														jQuery('.mobileNumberTakenWarning').show();

														Digits.embed({
														  	container: '.mobile-digits-container',
														}).done( verificationSuccess ).fail( verificationFail );

													} else {
														jQuery('.mobile-digits-container').remove();
														jQuery('.mobileNumberSuccessfullyChanged').show();
													}

												}

											});

  										}
									  	
									  	</script>

										<?php

									} else { ?>	

										<form id="lmh_edit_profile" enctype="multipart/form-data" action="" method="POST" class="mb-50">

											<div class="metro-box-wrapper-1">

												<div class="content">

													<div class="form-horizontal">
														
														<?php 
														extretion_disconnect_from_stripe();
														extretion_validate_stripe();
														extretion_saveprofile();
														extretion_paypal_email_error_message();
														extretion_getRegisterModalFields( $edit = true , $user_meta = true , $post_meta = false );
														?>

													</div>

												</div>

											</div>

										</form>

										<?php
									} ?>								

								</div>

							</div>

						</div>

					</div>

				</div>

			</div>

		</div>

	<?php

	endwhile;

endif;

get_footer();