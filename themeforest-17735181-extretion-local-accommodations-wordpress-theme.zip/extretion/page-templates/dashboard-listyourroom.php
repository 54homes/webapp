<?php
/* Template Name: List Your Room */

if( !is_user_logged_in() ){
	extretion_set404Page();
}

get_header(); ?>

<div id="post-<?php the_ID(); ?>" <?php post_class( "two-tone-layout" ); ?>>
			
	<div class="equal-content-sidebar">
	
		<div class="container">
		
			<div class="sidebar-wrapper">
			
				<aside>
					
					<div class="mb-10"></div>
					
					<?php extretion_getSidebar( 'list_my_room_sidebar' ); ?>
					
				</aside>
				
			</div>
			
			<div class="content-wrapper">
				
				<?php extretion_paypal_email_error_message(); ?>

				<div class="mb-10"></div>

				<form id="listYourRoomForm" method="POST" action="" enctype="multipart/form-data">

					<?php 
					extretion_saveListYourProperty();
					extretion_listYourProperty();
					?>

				</form>
				
				<div class="mb-40"></div>
				
			</div>
		
		</div>

	</div>

</div>

<?php
get_footer();