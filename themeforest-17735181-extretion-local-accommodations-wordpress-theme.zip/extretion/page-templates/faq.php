<?php
/* Template Name: FAQ's */
get_header();

if( have_posts() ): 

	while (have_posts()) : the_post(); ?>

		<div id="post-<?php the_ID(); ?>" <?php post_class("two-tone-layout size-2 left-sidebar"); ?>>
					
			<div class="equal-content-sidebar faq_page">
			
				<div class="container">
				
					<div class="sidebar-wrapper">
					
						<aside>
							<?php 
							$cat = get_post_meta( $post->ID, 'faq_categories' , true ); 
							?>
							<div class="faq-category">
								<h4 class="uppercase"><?php echo esc_html( get_post_meta( $post->ID , 'faq_sidebar_title' , true ) ); ?></h4>
								<div class="content">
									<ul id="faqTab" class="clearfix" role="tablist">

										<?php 
										if( !empty($cat) ){ 

											$first_key = key($cat);
											foreach( $cat as $key => $value ){ 

												$active = ( $first_key == $key ? 'active' : '' ); 

												$category = get_term_by( 'id' , $value , 'faq_cat' ); 
												//print_r($category);

												// Hide empty category
												if( $category->count != 0 ){ ?>

													<li role="presentation" class="<?php echo esc_html( $active ); ?>">
														<a href="#faqTab<?php echo esc_html( $key ); ?>" role="tab" data-toggle="tab" aria-expanded="true"><?php echo esc_html( $category->name ); ?></a>
													</li>
											
													<?php

												}

											} 

										} ?>
									</ul>
								</div>
							</div>
							
						</aside>
						
					</div>
					
					<div class="content-wrapper">

						<div class="section-title mb-20">
							<h2 class="mb-15 text-left"><?php echo esc_html( get_post_meta( $post->ID , 'faq_main_title' , true ) ); ?></h2>
						</div>
						
						<div class="bb"></div>
						<div class="bb"></div>

						<?php 
						$contentPosition = get_post_meta( $post->ID, 'faq_add_content' , true ); 

						if( $contentPosition == 2 ){  
							the_content(); 
						} ?>
						
						<div class="tab-content mt-10 mb-30">
							
							<?php 

							if( !empty($cat) ){  

								$layout = get_post_meta( $post->ID , 'faq_layout' , true ); // Accordion Layout
								$first_key = key($cat);

								foreach( $cat as $key => $value ){ 

									$active = ( $first_key == $key ? 'active' : '' ); 

									$category = get_term_by( 'id' , $value , 'faq_cat' );

									// Hide empty category
									if( $category->count != 0 ){  ?>

										<div role="tabpanel" class="tab-pane <?php echo esc_html( $active ); ?>" id="faqTab<?php echo esc_html( $key ); ?>">
											
											<?php extretion_getFaqCategoryPost( $value , $key , $layout ); ?>								
										</div>

										<?php 

									}

								}							

							} ?>
							
						</div>

						<?php 
						if( $contentPosition == 1 ){  
							the_content(); 
						} 
						?>

					</div>
				
				</div>

			</div>

		</div>

	<?php

	endwhile;

endif;

get_footer();