<?php
/* Template Name: Contact Us */
get_header(); 

if( have_posts() ):

	$address = get_post_meta( $post->ID , 'contact_address' , true );   

	while( have_posts() ): the_post(); ?>

		<div id="post-<?php the_ID(); ?>" <?php post_class("full-contact-map-wrapper map-wrapper"); ?>>
			<div id="contact-map" class="full-contact-map"></div>
			<div class="absolute-contact-info">
				<div class="container">
					<div class="content clearfix">
						<div class="row">
							<div class="col-xs-12 col-sm-6">
								<div class="item">
									<i class="fa fa-map-marker"></i><?php echo esc_html( $address['address'] ); ?>
								</div>
							</div>
							<div class="col-xs-12 col-sm-3">
								<div class="item">
									<i class="fa fa-phone"></i><?php echo esc_html( get_post_meta( $post->ID , 'contact_number' , true ) ); ?>
								</div>
							</div>
							<div class="col-xs-12 col-sm-3">
								<div class="pull-right xs-pull-left">
								<div class="item more-pl">
									<i class="fa fa-envelope"></i> <a href="mailto:<?php echo sanitize_email( get_post_meta( $post->ID , 'email' , true ) ); ?>"><?php echo sanitize_email( get_post_meta( $post->ID , 'email' , true ) ); ?></a>
								</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="container mt-50 mb-50">

			<?php the_content(); ?>
			
		</div>

		<?php

	endwhile;

endif;

get_footer();