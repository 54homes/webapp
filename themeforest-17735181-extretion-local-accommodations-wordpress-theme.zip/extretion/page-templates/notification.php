<?php
/* Template Name: Notification */

if( !is_user_logged_in() ){
	extretion_set404Page();
}

get_header(); ?>

<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					
	<div class="equal-content-sidebar-by-gridLex">
	
		<div class="container">

			<div class="GridLex-grid-noGutter-equalHeight notification_page">
		
				<div class="GridLex-col-3_sm-4_xs-12_xss-12">
					
					<?php extretion_dashboard_sidebar(); ?>
					
				</div>
				
				<div class="GridLex-col-9_sm-8_xs-12_xss-12">

					<div class="content-wrapper">

						<div class="dashboard-content">

							<div class="row">
							
								<div class="col-xs-12 col-sm-10 col-md-9">
									
									<div class="dashboard-heading">
									
										<h3><?php esc_html_e( 'Notifications' , 'extretion' ); ?></h3>
								
									</div>
									
								</div>

							</div>

						</div>

						<div class="notifications_wrapper">

							<?php extretion_get_user_notification_messages(); ?>
							
						</div>

					</div>

				</div>

			</div>

		</div>

	</div>

</div>

<?php
get_footer();