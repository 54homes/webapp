<?php 
/* Template Name: Homepage */
get_header(); 
$defaults = extretion_default_labels(); 

if( have_posts() ): ?>

	<?php

	while( have_posts() ): the_post(); 
		
		/**
		* Custom hook for the user
		*/

		do_action( 'extretion_before_homepage_search' );

		$banner_slider = get_option( 'options_slider_banner' );

		if( empty( $banner_slider ) || $banner_slider == 1 ){
			require_once( get_template_directory() . '/template-parts/homepage-banner.php' );
		} else {
			require_once( get_template_directory() . '/template-parts/homepage-slider.php' );
		}?>

		<div class="clear"></div>

		<?php 

		/**
		* Custom hook for the user
		*/

		do_action( 'extretion_before_static_info_homepage' );

		$info = get_option( 'options_static_info_homepage' ); 

		if( !empty( $info ) ){ ?>

			<div class="post-hero">

				<div class="container">
				
					<div class="row">
					
						<?php 
						echo wp_kses( 
							html_entity_decode( 
								get_option( 'options_static_info_homepage' ) 
							),
							array(
								'div' => array(
									'class' => true
								),
								'i' => array(
									'class' => true
								),
								'a' => array(
							        'href' => true,
							        'title' => true,
							    ),
							    'strong' => array(
							    	'class' => true
							    ),
							    'span' => array(
							    	'class' => true
							    ),
							    'p' => array(
							    	'class' => true
							    ),
							    'h5' => array()
							) 
						); ?>
					
					</div>
					
				</div>

			</div>

			<?php 

		} ?>

		<div class="clear"></div>

		<?php 

		/**
		* Custom hook for the user
		*/
		
		do_action( 'extretion_before_top_destination' );

		$destination_title = esc_html( get_option( 'options_destination_title_home' ) ); 
		$destination_title = !empty( $destination_title ) ? $destination_title : esc_html__( 'Top Destinations' , 'extretion' );

		$destination_status = get_option( 'options_destination_section' );
		$destination_status = !empty( $destination_status ) ? $destination_status : 1;

		$destination_subtitle = esc_html( get_option( 'options_destination_subtitle_home' ) );

		// Get destination categories for homepage
		$categories = extretion_get_homepage_destinations_categories();

		// Get user selected categories
		$user_selected_destination = get_option( 'options_choose_destination_category' ); 
		$user_selected_destination = empty( $user_selected_destination ) ? array() : $user_selected_destination;

		if( !empty( $destination_status ) && $destination_status != 'disable' && ( is_object( $categories ) || is_array( $user_selected_destination ) ) ){ ?>

			<div class="container pt-50 pb-60 home_strip_background">

				<div class="row">
				
						<div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
						
						<div class="section-title">
							<h2 class="home_destination_title"><?php echo esc_html( $destination_title ); ?></h2>

							<?php 
							if( !empty( $destination_subtitle ) ){	?>
								
								<p class="home_destination_subtitle"><?php echo esc_html( $destination_subtitle ); ?></p>
								
								<?php 
							}	?>
						</div>
						
					</div>
					
				</div>
				
				<div class="top-destination-wrapper">

					<div class="row gap-20">
						
						<?php 

						$display_destination = get_option( 'options_display_from_destination' ); 
					
						if( $display_destination != 2 ){

							foreach( $categories as $value ){ 

								extretion_get_the_destination_cat_home( $value );

							}

						} else { 

							if( !empty( $user_selected_destination ) && is_array( $user_selected_destination ) ){

								foreach( $user_selected_destination as $value ){

									$destination_term = get_term_by( 'id', $value, 'destinations' );

									if( is_object( $destination_term ) && $destination_term->parent != 0 ){

										//echo '<pre>'; print_r($destination_term); echo '</pre>';
										extretion_get_the_destination_cat_home( $destination_term );

									}

								}

							} 

						} ?>
						
					</div>

				</div>
				
			</div>

			<?php 

		} 

		/**
		* Custom hook for the user
		*/
		
		do_action( 'extretion_before_popular_accomadation' );

		$accommodation_section = get_option( 'options_accommodation_section' );
		$accommodation_section = !empty( $accommodation_section ) ? $accommodation_section : 1; 

		$limit_accomodation = get_option( 'options_limit_accommodations' ); 
		$limit_accomodation = !empty( $limit_accomodation ) ? esc_html( $limit_accomodation ) : 4;

		$accommodation_room_manually = get_option( 'options_accommodation_room_manually' );

		$args = array(
			'post_type' => 'room',
			'post_status' => 'publish',
			'posts_per_page' => $limit_accomodation,
			'meta_key' => 'lmh_post_views_count',
			'orderby' => 'meta_value_num',
		);

		$args = apply_filters( 'extretion_accommodation_query_homepage' , $args );

		$accommodation_query = new WP_Query( $args ); 

		if( !empty( $accommodation_section ) && $accommodation_section != 'disable' && ( $accommodation_query->have_posts() || is_array( $accommodation_room_manually ) ) ){ 

			$accomoodation_title = esc_html( get_option( 'options_accommodation_title' ) ); 
			$accomoodation_title = empty( $accomoodation_title ) ? esc_html__( 'Popular Accommodations' , 'extretion' ) : $accomoodation_title; 
			$accomoodation_subtitle = esc_html( get_option( 'options_accommodation_subtitle' ) );  

			$display_accommodations = get_option( 'options_display_accommodations_home' ); 

			$accommodation_columns = extretion_get_accomodation_coulmn(); ?>

			<!-- <div class="clear"></div> -->

			<div class="bg-white pt-50 pb-60 home_strip_background">

				<div class="container">
				
					<div class="row">
				
						<div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">

							<div class="section-title">
								<h2 class="home_accomodation_title"><?php echo esc_html( $accomoodation_title ); ?></h2>
								
								<?php 
								if( !empty( $accomoodation_subtitle ) ){ ?>
									<p class="home_accomodation_subtitle"><?php echo esc_html( $accomoodation_subtitle ); ?></p>
									<?php 
								} ?>

							</div>
							
						</div>
					
					</div>
					
					<div class="top-hotel-grid-wrapper">
						
						<div class="row gap-20">
							
							<?php 
							
							$defaults = extretion_default_labels();

							if( $display_accommodations != 1 ){ 

								//echo '<pre>'; print_r($accommodation_query); echo '</pre>';
								
								if( $accommodation_query->have_posts() ):

									while( $accommodation_query->have_posts() ): $accommodation_query->the_post();

										$image = extretion_get_first_image_room( $post->ID );

										extretion_get_grid_view_search( $image , $post , $defaults , $accommodation_columns );

										//echo '<pre>'; print_r($post); echo '</pre>';

									endwhile;

								endif; ?>

								<?php 
								
							} else {

								if( !empty( $accommodation_room_manually ) && is_array( $accommodation_room_manually ) ){

									foreach( $accommodation_room_manually as $value ){

										$acc_post = get_post( $value );

										$image = extretion_get_first_image_room( $acc_post->ID );

										extretion_get_grid_view_search( $image , $acc_post , $defaults , $accommodation_columns );

									}

								}


							} ?>
							
						</div>

					</div>
					
				</div>

			</div>

			<?php 

		} ?>

		<!-- <div class="clear"></div> -->

		<?php 

		/**
		* Custom hook for the user
		*/
		
		do_action( 'extretion_before_sign_up_message' );

		if( !is_user_logged_in() || is_customize_preview() ){ 

			$title_traveller = get_option( 'options_title_for_traveller' );
			$title_traveller = !empty( $title_traveller ) ? esc_html( $title_traveller ) : esc_html__( 'Traveller' , 'extretion' );

			$traveller_content = get_option( 'options_description_for_traveller' );
			$traveller_content = !empty( $traveller_content ) ? esc_html( $traveller_content ) : ''; 

			$title_owner = get_option( 'options_title_for_property_owner' );
			$title_owner = !empty( $title_owner ) ? esc_html( $title_owner ) : esc_html__( 'Property Owner' , 'extretion' ); 

			$owner_content = get_option( 'options_description_for_property_owner' );
			$owner_content = !empty( $owner_content ) ? esc_html( $owner_content ) : ''; ?>

			<div class="overflow-hidden">

				<div class="row gap-0 table-div user_choose">
				
					<div class="col-xs-12 col-sm-6 table-cell-div bg-primary">
					
						<div class="sell-or-buy">
						
							<div class="icon">
								<i class="et-line-briefcase"></i>
							</div>
							
							<div class="clear"></div>
							
							<div class="content">
							
								<h3 class="uppercase home_title_traveler"><?php echo esc_html( $title_traveller ); ?></h3>
								
								<p class="home_subtitle_traveler"><?php echo esc_html( $traveller_content ); ?></p>

								<a class="register_sign_up" href="javascript:void(0)"><?php echo esc_html( $defaults['homepage']['sign_up'] ); ?></a>
								
							</div>
						
						</div>
					
					</div>
					
					<div class="col-xs-12 col-sm-6 table-cell-div bg-warning">
					
						<div class="sell-or-buy">
						
							<div class="icon">
								<i class="et-line-map"></i>
							</div>
							
							<div class="clear"></div>
							
							<div class="content">
							
								<h3 class="uppercase home_title_hotel_owner"><?php echo esc_html( $title_owner ); ?></h3>
								
								<p class="home_subtitle_hotel_owner"><?php echo esc_html( $owner_content ); ?></p>
								
								<a class="register_sign_up" href="javascript:void(0)"><?php echo esc_html( $defaults['homepage']['become_host'] ); ?></a>
								
							</div>
						
						</div>
						
					</div>
				
				</div>

			</div>

			<?php 

		} 

		$testimonial_title = get_option( 'options_testimonial_title' );
		$testimonial_title = !empty( $testimonial_title ) ? esc_html( $testimonial_title ) : esc_html__( 'What people say about us' , 'extretion' ); ?>

		<!-- <div class="clear"></div> -->

		<?php 

		/**
		* Custom hook for the user
		*/
		
		do_action( 'extretion_before_testimonials' );

		$no_of_testimonials_home = get_option( 'options_no_of_testimonials_home' );
		$no_of_testimonials_home = !empty( $no_of_testimonials_home ) ? esc_html( $no_of_testimonials_home ) : 6;

		$order_by_testimonials = get_option( 'options_order_by_testimonials' );
		$order_by_testimonials = !empty( $order_by_testimonials ) ? esc_html( $order_by_testimonials ) : 'date';

			// Check blog section status
		$testimonials_section_status = get_option( 'options_testimonials_section_status' );
		$testimonials_section_status = !empty( $testimonials_section_status ) ? $testimonials_section_status : 1;

		$testimonial_args = array(
			'post_type' => 'testimonials',
			'posts_per_page' => $no_of_testimonials_home,
			'post_status' => 'publish',
			'order_by' => $order_by_testimonials,
			'order' => 'DESC'
		);

		$testimonial_args = apply_filters( 'extretion_testimonials_query_homepage' , $testimonial_args );

		$testimonials_query = new WP_Query( $testimonial_args );

		if( $testimonials_query->have_posts() && $testimonials_section_status != 'disable' ): ?>

			<div class="container1 pt-50 pb-50 home_strip_background">

				<div class="container">

					<div class="row">
					
						<div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
						
							<div class="section-title">
								<h2 class="home_testimonials_title"><?php echo esc_html( $testimonial_title ); ?></h2>
							</div>
							
						</div>
						
					</div>
					
					<div class="row">
					
						<div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
						
							<div class="slick-gallery-slideshow slick-testimonial-wrapper">

								<div class="slider gallery-slideshow slick-testimonial">

									<?php
									while( $testimonials_query->have_posts() ): 

										$testimonials_query->the_post(); ?>

										<div class="slick-item">
								
											<div class="testimonial-long">
											
												<p class="saying">
													<?php 
													echo esc_html( get_post_meta( $post->ID , 'testimonial' , true ) );
													?>
												</p>
												
												<h4 class="uppercase text-primary">
													<?php
													echo esc_html( get_post_meta( $post->ID , 'author_name' , true ) );?>
													
												</h4>
												<p class="he"><?php
												echo esc_html( get_post_meta( $post->ID , 'country' , true ) );?></p>
											
											</div>

										</div>

										<?php

									endwhile; ?>

								</div>

								<div class="clear"></div>

								<div class="slider gallery-nav slick-testimonial-nav alt">

									<?php
									while( $testimonials_query->have_posts() ): $testimonials_query->the_post(); 

										$image_author = get_avatar_url( 0 ); //get_template_directory_uri() . '/images/no-image-square.jpg';
										if( has_post_thumbnail( $post->ID ) ){
											$image_attr = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ) , 'thumbnail' );

											if( $image_attr ){
												$image_author = $image_attr[0];
											}
										} ?>

										<div class="slick-item">
											<div class="testimonial-man">
												<div class="image">
													<img src="<?php echo esc_url( $image_author ); ?>" alt="<?php the_title(); ?>"/>
												</div>
											</div>
										</div>

										<?php

									endwhile; ?>

								</div>

								<div class="clear mb-5"></div>

							</div>

						</div>

					</div>

				</div>

			</div>

			<?php

		endif;
		?>
	
		<!-- <div class="clear"></div> -->

		<?php 

		/**
		* Custom hook for the user
		*/
		
		do_action( 'extretion_before_homepage_blog' );

		$blog_title_home = get_option( 'options_blog_title_home' );
		$blog_title_home = !empty( $blog_title_home ) ? esc_html( $blog_title_home ) : esc_html__( 'Travel Guides &amp; Tips' , 'extretion' );

		$blog_description_home = get_option( 'options_blog_description_home' );

		$no_of_posts_blog = get_option( 'options_no_of_posts_blog' );
		$no_of_posts_blog = !empty( $no_of_posts_blog ) ? esc_html( $no_of_posts_blog ) : 4;

		// Check blog section status
		$blog_section_status = get_option( 'options_blog_section_status' );
		$blog_section_status = !empty( $blog_section_status ) ? $blog_section_status : 1;

		/**
		* Blog Section
		*/

		$blog_args = array(
			'post_type' => 'post',
			'posts_per_page' => $no_of_posts_blog,
			'post_status' => 'publish',
			'order' => 'DESC'
		);

		$blog_args = apply_filters( 'extretion_blog_query_homepage' , $blog_args );

		$blog_query = new WP_Query( $blog_args );

		if( $blog_query->have_posts() && $blog_section_status != 'disable' ): ?>

			<div class="bg-white pt-50 pb-60 home_strip_background">

				<div class="container">
				
					<div class="row">

						<div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
					
							<div class="section-title">
								<h2 class="home_blog_title"><?php echo esc_html( $blog_title_home ); ?></h2>
								<p class="home_blog_subtitle"><?php echo esc_html( $blog_description_home ); ?></p>
							</div>
					
						</div>
						
					</div>

					<div class="recent-post-wrapper">

						<div class="row gap-20">

							<?php

							while( $blog_query->have_posts() ): $blog_query->the_post(); ?>

								<div class="col-xs-12 col-sm-6" data-match-height="recent-post">
							
									<div class="recent-post">
										
										<?php 

										$blog_img = get_template_directory_uri() . '/images/no-image.jpg';

										if( has_post_thumbnail() ){

											$image_attr = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ) , 'extretion_search_page_image' );

											if( $image_attr ){
												$blog_img = $image_attr[0];
											}

											
										}
										?>

										<div class="image" style="background-image:url( <?php echo esc_url( $blog_img ); ?> );"></div>
										
										<div class="content">
										
											<div class="meta">
												<i class="fa fa-calendar"></i> 
												<a href="<?php echo site_url(); ?>/<?php echo date( 'Y/m' , strtotime( get_the_date() ) ); ?>">
													<?php echo get_the_date(); ?>
													
												</a> 
												<span class="mh-5">|</span> 
												<i class="fa fa-user"></i> 
												<a href="<?php echo get_author_posts_url( $post->post_author ); ?>">
													<?php echo get_the_author_meta( 'user_login' , $post->post_author ); ?>
												</a>
											</div>
											
											<h4><?php the_title(); ?></h4>
										
											<?php 
											echo '<p>' . extretion_string_limit_words( wp_strip_all_tags( get_the_content() ) , apply_filters( 'extretion_blog_listing_char_limit' , 15 ) ) . '</p>';
											?>
											
											<a href="<?php the_permalink(); ?>" class="btn-read-more">read more <i class="fa fa-long-arrow-right"></i></a>
											
										</div>
									
									</div>
									
								</div>

								<?php

							endwhile; ?>

						</div>
						
					</div>
				
				</div>

			</div>

			<?php

		endif; ?>

		<!-- <div class="clear"></div> -->

		<?php 
		$instagram_status = get_option( 'options_disable_instagram' );
		$instagram_username = esc_html( get_option( 'options_instagram_username' ) );

		if( $instagram_status != 1 && !empty( $instagram_username ) ){ ?>

			<div class="instagram-full-wrapper home_strip_background">
					
				<div class="container">
				
					<div class="row">
					
						<div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">

							<div class="section-title">
							
								<p class="p-top"><?php esc_html_e( 'Follow us on' , 'extretion' ); ?></p>
								<h4>Instagram <a target="blank" href="https://www.instagram.com/<?php echo esc_html( $instagram_username ); ?>"><i class="fa fa-at"></i> <?php echo esc_html( $instagram_username ); ?></a></h4>
								
							</div>
							
						</div>
						
					</div>
					
				</div>
				
				<div class="instagram-wrapper">
					<div id="instagram" class="instagram"></div>
				</div>
				
			</div>

			<div class="clear"></div>

			<?php

		}

		/**
		* Custom hook for the user
		*/
		
		do_action( 'extretion_before_homepage_footer' ); 

	endwhile; ?>
	
	<?php

endif;

get_footer();