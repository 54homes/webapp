<?php

/**
* Template Name: Messages
*/

if( !is_user_logged_in() ){
	extretion_set404Page();
}

get_header(); ?>

<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					
	<div class="equal-content-sidebar-by-gridLex">
	
		<div class="container">

			<div class="GridLex-grid-noGutter-equalHeight notification_page">
		
				<div class="GridLex-col-3_sm-4_xs-12_xss-12">
					
					<?php extretion_dashboard_sidebar(); ?>
					
				</div>
				
				<div class="GridLex-col-9_sm-8_xs-12_xss-12">

					<div class="content-wrapper">

						<?php 

						$reply_message_id = !empty( $_GET['reply'] ) ? (int) $_GET['reply'] : '';

						$traveler_id = get_post_meta( $reply_message_id, 'sender_id', true );
						$host_id = get_post_meta( $reply_message_id, 'receiver_id', true );

						$current_user_id = get_current_user_id();

						if( $current_user_id == $traveler_id || $current_user_id == $host_id ){

							require_once( get_template_directory() . '/template-parts/message-detail.php' );

						} else{
							require_once( get_template_directory() . '/template-parts/message-list.php' );
						}

						?>

					</div>

				</div>

			</div>

		</div>

	</div>

</div>

<?php
get_footer();