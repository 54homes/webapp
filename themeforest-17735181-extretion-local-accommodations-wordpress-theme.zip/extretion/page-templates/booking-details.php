<?php
/* Template Name: Booking Details ( Step 1 ) */

$post_id = get_query_var( 'post_id', null );
$secret = get_query_var( 'secret', null );
$order_id = extretion_get_order_id( $post_id , $secret );
$user_id = get_current_user_id();
$defaults = extretion_default_labels();
//echo '<pre>'; print_r($order_id); echo '</pre>';

if( $user_id != $order_id['booking_request_by'] || !is_user_logged_in() || extretion_check_secret_key_order( $post_id , $secret ) == false || !empty( $order_id['step_2_attributes'] ) ){
	extretion_set404Page();
} 

get_header(); ?>

<div id="post-<?php the_ID(); ?>" <?php post_class( "two-tone-layout" ); ?>>
			
	<div class="equal-content-sidebar">
	
		<div class="container">
		
			<div id="sticky-sidebar" class="sidebar-wrapper">
			
				<aside>
					
					<div class="mb-10"></div>
					
					<div class="room-page-right-sidebar alt">
					
						<div class="room-page-heading">
					
							<!-- Room Title -->
							<h4><?php echo get_the_title( $post_id ); ?></h4>

							<!-- Hotel Address -->
							<p>
								<i class="fa fa-map-marker"></i>
								<?php 
								echo sanitize_text_field( get_post_meta( $post_id, 'form_place_located_formatted_address', true ) );
								?>
							</p>
							
						</div>
						
						<!-- Room Photo -->
						<?php 
						$photos = get_post_meta( $post_id, 'room_photos', true );
						
						$image_attr = wp_get_attachment_image( $photos[0], 'extretion_booking_page_thumbnail' ); 

						if( $image_attr ){
							echo '<div class="image">' . $image_attr . '</div>';
						} ?>
							
						<div class="content mb-20">
							<h5><?php echo esc_html( $defaults['billing_info_your_dates'] ); ?></h5>
							<ul>
								<li class="clearfix">
									<span class="absolute"><?php echo esc_html( $defaults['billing_info_check_in'] ); ?> </span>
									<?php echo date( 'l , jS \of F Y' , strtotime( $order_id['check_in'] ) ); ?>
								</li>
								<li class="clearfix">
									<span class="absolute"><?php echo esc_html( $defaults['billing_info_check_out'] ); ?> </span>
									<?php echo date( 'l , jS \of F Y' , strtotime( $order_id['check_out'] ) ); ?>
								</li>
							</ul>
						</div>
						<div class="content booking_details_price">
							<h5><?php echo esc_html( $defaults['billing_info_price_title'] ); ?></h5>
							<ul class="inverse">
								<?php echo extretion_get_html_price_booking($order_id); ?>
							</ul>
						</div>

					</div>

					<div class="mb-30"></div>
					
				</aside>
				
			</div>
			
			<div class="content-wrapper">
				
				<div class="mb-10"></div>
				
				<div class="success-box">
				
					<div class="icon">
						
						<span><i class="ri ri-check-square"></i></span>
						
					</div>
					
					<div class="content">
						<h4><?php echo esc_html( $defaults['billing_info_great_choice'] ); ?></h4>
						<p><?php echo esc_html( $defaults['billing_info_fill_all_fields'] ); ?></p>
					</div>
					
				</div>

				<form id="billingInfoForm">
					
				<div class="alert alert-danger mb-30 text-center font600" id="error_message" style="display:none">
					<?php 
					echo wp_kses( 
						$defaults['billing_info_required_fields'], 
						array(
							'span' => array(
								'class' => array()
							)
						) 
					); 
					?>
					
				</div>

					<!-- User Details -->
					<div class="metro-box-wrapper">
					
						<div class="heading">
							<h3><?php echo esc_html( $defaults['billing_info_label'] ); ?></h3>
						</div>

						<div class="content">
						
							<div class="form-horizontal">
								<div class="form-group">
									<label class="col-sm-12 col-md-12 mb-20">
										<?php 
										echo wp_kses( 
											$defaults['billing_info_required_fields'], 
											array(
												'span' => array(
													'class' => array()
												)
											) 
										);  
										?>		 
									</label>
								</div>
								<div class="form-group">
									<label class="col-sm-4 col-md-2 control-label">
										<?php echo esc_html( $defaults['billing_info_first_name'] ); ?>
										<span class="text-danger">*</span>
									</label>
									<div class="col-sm-6 col-md-6">
										<input 
										type="text" 
										class="form-control mb-0" 
										placeholder="<?php echo esc_html( $defaults['billing_info_first_name'] ); ?>" 
										name="firstname" 
										value="<?php echo esc_html( get_the_author_meta( 'first_name' , $user_id ) ); ?>">
										<div class="error_label"></div>
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-4 col-md-2 control-label">
										<?php echo esc_html( $defaults['billing_info_last_name'] ); ?> 
										<span class="text-danger">*</span>
									</label>
									<div class="col-sm-6 col-md-6">
										<input 
										type="text" 
										class="form-control mb-0" 
										placeholder="<?php echo esc_html( $defaults['billing_info_last_name'] ); ?>" 
										name="lastname" 
										value="<?php echo esc_html( get_the_author_meta( 'last_name' , $user_id ) ); ?>">
										<div class="error_label"></div>
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-4 col-md-2 control-label">
										<?php echo esc_html( $defaults['billing_info_email_address'] ); ?> 
										<span class="text-danger">*</span>
									</label>
									<div class="col-sm-6 col-md-6">
										<input 
										type="email" 
										class="form-control mb-0" 
										placeholder="<?php echo esc_html( $defaults['billing_info_email_address'] ); ?>" 
										name="email" 
										value="<?php echo esc_html( get_the_author_meta( 'user_email' , $user_id ) ); ?>" 
										disabled="disabled">
										<div class="error_label"></div>
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-4 col-md-2 control-label">
										<?php echo esc_html( $defaults['billing_info_street_address'] ); ?> 
										<span class="text-danger">*</span>
									</label>
									<div class="col-sm-6 col-md-6">
										<input 
										value="" 
										type="text" 
										class="form-control mb-0" 
										placeholder="<?php echo esc_html( $defaults['billing_info_street_address'] ); ?>" 
										name="street_address">
										<div class="error_label"></div>
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-4 col-md-2 control-label">
										<?php echo esc_html( $defaults['billing_info_postal_code'] ); ?> 
										<span class="text-danger">*</span>
									</label>
									<div class="col-sm-6 col-md-6">
										<input 
										value="<?php echo esc_html( get_user_meta( $user_id, 'form_hotel_located_postal_code' , true ) ); ?>" 
										type="text" 
										class="form-control mb-0" 
										placeholder="<?php echo esc_html( $defaults['billing_info_postal_code'] ); ?>" 
										name="postal_code">
										<div class="error_label"></div>
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-4 col-md-2 control-label">
										<?php echo esc_html( $defaults['billing_info_city'] ); ?> 
										<span class="text-danger">*</span>
									</label>
									<div class="col-sm-6 col-md-6">
										<input 
										value="<?php echo esc_html( get_user_meta( $user_id, 'form_hotel_located_locality' , true ) ); ?>" 
										type="text" 
										class="form-control mb-0" 
										placeholder="<?php echo esc_html( $defaults['billing_info_city'] ); ?>" 
										name="city">
										<div class="error_label"></div>
									</div>
								</div>

								<div class="form-group">
									<label class="col-sm-4 col-md-2 control-label">
										<?php echo esc_html( $defaults['billing_info_country'] ); ?> 
										<span class="text-danger">*</span>
									</label>
									<div class="col-sm-6 col-md-6">
										<select class="selectpicker" data-size="5" name="country" data-live-search="true" autocomplete="off">
											<?php extretion_get_billing_country( $user_id ); ?>
										</select>
										<div class="error_label"></div>
									</div>
								</div>

								<div class="form-group">
									<label class="col-sm-4 col-md-2 control-label">
										<?php echo esc_html( $defaults['billing_info_phone'] ); ?> 
										<span class="text-danger">*</span>
									</label>
									<div class="col-sm-6 col-md-6">
										<input 
										type="text" 
										class="form-control mb-0" 
										placeholder="<?php echo esc_html( $defaults['billing_info_phone'] ); ?>" 
										name="phone" 
										value="<?php echo esc_html( get_user_meta( $user_id, 'phone_no' , true ) ); ?>">
										<div class="error_label"></div>
									</div>
								</div>
							</div>
						
						</div>
					
					</div>
					
					<!-- Guest Details -->
					<?php 
					$guest_info = get_option( 'options_guest_information' ); 
					$guest_info = $guest_info ? $guest_info : 1;

					if( $guest_info == 1 ){ ?>

						<div class="metro-box-wrapper">
						
							<div class="heading">
								<h3><?php echo esc_html( $defaults['guest_info_label'] ); ?></h3>
							</div>

							<div class="content">
								
								<?php 

								$required_fields = get_option( 'options_guest_info_fields' );
								if( empty( $required_fields ) || $required_fields == 1 ){
									$required = true;
								} else {
									$required = false;
								}

								for( $i =1 ; $i <= $order_id['guests'] ; $i++ ){ ?>

									<div class="form-horizontal">
										<div class="form-group">
											<label class="col-sm-4 col-md-3"></label>
											<div class="col-sm-6 col-md-6">
												<h5 class="font700 mb-0 line20 uppercase">
													<?php 
													echo esc_html( $defaults['guest_label'] ); echo ' '.$i; ?>											
												</h5>
											</div>
										</div>
									
										<div class="form-group">
											<label class="col-sm-4 col-md-3 control-label">
												<?php echo esc_html( $defaults['guest_info_first_name'] ); 
												if( $required == true ){
												  	echo ' <span class="text-danger">*</span>';
												}?>
											</label>
											<div class="col-sm-6 col-md-6">
												<input 
												name="guests_fname[<?php echo (int) $i; ?>]" 
												type="text" 
												class="form-control mb-0" 
												placeholder="<?php echo esc_html( $defaults['guest_info_first_name'] ); ?>" 
												value="">
												<div class="error_label"></div>
											</div>
										</div>
										<div class="form-group">
											<label class="col-sm-4 col-md-3 control-label">
												<?php echo esc_html( $defaults['guest_info_last_name'] ); 
												if( $required == true ){
												  	echo ' <span class="text-danger">*</span>';
												}?>
											</label>
											<div class="col-sm-6 col-md-6">
												<input 
												name="guests_lname[<?php echo (int) $i; ?>]" 
												type="text" 
												class="form-control mb-0" 
												placeholder="<?php echo esc_html( $defaults['guest_info_last_name'] ); ?>" 
												value="">
											</div>
										</div>
									</div>
									
									<?php 

									if( $i != $order_id['guests'] ) { ?>

										<div class="clear mb-15"></div>
										<div class="bb"></div>

										<?php 

									}

								} ?>
							
							</div>

						</div>

						<?php 

					} ?>
					
					<div class="payment-congrate">
						
						<div class="inner">
						
							<p class="lead"><?php echo esc_html( $defaults['congratulations_msg'] ); ?>
								<span class="font700">
									<?php 
									$currency_symbol = extretion_currency_symbol( $order_id['currency'] );
									$security_deposit = !empty( $order_id['security_deposit'] ) ? (int) $order_id['security_deposit'] : 0;
									
									$total_price = $order_id['total_price'] + $security_deposit;
									echo '<span class="currency_symbol">' . $currency_symbol . '</span>';
									echo number_format( $total_price , 2, '.', ','); ?>
										
								</span>
							</p>
							<p><?php echo esc_html( $defaults['secure_your_price'] ); ?></p>

							<input type="hidden" value="<?php echo sanitize_text_field( get_query_var( 'post_id' ) ); ?>" name="post_id">
							<input type="hidden" value="<?php echo sanitize_text_field( get_query_var( 'secret' ) ); ?>" name="secret">

							<input type="submit" class="btn book_now_step_2" value="<?php echo esc_html( $defaults['billing_info_book_now_btn'] ); ?> ">
							
							<p class="payment-term">
								<?php
								echo wp_kses(
									$defaults['book_now_rules_step_2'],
									array(
										'a' => array(
											'href' => array(),
											'class' => array(),
										)
									)
								); ?> 
							</p>
							
						</div>
						
					</div>
									
				</form>
				
				<div class="mb-40"></div>
				
			</div>
		
		</div>

	</div>

</div>

<?php
get_footer();