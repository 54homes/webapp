<?php
/* Template Name: Booking Request ( Step 2 ) */

$post_id = get_query_var( 'post_id', null );
$secret = get_query_var( 'secret', null );
$order_id = extretion_get_order_id( $post_id , $secret );
$user_id = get_current_user_id();
$defaults = extretion_default_labels();
//echo '<pre>'; print_r($order_id); echo '</pre>';

if( $user_id != $order_id['booking_request_by'] || !is_user_logged_in() /*|| extretion_check_secret_key_order( $post_id , $secret ) == false */ || empty( $order_id['step_2_attributes'] ) ){
	extretion_set404Page();
} 

get_header(); ?>

<div id="post-<?php the_ID(); ?>" <?php post_class( "container" ); ?>>

	<?php 
	require_once( get_template_directory() . '/template-parts/content-booking-request.php' ); 
	?>

	<div class="text-right mb-50">
	
		<a href="javascript:void(0)" class="btn btn-primary btn-lg btn-icon booking_step_2_confirm btn-booking">
			<?php esc_html_e( 'Send Booking Request' , 'extretion' ); ?>
			<span class="icon">
				<i class="pe-7s-angle-right"></i>
			</span>
		</a>

		<a href="<?php echo extretion_get_my_trips_link();  ?>" class="btn btn-danger btn-lg btn-icon booking_cancal">	
			<?php esc_html_e( 'Cancel' , 'extretion' ); ?>
			<span class="icon">
				<i class="pe-7s-angle-right"></i>
			</span>
		</a>

	</div>

</div>

<?php
get_footer();