<?php
/* Template Name: Change Password */

extretion_checkLoggedInUser();
get_header();

if( have_posts() ): 

	while ( have_posts() ) : the_post(); ?>
		
		<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					
			<div class="equal-content-sidebar-by-gridLex">
			
				<div class="container">

					<div class="GridLex-grid-noGutter-equalHeight">
				
						<div class="GridLex-col-3_sm-4_xs-12_xss-12">
							
							<?php extretion_dashboard_sidebar(); ?>
							
						</div>
						
						<div class="GridLex-col-9_sm-8_xs-12_xss-12">

							<div class="content-wrapper">

								<div class="dashboard-content">

									<div class="row">
									
										<div class="col-xs-12 col-sm-10 col-md-9">
											
											<div class="dashboard-heading">
											
												<h3><?php esc_html_e( 'Change Password' , 'extretion' ); ?></h3>
										
											</div>
											
										</div>

									</div>

									<?php extretion_paypal_email_error_message(); ?>

									<form id="lmh_change_password" class="form-horizontal metro-box-wrapper-1">
									
										<div class="row">
											
											<div class="col-xss-12 col-xs-12 col-sm-12 col-md-12 change_pass_error_wrapper" style="display:none">
												<div class="form-group">
													<div class="col-sm-6 col-md-6">
														<ul class="login_modal_error change_pass_error"></ul>
													</div>
												</div>
											</div>

											<div class="col-xss-12 col-xs-12 col-sm-12 col-md-12">
											
												<div class="form-group">
																									
													<div class="col-sm-6 col-md-6">
														<input autocomplete="off" type="password" name="old_password" class="old_password mb-5 form-control" placeholder="<?php esc_html_e( 'Old Password' , 'extretion' ); ?>" />
													</div>

												</div>
												
											</div>
											
											<div class="clear"></div>
											
											<div class="col-xss-12 col-xs-12 col-sm-12 col-md-12">
											
												<div class="form-group">
																									
													<div class="col-sm-6 col-md-6">
														<input autocomplete="off" type="password" name="new_password" class="new_password mb-5 form-control" placeholder="<?php esc_html_e( 'New Password' , 'extretion' ); ?>" />
													</div>

												</div>
												
											</div>
										
											<div class="clear"></div>

											<div class="col-xss-12 col-xs-12 col-sm-12 col-md-12">
											
												<div class="form-group">
																									
													<div class="col-sm-6 col-md-6">
														<input autocomplete="off" type="password" name="confirm_password" class="confirm_password mb-5 form-control" placeholder="<?php esc_html_e( 'Confirm New Password' , 'extretion' ); ?>" />
													</div>

												</div>
												
											</div>
										
											<div class="clear"></div>
											
											<div class="col-xs-12 col-sm-6 col-md-5">
											
												<input type="submit" class="btn btn-danger lmh_change_password" value="<?php esc_html_e( 'Save', 'extretion' ); ?>" autocomplete="off">
											
											</div>
											
										</div>
										
									</form>

								</div>

							</div>

						</div>

					</div>

				</div>

			</div>

		</div>

	<?php
	endwhile;

endif;
get_footer();