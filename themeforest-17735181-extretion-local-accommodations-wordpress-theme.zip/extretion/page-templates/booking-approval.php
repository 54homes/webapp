<?php
/* Template Name: Booking Approval ( Step 3 ) */

$invoice_id = get_query_var( 'post_id', null ); // Get invoice id
$hotel_id = get_post_meta( $invoice_id, 'hotel_owner', true ); // Get hotel owner id
$order_id = get_post_meta( $invoice_id, 'invoice_details', true ); // Get invoice details
$user_id = get_current_user_id();
$invoice_details = get_post( $invoice_id ); // Get invoice objects
$payment_status = get_post_meta( $invoice_id, 'payment_status', true );

if( !is_user_logged_in() || !is_object( $invoice_details ) || extretion_booking_page_privelage( $invoice_details , $user_id , $hotel_id ) == false || $payment_status != 'pending_approval' ){
	extretion_set404Page(); // Set 404 error
}

$post_id = $order_id['post_id']; // Get room id
$defaults = extretion_default_labels(); // Get defaults labels

get_header(); ?>

<div id="post-<?php the_ID(); ?>" <?php post_class( "container" ); ?>>

	<?php 
	
	require_once( get_template_directory() . '/template-parts/content-booking-request.php' ); 

	/**
	* Show section to the traveller
	*/

	if( $payment_status == 'pending_approval' && $invoice_details->post_author == $user_id ){ ?>

		<div class="alert alert-info mb-25">
			<?php esc_html_e( 'Status : Pending Approval' , 'extretion' ); ?>
		</div>

			<div class="text-right mb-50">

				<a href="javascript:void(0)" class="btn btn-danger btn-lg btn-icon cancel_contract_traveller" onclick="jQuery('#traveller_cancel_booking').modal('show')">	
					<?php esc_html_e( 'Cancel Booking' , 'extretion' ); ?>
					<span class="icon">
						<i class="pe-7s-angle-right"></i>
					</span>
				</a>

			</div>

		<?php
	} 

	/**
	* Show section to the hotel owner
	*/

	elseif( $payment_status == 'pending_approval' && $user_id == $hotel_id  ){ ?>

		<div class="alert alert-info mb-25">
			<?php esc_html_e( 'Status : Pending Approval' , 'extretion' ); ?>
		</div>

		<div class="text-right mb-50">

			<a href="javascript:void(0)" class="btn btn-primary btn-lg btn-icon accept_contract_by_hotel btn-booking">	
				<?php esc_html_e( 'Accept Guest' , 'extretion' ); ?>
				<span class="icon">
					<i class="pe-7s-angle-right"></i>
				</span>
			</a>

			<a href="javascript:void(0)" class="btn btn-danger btn-lg btn-icon cancel_contract_by_hotel" onclick="jQuery('#hotel_cancel_booking').modal('show')">	
				<?php esc_html_e( 'Reject Guest' , 'extretion' ); ?>
				<span class="icon">
					<i class="pe-7s-angle-right"></i>
				</span>
			</a>

		</div>

		<?php
	}
	?>

</div>

<?php
get_footer();