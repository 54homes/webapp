<?php
get_header(); 
get_template_part( 'template-parts/content', 'blog' ); 
get_footer();