<?php 

if ( !class_exists( 'Kirki' ) ) {
	return;
}

add_action( 'init' , 'extretion_get_kirki_fields' );

function extretion_get_kirki_fields(){

	Kirki::add_config( 'my_theme', 
		array(
			'capability'    => 'edit_theme_options',
			'option_type'   => 'theme_mod',
		)
	);

	/******************************************
	* Theme Settings Section
	*******************************************/

	Kirki::add_section( 'theme-settings' ,
		array(
		    'title'          => __( 'Theme Settings' , 'extretion' ),
		    'description'    => __( '' , 'extretion' ),
		    'panel'          => '',
		    'priority'       => 1,
		    'capability'     => 'edit_theme_options',
		    'type'           => ''
		) 
	);

	/**
	* Radio Buttonset Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_header_preloader',
			'label'    => __( 'Preloader' , 'extretion' ),
			'section'  => 'theme-settings',
			'type'     => 'radio-buttonset',
			'priority' => 2,
			'default'  => '1',
			'option_type' => 'option',
			'choices' => array(
	 			'1' => __( 'Enable' , 'extretion' ),
	 			'2' => __( 'Disable' , 'extretion' ),
	 		),
			'transport' => 'refresh'
		) 
	);

	/**
	* Radio Buttonset Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_header_logo_text',
			'label'    => __( 'Header Logo / Text' , 'extretion' ),
			'section'  => 'theme-settings',
			'type'     => 'radio-buttonset',
			'priority' => 2,
			'description' => __( '' , 'extretion' ),
			'default'  => '1',
			'tooltip' => __( 'Choose between header logo or text' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'1' => __( 'Text' , 'extretion' ),
	 			'2' => __( 'Image' , 'extretion' ),
	 		),
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* Text Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_header_text',
			'label'    => __( 'Header Text' , 'extretion' ),
			'section'  => 'theme-settings',
			'type'     => 'text',
			'priority' => 3,
			'description' => __( '' , 'extretion' ),
			'default'  => 'Extretion',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => array(
				array(
					'setting'  => 'options_header_logo_text',
					'operator' => '==',
					'value'    => '1',
				),
			),
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => 'a.navbar-brand',
					'function' => 'html',
				),
			)
		) 
	);

	/**
	* Image Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_header_logo',
			'label'    => __( 'Header Logo' , 'extretion' ),
			'section'  => 'theme-settings',
			'type'     => 'image',
			'priority' => 4,
			'description' => __( '' , 'extretion' ),
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => array(
				array(
					'setting'  => 'options_header_logo_text',
					'operator' => '==',
					'value'    => '2',
				),
			),
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* Number Field
	*/
			
	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_commision_rate',
			'label'    => __( 'Commission Rate ( in % )' , 'extretion' ),
			'section'  => 'theme-settings',
			'type'     => 'number',
			'priority' => 5,
			'description' => __( 'This is the commission rate you will get for the room bookings. eg if user puts <code>100 USD</code> for his room, the total price will be <code>110 USD</code> if commission rate is <code>10%</code> where you will get <code>10 USD</code>.' , 'extretion' ),
			'default'  => '10',
			'choices' => array(
				'min'  => '1',
				'max'  => '100'
			),
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* select Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_base_currency',
			'label'    => __( 'Default Currency' , 'extretion' ),
			'section'  => 'theme-settings',
			'type'     => 'select',
			'priority' => 6,
			'description' => __( '' , 'extretion' ),
			'default'  => array(
				'0' => 'USD',
					),
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'ALL' => __( 'Albania Lek ( ALL )' , 'extretion' ),
	 			'AFN' => __( 'Afghanistan Afghani ( AFN )' , 'extretion' ),
	 			'ARS' => __( 'Argentina Peso ( ARS )' , 'extretion' ),
	 			'AWG' => __( 'Aruba Guilder ( AWG )' , 'extretion' ),
	 			'AUD' => __( 'Australia Dollar ( AUD )' , 'extretion' ),
	 			'BSD' => __( 'Bahamas Dollar ( BSD )' , 'extretion' ),
	 			'AZN' => __( 'Azerbaijan New Manat ( AZN )' , 'extretion' ),
	 			'BBD' => __( 'Barbados Dollar ( BBD )' , 'extretion' ),
	 			'BDT' => __( 'Bangladeshi taka ( BDT )' , 'extretion' ),
	 			'BYR' => __( 'Belarus Ruble ( BYR )' , 'extretion' ),
	 			'BZD' => __( 'Belize Dollar ( BZD )' , 'extretion' ),
	 			'BMD' => __( 'Bermuda Dollar ( BMD )' , 'extretion' ),
	 			'BOB' => __( 'Bolivia Boliviano ( BOB )' , 'extretion' ),
	 			'BAM' => __( 'Bosnia and Herzegovina Convertible Marka ( BAM )' , 'extretion' ),
	 			'BWP' => __( 'Botswana Pula ( BWP )' , 'extretion' ),
	 			'BGN' => __( 'Bulgaria Lev ( BGN )' , 'extretion' ),
	 			'BRL' => __( 'Brazil Real ( BRL )' , 'extretion' ),
	 			'BND' => __( 'Brunei Darussalam Dollar ( BND )' , 'extretion' ),
	 			'KHR' => __( 'Cambodia Riel ( KHR )' , 'extretion' ),
	 			'CAD' => __( 'Canada Dollar ( CAD )' , 'extretion' ),
	 			'KYD' => __( 'Cayman Islands Dollar ( KYD )' , 'extretion' ),
	 			'CLP' => __( 'Chile Peso ( CLP )' , 'extretion' ),
	 			'CNY' => __( 'China Yuan Renminbi ( CNY )' , 'extretion' ),
	 			'COP' => __( 'Colombia Peso ( COP )' , 'extretion' ),
	 			'CRC' => __( 'Costa Rica Colon ( CRC )' , 'extretion' ),
	 			'HRK' => __( 'Croatia Kuna ( HRK )' , 'extretion' ),
	 			'CUP' => __( 'Cuba Peso ( CUP )' , 'extretion' ),
	 			'CZK' => __( 'Czech Republic Koruna ( CZK )' , 'extretion' ),
	 			'DKK' => __( 'Denmark Krone ( DKK )' , 'extretion' ),
	 			'DOP' => __( 'Dominican Republic Peso ( DOP )' , 'extretion' ),
	 			'XCD' => __( 'East Caribbean Dollar ( XCD )' , 'extretion' ),
	 			'EGP' => __( 'Egypt Pound ( EGP )' , 'extretion' ),
	 			'SVC' => __( 'El Salvador Colon ( SVC )' , 'extretion' ),
	 			'EUR' => __( 'Euro Member Countries ( EUR )' , 'extretion' ),
	 			'FKP' => __( 'Falkland Islands (Malvinas) Pound ( FKP )' , 'extretion' ),
	 			'FJD' => __( 'Fiji Dollar ( FJD )' , 'extretion' ),
	 			'GNF' => __( 'Guinean Franc ( GNF )' , 'extretion' ),
	 			'GIP' => __( 'Gibraltar Pound ( GIP )' , 'extretion' ),
	 			'GTQ' => __( 'Guatemala Quetzal ( GTQ )' , 'extretion' ),
	 			'GYD' => __( 'Guyana Dollar ( GYD )' , 'extretion' ),
	 			'HNL' => __( 'Honduras Lempira ( HNL )' , 'extretion' ),
	 			'HKD' => __( 'Hong Kong Dollar ( HKD )' , 'extretion' ),
	 			'HUF' => __( 'Hungary Forint ( HUF )' , 'extretion' ),
	 			'ISK' => __( 'Iceland Krona ( ISK )' , 'extretion' ),
	 			'INR' => __( 'India Rupee ( INR )' , 'extretion' ),
	 			'IDR' => __( 'Indonesia Rupiah ( IDR )' , 'extretion' ),
	 			'IRR' => __( 'Iran Rial ( IRR )' , 'extretion' ),
	 			'ILS' => __( 'Israel Shekel ( ILS )' , 'extretion' ),
	 			'JMD' => __( 'Jamaica Dollar ( JMD )' , 'extretion' ),
	 			'JPY' => __( 'Japan Yen ( JPY )' , 'extretion' ),
	 			'KZT' => __( 'Kazakhstan Tenge ( KZT )' , 'extretion' ),
	 			'KPW' => __( 'Korea (North) Won ( KPW )' , 'extretion' ),
	 			'KRW' => __( 'Korea (South) Won ( KRW )' , 'extretion' ),
	 			'KGS' => __( 'Kyrgyzstan Som ( KGS )' , 'extretion' ),
	 			'LAK' => __( 'Laos Kip ( LAK )' , 'extretion' ),
	 			'LVL' => __( 'Latvia Lat ( LVL )' , 'extretion' ),
	 			'LBP' => __( 'Lebanon Pound ( LBP )' , 'extretion' ),
	 			'LRD' => __( 'Liberia Dollar ( LRD )' , 'extretion' ),
	 			'LTL' => __( 'Lithuania Litas ( LTL )' , 'extretion' ),
	 			'MKD' => __( 'Macedonia Denar ( MKD )' , 'extretion' ),
	 			'MYR' => __( 'Malaysia Ringgit ( MYR )' , 'extretion' ),
	 			'MUR' => __( 'Mauritius Rupee ( MUR )' , 'extretion' ),
	 			'MXN' => __( 'Mexico Peso ( MXN )' , 'extretion' ),
	 			'MNT' => __( 'Mongolia Tughrik ( MNT )' , 'extretion' ),
	 			'MZN' => __( 'Mozambique Metical ( MZN )' , 'extretion' ),
	 			'NAD' => __( 'Namibia Dollar ( NAD )' , 'extretion' ),
	 			'NPR' => __( 'Nepal Rupee ( NPR )' , 'extretion' ),
	 			'ANG' => __( 'Netherlands Antilles Guilder ( ANG )' , 'extretion' ),
	 			'NZD' => __( 'New Zealand Dollar ( NZD )' , 'extretion' ),
	 			'NIO' => __( 'Nicaragua Cordoba ( NIO )' , 'extretion' ),
	 			'NGN' => __( 'Nigeria Naira ( NGN )' , 'extretion' ),
	 			'NOK' => __( 'Norway Krone ( NOK )' , 'extretion' ),
	 			'OMR' => __( 'Oman Rial ( OMR )' , 'extretion' ),
	 			'PKR' => __( 'Pakistan Rupee ( PKR )' , 'extretion' ),
	 			'PAB' => __( 'Panama Balboa ( PAB )' , 'extretion' ),
	 			'PYG' => __( 'Paraguay Guarani ( PYG )' , 'extretion' ),
	 			'PEN' => __( 'Peru Nuevo Sol ( PEN )' , 'extretion' ),
	 			'PHP' => __( 'Philippines Peso ( PHP )' , 'extretion' ),
	 			'PLN' => __( 'Poland Zloty ( PLN )' , 'extretion' ),
	 			'QAR' => __( 'Qatar Riyal ( QAR )' , 'extretion' ),
	 			'RON' => __( 'Romania New Leu ( RON )' , 'extretion' ),
	 			'RUB' => __( 'Russia Ruble ( RUB )' , 'extretion' ),
	 			'SHP' => __( 'Saint Helena Pound ( SHP )' , 'extretion' ),
	 			'SAR' => __( 'Saudi Arabia Riyal ( SAR )' , 'extretion' ),
	 			'RSD' => __( 'Serbia Dinar ( RSD )' , 'extretion' ),
	 			'SCR' => __( 'Seychelles Rupee ( SCR )' , 'extretion' ),
	 			'SGD' => __( 'Singapore Dollar ( SGD )' , 'extretion' ),
	 			'SBD' => __( 'Solomon Islands Dollar ( SBD )' , 'extretion' ),
	 			'SOS' => __( 'Somalia Shilling ( SOS )' , 'extretion' ),
	 			'ZAR' => __( 'South Africa Rand ( ZAR )' , 'extretion' ),
	 			'LKR' => __( 'Sri Lanka Rupee ( LKR )' , 'extretion' ),
	 			'SEK' => __( 'Sweden Krona ( SEK )' , 'extretion' ),
	 			'CHF' => __( 'Switzerland Franc ( CHF )' , 'extretion' ),
	 			'SRD' => __( 'Suriname Dollar ( SRD )' , 'extretion' ),
	 			'SYP' => __( 'Syria Pound ( SYP )' , 'extretion' ),
	 			'TWD' => __( 'Taiwan New Dollar ( TWD )' , 'extretion' ),
	 			'THB' => __( 'Thailand Baht ( THB )' , 'extretion' ),
	 			'TTD' => __( 'Trinidad and Tobago Dollar ( TTD )' , 'extretion' ),
	 			'TRY' => __( 'Turkey Lira ( TRY )' , 'extretion' ),
	 			'UAH' => __( 'Ukraine Hryvna ( UAH )' , 'extretion' ),
	 			'GBP' => __( 'United Kingdom Pound ( GBP )' , 'extretion' ),
	 			'UGX' => __( 'Uganda Shilling ( UGX )' , 'extretion' ),
	 			'USD' => __( 'United States Dollar ( USD )' , 'extretion' ),
	 			'UYU' => __( 'Uruguay Peso ( UYU )' , 'extretion' ),
	 			'UZS' => __( 'Uzbekistan Som ( UZS )' , 'extretion' ),
	 			'VEF' => __( 'Venezuela Bolivar ( VEF )' , 'extretion' ),
	 			'VND' => __( 'Viet Nam Dong ( VND )' , 'extretion' ),
	 			'XOF' => __( 'West African CFA franc ( XOF )' , 'extretion' ),
	 			'YER' => __( 'Yemen Rial ( YER )' , 'extretion' ),
	 		),
			'multiple' => '1',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* select Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_refresh_currency_after',
			'label'    => __( 'Refresh Currency Interval' , 'extretion' ),
			'section'  => 'theme-settings',
			'type'     => 'select',
			'priority' => 7,
			'description' => __( 'The currencies are save on the database and will be updated after certain time. Please choose your interval time.' , 'extretion' ),
			'default'  => '7200',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'7200' => __( '2 Hours' , 'extretion' ),
	 			'14400' => __( '4 Hours' , 'extretion' ),
	 			'28800' => __( '8 Hours' , 'extretion' ),
	 			'57600' => __( '16 Hours' , 'extretion' ),
	 			'86400' => __( '1 Day' , 'extretion' ),
	 		),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* Color Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_theme_colour',
			'label'    => __( 'Theme Color' , 'extretion' ),
			'section'  => 'theme-settings',
			'type'     => 'color',
			'priority' => 8,
			'description' => __( 'Primary color for this theme' , 'extretion' ),
			'default'  => '#005294',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'alpha' => true,
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* Color Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_secondary_theme_colour',
			'label'    => __( 'Secondary Theme Color' , 'extretion' ),
			'section'  => 'theme-settings',
			'type'     => 'color',
			'priority' => 9,
			'description' => __( '' , 'extretion' ),
			'default'  => '#D60D35',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'alpha' => true,
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* Text Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_hot_line',
			'label'    => __( 'Hot Line' , 'extretion' ),
			'section'  => 'theme-settings',
			'type'     => 'text',
			'priority' => 10,
			'description' => __( 'Your hotline/phone number' , 'extretion' ),
			'default'  => '9849-xx-xxx',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* select Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_blog_listing_pagination',
			'label'    => __( 'Pagination Style' , 'extretion' ),
			'section'  => 'theme-settings',
			'type'     => 'select',
			'priority' => 11,
			'description' => __( '' , 'extretion' ),
			'default'  => '1',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'1' => __( 'Default' , 'extretion' ),
	 			'2' => __( 'Numbered' , 'extretion' ),
	 		),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* Color Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'header_background',
			'label'    => __( 'Header Background' , 'extretion' ),
			'section'  => 'theme-settings',
			'type'     => 'color',
			'priority' => 12,
			'default'  => '#000',
			'option_type' => 'option',
			'alpha' => true,
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.with-navbar-top-bottom .navbar-top,.colored-navbar-brand .navbar-default .navbar-brand::before,.colored-navbar-brand .navbar-default .navbar-brand,.with-navbar-top-bottom .navbar-top .navbar-mini > ul > li',
					'function' => 'css',
					'property' => 'background',
					'suffix' => ' !important'
				),
				array(
					'element' => '.with-navbar-top-bottom .navbar-top .navbar-mini > ul > li',
					'function' => 'css',
					'property' => 'border-right',
					'suffix' => ' !important',
					'prefix' => '1px solid '
				),
				array(
					'element' => '.with-navbar-top-bottom .navbar-top .navbar-mini > ul',
					'function' => 'css',
					'property' => 'border-left',
					'suffix' => ' !important',
					'prefix' => '1px solid '
				),
			),
			'output' => array(
				array(
					'element' => '.with-navbar-top-bottom .navbar-top,.colored-navbar-brand .navbar-default .navbar-brand::before,.colored-navbar-brand .navbar-default .navbar-brand,.with-navbar-top-bottom .navbar-top .navbar-mini > ul > li',
					'property' => 'background',
					//'suffix' => ' !important',
					//'media_query' => '@media (min-width: 480px)',
				),
				array(
					'element' => '.with-navbar-top-bottom .navbar-top .navbar-mini > ul > li',
					'property' => 'border-right',
					//'suffix' => ' !important',
					'prefix' => '1px solid ',
					//'media_query' => '@media (min-width: 480px)',
				),
				array(
					'element' => '.with-navbar-top-bottom .navbar-top .navbar-mini > ul',
					'property' => 'border-left',
					//'suffix' => ' !important',
					'prefix' => '1px solid ',
					//'media_query' => '@media (min-width: 480px)',
				),
			),
		) 
	);

	/**
	* Color Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'footer_background',
			'label'    => __( 'Footer Background' , 'extretion' ),
			'section'  => 'theme-settings',
			'type'     => 'color',
			'priority' => 12,
			'default'  => '#111111',
			'option_type' => 'option',
			'alpha' => true,
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => 'footer.main-footer',
					'function' => 'css',
					'property' => 'background',
					'suffix' => ' !important'
				),
			),
			'output' => array(
				array(
					'element'  => 'footer.main-footer',
					'property' => 'background',
					'suffix' => ' !important'
				)
			),
		) 
	);

	Kirki::add_field( 'my_theme', array(
		'type'        => 'radio-buttonset',
		'settings'    => 'digits_status',
		'label'       => __( 'Digits', 'extretion' ),
		'section'     => 'theme-settings',
		'default'     => 'disable',
		'priority'    => 13,
		'option_type' => 'option',
		'choices'     => array(
			'enable'  => esc_attr__( 'Enable', 'extretion' ),
			'disable' => esc_attr__( 'Disable', 'extretion' ),
		),
		'description' => 'Digits is a free, white labeled solution for verifying your users through their phone numbers - without the headache of passwords.'
	) );

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_consumerKey',
			'label'    => __( 'Digits Consumer Key' , 'extretion' ),
			'section'  => 'theme-settings',
			'type'     => 'text',
			'option_type' => 'option',
			'description' => 'This key will be used by <a target="_blank" href="https://get.digits.com/">digits</a> for mobile verifications.',
			'priority' => 14,
			'active_callback'    => array(
				array(
					'setting'  => 'digits_status',
					'operator' => '==',
					'value'    => 'enable',
				),
			),
		) 
	);

	/******************************************
	* Homepage Panel
	*******************************************/

	Kirki::add_panel( 'homepage' ,
		array(
		    'title'          => __( 'Homepage' , 'extretion' ),
		    'description'    => __( 'This panel controls all the homepage settings.' , 'extretion' ),
		    'priority'       => 12,
		) 
	);

	/******************************************
	* Banner / Slider Section
	*******************************************/

	Kirki::add_section( 'banner-slider-section' ,
		array(
		    'title'          => __( 'Banner / Slider' , 'extretion' ),
		    'description'    => __( '' , 'extretion' ),
		    'panel'          => 'homepage',
		    'priority'       => 13,
		    'capability'     => 'edit_theme_options',
		    'type'           => ''
		) 
	);

	/**
	* Radio Buttonset Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_slider_banner',
			'label'    => __( 'Slider / Banner' , 'extretion' ),
			'section'  => 'banner-slider-section',
			'type'     => 'radio-buttonset',
			'priority' => 14,
			'description' => __( '' , 'extretion' ),
			'default'  => '1',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'1' => __( 'Banner' , 'extretion' ),
	 			'2' => __( 'Slider' , 'extretion' ),
	 		),
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_slider_autoplayspeed',
			'label'    => __( 'Auto Play Speed ( in millisecond )' , 'extretion' ),
			'description' => __( '1000 ms = 1 second' , 'extretion' ),
			'section'  => 'banner-slider-section',
			'type'     => 'text',
			'priority' => 16,
			'default'  => 4500,
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => array(
				array(
					'setting'  => 'options_slider_banner',
					'operator' => '==',
					'value'    => 2,
				),
			),
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_slider_dots',
			'label'    => __( 'Dots' , 'extretion' ),
			'section'  => 'banner-slider-section',
			'type'     => 'radio-buttonset',
			'priority' => 17,
			'default'  => true,
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => array(
				array(
					'setting'  => 'options_slider_banner',
					'operator' => '==',
					'value'    => 2,
				),
			),
			'choices' => array(
	 			true => __( 'Enable' , 'extretion' ),
	 			false => __( 'Disable' , 'extretion' ),
	 		),
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_slider_slide_speed',
			'label'    => __( 'Slide Speed ( in millisecond )' , 'extretion' ),
			'section'  => 'banner-slider-section',
			'description' => __( '1000 ms = 1 second' , 'extretion' ),
			'type'     => 'text',
			'priority' => 18,
			'default'  => 500,
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => array(
				array(
					'setting'  => 'options_slider_banner',
					'operator' => '==',
					'value'    => 2,
				),
			),
		) 
	);

	/**
	* Image Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_banner_homepage',
			'label'    => __( 'Banner Image' , 'extretion' ),
			'section'  => 'banner-slider-section',
			'type'     => 'image',
			'priority' => 15,
			'description' => __( '' , 'extretion' ),
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => array(
				array(
					'setting'  => 'options_slider_banner',
					'operator' => '==',
					'value'    => '1',
				),
			),
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* Text Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_banner_title',
			'label'    => __( 'Banner Title' , 'extretion' ),
			'section'  => 'banner-slider-section',
			'type'     => 'text',
			'priority' => 16,
			'description' => __( '' , 'extretion' ),
			'default'  => 'Live There',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => array(
				array(
					'setting'  => 'options_slider_banner',
					'operator' => '==',
					'value'    => '1',
				),
			),
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.hero-texting h1',
					'function' => 'html',
				),
			)
		) 
	);

	/**
	* Textarea Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_subtitle_homepage',
			'label'    => __( 'Banner Subtitle' , 'extretion' ),
			'section'  => 'banner-slider-section',
			'type'     => 'textarea',
			'priority' => 17,
			'description' => __( '' , 'extretion' ),
			'default'  => 'If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text.',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => array(
				array(
					'setting'  => 'options_slider_banner',
					'operator' => '==',
					'value'    => '1',
				),
			),
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.extretion_banner_subtitle',
					'function' => 'html',
				),
			)
		) 
	);

	/******************************************
	* Static Info Section
	*******************************************/

	Kirki::add_section( 'static-info-section' ,
		array(
		    'title'          => __( 'Static Info' , 'extretion' ),
		    'description'    => __( '' , 'extretion' ),
		    'panel'          => 'homepage',
		    'priority'       => 18,
		    'capability'     => 'edit_theme_options',
		    'type'           => ''
		) 
	);

	/**
	* Textarea Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_static_info_homepage',
			'label'    => __( 'Static Info' , 'extretion' ),
			'section'  => 'static-info-section',
			'type'     => 'textarea',
			'priority' => 19,
			'description' => __( 'This section will be displayed after the banner.' , 'extretion' ),
			'default'  => '<div class="col-sm-4"> 						 						<div class="featured-item-03 clearfix"> 						 							<div class="icon"> 								<i class="et-line-trophy"></i> 							</div> 							 							<div class="content"> 							 								<h5>Quality Assured</h5> 								<p>So by colonel hearted ferrars. Draw from upon here gone add one. He in sportsman household otherwise.</p> 								 							</div> 							 						</div> 					 					</div>  					<div class="col-sm-4"> 						 						<div class="featured-item-03 clearfix"> 						 							<div class="icon"> 								<i class="et-line-wallet"></i> 							</div> 							 							<div class="content"> 							 								<h5>Book Now, Pay Later</h5> 								<p>Whatever throwing we on resolved entrance together graceful. Mrs assured add private married removed.</p> 								 							</div> 							 						</div> 					 					</div> 					 					<div class="col-sm-4"> 						 						<div class="featured-item-03 clearfix"> 						 							<div class="icon"> 								<i class="et-line-heart"></i> 							</div> 							 							<div class="content"> 							 								<h5>We Care, You Happy</h5> 								<p>Dependent certainty off discovery him his tolerably offending. Ham for attention remainder sometimes.</p> 								 							</div> 							 						</div> 					 					</div>',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/******************************************
	* Destination Section
	*******************************************/

	Kirki::add_section( 'destination-section' ,
		array(
		    'title'          => __( 'Destination' , 'extretion' ),
		    'description'    => __( '' , 'extretion' ),
		    'panel'          => 'homepage',
		    'priority'       => 20,
		    'capability'     => 'edit_theme_options',
		    'type'           => ''
		) 
	);

	/**
	* Radio Buttonset Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_destination_section',
			'label'    => __( 'Destination Section' , 'extretion' ),
			'section'  => 'destination-section',
			'type'     => 'radio-buttonset',
			'priority' => 21,
			'description' => __( '' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'enable' => __( 'Enable' , 'extretion' ),
	 			'disable' => __( 'Disable' , 'extretion' ),
	 		),
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* Text Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_destination_title_home',
			'label'    => __( 'Title' , 'extretion' ),
			'section'  => 'destination-section',
			'type'     => 'text',
			'priority' => 22,
			'description' => __( '' , 'extretion' ),
			'default'  => 'Top Destinations',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.home_destination_title',
					'function' => 'html',
				),
			),
			'active_callback'    => array(
				array(
					'setting'  => 'options_destination_section',
					'operator' => '==',
					'value'    => 'enable',
				),
			),
		) 
	);

	/**
	* Textarea Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_destination_subtitle_home',
			'label'    => __( 'Subtitle' , 'extretion' ),
			'section'  => 'destination-section',
			'type'     => 'textarea',
			'priority' => 23,
			'description' => __( '' , 'extretion' ),
			'default'  => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.home_destination_subtitle',
					'function' => 'html',
				),
			),
			'active_callback'    => array(
				array(
					'setting'  => 'options_destination_section',
					'operator' => '==',
					'value'    => 'enable',
				),
			),
		) 
	);

	/**
	* Radio Buttonset Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_display_from_destination',
			'label'    => __( 'Display Destination' , 'extretion' ),
			'section'  => 'destination-section',
			'type'     => 'radio-buttonset',
			'priority' => 24,
			'description' => __( 'Select how destinations will be displayed.' , 'extretion' ),
			'default'  => '1',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'1' => __( 'Automatically' , 'extretion' ),
	 			'2' => __( 'Manually' , 'extretion' ),
	 		),
			'transport' => 'refresh',
			'js_vars' => '',
			'active_callback'    => array(
				array(
					'setting'  => 'options_destination_section',
					'operator' => '==',
					'value'    => 'enable',
				),
			),
		) 
	);

	/**
	* select Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_no_of_destinations_home',
			'label'    => __( 'No of destinations' , 'extretion' ),
			'section'  => 'destination-section',
			'type'     => 'select',
			'priority' => 25,
			'description' => __( '' , 'extretion' ),
			'default'  => '4',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => array(
				array(
					'setting'  => 'options_display_from_destination',
					'operator' => '==',
					'value'    => '1',
				),
			),
			'choices' => array(
	 			'4' => __( '4' , 'extretion' ),
	 			'8' => __( '8' , 'extretion' ),
	 			'12' => __( '12' , 'extretion' ),
	 			'16' => __( '16' , 'extretion' ),
	 		),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => '',
			'active_callback'    => array(
				array(
					'setting'  => 'options_destination_section',
					'operator' => '==',
					'value'    => 'enable',
				),
			),
		) 
	);

	/**
	* taxonomy Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_choose_destination_category',
			'label'    => __( 'Choose Destination Categories' , 'extretion' ),
			'section'  => 'destination-section',
			'type'     => 'select',
			'priority' => 26,
			'description' => __( '' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => array(
				array(
					'setting'  => 'options_display_from_destination',
					'operator' => '==',
					'value'    => '2',
				),
			),
			'choices' => extretion_get_terms( 'destinations' ),
			'multiple' => '20',
			'transport' => 'refresh',
			'js_vars' => '',
			'active_callback'    => array(
				array(
					'setting'  => 'options_destination_section',
					'operator' => '==',
					'value'    => 'enable',
				),
			),
		) 
	);

	/******************************************
	* Accommodations Section
	*******************************************/

	Kirki::add_section( 'accommodations-section' ,
		array(
		    'title'          => __( 'Accommodations' , 'extretion' ),
		    'description'    => __( '' , 'extretion' ),
		    'panel'          => 'homepage',
		    'priority'       => 27,
		    'capability'     => 'edit_theme_options',
		    'type'           => ''
		) 
	);

	/**
	* Radio Buttonset Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_accommodation_section',
			'label'    => __( 'Accommodation Section' , 'extretion' ),
			'section'  => 'accommodations-section',
			'type'     => 'radio-buttonset',
			'priority' => 28,
			'description' => __( '' , 'extretion' ),
			'default'  => 'enable',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'enable' => __( 'Enable' , 'extretion' ),
	 			'disable' => __( 'Disable' , 'extretion' ),
	 		),
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* Text Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_accommodation_title',
			'label'    => __( 'Title' , 'extretion' ),
			'section'  => 'accommodations-section',
			'type'     => 'text',
			'priority' => 29,
			'description' => __( '' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.home_accomodation_title',
					'function' => 'html',
				),
			),
			'active_callback'    => array(
				array(
					'setting'  => 'options_accommodation_section',
					'operator' => '==',
					'value'    => 'enable',
				),
			),
		) 
	);

	/**
	* Textarea Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_accommodation_subtitle',
			'label'    => __( 'Subtitle' , 'extretion' ),
			'section'  => 'accommodations-section',
			'type'     => 'textarea',
			'priority' => 30,
			'description' => __( '' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.home_accomodation_subtitle',
					'function' => 'html',
				),
			),
			'active_callback'    => array(
				array(
					'setting'  => 'options_accommodation_section',
					'operator' => '==',
					'value'    => 'enable',
				),
			),
		) 
	);

	/**
	* Radio Buttonset Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_display_accommodations_home',
			'label'    => __( 'Display Accommodations' , 'extretion' ),
			'section'  => 'accommodations-section',
			'type'     => 'radio-buttonset',
			'priority' => 31,
			'description' => __( 'Select how accommodations will be displayed.' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'0' => __( 'Automatically' , 'extretion' ),
	 			'1' => __( 'Manually' , 'extretion' ),
	 		),
			'transport' => 'refresh',
			'js_vars' => '',
			'active_callback'    => array(
				array(
					'setting'  => 'options_accommodation_section',
					'operator' => '==',
					'value'    => 'enable',
				),
			),
		) 
	);

	/**
	* select Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_limit_accommodations',
			'label'    => __( 'Limit' , 'extretion' ),
			'section'  => 'accommodations-section',
			'type'     => 'select',
			'priority' => 32,
			'description' => __( 'Select how many accommodations will be displayed.' , 'extretion' ),
			'default'  => '8',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => array(
				array(
					'setting'  => 'options_display_accommodations_home',
					'operator' => '==',
					'value'    => '0',
				),
			),
			'choices' => array(
	 			'3' => __( '3' , 'extretion' ),
	 			'4' => __( '4' , 'extretion' ),
	 			'5' => __( '5' , 'extretion' ),
	 			'6' => __( '6' , 'extretion' ),
	 			'7' => __( '7' , 'extretion' ),
	 			'8' => __( '8' , 'extretion' ),
	 			'9' => __( '9' , 'extretion' ),
	 			'10' => __( '10' , 'extretion' ),
	 			'11' => __( '11' , 'extretion' ),
	 			'12' => __( '12' , 'extretion' ),
	 		),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => '',
			'active_callback'    => array(
				array(
					'setting'  => 'options_accommodation_section',
					'operator' => '==',
					'value'    => 'enable',
				),
			),
		) 
	);

	/**
	* page-id Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_accommodation_room_manually',
			'label'    => __( 'Select Rooms' , 'extretion' ),
			'section'  => 'accommodations-section',
			'type'     => 'select',
			'priority' => 33,
			'description' => __( '' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => array(
				array(
					'setting'  => 'options_display_accommodations_home',
					'operator' => '==',
					'value'    => '1',
				),
			),
			'choices' => extretion_get_post_type_options( $post_type = 'room' ),
			'multiple' => '99',
			'transport' => 'refresh',
			'js_vars' => '',
			'active_callback'    => array(
				array(
					'setting'  => 'options_accommodation_section',
					'operator' => '==',
					'value'    => 'enable',
				),
			),
		) 
	);

	/**
	* select Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_accommodation_columns',
			'label'    => __( 'Columns' , 'extretion' ),
			'section'  => 'accommodations-section',
			'type'     => 'select',
			'priority' => 34,
			'description' => __( '' , 'extretion' ),
			'default'  => '4',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'3' => __( '3' , 'extretion' ),
	 			'4' => __( '4' , 'extretion' ),
	 		),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => '',
			'active_callback'    => array(
				array(
					'setting'  => 'options_accommodation_section',
					'operator' => '==',
					'value'    => 'enable',
				),
			),
		) 
	);

	/******************************************
	* Sign Up Message Section
	*******************************************/

	Kirki::add_section( 'sign-up-message' ,
		array(
		    'title'          => __( 'Sign Up Message' , 'extretion' ),
		    'description'    => __( '' , 'extretion' ),
		    'panel'          => 'homepage',
		    'priority'       => 35,
		    'capability'     => 'edit_theme_options',
		    'type'           => ''
		) 
	);

	/**
	* Text Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_title_for_traveller',
			'label'    => __( 'Title for Traveler' , 'extretion' ),
			'section'  => 'sign-up-message',
			'type'     => 'text',
			'priority' => 36,
			'description' => __( '' , 'extretion' ),
			'default'  => 'Traveler',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.home_title_traveler',
					'function' => 'html',
				),
			)
		) 
	);

	/**
	* Textarea Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_description_for_traveller',
			'label'    => __( 'Description for Traveler' , 'extretion' ),
			'section'  => 'sign-up-message',
			'type'     => 'textarea',
			'priority' => 37,
			'description' => __( '' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.home_subtitle_traveler',
					'function' => 'html',
				),
			)
		) 
	);

	/**
	* Text Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_title_for_property_owner',
			'label'    => __( 'Title for Property Owner' , 'extretion' ),
			'section'  => 'sign-up-message',
			'type'     => 'text',
			'priority' => 38,
			'description' => __( '' , 'extretion' ),
			'default'  => 'Hotel Owner',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.home_title_hotel_owner',
					'function' => 'html',
				),
			)
		) 
	);

	/**
	* Textarea Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_description_for_property_owner',
			'label'    => __( 'Description for Property Owner' , 'extretion' ),
			'section'  => 'sign-up-message',
			'type'     => 'textarea',
			'priority' => 39,
			'description' => __( '' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.home_subtitle_hotel_owner',
					'function' => 'html',
				),
			)
		) 
	);

	/******************************************
	* Testimonials Section
	*******************************************/

	Kirki::add_section( 'testimonials-section' ,
		array(
		    'title'          => __( 'Testimonials' , 'extretion' ),
		    'description'    => __( '' , 'extretion' ),
		    'panel'          => 'homepage',
		    'priority'       => 40,
		    'capability'     => 'edit_theme_options',
		    'type'           => ''
		) 
	);

	/**
	* Radio Buttonset Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_testimonials_section_status',
			'label'    => __( 'Testimonials Section' , 'extretion' ),
			'section'  => 'testimonials-section',
			'type'     => 'radio-buttonset',
			'priority' => 41,
			'description' => __( '' , 'extretion' ),
			'default'  => 'disable',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'enable' => __( 'Enable' , 'extretion' ),
	 			'disable' => __( 'Disable' , 'extretion' ),
	 		),
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* Text Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_testimonial_title',
			'label'    => __( 'Title' , 'extretion' ),
			'section'  => 'testimonials-section',
			'type'     => 'text',
			'priority' => 42,
			'description' => __( '' , 'extretion' ),
			'default'  => 'What people say about us',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.home_testimonials_title',
					'function' => 'html',
				),
			),
			'active_callback'    => array(
				array(
					'setting'  => 'options_testimonials_section_status',
					'operator' => '==',
					'value'    => 'enable',
				),
			),
		) 
	);

	/**
	* select Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_no_of_testimonials_home',
			'label'    => __( 'No of Testimonials' , 'extretion' ),
			'section'  => 'testimonials-section',
			'type'     => 'select',
			'priority' => 43,
			'description' => __( '' , 'extretion' ),
			'default'  => '6',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'3' => __( '3' , 'extretion' ),
	 			'6' => __( '6' , 'extretion' ),
	 			'9' => __( '9' , 'extretion' ),
	 		),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => '',
			'active_callback'    => array(
				array(
					'setting'  => 'options_testimonials_section_status',
					'operator' => '==',
					'value'    => 'enable',
				),
			),
		) 
	);

	/**
	* select Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_order_by_testimonials',
			'label'    => __( 'Order By' , 'extretion' ),
			'section'  => 'testimonials-section',
			'type'     => 'select',
			'priority' => 44,
			'description' => __( '' , 'extretion' ),
			'default'  => 'date',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'ID' => __( 'ID' , 'extretion' ),
	 			'title' => __( 'title' , 'extretion' ),
	 			'name' => __( 'name' , 'extretion' ),
	 			'date' => __( 'date' , 'extretion' ),
	 			'rand' => __( 'rand' , 'extretion' ),
	 		),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => '',
			'active_callback'    => array(
				array(
					'setting'  => 'options_testimonials_section_status',
					'operator' => '==',
					'value'    => 'enable',
				),
			),
		) 
	);

	/******************************************
	* Blog Section
	*******************************************/

	Kirki::add_section( 'blog-section' ,
		array(
		    'title'          => __( 'Blog' , 'extretion' ),
		    'description'    => __( '' , 'extretion' ),
		    'panel'          => 'homepage',
		    'priority'       => 45,
		    'capability'     => 'edit_theme_options',
		    'type'           => ''
		) 
	);

	/**
	* Radio Buttonset Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_blog_section_status',
			'label'    => __( 'Blog Section' , 'extretion' ),
			'section'  => 'blog-section',
			'type'     => 'radio-buttonset',
			'priority' => 46,
			'description' => __( '' , 'extretion' ),
			'default'  => 'enable',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'disable' => __( 'Disable' , 'extretion' ),
	 			'enable' => __( 'Enable' , 'extretion' ),
	 		),
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* Text Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_blog_title_home',
			'label'    => __( 'Title' , 'extretion' ),
			'section'  => 'blog-section',
			'type'     => 'text',
			'priority' => 47,
			'description' => __( '' , 'extretion' ),
			'default'  => 'Travel Guides & Tips for traveler',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.home_blog_title',
					'function' => 'html',
				),
			),
			'active_callback'    => array(
				array(
					'setting'  => 'options_blog_section_status',
					'operator' => '==',
					'value'    => 'enable',
				),
			),
		) 
	);

	/**
	* Textarea Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_blog_description_home',
			'label'    => __( 'Description' , 'extretion' ),
			'section'  => 'blog-section',
			'type'     => 'textarea',
			'priority' => 48,
			'description' => __( '' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.home_blog_subtitle',
					'function' => 'html',
				),
			),
			'active_callback'    => array(
				array(
					'setting'  => 'options_blog_section_status',
					'operator' => '==',
					'value'    => 'enable',
				),
			),
		) 
	);

	/**
	* select Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_no_of_posts_blog',
			'label'    => __( 'No of posts' , 'extretion' ),
			'section'  => 'blog-section',
			'type'     => 'select',
			'priority' => 49,
			'description' => __( '' , 'extretion' ),
			'default'  => '2',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'2' => __( '2' , 'extretion' ),
	 			'4' => __( '4' , 'extretion' ),
	 			'6' => __( '6' , 'extretion' ),
	 			'8' => __( '8' , 'extretion' ),
	 		),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => '',
			'active_callback'    => array(
				array(
					'setting'  => 'options_blog_section_status',
					'operator' => '==',
					'value'    => 'enable',
				),
			),
		) 
	);

	/******************************************
	* Instagram Section Section
	*******************************************/

	Kirki::add_section( 'instagram-section' ,
		array(
		    'title'          => __( 'Instagram Section' , 'extretion' ),
		    'description'    => __( '' , 'extretion' ),
		    'panel'          => 'homepage',
		    'priority'       => 50,
		    'capability'     => 'edit_theme_options',
		    'type'           => ''
		) 
	);

	/**
	* Radio Buttonset Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_disable_instagram',
			'label'    => __( 'Instagram' , 'extretion' ),
			'section'  => 'instagram-section',
			'type'     => 'radio-buttonset',
			'priority' => 51,
			'description' => __( '' , 'extretion' ),
			'default'  => '2',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'1' => __( 'Disable' , 'extretion' ),
	 			'0' => __( 'Enable' , 'extretion' ),
	 		),
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* Text Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_instagram_username',
			'label'    => __( 'Instagram Username' , 'extretion' ),
			'section'  => 'instagram-section',
			'type'     => 'text',
			'priority' => 52,
			'description' => __( '' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'transport' => 'refresh',
			'js_vars' => '',
			'active_callback'    => array(
				array(
					'setting'  => 'options_disable_instagram',
					'operator' => '==',
					'value'    => '0',
				),
			),
		) 
	);

	/**
	* Text Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_no_of_photos_to_show_instagram',
			'label'    => __( 'No of photos to show' , 'extretion' ),
			'section'  => 'instagram-section',
			'type'     => 'text',
			'priority' => 53,
			'description' => __( '' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'transport' => 'refresh',
			'js_vars' => '',
			'active_callback'    => array(
				array(
					'setting'  => 'options_disable_instagram',
					'operator' => '==',
					'value'    => '0',
				),
			),
		) 
	);

	/**
	* Text Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_user_id_instagram',
			'label'    => __( 'Instagram User Id' , 'extretion' ),
			'section'  => 'instagram-section',
			'type'     => 'text',
			'priority' => 54,
			'description' => __( '' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'transport' => 'refresh',
			'js_vars' => '',
			'active_callback'    => array(
				array(
					'setting'  => 'options_disable_instagram',
					'operator' => '==',
					'value'    => '0',
				),
			),
		) 
	);

	/**
	* Text Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_instagram_access_token',
			'label'    => __( 'Instagram Access Token' , 'extretion' ),
			'section'  => 'instagram-section',
			'type'     => 'text',
			'priority' => 55,
			'description' => __( '' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'transport' => 'refresh',
			'js_vars' => '',
			'active_callback'    => array(
				array(
					'setting'  => 'options_disable_instagram',
					'operator' => '==',
					'value'    => '0',
				),
			),
		) 
	);

	/******************************************
	* Registration / Profile Section
	*******************************************/

	Kirki::add_section( 'registration-page' ,
		array(
		    'title'          => __( 'Registration / Profile Page' , 'extretion' ),
		    'description'    => __( 'You can control the registration modal and profile page from here' , 'extretion' ),
		    'panel'          => '',
		    'priority'       => 56,
		    'capability'     => 'edit_theme_options',
		    'type'           => ''
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_registration_captcha',
			'label'    => __( 'Captcha' , 'extretion' ),
			'section'  => 'registration-page',
			'type'     => 'radio-buttonset',
			'default'  => '2',
			'option_type' => 'option',
			'choices' => array(
	 			'1' => __( 'Enable' , 'extretion' ),
	 			'2' => __( 'Disable' , 'extretion' ),
	 		),
			'transport' => 'refresh',
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_user_password_strength',
			'label'    => __( 'Password Strength' , 'extretion' ),
			'section'  => 'registration-page',
			'type'     => 'radio-buttonset',
			'default'  => '2',
			'option_type' => 'option',
			'choices' => array(
	 			'1' => __( 'Weak' , 'extretion' ),
	 			'2' => __( 'Strong' , 'extretion' ),
	 		),
			'transport' => 'refresh',
		) 
	);

	/******************************************
	* Room Submission Page Section
	*******************************************/

	Kirki::add_section( 'room-submission-page' ,
		array(
		    'title'          => __( 'Room Submission Page' , 'extretion' ),
		    'description'    => __( '' , 'extretion' ),
		    'panel'          => '',
		    'priority'       => 56,
		    'capability'     => 'edit_theme_options',
		    'type'           => ''
		) 
	);

	/**
	* Slider Field
	*/
			
	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_max_photos_upload_detail_page',
			'label'    => __( 'Max Photos Upload' , 'extretion' ),
			'section'  => 'room-submission-page',
			'type'     => 'slider',
			'priority' => 57,
			'description' => __( 'Maximum photos to upload on room gallery' , 'extretion' ),
			'default'  => '7',
			'choices' => array(
				'min'  => '1',
				'max'  => '50'
			),
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* page-id Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_terms_and_condition_page',
			'label'    => __( 'Terms and condition' , 'extretion' ),
			'section'  => 'room-submission-page',
			'type'     => 'select',
			'priority' => 58,
			'description' => __( 'Select the terms and condition page. This link will be displayed on the room registration page.' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => extretion_get_post_type_options( 'page' ),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/******************************************
	* Room Detail Page Section
	*******************************************/

	Kirki::add_section( 'room-detail-page' ,
		array(
		    'title'          => __( 'Room Detail Page' , 'extretion' ),
		    'description'    => __( '' , 'extretion' ),
		    'panel'          => '',
		    'priority'       => 59,
		    'capability'     => 'edit_theme_options',
		    'type'           => ''
		) 
	);

	/**
	* select Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_room_layout',
			'label'    => __( 'Layout' , 'extretion' ),
			'section'  => 'room-detail-page',
			'type'     => 'select',
			'priority' => 60,
			'description' => __( '' , 'extretion' ),
			'default'  => '1',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'1' => __( 'Without Tabs' , 'extretion' ),
	 			'2' => __( 'With Tabs' , 'extretion' ),
	 		),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* select Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_sticky_sidebar_room_detail',
			'label'    => __( 'Sticky Sidebar' , 'extretion' ),
			'section'  => 'room-detail-page',
			'type'     => 'select',
			'priority' => 61,
			'description' => __( '' , 'extretion' ),
			'default'  => '1',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'1' => __( 'Disable' , 'extretion' ),
	 			'2' => __( 'Enable' , 'extretion' ),
	 		),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_report_listings_messages',
			'label'    => __( 'Report Listing Messages' , 'extretion' ),
			'section'  => 'room-detail-page',
			'type'     => 'textarea',
			'priority' => 62,
			'description' => __( 'For multiple messages write in a new line' , 'extretion' ),
			'default'  => "This listing should't be on this site\nThis is not an accomodation\nInappropriate content or spam\nInappropriate or deceptive photo",
			'option_type' => 'option',
			'transport' => 'refresh',
		) 
	);

	/******************************************
	* Room Category page Section
	*******************************************/

	Kirki::add_section( 'room-category-page' ,
		array(
		    'title'          => __( 'Room Category page' , 'extretion' ),
		    'description'    => __( '' , 'extretion' ),
		    'panel'          => '',
		    'priority'       => 62,
		    'capability'     => 'edit_theme_options',
		    'type'           => ''
		) 
	);

	/**
	* select Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_room_category_page_layout',
			'label'    => __( 'Layout' , 'extretion' ),
			'section'  => 'room-category-page',
			'type'     => 'select',
			'priority' => 63,
			'description' => __( '' , 'extretion' ),
			'default'  => 'grid',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'grid' => __( 'Grid View' , 'extretion' ),
	 			'list' => __( 'List View' , 'extretion' ),
	 		),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* select Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_room_category_sidebar',
			'label'    => __( 'Sidebar' , 'extretion' ),
			'section'  => 'room-category-page',
			'type'     => 'select',
			'priority' => 64,
			'description' => __( '' , 'extretion' ),
			'default'  => 'right-sidebar',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'left-sidebar' => __( 'Left' , 'extretion' ),
	 			'right-sidebar' => __( 'Right' , 'extretion' ),
	 		),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* select Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_no_of_rooms_category_page',
			'label'    => __( 'No of Rooms' , 'extretion' ),
			'section'  => 'room-category-page',
			'type'     => 'select',
			'priority' => 65,
			'description' => __( '' , 'extretion' ),
			'default'  => '6',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'3' => __( '3' , 'extretion' ),
	 			'6' => __( '6' , 'extretion' ),
	 			'9' => __( '9' , 'extretion' ),
	 			'12' => __( '12' , 'extretion' ),
	 		),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/******************************************
	* Search Page Section
	*******************************************/

	Kirki::add_section( 'search-page' ,
		array(
		    'title'          => __( 'Search Page' , 'extretion' ),
		    'description'    => __( '' , 'extretion' ),
		    'panel'          => '',
		    'priority'       => 66,
		    'capability'     => 'edit_theme_options',
		    'type'           => ''
		) 
	);

	/**
	* Slider Field
	*/

	Kirki::add_field( 'my_theme', array(
		'type'        => 'slider',
		'settings' => 'options_search_radius',
		'label'       => esc_attr__( 'Search Radius', 'extretion' ),
		'section'  => 'search-page',
		'choices'     => array(
			'min'  => '5',
			'max'  => '500',
			'step' => '10',
		),
		'default'  => '10',
		'option_type' => 'option',
	) );

	/**
	* select Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_number_of_rooms_to_display',
			'label'    => __( 'Number of rooms to display on each page' , 'extretion' ),
			'section'  => 'search-page',
			'type'     => 'select',
			'priority' => 67,
			'description' => __( '' , 'extretion' ),
			'default'  => '9',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'3' => __( '3' , 'extretion' ),
	 			'6' => __( '6' , 'extretion' ),
	 			'9' => __( '9' , 'extretion' ),
	 			'12' => __( '12' , 'extretion' ),
	 			'15' => __( '15' , 'extretion' ),
	 			'18' => __( '18' , 'extretion' ),
	 		),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* Multicheck Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_search_filters',
			'label'    => __( 'Search Filters' , 'extretion' ),
			'section'  => 'search-page',
			'type'     => 'multicheck',
			'priority' => 68,
			'description' => __( 'Note : If you select all the filters the search result time will be increased.' , 'extretion' ),
			'default'  => array(
				'0' => 'room_type',
				'1' => 'bedrooms',
				'2' => 'bathrooms',
				'3' => 'beds',
				'4' => 'facilities',
				'5' => 'type_of_place',
					),
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'room_type' => __( 'Room Type' , 'extretion' ),
	 			'bedrooms' => __( 'Bedrooms' , 'extretion' ),
	 			'bathrooms' => __( 'Bathrooms' , 'extretion' ),
	 			'beds' => __( 'Beds' , 'extretion' ),
	 			'facilities' => __( 'Facilities' , 'extretion' ),
	 			'type_of_place' => __( 'Type of Place' , 'extretion' ),
	 		),
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/******************************************
	* Blog Listing Page Section
	*******************************************/

	Kirki::add_section( 'blog-listing-page' ,
		array(
		    'title'          => __( 'Blog Listing Page' , 'extretion' ),
		    'description'    => __( '' , 'extretion' ),
		    'panel'          => '',
		    'priority'       => 69,
		    'capability'     => 'edit_theme_options',
		    'type'           => ''
		) 
	);

	/**
	* select Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_blog_listing_layout',
			'label'    => __( 'Layout' , 'extretion' ),
			'section'  => 'blog-listing-page',
			'type'     => 'select',
			'priority' => 70,
			'description' => __( '' , 'extretion' ),
			'default'  => '1',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'1' => __( 'Right Sidebar' , 'extretion' ),
	 			'2' => __( 'Left Sidebar' , 'extretion' ),
	 		),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* select Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_blog_listing_featured_image',
			'label'    => __( 'Featured Image' , 'extretion' ),
			'section'  => 'blog-listing-page',
			'type'     => 'select',
			'priority' => 71,
			'description' => __( '' , 'extretion' ),
			'default'  => '1',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'1' => __( 'Show' , 'extretion' ),
	 			'0' => __( 'Hide' , 'extretion' ),
	 		),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* select Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_blog_listing_published_date',
			'label'    => __( 'Published Date' , 'extretion' ),
			'section'  => 'blog-listing-page',
			'type'     => 'select',
			'priority' => 72,
			'description' => __( '' , 'extretion' ),
			'default'  => '1',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'1' => __( 'Show' , 'extretion' ),
	 			'0' => __( 'Hide' , 'extretion' ),
	 		),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* select Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_blog_listing_author',
			'label'    => __( 'Author' , 'extretion' ),
			'section'  => 'blog-listing-page',
			'type'     => 'select',
			'priority' => 73,
			'description' => __( '' , 'extretion' ),
			'default'  => '1',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'1' => __( 'Show' , 'extretion' ),
	 			'0' => __( 'Hide' , 'extretion' ),
	 		),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* select Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_blog_listing_category',
			'label'    => __( 'Category' , 'extretion' ),
			'section'  => 'blog-listing-page',
			'type'     => 'select',
			'priority' => 74,
			'description' => __( '' , 'extretion' ),
			'default'  => '1',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'1' => __( 'Show' , 'extretion' ),
	 			'0' => __( 'Hide' , 'extretion' ),
	 		),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/******************************************
	* 404 Page Section
	*******************************************/

	Kirki::add_section( '404-page' ,
		array(
		    'title'          => __( '404 Page' , 'extretion' ),
		    'description'    => __( '' , 'extretion' ),
		    'panel'          => '',
		    'priority'       => 75,
		    'capability'     => 'edit_theme_options',
		    'type'           => ''
		) 
	);

	/**
	* select Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_404_search_field',
			'label'    => __( 'Search Field' , 'extretion' ),
			'section'  => '404-page',
			'type'     => 'select',
			'priority' => 76,
			'description' => __( '' , 'extretion' ),
			'default'  => '1',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'1' => __( 'Enable' , 'extretion' ),
	 			'2' => __( 'Disable' , 'extretion' ),
	 		),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* page-id Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_404_helpful_links',
			'label'    => __( 'Helpful Links' , 'extretion' ),
			'section'  => '404-page',
			'type'     => 'select',
			'priority' => 77,
			'description' => __( 'Select helpful links to show when there is 404 page error.' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => extretion_get_post_type_options( 'page' ),
			'multiple' => '20',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/******************************************
	* Redirect Pages Section
	*******************************************/

	Kirki::add_section( 'redirect-pages' ,
		array(
		    'title'          => __( 'Redirect Pages' , 'extretion' ),
		    'description'    => __( '' , 'extretion' ),
		    'panel'          => '',
		    'priority'       => 78,
		    'capability'     => 'edit_theme_options',
		    'type'           => ''
		) 
	);

	/**
	* page-id Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_after_login_completed',
			'label'    => __( 'After login redirect to' , 'extretion' ),
			'section'  => 'redirect-pages',
			'type'     => 'select',
			'priority' => 79,
			'description' => __( 'Default will redirect to Current URL.' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => extretion_get_post_type_options( 'page' ),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* page-id Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_after_loggout_completed',
			'label'    => __( 'After loggout redirect to' , 'extretion' ),
			'section'  => 'redirect-pages',
			'type'     => 'select',
			'priority' => 80,
			'description' => __( 'Default will redirect to Current URL.' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => extretion_get_post_type_options( 'page' ),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* page-id Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_select_booking_detail_page',
			'label'    => __( 'Select Booking Detail Page' , 'extretion' ),
			'section'  => 'redirect-pages',
			'type'     => 'select',
			'priority' => 81,
			'description' => __( 'Select the page which is linked with page template <strong>Template Name: Booking Details ( Step 1 )</strong>' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => extretion_get_post_type_options( 'page' ),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* page-id Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_select_booking_confirmation_page',
			'label'    => __( 'Select Booking Request Page' , 'extretion' ),
			'section'  => 'redirect-pages',
			'type'     => 'select',
			'priority' => 82,
			'description' => __( 'Select the page which is linked with page template <strong>Template Name: Booking Request ( Step 2 )</strong>' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => extretion_get_post_type_options( 'page' ),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* page-id Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_select_booking_approval_page',
			'label'    => __( 'Select Booking Approval Page' , 'extretion' ),
			'section'  => 'redirect-pages',
			'type'     => 'select',
			'priority' => 83,
			'description' => __( 'Select the page which is linked with page template <strong>Template Name: Booking Approval ( Step 3 )</strong>' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => extretion_get_post_type_options( 'page' ),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* page-id Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_select_booking_confirmation_n_payment',
			'label'    => __( 'Select Booking Confirmation & Payment' , 'extretion' ),
			'section'  => 'redirect-pages',
			'type'     => 'select',
			'priority' => 84,
			'description' => __( 'Select the page which is linked with page template <strong>Template Name: Booking Confirmation & Payment ( Step 4 )</strong>' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => extretion_get_post_type_options( 'page' ),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* page-id Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_select_my_trips_page',
			'label'    => __( 'Select My Trips Page' , 'extretion' ),
			'section'  => 'redirect-pages',
			'type'     => 'select',
			'priority' => 85,
			'description' => __( 'Select the page which is linked with page template <strong>Template Name: My Trips</strong>' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => extretion_get_post_type_options( 'page' ),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* page-id Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_select_reservation_page',
			'label'    => __( 'Select Reservation Page' , 'extretion' ),
			'section'  => 'redirect-pages',
			'type'     => 'select',
			'priority' => 86,
			'description' => __( 'Select the page which is linked with page template <strong>Template Name: Reservations</strong>' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => extretion_get_post_type_options( 'page' ),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* page-id Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_select_edit_room_page',
			'label'    => __( 'Select Edit Room Page' , 'extretion' ),
			'section'  => 'redirect-pages',
			'type'     => 'select',
			'priority' => 87,
			'description' => __( 'Select the page which is linked with page template <strong>Template Name: Edit Room</strong>' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => extretion_get_post_type_options( 'page' ),
			'multiple' => '',
			'transport' => 'refresh',
			'js_vars' => '',
		) 
	);

	/**
	* page-id Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_select_notification_page',
			'label'    => __( 'Select Notification Page' , 'extretion' ),
			'section'  => 'redirect-pages',
			'type'     => 'select',
			'priority' => 87,
			'description' => __( 'Select the page which is linked with page template <strong>Template Name: Notification</strong>' , 'extretion' ),
			'option_type' => 'option',
			'choices' => extretion_get_post_type_options( 'page' ),
			'transport' => 'refresh',
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_select_messages_page',
			'label'    => __( 'Select Messages Page' , 'extretion' ),
			'section'  => 'redirect-pages',
			'type'     => 'select',
			'priority' => 88,
			'description' => __( 'Select the page which is linked with page template <strong>Template Name: Messages</strong>' , 'extretion' ),
			'option_type' => 'option',
			'choices' => extretion_get_post_type_options( 'page' ),
			'transport' => 'refresh',
		) 
	);

	/******************************************
	* Booking Page Panel
	*******************************************/

	Kirki::add_panel( 'bookingpage' ,
		array(
		    'title'          => __( 'Booking Page' , 'extretion' ),
		    'description'    => __( '' , 'extretion' ),
		    'priority'       => 88,
		) 
	);

	Kirki::add_section( 'booking-settings' ,
		array(
		    'title'          => __( 'Booking Settings' , 'extretion' ),
		    'panel'          => 'bookingpage',
		    'priority'       => 89,
		    'capability'     => 'edit_theme_options'
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_booking_form',
			'label'    => __( 'Disable Payment Methods' , 'extretion' ),
			'section'  => 'booking-settings',
			'type'     => 'checkbox',
			'description' => __( 'If checked this will disable payment methods and request will be sent through email.' , 'extretion' ),
			'default'  => false,
			'option_type' => 'option',
			'transport' => 'refresh',
		) 
	);

	/******************************************
	* Booking Details ( Step 1 ) Options Section
	*******************************************/

	Kirki::add_section( 'booking-details-step1-options' ,
		array(
		    'title'          => __( 'Booking Details ( Step 1 ) Options' , 'extretion' ),
		    'description'    => __( '' , 'extretion' ),
		    'panel'          => 'bookingpage',
		    'priority'       => 89,
		    'capability'     => 'edit_theme_options'
		) 
	);

	/**
	* Radio Buttonset Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_guest_information',
			'label'    => __( 'Guest Information' , 'extretion' ),
			'section'  => 'booking-details-step1-options',
			'type'     => 'radio-buttonset',
			'priority' => 90,
			'description' => __( '' , 'extretion' ),
			'default'  => '1',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'1' => __( 'Enable' , 'extretion' ),
	 			'2' => __( 'Disable' , 'extretion' ),
	 		),
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* Radio Buttonset Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_guest_info_fields',
			'label'    => __( 'Guest Info Fields' , 'extretion' ),
			'section'  => 'booking-details-step1-options',
			'type'     => 'radio-buttonset',
			'priority' => 91,
			'description' => __( '' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'1' => __( 'Mandatory' , 'extretion' ),
	 			'2' => __( 'Optional' , 'extretion' ),
	 		),
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* Textarea Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_terms_and_conditions_message',
			'label'    => __( 'Terms & Conditions Message' , 'extretion' ),
			'section'  => 'booking-details-step1-options',
			'type'     => 'textarea',
			'priority' => 92,
			'description' => __( 'You may only use <code>Anchor tag</code> , <code>Anchor tag class</code> and <code>Anchor tag href</code>' , 'extretion' ),
			'default'  => 'By submitting a booking request, you accept the  <a href="#">Terms and conditions</a> as well as the <a href="#">Cancellation policy</a> and <a href="#">House Rules</a>',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_sidebar_booking_background',
			'label'    => __( 'Sidebar Booking Details Background' , 'extretion' ),
			'section'  => 'booking-details-step1-options',
			'type'     => 'color',
			'priority' => 93,
			'default'  => '#005294',
			'option_type' => 'option',
			'transport' => 'refresh',
			'output' => array(
				array(
					'element'  => '.room-page-right-sidebar.alt',
					'function' => 'css',
					'property' => 'background',
					'suffix' => ' !important'
				),
			),
		) 
	);

	Kirki::add_panel( 'payment_methods', array(
	    'priority'    => 92,
	    'title'       => __( 'Payment Methods', 'extretion' ),
	) );

	Kirki::add_section( 'stripe-account' ,
		array(
		    'title'          => __( 'Stripe Account' , 'extretion' ),
		    'panel'          => 'payment_methods',
		    'priority'       => 93,
		    'capability'     => 'edit_theme_options',
		    'type'           => ''
		) 
	);

	Kirki::add_field( 'my_theme', array(
		'type'        => 'checkbox',
		'settings'    => 'options_stripe_status',
		'label'       => __( 'Disable Stripe', 'extretion' ),
		'section'     => 'stripe-account',
		'option_type' => 'option',
	) );

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_stripe_sandbox_live',
			'label'    => __( 'Stripe Account' , 'extretion' ),
			'section'  => 'stripe-account',
			'type'     => 'radio-buttonset',
			'description' => __( 'Live for ( Real Transaction ) or Sandbox for ( Testing )' , 'extretion' ),
			'default'  => 'sandbox',
			'option_type' => 'option',
			'choices' => array(
	 			'live' => __( 'Live' , 'extretion' ),
	 			'sandbox' => __( 'Sandbox' , 'extretion' ),
	 		),
			'transport' => 'refresh',
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_test_secret_key',
			'label'    => __( 'Test Secret Key' , 'extretion' ),
			'section'  => 'stripe-account',
			'type'     => 'text',
			'option_type' => 'option',
			'active_callback'    => array(
				array(
					'setting'  => 'options_stripe_sandbox_live',
					'operator' => '==',
					'value'    => 'sandbox',
				),
			),
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_test_publishable_key',
			'label'    => __( 'Test Publishable Key' , 'extretion' ),
			'section'  => 'stripe-account',
			'type'     => 'text',
			'option_type' => 'option',
			'active_callback'    => array(
				array(
					'setting'  => 'options_stripe_sandbox_live',
					'operator' => '==',
					'value'    => 'sandbox',
				),
			),
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_test_client_id',
			'label'    => __( 'Client ID' , 'extretion' ),
			'section'  => 'stripe-account',
			'type'     => 'text',
			'option_type' => 'option',
			'active_callback'    => array(
				array(
					'setting'  => 'options_stripe_sandbox_live',
					'operator' => '==',
					'value'    => 'sandbox',
				),
			),
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_live_secret_key',
			'label'    => __( 'Live Secret Key' , 'extretion' ),
			'section'  => 'stripe-account',
			'type'     => 'text',
			'option_type' => 'option',
			'active_callback'    => array(
				array(
					'setting'  => 'options_stripe_sandbox_live',
					'operator' => '==',
					'value'    => 'live',
				),
			),
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_live_publishable_key',
			'label'    => __( 'Live Publishable Key' , 'extretion' ),
			'section'  => 'stripe-account',
			'type'     => 'text',
			'option_type' => 'option',
			'active_callback'    => array(
				array(
					'setting'  => 'options_stripe_sandbox_live',
					'operator' => '==',
					'value'    => 'live',
				),
			),
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_live_client_id',
			'label'    => __( 'Client ID' , 'extretion' ),
			'section'  => 'stripe-account',
			'type'     => 'text',
			'option_type' => 'option',
			'active_callback'    => array(
				array(
					'setting'  => 'options_stripe_sandbox_live',
					'operator' => '==',
					'value'    => 'live',
				),
			),
		) 
	);

	/******************************************
	* Paypal Account Section
	*******************************************/

	Kirki::add_section( 'paypal-account' ,
		array(
		    'title'          => __( 'Paypal Account' , 'extretion' ),
		    'description'    => __( '' , 'extretion' ),
		    'panel'          => 'payment_methods',
		    'priority'       => 93,
		    'capability'     => 'edit_theme_options',
		    'type'           => ''
		) 
	);

	Kirki::add_field( 'my_theme', array(
		'type'        => 'checkbox',
		'settings'    => 'options_paypal_status',
		'label'       => __( 'Disable Paypal', 'extretion' ),
		'section'     => 'paypal-account',
		'option_type' => 'option',
		'priority'    => 94,
	) );

	/**
	* Text Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_paypal_email_owner',
			'label'    => __( 'PayPal Email' , 'extretion' ),
			'section'  => 'paypal-account',
			'type'     => 'text',
			'priority' => 94,
			'description' => __( 'Please enter the PayPal email address where the commission will be received.' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* Radio Buttonset Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_enable_live_sandbox',
			'label'    => __( 'Paypal Account' , 'extretion' ),
			'section'  => 'paypal-account',
			'type'     => 'radio-buttonset',
			'priority' => 95,
			'description' => __( 'Live for ( Real Transaction ) or Sandbox for ( Testing )' , 'extretion' ),
			'default'  => 'sandbox',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'choices' => array(
	 			'live' => __( 'Live' , 'extretion' ),
	 			'sandbox' => __( 'Sandbox' , 'extretion' ),
	 		),
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* Text Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_sandbox_security_user_id',
			'label'    => __( 'Sandbox Security User Id' , 'extretion' ),
			'section'  => 'paypal-account',
			'type'     => 'text',
			'priority' => 96,
			'description' => __( '' , 'extretion' ),
			'default'  => 'ravishakya_357-facilitator_api1.yahoo.com',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => array(
				array(
					'setting'  => 'options_enable_live_sandbox',
					'operator' => '==',
					'value'    => 'sandbox',
				),
			),
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* Text Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_sandbox_security_password',
			'label'    => __( 'Sandbox Security Password' , 'extretion' ),
			'section'  => 'paypal-account',
			'type'     => 'text',
			'priority' => 97,
			'description' => __( '' , 'extretion' ),
			'default'  => '5B4N666SY64B4CAE',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => array(
				array(
					'setting'  => 'options_enable_live_sandbox',
					'operator' => '==',
					'value'    => 'sandbox',
				),
			),
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* Text Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_sandbox_security_signature',
			'label'    => __( 'Sandbox Security Signature' , 'extretion' ),
			'section'  => 'paypal-account',
			'type'     => 'text',
			'priority' => 98,
			'description' => __( '' , 'extretion' ),
			'default'  => 'AFcWxV21C7fd0v3bYYYRCpSSRl31AeuQRFF30VE5HcjPCF82CovjsXSy',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => array(
				array(
					'setting'  => 'options_enable_live_sandbox',
					'operator' => '==',
					'value'    => 'sandbox',
				),
			),
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* Text Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_live_security_user_id',
			'label'    => __( 'Live Security User Id' , 'extretion' ),
			'section'  => 'paypal-account',
			'type'     => 'text',
			'priority' => 99,
			'description' => __( '' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => array(
				array(
					'setting'  => 'options_enable_live_sandbox',
					'operator' => '==',
					'value'    => 'live',
				),
			),
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* Text Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_live_security_password',
			'label'    => __( 'Live Security Password' , 'extretion' ),
			'section'  => 'paypal-account',
			'type'     => 'text',
			'priority' => 100,
			'description' => __( '' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => array(
				array(
					'setting'  => 'options_enable_live_sandbox',
					'operator' => '==',
					'value'    => 'live',
				),
			),
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* Text Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_live_security_signature',
			'label'    => __( 'Live Security Signature' , 'extretion' ),
			'section'  => 'paypal-account',
			'type'     => 'text',
			'priority' => 101,
			'description' => __( '' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => array(
				array(
					'setting'  => 'options_enable_live_sandbox',
					'operator' => '==',
					'value'    => 'live',
				),
			),
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/**
	* Text Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_live_application_id',
			'label'    => __( 'Application Id' , 'extretion' ),
			'section'  => 'paypal-account',
			'type'     => 'text',
			'priority' => 102,
			'description' => __( '' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => array(
				array(
					'setting'  => 'options_enable_live_sandbox',
					'operator' => '==',
					'value'    => 'live',
				),
			),
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/******************************************
	* API\'s Section
	*******************************************/

	Kirki::add_section( 'apis' ,
		array(
		    'title'          => __( 'API\'s' , 'extretion' ),
		    'description'    => __( '' , 'extretion' ),
		    'panel'          => '',
		    'priority'       => 103,
		    'capability'     => 'edit_theme_options',
		    'type'           => ''
		) 
	);

	/**
	* Text Field
	*/

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_lmh_google_map_api',
			'label'    => __( 'Google Map API' , 'extretion' ),
			'section'  => 'apis',
			'type'     => 'text',
			'priority' => 104,
			'description' => __( 'You can get Google Map API from
	<a href="https://developers.google.com/maps/documentation/javascript/get-api-key#get-an-api-key" target="_blank">here</a>' , 'extretion' ),
			'default'  => '',
			'tooltip' => __( '' , 'extretion' ),
			'option_type' => 'option',
			'option_name' => '',
			'active_callback' => '',
			'transport' => 'refresh',
			'js_vars' => ''
		) 
	);

	/******************************************
	* Notification Settings Section
	*******************************************/

	Kirki::add_panel( 'notification_settings' ,
		array(
		    'title'          => __( 'Notification Settings' , 'extretion' ),
		    'priority'       => 107,
		) 
	);

	Kirki::add_section( 'notification_options' ,
		array(
		    'title'          => __( 'Notification Page Options' , 'extretion' ),
		    'priority'       => 108,
		    'capability'     => 'edit_theme_options',
		    'panel'          => 'notification_settings',
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'notification_load_more_label',
			'section'  => 'notification_options',
			'type'     => 'text',
			'priority' => 108,
			'label'    => __( 'Button Label' , 'extretion' ),
			'default'  => __( 'Load More' , 'extretion' ),
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.notification_load_more_label',
					'function' => 'html',
				),
			)
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'notification_load_more_label_background',
			'section'  => 'notification_options',
			'type'     => 'color',
			'alpha' => true,
			'priority' => 144,
			'label'    => __( 'Button Background Color' , 'extretion' ),
			'default'  => '#000',
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.notification_load_more_label',
					'function' => 'css',
					'property' => 'background',
					'suffix' => ' !important'
				),
				array(
					'element' => '.notification_load_more_label',
					'function' => 'css',
					'property' => 'border-color',
					'suffix' => ' !important'
				),
			)
		) 
	);

	Kirki::add_field( 'my_theme', array(
		'type'        => 'slider',
		'settings'    => 'notifications_per_page',
		'label'       => esc_html__( 'Per Page Notifications', 'extretion' ),
		'description' => esc_html__( 'Define the number of notifications to show per page.' , 'extretion' ),
		'section'     => 'notification_options',
		'priority'    => 144,
		'default'     => 10,
		'option_type' => 'option',
		'choices'     => array(
			'min'  => '5',
			'max'  => '20',
			'step' => '1',
		),
	) );

	Kirki::add_section( 'password_notification_settings' ,
		array(
		    'title'          => __( 'Password Change Notification' , 'extretion' ),
		    'priority'       => 108,
		    'capability'     => 'edit_theme_options',
		    'panel'          => 'notification_settings' 
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'password_notification_settings_label',
			'section'  => 'password_notification_settings',
			'type'     => 'text',
			'priority' => 109,
			'label'    => __( 'Title' , 'extretion' ),
			'default'  => __( 'Password Successfully Changed' , 'extretion' ),
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.password_notification_settings_label',
					'function' => 'html',
				),
			)
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'password_notification_settings_color_label',
			'section'  => 'password_notification_settings',
			'type'     => 'color',
			'alpha' => true,
			'priority' => 109,
			'label'    => __( 'Title Background Color' , 'extretion' ),
			'default'  => '#5CB85C',
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.password_notification_settings_label',
					'function' => 'css',
					'property' => 'background',
					'suffix' => ' !important'
				),
			)
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'password_notification_settings_sublabel',
			'section'  => 'password_notification_settings',
			'type'     => 'text',
			'priority' => 110,
			'label'    => __( 'Subtitle' , 'extretion' ),
			'default'  => __( 'You have successfully changed your password.' , 'extretion' ),
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.password_notification_settings_sublabel',
					'function' => 'html',
				),
			)
		) 
	);

	Kirki::add_section( 'booking_request_notification_settings' ,
		array(
		    'title'          => __( 'Booking Request Notification' , 'extretion' ),
		    'priority'       => 111,
		    'capability'     => 'edit_theme_options',
		    'panel'          => 'notification_settings' 
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'booking_request_notification_settings_label',
			'section'  => 'booking_request_notification_settings',
			'type'     => 'text',
			'priority' => 112,
			'label'    => __( 'Title' , 'extretion' ),
			'default'  => __( 'Booking Request' , 'extretion' ),
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.booking_request_notification_settings_label',
					'function' => 'html',
				),
			)
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'booking_request_notification_settings_sublabel',
			'section'  => 'booking_request_notification_settings',
			'type'     => 'textarea',
			'priority' => 113,
			'description' => __( 'You may use <code>[room_name]</code> in the message.' , 'extretion' ),
			'label'    => __( 'Subtitle' , 'extretion' ),
			'default'  => __( 'You have received a booking request for [room_name].' , 'extretion' ),
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.booking_request_notification_settings_sublabel',
					'function' => 'html',
				),
			)
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'booking_request_notification_settings_color_label',
			'section'  => 'booking_request_notification_settings',
			'type'     => 'color',
			'alpha' => true,
			'priority' => 114,
			'label'    => __( 'Title Background Color' , 'extretion' ),
			'default'  => '#5cb85c',
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.booking_request_notification_settings_label',
					'function' => 'css',
					'property' => 'background',
					'suffix' => ' !important'
				),
			)
		) 
	);

	Kirki::add_section( 'pending_payment_notification_settings' ,
		array(
		    'title'          => __( 'Pending Payment Notification' , 'extretion' ),
		    'priority'       => 115,
		    'capability'     => 'edit_theme_options',
		    'panel'          => 'notification_settings' 
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'pending_payment_notification_settings_label',
			'section'  => 'pending_payment_notification_settings',
			'type'     => 'text',
			'priority' => 116,
			'label'    => __( 'Title' , 'extretion' ),
			'default'  => __( 'Pending Payment' , 'extretion' ),
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.pending_payment_notification_settings_label',
					'function' => 'html',
				),
			)
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'pending_payment_notification_settings_sublabel',
			'section'  => 'pending_payment_notification_settings',
			'type'     => 'textarea',
			'priority' => 117,
			'description' => __( 'You may use <code>[room_name]</code> in the message.' , 'extretion' ),
			'label'    => __( 'Subtitle' , 'extretion' ),
			'default'  => __( 'You have a pending payment for [room_name].' , 'extretion' ),
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.pending_payment_notification_settings_sublabel',
					'function' => 'html',
				),
			)
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'pending_payment_notification_settings_color_label',
			'section'  => 'pending_payment_notification_settings',
			'type'     => 'color',
			'alpha' => true,
			'priority' => 118,
			'label'    => __( 'Title Background Color' , 'extretion' ),
			'default'  => '#f0ad4e',
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.pending_payment_notification_settings_label',
					'function' => 'css',
					'property' => 'background',
					'suffix' => ' !important'
				),
			)
		) 
	);

	Kirki::add_section( 'successful_payment_notification_settings' ,
		array(
		    'title'          => __( 'Payment Successful Notification' , 'extretion' ),
		    'priority'       => 119,
		    'capability'     => 'edit_theme_options',
		    'panel'          => 'notification_settings' 
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'successful_payment_notification_settings_label',
			'section'  => 'successful_payment_notification_settings',
			'type'     => 'text',
			'priority' => 120,
			'label'    => __( 'Title' , 'extretion' ),
			'default'  => __( 'Payment Successful' , 'extretion' ),
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.successful_payment_notification_settings_label',
					'function' => 'html',
				),
			)
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'successful_payment_notification_settings_sublabel',
			'section'  => 'successful_payment_notification_settings',
			'type'     => 'textarea',
			'priority' => 121,
			'description' => __( 'You may use <code>[room_name]</code> in the message.' , 'extretion' ),
			'label'    => __( 'Subtitle' , 'extretion' ),
			'default'  => __( 'You have successfully paid for [room_name].' , 'extretion' ),
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.successful_payment_notification_settings_sublabel',
					'function' => 'html',
				),
			)
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'successful_payment_notification_settings_color_label',
			'section'  => 'successful_payment_notification_settings',
			'type'     => 'color',
			'alpha' => true,
			'priority' => 122,
			'label'    => __( 'Title Background Color' , 'extretion' ),
			'default'  => '#5CB85C',
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.successful_payment_notification_settings_label',
					'function' => 'css',
					'property' => 'background',
					'suffix' => ' !important'
				),
			)
		) 
	);

	Kirki::add_section( 'cancelled_booking_by_traveler_notification_settings' ,
		array(
		    'title'          => __( 'Cancelled Booking Notification' , 'extretion' ),
		    'priority'       => 123,
		    'capability'     => 'edit_theme_options',
		    'panel'          => 'notification_settings' 
		) 
	);

	Kirki::add_field( 'my_theme', array(
		'type'        => 'custom',
		'settings'    => 'cancelled_booking_by_traveler_heading',
		'section'     => 'cancelled_booking_by_traveler_notification_settings',
		'default'     => '<div style="padding: 10px;background-color: #777; color: #fff;">' . esc_html__( 'By Traveler', 'extretion' ) . '</div>',
		'priority'    => 124,
	) );

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'cancelled_booking_by_traveler_notification_settings_label',
			'section'  => 'cancelled_booking_by_traveler_notification_settings',
			'type'     => 'text',
			'priority' => 125,
			'label'    => __( 'Title' , 'extretion' ),
			'default'  => __( 'Cancelled Booking Request' , 'extretion' ),
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.cancelled_booking_by_traveler_notification_settings_label',
					'function' => 'html',
				),
			)
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'cancelled_booking_by_traveler_notification_settings_sublabel',
			'section'  => 'cancelled_booking_by_traveler_notification_settings',
			'type'     => 'textarea',
			'priority' => 126,
			'description' => __( 'You may use <code>[invoice_name]</code> in the message.' , 'extretion' ),
			'label'    => __( 'Subtitle' , 'extretion' ),
			'default'  => __( 'Booking request [invoice_name] was cancelled by Traveler.' , 'extretion' ),
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.cancelled_booking_by_traveler_notification_settings_sublabel',
					'function' => 'html',
				),
			)
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'cancelled_booking_by_traveler_notification_settings_color_label',
			'section'  => 'cancelled_booking_by_traveler_notification_settings',
			'type'     => 'color',
			'alpha' => true,
			'priority' => 127,
			'label'    => __( 'Title Background Color' , 'extretion' ),
			'default'  => '#DD3333',
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.cancelled_booking_by_traveler_notification_settings_label',
					'function' => 'css',
					'property' => 'background',
					'suffix' => ' !important'
				),
			)
		) 
	);

	Kirki::add_field( 'my_theme', array(
		'type'        => 'custom',
		'settings'    => 'denied_booking_by_host_heading',
		'section'     => 'cancelled_booking_by_traveler_notification_settings',
		'default'     => '<div style="padding: 10px;background-color: #777; color: #fff;">' . esc_html__( 'By Host', 'extretion' ) . '</div>',
		'priority'    => 128,
	) );

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'denied_booking_by_host_notification_settings_label',
			'section'  => 'cancelled_booking_by_traveler_notification_settings',
			'type'     => 'text',
			'priority' => 129,
			'label'    => __( 'Title' , 'extretion' ),
			'default'  => __( 'Cancelled Booking Request' , 'extretion' ),
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.denied_booking_by_host_notification_settings_label',
					'function' => 'html',
				),
			)
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'denied_booking_by_host_notification_settings_sublabel',
			'section'  => 'cancelled_booking_by_traveler_notification_settings',
			'type'     => 'textarea',
			'priority' => 130,
			'description' => __( 'You may use <code>[invoice_name]</code> in the message.' , 'extretion' ),
			'label'    => __( 'Subtitle' , 'extretion' ),
			'default'  => __( 'Booking request [invoice_name] was denied by host.' , 'extretion' ),
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.denied_booking_by_host_notification_settings_sublabel',
					'function' => 'html',
				),
			)
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'denied_booking_by_host_notification_settings_color_label',
			'section'  => 'cancelled_booking_by_traveler_notification_settings',
			'type'     => 'color',
			'alpha' => true,
			'priority' => 131,
			'label'    => __( 'Title Background Color' , 'extretion' ),
			'default'  => '#DD3333',
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.denied_booking_by_host_notification_settings_label',
					'function' => 'css',
					'property' => 'background',
					'suffix' => ' !important'
				),
			)
		) 
	);

	Kirki::add_section( 'automatically_deleted_booking_notification_settings' ,
		array(
		    'title'          => __( 'Automatically Deleted Booking Notification' , 'extretion' ),
		    'priority'       => 132,
		    'capability'     => 'edit_theme_options',
		    'panel'          => 'notification_settings' 
		) 
	);

	Kirki::add_field( 'my_theme', array(
		'type'        => 'custom',
		'settings'    => 'check_in_date_exceeded_heading',
		'section'     => 'automatically_deleted_booking_notification_settings',
		'default'     => '<div style="padding: 10px;background-color: #777; color: #fff;">' . esc_html__( 'Exceeded the Check in date', 'extretion' ) . '</div>',
		'priority'    => 133,
	) );

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'check_in_date_exceeded_notification_settings_label',
			'section'  => 'automatically_deleted_booking_notification_settings',
			'type'     => 'text',
			'priority' => 134,
			'label'    => __( 'Title' , 'extretion' ),
			'default'  => __( 'Deleted Booking Request' , 'extretion' ),
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.check_in_date_exceeded_notification_settings_label',
					'function' => 'html',
				),
			)
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'check_in_date_exceeded_notification_settings_sublabel',
			'section'  => 'automatically_deleted_booking_notification_settings',
			'type'     => 'textarea',
			'priority' => 135,
			'description' => __( 'You may use <code>[invoice_name]</code> in the message.' , 'extretion' ),
			'label'    => __( 'Subtitle' , 'extretion' ),
			'default'  => __( 'Booking request [invoice_name] has been removed because it has not been answered by the owner and it has exceeded the Check In Date.' , 'extretion' ),
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.check_in_date_exceeded_notification_settings_sublabel',
					'function' => 'html',
				),
			)
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'check_in_date_exceeded_notification_settings_color_label',
			'section'  => 'automatically_deleted_booking_notification_settings',
			'type'     => 'color',
			'alpha' => true,
			'priority' => 136,
			'label'    => __( 'Title Background Color' , 'extretion' ),
			'default'  => '#DD3333',
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.check_in_date_exceeded_notification_settings_label',
					'function' => 'css',
					'property' => 'background',
					'suffix' => ' !important'
				),
			)
		) 
	);

	Kirki::add_field( 'my_theme', array(
		'type'        => 'custom',
		'settings'    => 'after_14_days_exceeded_heading',
		'section'     => 'automatically_deleted_booking_notification_settings',
		'default'     => '<div style="padding: 10px;background-color: #777; color: #fff;">' . esc_html__( 'Unanswered by the host for last 14 days', 'extretion' ) . '</div>',
		'priority'    => 137,
	) );

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'after_14_days_exceeded_notification_settings_label',
			'section'  => 'automatically_deleted_booking_notification_settings',
			'type'     => 'text',
			'priority' => 138,
			'label'    => __( 'Title' , 'extretion' ),
			'default'  => __( 'Deleted Booking Request' , 'extretion' ),
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.after_14_days_exceeded_notification_settings_label',
					'function' => 'html',
				),
			)
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'after_14_days_exceeded_notification_settings_sublabel',
			'section'  => 'automatically_deleted_booking_notification_settings',
			'type'     => 'textarea',
			'priority' => 139,
			'description' => __( 'You may use <code>[invoice_name]</code> in the message.' , 'extretion' ),
			'label'    => __( 'Subtitle' , 'extretion' ),
			'default'  => __( 'Booking request [invoice_name] has not been answered by the owner for last 14 days and now has been removed.' , 'extretion' ),
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.after_14_days_exceeded_notification_settings_sublabel',
					'function' => 'html',
				),
			)
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'after_14_days_exceeded_notification_settings_color_label',
			'section'  => 'automatically_deleted_booking_notification_settings',
			'type'     => 'color',
			'alpha' => true,
			'priority' => 140,
			'label'    => __( 'Title Background Color' , 'extretion' ),
			'default'  => '#DD3333',
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.after_14_days_exceeded_notification_settings_label',
					'function' => 'css',
					'property' => 'background',
					'suffix' => ' !important'
				),
			)
		) 
	);

	Kirki::add_field( 'my_theme', array(
		'type'        => 'custom',
		'settings'    => 'after_48_hrs_no_payment_heading',
		'section'     => 'automatically_deleted_booking_notification_settings',
		'default'     => '<div style="padding: 10px;background-color: #777; color: #fff;">' . esc_html__( 'No payment by traveler within 48hrs', 'extretion' ) . '</div>',
		'priority'    => 141,
	) );

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'after_48_hrs_no_payment_notification_settings_label',
			'section'  => 'automatically_deleted_booking_notification_settings',
			'type'     => 'text',
			'priority' => 142,
			'label'    => __( 'Title' , 'extretion' ),
			'default'  => __( 'Deleted Booking Request' , 'extretion' ),
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.after_48_hrs_no_payment_notification_settings_label',
					'function' => 'html',
				),
			)
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'after_48_hrs_no_payment_notification_settings_sublabel',
			'section'  => 'automatically_deleted_booking_notification_settings',
			'type'     => 'textarea',
			'priority' => 143,
			'description' => __( 'You may use <code>[invoice_name]</code> in the message.' , 'extretion' ),
			'label'    => __( 'Subtitle' , 'extretion' ),
			'default'  => __( 'Booking fee of [invoice_name] has not been paid by the traveler within 48hrs so we have deleted the booking request.' , 'extretion' ),
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.after_48_hrs_no_payment_notification_settings_sublabel',
					'function' => 'html',
				),
			)
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'after_48_hrs_no_payment_notification_settings_color_label',
			'section'  => 'automatically_deleted_booking_notification_settings',
			'type'     => 'color',
			'alpha' => true,
			'priority' => 144,
			'label'    => __( 'Title Background Color' , 'extretion' ),
			'default'  => '#DD3333',
			'option_type' => 'option',
			'transport' => 'postMessage',
			'js_vars' => array(
				array(
					'element' => '.after_48_hrs_no_payment_notification_settings_label',
					'function' => 'css',
					'property' => 'background',
					'suffix' => ' !important'
				),
			)
		) 
	);

	Kirki::add_section( 'extretions_fonts' ,
		array(
		    'title'          => __( 'Fonts' , 'extretion' ),
		    'priority'       => 145,
		    'capability'     => 'edit_theme_options'
		) 
	);

	Kirki::add_field( 'my_theme', array(
		'type'        => 'typography',
		'settings'    => 'body_font',
		'label'       => __( 'Body Font', 'extretion' ),
		'section'     => 'extretions_fonts',
		'default'     => array(
			'font-family'    => 'PT Sans',
			'variant'        => 'regular',
			'font-size'      => '14px',
			'line-height'    => '22px',
			'letter-spacing' => '0',
			'subsets'        => array( 'latin-ext' ),
			'color'          => '#5d5d5d',
		),
		'output'      => array(
			array(
				'element' => 'body',
			),
		),
	) );

	Kirki::add_field( 'my_theme', array(
		'type'        => 'typography',
		'settings'    => 'main_menu_font',
		'label'       => __( 'Main Menu Font', 'extretion' ),
		'section'     => 'extretions_fonts',
		'default'     => array(
			'font-family'    => 'PT Sans',
			'variant'        => 'regular',
			'font-size'      => '14px',
			'line-height'    => '22px',
			'letter-spacing' => '0',
			'subsets'        => array( 'latin-ext' ),
			'color'          => '#5d5d5d',
			'text-transform' => 'none',
		),
		'output'      => array(
			array(
				'element' => '.menu-main-menu-container .navbar-nav li a',
			),
		),
	) );

	Kirki::add_field( 'my_theme', array(
		'type'        => 'typography',
		'settings'    => 'footer_font',
		'label'       => __( 'Footer Font', 'extretion' ),
		'section'     => 'extretions_fonts',
		'default'     => array(
			'font-family'    => 'PT Sans',
			'variant'        => 'regular',
			'font-size'      => '14px',
			'line-height'    => '22px',
			'letter-spacing' => '0',
			'subsets'        => array( 'latin-ext' ),
			'text-transform' => 'none',
		),
		'output'      => array(
			array(
				'element' => '.main-footer',
			),
		),
	) );

	/******************************************
	* User Verification Section
	*******************************************/

	Kirki::add_section( 'verification_section' ,
		array(
		    'title'          => __( 'User Verification' , 'extretion' ),
		    'panel'          => '',
		    'priority'       => 146,
		    'capability'     => 'edit_theme_options',
		    'type'           => ''
		) 
	);

	Kirki::add_field( 'my_theme', 
		array(
			'settings' => 'options_email_verification',
			'label'    => __( 'Email Verification' , 'extretion' ),
			'section'  => 'verification_section',
			'type'     => 'radio-buttonset',
			'default'  => '1',
			'option_type' => 'option',
			'choices' => array(
	 			'1' => __( 'Enable' , 'extretion' ),
	 			'2' => __( 'Disable' , 'extretion' ),
	 		),
			'transport' => 'refresh',
			'description' => __( 'If <code>Disable</code> selected, the user will not get verification email on register.', 'extretion' )
		) 
	);

}