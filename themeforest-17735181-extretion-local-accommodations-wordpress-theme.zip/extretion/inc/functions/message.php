<?php

add_action( 'wp_ajax_extretion_get_message_modal' , 'extretion_get_message_modal' );
function extretion_get_message_modal(){

	$user_id = get_current_user_id();
	$room_id = sanitize_text_field( $_POST['room_id'] );

	$post = get_post( $room_id );
	$host_id = $post->post_author;

	$host_first_name = get_user_meta( $host_id, 'first_name' , true );
	$host_display_name = !empty( $host_first_name ) ? $host_first_name : get_the_author_meta( 'user_login' , $host_id );

	ob_start(); ?>
	
	<div class="modal fade modal-login modal-border-transparent" id="send_message_modal" tabindex="-1" role="dialog" aria-hidden="true" >

		<div class="modal-dialog">

			<div class="modal-content">
				
				<button type="button" class="btn btn-close close" data-dismiss="modal" aria-label="Close">
					<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
				</button>
				
				<div class="clear"></div>
				
				<!-- Begin # DIV Form -->
				<div id="modal-message-form-wrapper">
					
					<!-- Begin # Login Form -->
					<form id="message_form">
					
						<div class="modal-body pb-10">
					
							<!-- Error Message Display -->
							<ul class="login_modal_error send_message_error mt-20"></ul>

							<!-- Success Message -->
							<div class="alert alert-success send_message_success mb-20 mt-20" style="display:none;"></div>

							<div class="traveler_image_wrapper_modal text-center">
									
								<div class="traveler_image">
									<?php echo get_avatar( $host_id , '150' ); ?>
								</div>

								<h4 class="mt-10">
									<?php 
									printf( 
										esc_html__( 'Ask %s about this rental', 'extretion' ), 
										$host_display_name 
									); ?>
								<h4>

							</div>

							<div class="form-group mb-0"> 
								<textarea autocomplete="off" name="first_message" class="form-control mb-5 first_message" placeholder="<?php esc_html_e( 'Write Your Message' , 'extretion' ); ?>"></textarea>
							</div>
							
						</div>
						
						<div class="modal-footer pt-20 pb-5">
						
							<div class="row gap-10">

								<div class="col-sm-12 mb-10">
									<input type="hidden" id="room_id_modal" value="<?php echo $room_id; ?>">
									<button class="btn btn-primary btn-block send_message_modal_btn">
										<?php esc_html_e( 'Send Message' , 'extretion' ); ?>	
									</button>
								</div>

							</div>
							
						</div>

					</form>	
								
				</div>
								
			</div>
		</div>
	</div>
	
	<?php

	$content = ob_get_clean();

	echo json_encode(
		array(
			'status' => true,
			'content' => $content
		)
	);

	die;
}

add_action( 'wp_ajax_extretion_save_first_message' , 'extretion_save_first_message' );
function extretion_save_first_message(){

	$data = array_map( 'strip_tags' , $_POST );

	$message = $data['message']; // Traveler message for the host
	$room_id = (int) $data['room_id']; // Room id

	$error_message = '<li>' . esc_html__( 'There seems to be an error. Please try again.', 'extretion' ) . '</li>';

	if( !is_int( $room_id ) ){
		echo json_encode( array( 'status' => false , 'message' => $error_message ) );
		die;
	}

	$post = get_post( $room_id ); // Get post object

	if( !is_object( $post ) ){
		echo json_encode( array( 'status' => false , 'message' => $error_message ) );
		die;
	}

	$traveler_id = get_current_user_id();
	$host_id = $post->post_author;

	if( $traveler_id == $host_id ){
		echo json_encode( array( 'status' => false , 'message' => $error_message ) );
		die;
	}

	$new_post = array(
        'post_type' => 'messages',
        'post_title' =>  get_the_title( $room_id ),
        'post_status' => 'publish',
        'post_author' => $traveler_id,
        'post_content' => $message
    );


    $post_id = wp_insert_post($new_post);

    update_post_meta( $post_id, 'sender_id', $traveler_id);
    update_post_meta( $post_id, 'related_room_id', $room_id );
    update_post_meta( $post_id, 'receiver_id', $host_id );
    update_post_meta( $post_id, 'delete_id', array('sender_del' => 0, 'receiver_del' => 0));

    $message_detail = array();
    $message_detail['date'] = date('Y-m-d H:i');
    $message_detail['message'] = $message;
    $message_detail['status'] = 0;
    $message_detail['receiver_id'] = $host_id;
    $message_detail['user_hide_message_status']['sender_id'] = $traveler_id;
    $message_detail['user_hide_message_status']['sender_status'] = 0; 
    $message_detail['user_hide_message_status']['receiver_id'] = $host_id;
    $message_detail['user_hide_message_status']['receiver_status'] = 0;

    update_post_meta( $post_id, 'message_detail', array( $message_detail ) );

    do_action( 'extretion_after_message_saved', $traveler_id , $host_id , $post_id );

    echo json_encode( 
    	array( 
    		'status' => true,
    		'message' => esc_html__( 'Your message has been sent to the host. The host will contact you as soon as possible.' , 'extretion' )
    	) 
    );
	die;

}

add_action( 'extretion_after_message_saved' , 'extretion_host_message_notification' , 10 , 3 );
function extretion_host_message_notification( $traveler_id , $host_id , $message_id ){

	$subject_db = get_option('options_messages_subject');
	$subject_db = empty( $subject_db ) ? 'New message at [site_name]' : $subject_db;
	$subject = str_replace( '[site_name]' , get_bloginfo( 'name' ) , $subject_db );

	$receiver_name = get_user_display_name( $host_id );
	$sender_name = get_user_display_name( $traveler_id );

	$message_details = get_post_meta( $message_id , 'message_detail' , true );

	$message_details_sort = array_reverse( $message_details );
	$message_text = $message_details_sort[0]['message'];

	$message_db = get_option( 'options_private_message' );
	$message_db = !empty( $message_db ) ? $message_db : 'Hello [receiver_name],<br /><br />You have received a message from [sender_name].<br /><br /><strong>Message:</strong><br /><br /><em>"[message]"</em><br /><br />Please log in to [site_url] and read the full message.<br /><br />Answer questions and you get, good response gives good impression!';

	$message = str_replace( '[receiver_name]' , $receiver_name , $message_db );
	$message = str_replace( '[sender_name]' , $sender_name , $message );
	$message = str_replace( '[message]' , $message_text , $message );
	$message = str_replace( '[site_url]' , site_url() , $message );

	$to = get_the_author_meta( 'user_email', $host_id );

	wp_mail( $to, $subject, nl2br( $message ), extretion_mail_headers() );

}

function extretion_get_messages( $sender = false ){

	//$paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;

	$current_user_id = get_current_user_id();
	$args = array(
		'post_status'    => 'publish',
		'post_type' => 'messages',
		'orderby' => 'modified',
		'posts_per_page' => -1,
		//'paged' => $paged,
		'meta_query' => array( 
			array( 
			'key' => $sender ? 'sender_id' : 'receiver_id', 
			'value' => get_current_user_id()
			)
		),								
	);

	// $args2 = array(
	// 	'post_status'    => 'publish',
	// 	'post_type' => 'messages',
	// 	'posts_per_page' => -1,
	// 	'meta_query' => array( 
	// 		array( 
	// 		'key' => $sender ? 'sender_id' : 'receiver_id', 
	// 		'value' => get_current_user_id()
	// 		)
	// 	),								
	// );

	// $all_messages = new WP_Query( $args2 );

	$inbox_mesages_query = new WP_Query($args);
	$count_display_message = 0;

	if($inbox_mesages_query->have_posts()):

		while($inbox_mesages_query->have_posts()): $inbox_mesages_query->the_post();

			global $post;

			/****************************************/
			/* Start Count Notification for a post */
			/***************************************/
				
				$count_message = get_post_meta($post->ID,'message_detail',true);

				$not_read = 0;
				foreach($count_message as $message_data){
					
					if($message_data['status'] == 0 && $message_data['receiver_id'] == get_current_user_id()){
						$not_read++;
					}

				}
					
			/****************************************/
			/* End Count Notification for a post */
			/***************************************/

			$message_delete_id = get_post_meta($post->ID , 'delete_id', true);
			$room_id = get_post_meta( $post->ID, 'related_room_id', true );

			$delete_key = $sender ? 'sender_del' : 'receiver_del';

			if($message_delete_id[$delete_key] == 0){ 

				$count_display_message++; ?>

				<li>
								
					<div class="cleaffix relative">
						
						<?php if( $not_read > 0 ){ ?>

				  			<span class="action-label label label-danger">
				  				
				  				<?php 
				  				printf( 
				  					_n( 
				  						'%s new message', 
				  						'%s new messages', 
				  						$not_read, 
				  						'extretion' 
				  					), 
				  					$not_read 
				  				); 
				  				?>				  				
				  				
				  			</span>

				  		<?php } ?>
						
						<div class="image">
							<img src="<?php echo extretion_get_first_image_room( $room_id ); ?>">
						</div>
						
						<div class="content">

							<h4><?php echo get_the_title( $room_id ); ?></h4>

							<?php 
							$address = get_post_meta( $room_id, 'place_located', true );
							
							if( !empty( $address ) ){ ?>

								<p class="location">
									<i class="fa fa-map-marker text-primary"></i> 
									<?php echo mb_strimwidth( $address , 0, 50, ' ...'); ?>
								</p>

								<?php 
							} ?>
							
							<div class="man">
								<div class="avatar">
									
									<?php 

									$sender_id = get_post_meta( $post->ID, 'sender_id', true );
									$receiver_id = get_post_meta( $post->ID, 'receiver_id', true );

									/**
									* If user is Host then show traveler details
									* If user is Traveler then show host details
									*/

									if( $current_user_id == $sender_id ){
										$user_id1 = $receiver_id;
										$role = 'host';
									} else {
										$user_id1 = $sender_id;
										$role = 'traveler';
									}

								  	echo get_avatar( 
								  		$user_id1, 
								  		'100', 
								  		false,
								  		false, 
								  		array( 
								  			'class' => 'img-circle' 
								  		) 
								  	); ?>

								</div>
								<div class="info">
									<h5>
									
										<?php echo get_user_display_name( $user_id1 ); ?>
										<span class="label label-warning ml-5 user_role">

											<?php 
											if( $role == 'host' ){
												esc_html_e( 'Property Owner' , 'extretion' );
											} else {
												esc_html_e( 'Traveler' , 'extretion' );
											} ?>
											
										</span>
										
									</h5>
									<p>
										<strong>
											<?php esc_html_e( 'Speaks' , 'extretion' ); ?>		
										</strong> : <?php echo extretion_get_spoken_language( $user_id1 ); ?></p>
								</div>
							</div>
							
							<div class="row">
							
								<div class="col-xs-12 col-sm-6">
									<div class="date"><i class="fa fa-clock-o mr-5"></i> <?php echo ' '.extretion_get_post_time( $count_message ); ?></div>
								</div>
								
								<div class="col-xs-12 col-sm-6">
									
									<?php 
									$message_page_id = get_option( 'options_select_messages_page' );
									?>

									<div class="action-btn">
										<a class="btn btn-sm btn-primary view_message" href="<?php echo get_permalink( $message_page_id ) . '?reply=' . $post->ID; ?>"><?php esc_html_e( 'Reply' , 'extretion' ); ?></a>
										<a class="btn btn-sm btn-danger delete_message" message_id="<?php echo $post->ID; ?>"><?php esc_html_e( 'Delete' , 'extretion' ); ?></a>
									</div>
									
								</div>
								
							</div>
							
						</div>

					</div>
				
				</li>

				<?php

			}

		endwhile;
		
	endif;

	wp_reset_postdata();

	if($count_display_message == 0){

		if( $sender == true ){
			echo '<div class="no_inbox_message alert alert-info">' . esc_html__( 'There are no sent messages.' , 'extretion' ) . '</div>';
		} else {
			echo '<div class="no_inbox_message alert alert-info">' . esc_html__( 'There are no inbox messages.' , 'extretion' ) . '</div>';
		}
		
	}

	//listMyHotelPagination( ceil( $all_messages->found_posts/5 ) );

}

function get_user_display_name( $user_id ){

	$first_name = get_user_meta( $user_id, 'first_name', true );
	$last_name = get_user_meta( $user_id, 'last_name', true );
	$user_login = get_the_author_meta( 'user_login' , $user_id );

	$full_name = sanitize_text_field( $first_name . ' ' . $last_name );

	return ( !empty( $full_name ) ? $full_name : $user_login );

}

function extretion_get_spoken_language( $user_id ){

	$language = get_user_meta( $user_id, 'language_spoken' , true );

	if( is_array( $language ) ){
		$language = array_filter( $language );
	}

	if( !empty( $language ) && is_array( $language ) ){

		if( count( $language ) <= 3 ){
			return implode( ', ' , $language );
		} else{
			$remaining = count( $language ) - 3;
			return $language[0] . ', ' . $language[1] . ', ' . $language[2] . ' ' . sprintf( esc_html__( 'and %d more', 'extretion' ) , $remaining );
		}
		
	}
	return esc_html__( 'Not available' , 'extretion' );

}

function extretion_get_post_time( $messages ){

	$latest_message = end( $messages );
	return extretion_timeAgo( $latest_message['date'] );

}

function extretion_count_user_hide_message_status( $post_id , $host_traveler_id ){

	$count_message = get_post_meta( $post_id, 'message_detail', true );

    $j = 0;

    foreach( $count_message as $message_data ){

        if ( $message_data['user_hide_message_status']['sender_id'] == $host_traveler_id ) {

            if ( $message_data['user_hide_message_status']['sender_status'] == 0) {
                $j++;
               // echo 'sender' . $j;
            }

        } else {

            if ($message_data['user_hide_message_status']['receiver_status'] == 0) {
                $j++;
               // echo 'sender' . $j;
            }
        }

    }

    if ( $j == 0 ) {

       // echo 'm in';

        $data = array();

        /*********************************************************** */
        // Start Set Status to Read so that it wont give notification
        /********************************************************** */

        foreach($count_message as $message_data){

            $message_data['status'] = 1;

            array_push($data, $message_data);

        }
        update_post_meta($post_id, 'message_detail', $data);

        /*********************************************************** */
        // End Set Status to Read so that it wont give notification
        /*********************************************************** */
        wp_delete_post($post_id);
        //echo 'post deleted';
        die;

    }

}

add_action( 'wp_ajax_extretion_delete_message' , 'extretion_delete_message' );
function extretion_delete_message(){

	$current_user = get_current_user_id();
    $post_id = $_POST['post_id'];

    $args = array(
    	'post_type' => 'messages',
    	'post__in' => array( $post_id ),
    	'post_status' => 'publish'
    );

    $messages_query = new WP_Query( $args );

    if( !$messages_query->have_posts() ){
    	echo json_encode( array( 'status' => false ) );
    	die;
    }

    $sender_id = get_post_meta($post_id, 'sender_id', true);
    $receiver_id = get_post_meta($post_id, 'receiver_id', true);

    $delete_user_id = get_post_meta($post_id, 'delete_id', true);

    if ($current_user == $sender_id) {

        /********************** */
        /* Delete Message Post */
        /********************** */

        if ( $delete_user_id['receiver_del'] == 1 ) {
        	extretion_count_user_hide_message_status( $post_id , $receiver_id );
        }

        /******************** */
        /* Hide Message Post */
        /******************** */

        $delete_user_id['sender_del'] = 1;
        update_post_meta($post_id, 'delete_id', $delete_user_id);
        extretion_hide_message($sender_id, $post_id);
    }

    if ($current_user == $receiver_id) {

    	//echo 'receiver';
        /********************** */
        /* Delete Message Post */
        /********************** */

        if ( $delete_user_id['sender_del'] == 1 ) {
        	extretion_count_user_hide_message_status( $post_id , $sender_id );
        }

        /******************** */
        /* Hide Message Post */
        /******************** */

        $delete_user_id['receiver_del'] = 1;
        update_post_meta($post_id, 'delete_id', $delete_user_id);
        extretion_hide_message( $receiver_id, $post_id );
    }

    die;

}

/**************************** */
/* Hide Message */
/**************************** */

function extretion_hide_message( $user, $post_id ) {
   
    $count_message = get_post_meta($post_id,'message_detail',true);
    $data = array();
    // Hide all Current message when press delete
    foreach($count_message as $message_data){

        if ($user == $message_data['user_hide_message_status']['sender_id']) {
            $message_data['user_hide_message_status']['sender_status'] = 1;
            $message_data['status'] = 1;
        } elseif ($user == $message_data['user_hide_message_status']['receiver_id']) {
            $message_data['user_hide_message_status']['receiver_status'] = 1;
            $message_data['status'] = 1;
        }
        
        array_push($data, $message_data);

    }
    //printr($data);
    update_post_meta($post_id, 'message_detail', $data);
}

add_action( 'wp_ajax_extretion_reply_message' , 'extretion_reply_message' );
function extretion_reply_message(){

	$data = array_map( 'strip_tags' , $_POST );
	$reply_message = $data['reply_message'];
	$message_id = $data['post_id'];

	$user_id = get_current_user_id();
	$receiver_id = get_post_meta( $message_id, 'receiver_id', true);
	$sender_id = get_post_meta( $message_id, 'sender_id', true); 

	if( $user_id == $receiver_id || $user_id == $sender_id ){

		// For Mail
		$sender_ids = $user_id;
		if( $user_id == $receiver_id ){
	    	$receiver_ids = $sender_id;
	    } else {
	    	$receiver_ids = $receiver_id;
	    }

		if ( $user_id == $receiver_id ) {
	        $notification_id = $sender_id;
	        $notification_id1 = $receiver_id;

	        //View post to the sender (change state from hide to show post )
	    } else {
	        $notification_id = $receiver_id;
	        $notification_id1 = $sender_id;

	        //View post to the receiver (change state from hide to show post )
	    }

	    $post_user = array();
	    $post_user['receiver_del'] = 0;
	    $post_user['sender_del'] = 0;

	    $message_detail = array();
	    $message_detail['date'] = date( 'Y-m-d H:i' );
	    $message_detail['message'] = $reply_message;
	    $message_detail['status'] = 0;
	    $message_detail['receiver_id'] = $notification_id;

	    $message_detail['user_hide_message_status']['sender_id'] = $notification_id1;
	    $message_detail['user_hide_message_status']['sender_status'] = 0; 
	    $message_detail['user_hide_message_status']['receiver_id'] = $notification_id;
	    $message_detail['user_hide_message_status']['receiver_status'] = 0;

	    $prev_message = get_post_meta( $message_id ,'message_detail',true);

	    array_push( $prev_message, $message_detail );

	    update_post_meta( $message_id , 'delete_id', $post_user );
	    update_post_meta( $message_id , 'message_detail', $prev_message );

	    // To show reply message at first
	    $my_post = array(
		    'ID' => $message_id,
		);
		wp_update_post( $my_post );

		do_action( 'extretion_after_message_saved', $sender_ids , $receiver_ids , $message_id );
		
	}

    echo json_encode( array( 'status' => 'success' ) );

	die;

}

add_action( 'wp_ajax_extretion_get_more_messages' , 'extretion_get_more_messages' );
function extretion_get_more_messages(){

	$data = array_map( 'sanitize_text_field' , $_POST );

	$message_id = (int) $data['post_id']; // Get message id
	$last_msg_id = (int) $data['last_msg_id']; // This is for pagination
	$user_id = get_current_user_id();

	$receiver_id = get_post_meta( $message_id, 'receiver_id', true);
	$sender_id = get_post_meta( $message_id, 'sender_id', true); 

	$from = $last_msg_id + 1;

	// Only receiver and sender can see the message
	if( $user_id == $receiver_id || $user_id == $sender_id ){

		// Get all messages
		$content = '';
		$message_details_unsort = get_post_meta( $message_id, 'message_detail' , true );

		$message_details_sort = array_reverse( $message_details_unsort );

		$get_five_message = array_slice( $message_details_sort, $from, 5, true ); 

		if( is_array( $get_five_message ) && !empty( $get_five_message ) ){

			ob_start();

			extretion_get_the_message( $get_five_message , $message_id );

			$content = ob_get_clean();

		}

		echo json_encode( 
			array( 
				'status' => 'success', 
				'content' => $content,
				'notification_count' => extretion_count_message_notifications(),
				'pagination' => ( empty( $content ) || count($get_five_message) < 5 ) ? false : true
			) 
		);
		die;	

	}

	echo json_encode( 
		array( 
			'status' => 'error',
			'content' => '',
			'pagination' => false,
			'notification_count' => 0
		) 
	);

	die;

}

function extretion_get_the_message( $messages , $message_id ){

	$current_user = get_current_user_id();
	$all_message = get_post_meta( $message_id , 'message_detail', true );
	$all_message = array_reverse( $all_message );

	foreach( $messages as $key => $message_detail ){

		// If message is read don't show the notification count
		if ( $current_user == $message_detail['receiver_id'] ) {
			//$receiver = $message_detail['receiver_id'];
            $all_message[$key]['status'] = 1;
        }

		$sender_id = $message_detail['user_hide_message_status']['sender_id'];
		$date = !empty( $message_detail['date'] ) ? $message_detail['date'] : '';
		$message = !empty( $message_detail['message'] ) ? $message_detail['message'] : ''; ?>

		<div class="message-item" data_message_id="<?php echo $key; ?>">
		
			<div class="row">
			
				<div class="col-xs-12 col-sm-4 col-md-3">
				
					<div class="message-author">
						
						<div class="avatar">
							<?php 
						  	echo get_avatar( 
						  		$sender_id, 
						  		'100', 
						  		false,
						  		false, 
						  		array( 
						  			'class' => 'img-circle' 
						  		) 
						  	); ?>
						</div>
						<div class="info">
							<h5><?php echo get_user_display_name( $sender_id ); ?></h5>
							<p title="<?php echo date( 'M d, Y' , strtotime( $date ) ); ?>"><i class="fa fa-clock-o"></i> <?php echo extretion_timeAgo($date); ?></p>
						</div>
						
					</div>
				
				</div>
				
				<div class="col-xs-12 col-sm-8 col-md-9">
				
					<div class="message-entry">
						
						<p><?php echo nl2br($message); ?></p>
					
					</div>
					
				</div>
				
			</div>
			
		</div>

		<?php 

	} 

	///echo '<pre>'; print_r($all_message); echo '</pre>';

	//if ( $current_user == $receiver ) {
	update_post_meta( $message_id , 'message_detail', array_reverse( $all_message ) );
	//}

}

function extretion_get_message_notification_page(){

	$link = get_option( 'options_select_messages_page' );

	if( empty( $link ) ){
		return '#';
	}

	return get_permalink( $link );

}

function extretion_message_notification(){

	if( !is_user_logged_in() ){
		return;
	} 

	$message_count = extretion_count_message_notifications(); ?>

	<li class="has-msg">
		<a href="<?php echo extretion_get_message_notification_page(); ?>" class="icon-msg">
			<i class="fa fa-envelope" aria-hidden="true"></i>
			<?php 
			if( $message_count > 0 ){ ?>
				<span class="count bg-danger message_count_header"><?php echo $message_count; ?> </span>    
				<?php 
			} ?>      
		</a>
	</li>

	<?php
}

function extretion_count_message_notifications(){

	$user_id = get_current_user_id();
    $args = array(
        'post_type' => 'messages',
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'meta_query' => array(
            'relation' => 'OR',
            array(
                'key' => 'receiver_id',
                'value' => $user_id,
                'compare' => '='
            ),
            array(
                'key' => 'sender_id',
                'value' => $user_id,
                'compare' => '='
            )
        )
    );

    $message_post = new WP_Query($args);
    $noti_num = 0;
    if($message_post->have_posts()):
        while ($message_post->have_posts()): $message_post->the_post();
            global $post;
            $sender_id = get_post_meta($post->ID, 'sender_id', true);
            $receiver_id = get_post_meta($post->ID, 'receiver_id', true);

            /********************************************************************************* */
            // Start Check post is hide or not. If hide do not count notification of that post
            /********************************************************************************* */

            if ($user_id == $sender_id) {
                $post_hide_or_not = get_post_meta($post->ID, 'delete_id', true);
                $result = $post_hide_or_not['sender_del'];
            } elseif ($user_id == $receiver_id) {
                $post_hide_or_not = get_post_meta($post->ID, 'delete_id', true);
                $result = $post_hide_or_not['receiver_del'];
            }

            /********************************************************************************* */
            // End Check post is hide or not. If hide do not count notification of that post
            /********************************************************************************* */

            $i = get_post_meta($post->ID,'message_detail',true);

            if(!empty($i)):
                foreach($i as $message){
                    if ($message['receiver_id'] == $user_id && $message['status'] == 0 && $result == 0) {
                        $noti_num++;
                    }
                }

            endif;

        endwhile;

    endif;
    wp_reset_postdata();
    return $noti_num;

}

function count_inbox_notification() {
    $user_id = get_current_user_id();
    $args = array(
        'post_type' => 'messages',
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'meta_query' => array(
            'relation' => 'OR',
            array(
                'key' => 'receiver_id',
                'value' => $user_id,
                'compare' => '='
            )
        )
    );

    $message_post = new WP_Query($args);
    $noti_num = 0;
    if($message_post->have_posts()):
        while ($message_post->have_posts()): $message_post->the_post();
            global $post;
            $sender_id = get_post_meta($post->ID, 'sender_id', true);
            $receiver_id = get_post_meta($post->ID, 'receiver_id', true);

            /********************************************************************************* */
            // Start Check post is hide or not. If hide do not count notification of that post
            /********************************************************************************* */

            if ($user_id == $sender_id) {
                $post_hide_or_not = get_post_meta($post->ID, 'delete_id', true);
                $result = $post_hide_or_not['sender_del'];
            } elseif ($user_id == $receiver_id) {
                $post_hide_or_not = get_post_meta($post->ID, 'delete_id', true);
                $result = $post_hide_or_not['receiver_del'];
            }

            /********************************************************************************* */
            // End Check post is hide or not. If hide do not count notification of that post
            /********************************************************************************* */

            $i = get_post_meta($post->ID,'message_detail',true);

            if(!empty($i)):
                foreach($i as $message){
                    if ($message['receiver_id'] == $user_id && $message['status'] == 0 && $result == 0) {
                        $noti_num++;
                    }
                }

            endif;

        endwhile;

    endif;
    wp_reset_postdata();
    return $noti_num;
}

function count_sent_notification() {
    $user_id = get_current_user_id();
    $args = array(
        'post_type' => 'messages',
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'meta_query' => array(
            'relation' => 'OR',
            array(
                'key' => 'sender_id',
                'value' => $user_id,
                'compare' => '='
            )
        )
    );

    $message_post = new WP_Query($args);
    $noti_num = 0;
    if($message_post->have_posts()):
        while ($message_post->have_posts()): $message_post->the_post();
            global $post;
            $sender_id = get_post_meta($post->ID, 'sender_id', true);
            $receiver_id = get_post_meta($post->ID, 'receiver_id', true);

            /********************************************************************************* */
            // Start Check post is hide or not. If hide do not count notification of that post
            /********************************************************************************* */

            if ($user_id == $sender_id) {
                $post_hide_or_not = get_post_meta($post->ID, 'delete_id', true);
                $result = $post_hide_or_not['sender_del'];
            } elseif ($user_id == $receiver_id) {
                $post_hide_or_not = get_post_meta($post->ID, 'delete_id', true);
                $result = $post_hide_or_not['receiver_del'];
            }

            /********************************************************************************* */
            // End Check post is hide or not. If hide do not count notification of that post
            /********************************************************************************* */

            $i = get_post_meta($post->ID,'message_detail',true);

            if(!empty($i)):
                foreach($i as $message){
                    if ($message['receiver_id'] == $user_id && $message['status'] == 0 && $result == 0) {
                        $noti_num++;
                    }
                }

            endif;

        endwhile;

    endif;
    wp_reset_postdata();
    return $noti_num;
}