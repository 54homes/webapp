<?php
class hotel_category_widget extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {
		parent::__construct(
			'hotel_category_widget', // Base ID
			esc_html__( 'Extretion Category', 'extretion' ), // Name
			array( 'description' => esc_html__( 'All Categories', 'extretion' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */

	public function widget( $args, $instance ) {

		echo $args['before_widget'];

		if ( ! empty( $instance['title'] ) ) { ?>

			<div class="section-title-3">
				<h2><?php echo apply_filters( 'extretion_widget_search_title', $instance['title'] ); ?></h2>
			</div>

			<?php 
		} ?>

		<ul class="sidebar-cat clearfix mb-30 mmt">
			<?php $this->getCategories( $instance['category'] , $instance['postcount'] ); ?>
		</ul>

			<?php
		echo $args['after_widget'];
	}

	function getCategories( $category , $postcount ){

    	$category_list = get_terms( $category , array( 'hide_empty' => false ) );

    	if( !empty( $category_list ) && is_array( $category_list ) ){

    		$lists = array();
    		foreach( $category_list as $key => $value ){

    			//print_r($value);

    			$category_link = get_category_link( $value->term_id );
    			echo '<li><a href="' . $category_link . '">' . $value->name;

    			if( $postcount == 1 ){
    				echo ' <span class="absolute">('. $value->count .')</span>';	
    			}
    			
    			echo '</a></li>';

    		}
    		
    	} else {
    		echo '<li>' . esc_html__( 'No categories found.' , 'extretion' ) . '</li>';
    	}

    }

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {

		$title = ! empty( $instance['title'] ) ? $instance['title'] : '';
		$category = ! empty( $instance['category'] ) ? $instance['category'] : '';
		$postcount = ! empty( $instance['postcount'] ) ? $instance['postcount'] : '';
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>">
				<?php esc_attr_e( 'Title:' , 'extretion' ); ?>			
			</label> 
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'category' ) ); ?>">
				<?php esc_attr_e( 'Select Category:' , 'extretion' ); ?>			
			</label>
			<br>
			<?php $this->getAllTaxonomies( esc_attr( $this->get_field_name( 'category' ) ) , $category ); ?>
		</p>

		<p>
			<label>
				<input autocomplete="off" type="checkbox" value="1" name="<?php echo esc_attr( $this->get_field_name( 'postcount' ) ); ?>" <?php checked( $postcount, 1 );?>>
				<?php esc_html_e( 'Show Post Counts' , 'extretion' ); ?>			
			</label>
		</p>

		<?php 
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['category'] = ( ! empty( $new_instance['category'] ) ) ? strip_tags( $new_instance['category'] ) : '';
		$instance['postcount'] = ( ! empty( $new_instance['postcount'] ) ) ? strip_tags( $new_instance['postcount'] ) : '';

		return $instance;
	}

	function getAllTaxonomies( $name , $selected ){

		$result = $this->getTax();

		if( !empty($result) ){
			echo '<select name="' . $name . '">';
			foreach( $result as $name => $slug ){ ?>
				
				<option value="<?php echo esc_html( $slug ); ?>" <?php selected( $selected, $slug ); ?>><?php echo esc_html( $name ); ?></option>
				
				<?php
			}
			echo '</select>';
		} else {

		}

	}

	function getTax(){

    	//$args = array(
		//   'public'   => true,
		//   '_builtin' => false
		//);

		//$output = 'names'; // names or objects, note names is the default
		//$operator = 'and'; // 'and' or 'or'

		//$post_types = get_post_types( $args, $output, $operator ); 
		$post_types['room'] = 'room'; 
		$post_types['post'] = 'post';
		$post_types['page'] = 'page';
		$pageArray = array();
		$tax = array();

		foreach( $post_types as $post_type ){

			$taxonomy_objects = get_object_taxonomies( $post_type, 'objects' );

	   		if( !empty( $taxonomy_objects ) && is_array( $taxonomy_objects ) ){

	   			foreach( $taxonomy_objects as $key => $value ){

	   				$slug = $value->rewrite['slug'];
	   				$tax[$value->labels->name] = $slug;

	   			}

	   		} 

		}
		unset( $tax['Format'] );
		unset( $tax['Tags'] );
		return $tax;

    }

}

function register_hotel_category_widget() {
    register_widget( 'hotel_category_widget' );
}
add_action( 'widgets_init', 'register_hotel_category_widget' );