<?php

class search_form_widget extends WP_Widget {

	function __construct() {
		parent::__construct(
			'search_form_widget', // Base ID
			esc_html__( 'Extretion Search Form' , 'extretion' ), // Name
			array( 'description' => esc_html__( 'Room search form', 'extretion' ), ) // Args
		);
	}	

	public function widget( $args, $instance ) { 

		$defaults = extretion_default_labels(); ?>

		<div class="mb-10"></div>
					
		<div class="result-search-form-wrapper clearfix">
		
			<h3><?php echo esc_html( $defaults['search_page']['search_again'] ); ?></h3>

			<div class="inner">
				<form class="gap-10 search_page_form" method="get" action="<?php echo site_url(); ?>">
					<div class="col-xs-12 col-sm-12">
						<div class="form-group form-icon-right mb-10">

							<label>
								<?php echo esc_html( $defaults['search_page']['where_to_go'] ); ?>
								
							</label>

							<input name="s" id="destination-search-homepage" type="text" class="form-control mb-0" placeholder="<?php echo esc_html( $defaults['search_page']['type_a_place'] ); ?>" autocomplete="off" value="">

							<i class="fa fa-map-marker"></i>

							<div class="search_place_attr" style="display:none">

					        	<input data-geo="lat" name="lat" value="" type="hidden" >
						        <input data-geo="lng" name="lng" value="" type="hidden">
						        <input data-geo="formatted_address" name="formatted_address" value="" type="hidden">
						        <input data-geo="name" name="place" value="" type="hidden">
					
						    </div>
						</div>
						<div class="error_label"></div>
					</div>

					<?php
					if( empty( $_GET['arrival_date'] ) || empty( $_GET['departure_date'] ) ){

						$arrival_date = date( 'd-m-Y' );
						$departure_date = date('d-m-Y',strtotime( $arrival_date . "+1 days") );

					} else {
						$arrival_date = sanitize_text_field( $_GET['arrival_date'] );
						$departure_date = sanitize_text_field( $_GET['departure_date'] );
					}
					?>

					<div class="col-xs-6 col-sm-6">
						<div class="form-group form-icon-right mb-10"> 
							<label>
								<?php echo esc_html( $defaults['search_page']['check_in'] ); ?>
								
							</label>
							<input name="arrival_date" class="form-control mb-0" id="arrival_date" placeholder="<?php echo esc_html( $defaults['search_page']['check_in'] ); ?>" type="text" autocomplete="off" value="<?php echo esc_html( $arrival_date ); ?>">
						</div>
					</div>
					<div class="col-xs-6 col-sm-6">
						<div class="form-group form-icon-right mb-10"> 
							<label><?php echo esc_html( $defaults['search_page']['check_out'] ); ?></label>
							<input 
							name="departure_date" 
							class="form-control mb-0" 
							id="departure_date" 
							placeholder="<?php echo esc_html( $defaults['search_page']['check_out'] ); ?>" 
							type="text" 
							autocomplete="off" 
							value="<?php echo esc_html( $departure_date ); ?>">
						</div>
					</div>
					<div class="col-xs-12 col-sm-12">
						<div class="form-group">
							<label><?php echo esc_html( $defaults['search_page']['rooms'] ); ?></label>
							
							<select name="guests" class="custom-select" id="change-search-room">
								<?php 
								$guests = extretion_guestAccomodate();

								$selected_guests = !empty( $_GET['guests'] ) ? sanitize_text_field( $_GET['guests'] ) : '';

								foreach( $guests as $guest ){ ?>
									<option <?php selected( $selected_guests, $guest ); ?> value="<?php echo (int) $guest; ?>"><?php echo (int) $guest; ?></option>
									<?php
								} 
								?>
							</select>
						</div>
					</div>
					
					<div class="clear"></div>
					
					<div class="col-sm-12">
						 <input name="view" value="" type="hidden">
						<button class="btn btn-block btn-primary btn-icon mt-5"><?php echo esc_html( $defaults['search_page']['search'] ); ?> <span class="icon"><i class="fa fa-search"></i></span></button>
					</div>
														
					<div class="clear"></div>

				</form>
			</div>
		</div>

		<div class="mb-40"></div>

		<?php
	}

}

function register_search_form_widget() {
    register_widget( 'search_form_widget' );
}
add_action( 'widgets_init', 'register_search_form_widget' );