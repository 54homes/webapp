<?php
class hotel_questions_widget extends WP_Widget {

	function __construct() {
		parent::__construct(
			'hotel_questions_widget', // Base ID
			esc_html__( 'Extretion Faq&#39;s' , 'extretion' ), // Name
			array( 'description' => esc_html__( 'Frequently asked questions', 'extretion' ), ) // Args
		);
	}	

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) { 
				//print_r($instance);

		$title = !empty( $instance['title'] ) ? $instance['title'] : ''; 
		$category = ! empty( $instance['category'] ) ? $instance['category'] : ''; ?>

		<p>
			<label for="<?php echo  esc_attr( $this->get_field_id( 'title' ) ); ?>">
				<?php esc_attr_e( 'Title:' , 'extretion' ); ?>			
			</label> 
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'category' ) ); ?>">
				<?php esc_attr_e( 'Select Category:' , 'extretion' ); ?>			
			</label>
			<br>

			<?php 
			$categories = extretion_getAllTermsArray('faq_cat'); 
			
			if( !empty( $categories ) ){

				echo '<select name="' . esc_attr( $this->get_field_name( 'category' ) ) . '">';

				foreach( $categories as $key => $value ){

					echo '<option value="' . $key . '"';
					selected( $category , $key );
					echo ' >' . $value . '</option>';

				}

				echo '</select>';

			} else {
				esc_html_e( 'No categories found.' , 'extretion' );
			}

			?>
		</p>

		<?php
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {

		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
		$instance['category'] = ( ! empty( $new_instance['category'] ) ) ? sanitize_text_field( $new_instance['category'] ) : '';

		return $instance;
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {

		echo $args['before_widget'];

		if ( ! empty( $instance['title'] ) ) { ?>

			<div class="section-title-3">
				<h2><?php echo esc_attr( $instance['title'] ); ?></h2>
			</div>

			<?php 
		} 

		$faq_args = array(
			'post_type' => 'faqs',
			'posts_per_page' => -1,
			'post_status' => 'publish',
			'tax_query' => array(
				array(
					'taxonomy' => 'faq_cat',
					'field'    => 'id',
					'terms'    => $instance['category'],
				),
			),
		); 

		$faq_args = apply_filters( 'extretion_widget_faq_query' , $faq_args );

		$faq_query = new WP_Query( $faq_args ); 

		if( $faq_query->have_posts() ):

			echo '<div class="accordion-wrapper faq-accordion-wrapper faq-accordion-sm-wrapper" id="faqAccordionOne" role="tablist" aria-multiselectable="true">';

			while ( $faq_query->have_posts() ): $faq_query->the_post(); 

				global $post;
				$post_id = $post->ID; ?>
				
				<div class="panel accordion-item">

					<div class="accordion-heading" role="tab" id="faqAccordionOneHeader<?php echo (int) $post_id; ?>">
						<h4 class="panel-title">
							<a class="collapsed" data-toggle="collapse" data-parent="#faqAccordionOne" href="#faqAccordionOne<?php echo (int) $post_id; ?>" aria-expanded="true" aria-controls="faqAccordionOne<?php echo (int) $post_id; ?>">
								<?php the_title(); ?>
							</a>
						</h4>
					</div>

					<div id="faqAccordionOne<?php echo (int) $post_id; ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="faqAccordionOneHeader<?php echo (int) $post_id; ?>">
						<div class="panel-body">
							<div class="accordion-inner">
								<?php the_content(); ?>
							</div>
						</div>
					</div>
				</div>

				<?php

			endwhile;

			echo '</div>';

		endif; ?>

		<?php
		echo $args['after_widget'];

		wp_reset_postdata();

	}

}

function register_hotel_questions() {
    register_widget( 'hotel_questions_widget' );
}
add_action( 'widgets_init', 'register_hotel_questions' );