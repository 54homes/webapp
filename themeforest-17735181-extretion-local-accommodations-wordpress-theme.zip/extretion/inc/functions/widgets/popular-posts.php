<?php
/**
 * Adds Foo_Widget widget.
 */
class hotel_popular_posts_widget extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {
		parent::__construct(
			'hotel_popular_posts_widget', // Base ID
			esc_html__( 'Extretion Posts', 'extretion' ), // Name
			array( 'description' => esc_html__( 'Display Posts', 'extretion' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {

		//echo '<pre>'; print_r( $instance ); echo '</pre>';

		$results = $this->getPostQuery( $instance );

		if( $results['no_of_posts'] == 0 ){
			return;
		}

		echo $args['before_widget'];
		if ( ! empty( $instance['title'] ) ) { ?>

			<div class="section-title-3">
				<h2><?php echo apply_filters( 'extretion_widget_post_title', $instance['title'] ); ?></h2>
			</div>

			<?php

			printf( '%s' , $results['content'] );
		}
		echo $args['after_widget'];
	}

	function getPostQuery( $instance ){

		$content = '';
		$hideImage = !empty( $instance['image'] ) ? $instance['image'] : null;
		$hideComment = !empty( $instance['commentstatus'] ) ? $instance['commentstatus'] : null;
		$data = array();
		$args = array(
			'post_type' => 'post',
			'posts_per_page' => $instance['limit'],
			'order' => $instance['order'],
			'orderby' => $instance['orderby'],
			'post_status' => 'publish'
		);

		$args = apply_filters( 'extretion_widget_popular_post' , $args );

		$query = new WP_Query( $args );

		if( $query->have_posts() ){

			ob_start();
			echo '<ul class="recent-post-sm clearfix mb-20">';
			while( $query->have_posts() ){

				$query->the_post(); 

				global $post; ?>

				<li class="clearfix">
					<a href="<?php the_permalink(); ?>">	
					
						<?php 
						$image = $this->getImageUrl( $post->ID );

						/**
						* @param $hideImage == 1 ( Hide Image )
						*/

						if( !empty( $image ) && empty( $hideImage )){ ?>				
							<div class="image">
								<img src="<?php echo esc_url( $this->getImageUrl( $post->ID ) ); ?>" alt="<?php the_title(); ?>" />
							</div>
							<?php
							$removeSpace = ''; 
						} else {
							$removeSpace = 'margin-left: 0px;';
						}?>

						<div class="content" style="<?php echo esc_html( $removeSpace ); ?>">
							<h3><?php the_title(); ?></h3>

							<?php
							$comments = $this->getPublishedComments( $post->ID ); 

							if( $comments && empty($hideComment) ) { ?>
								<p class="recent-post-sm-meta">
									<i class="fa fa-comments mr-5"></i>
									<?php if( $comments == 1 ){
										echo esc_html( $comments ) . ' ' . esc_html__( 'comment' , 'extretion' );
									} else {
										echo esc_html( $comments ) . ' ' . esc_html__( 'comments' , 'extretion' );
									}?>
								</p>
								<?php 
							} ?>
						</div>
					</a>
				</li>

				<?php

			}
			echo '</ul>';
			$content = ob_get_clean();			
			$data['content'] = $content;
			$data['no_of_posts'] = $query->found_posts;
			wp_reset_postdata();
			return $data;

		} else {
			$data['no_of_posts'] = 0;
			return $data;
		}

	}

	function getPublishedComments( $post_id ){

		$args = array(
			'post_id' => $post_id,
			'status' => 'approve'
		);

		$results = get_comments( $args );
		return count( $results );

	}

	function getImageUrl( $post_id ){

		$post_thumbnail_id = get_post_thumbnail_id( $post_id );
		$image_attributes = wp_get_attachment_image_src( $post_thumbnail_id , 'thumbnail' );

		if( !empty( $image_attributes ) ){
			return $image_attributes[0];
		} else{
			return null;
		}

	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {

		//print_r($instance);

		$title = ! empty( $instance['title'] ) ? $instance['title'] : '';
		$order = ! empty( $instance['order'] ) ? $instance['order'] : 'DESC';
		$orderby = ! empty( $instance['orderby'] ) ? $instance['orderby'] : 'date';
		$commentstatus = ! empty( $instance['commentstatus'] ) ? $instance['commentstatus'] : '';
		$image = ! empty( $instance['image'] ) ? $instance['image'] : '';
		$limit = ! empty( $instance['limit'] ) ? $instance['limit'] : 5;

		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>">
				<?php esc_html_e( 'Title:' , 'extretion' ); ?>			
			</label> 
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'limit' ) ); ?>">
				<?php esc_html_e( 'Limit:' , 'extretion' ); ?>			
			</label> 
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'limit' ) ); ?>" type="text" value="<?php echo esc_attr( $limit ); ?>">
			<small><?php esc_html_e( 'No of posts to show' , 'extretion' ); ?></small>
		</p>
		<p>
			<label><?php esc_html_e( 'Order:' , 'extretion' ); ?></label>
			<br>
			<select name="<?php echo esc_attr( $this->get_field_name( 'order' ) ); ?>">
				<option value="ASC" <?php selected( $order , 'ASC' );?>><?php esc_html_e( 'Ascending' , 'extretion' ); ?></option>
				<option value="DESC" <?php selected( $order , 'DESC' );?>><?php esc_html_e( 'Decending' , 'extretion' ); ?></option>
			</select>
		</p>
		<p>
			<label><?php esc_html_e( 'Order By:' , 'extretion' ); ?></label>
			<br>
			<?php 
			$orderBy = array( 'name' , 'id' , 'title' , 'date' , 'rand'  );
			?>
			<select name="<?php echo esc_attr( $this->get_field_name( 'orderby' ) ); ?>">
				
				<?php 
					foreach( $orderBy as $value ){
						echo '<option ';
						selected( $orderby, $value );
						echo 'value="' . $value . '">' . ucfirst($value) . '</option>';
					}
				?>

			</select>
		</p>
		<p>
			<label>
				<input <?php checked( $commentstatus, 1 );?> value="1" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'commentstatus' ) ); ?>">
				<?php esc_html_e( 'Hide Number of comments' , 'extretion' ); ?>
			</label>
			<br>
			<label>
				<input <?php checked( $image, 1 );?> type="checkbox" value="1" name="<?php echo esc_attr( $this->get_field_name( 'image' ) ); ?>">
				<?php esc_html_e( 'Hide Image' , 'extretion' ); ?>
			</label>
		</p>

		<?php 
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['order'] = ( ! empty( $new_instance['order'] ) ) ? strip_tags( $new_instance['order'] ) : 'DESC';
		$instance['orderby'] = ( ! empty( $new_instance['orderby'] ) ) ? strip_tags( $new_instance['orderby'] ) : 'date';
		$instance['commentstatus'] = ( ! empty( $new_instance['commentstatus'] ) ) ? strip_tags( $new_instance['commentstatus'] ) : '';
		$instance['image'] = ( ! empty( $new_instance['image'] ) ) ? strip_tags( $new_instance['image'] ) : '';
		$instance['limit'] = ( ! empty( $new_instance['limit'] ) ) ? strip_tags( $new_instance['limit'] ) : '5';

		return $instance;
	}

}

function register_hotel_popular_posts_widget() {
    register_widget( 'hotel_popular_posts_widget' );
}
add_action( 'widgets_init', 'register_hotel_popular_posts_widget' );