<?php

/**
* All the notifications will be handled through here
*/

function extretion_save_notification( $title , $user_id , $category ){

	$my_post = array(
		'post_type'     => 'notification',
	  	'post_title'    => $title,
	  	'post_status'   => 'publish',
	  	'post_author'   => $user_id
	);

	// Insert the post into the database
	$post_id = wp_insert_post( $my_post );

	wp_set_post_terms( $post_id, $category , 'notification_type' );
	return $post_id;

}

/**
* When user changes the password, save it to the notification
*/

add_action( 'extretion_after_password_changed' , 'extretion_save_change_pass_notification' );
function extretion_save_change_pass_notification( $user_id ){

	$title = 'Password Successfully Changed';
	$category = 'extretion_notification_change_password';
	extretion_save_notification( $title , $user_id , $category );

}

function extretion_get_notification_page(){

	$page_id = get_option( 'options_select_notification_page' , '#' );

	return get_permalink( $page_id );
}

function extretion_get_notification_number(){

    $user_id = get_current_user_id();

    $args = array(
        'post_type' => 'notification',
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'author' => $user_id,
        'meta_query' => array(
            array(
                'key'     => 'notification_read',
                'compare' => 'NOT EXISTS',
            ),
        ),
    );

    $query = new WP_Query($args);
    return $query->post_count;

}

function extretion_count_notifications(){

    $notifications = extretion_get_notification_number();

    if( $notifications < 1 ){
        return;
    }

    echo '<span class="count bg-danger">' . $notifications . '</span>';

}

/**
* Get header notification 
*/

function extretion_header_notification(){

	if( !is_user_logged_in() ){
		return;
	} ?>

	<li class="has-msg">
		<a href="<?php echo extretion_get_notification_page(); ?>" class="icon-msg">
			<i class="fa fa-bell" aria-hidden="true"></i>
			<?php extretion_count_notifications(); ?>            
		</a>
	</li>

	<?php
}

function extretion_get_user_notification_messages(){

	$user_id = get_current_user_id();

    $per_page = get_option( 'notifications_per_page' );
    $per_page = !empty( $per_page ) ? $per_page : 10;

	$args = array(
		'post_type' => 'notification',
		'post_status' => 'publish',
		'posts_per_page' => $per_page,
		'author' => $user_id
	);

	$query = new WP_Query($args);
	$dates = array();

	if( $query->have_posts() ):

		while( $query->have_posts() ): $query->the_post();

			global $post;

			$post_date = get_the_date();

			if( !in_array( $post_date , $dates ) ){ ?>

				<div class="date_notify">

					<h4><span><?php echo extretion_get_day_name( strtotime( $post_date ) ); ?></span></h4>

				</div>

				<div class="clearfix"></div>

				<?php

				array_push( $dates , $post_date );
			}

			extretion_get_notification_types( $post );
            update_post_meta( $post->ID, 'notification_read', true );

		endwhile;

    else:

        echo '<div class="alert alert-info mt-10">' . esc_html__( 'You have no new notifications to display.' , 'extretion' ) . '</div>';	

	endif;

	wp_reset_postdata();

    if( $query->post_count ==  $per_page ){

        $load_more_title = get_option( 'notification_load_more_label' );
        $load_more_title = !empty( $load_more_title ) ? esc_html( $load_more_title ) : esc_html__( 'Load More' , 'extretion' );

        $notification_color = get_option( 'notification_load_more_label_background' );

        echo '<div class="load_more_wrapper ">';
        echo '<a data-page="2" data-post-date="' . date( 'Y-m-d' , strtotime( $post_date ) ) . '" class="btn btn-primary mt-20 notification_load_more_label" style="border-color: ' . $notification_color . '; background:' . $notification_color . '">';
        echo $load_more_title;
        echo '</a></div>';

    }

}

add_action( 'wp_ajax_extretion_get_more_notifications' , 'extretion_get_more_notifications' );
function extretion_get_more_notifications(){

    $data = array_map( 'sanitize_text_field' , $_POST );

    if( empty( $data['page_no'] ) || empty( $data['recent_date'] ) ){
        echo json_encode(
            array(
                'content' => null,
                'page_no' => null,
                'recent_date' => null,
                'unread_notifications' => null
            )
        );

        die;
    }

    $user_id = get_current_user_id();

    $per_page = get_option( 'notifications_per_page' );
    $per_page = !empty( $per_page ) ? $per_page : 10;

    $paged = ( is_numeric( $data['page_no'] ) ? $data['page_no'] : 1 );
    $recent_date = ( !empty( $data['recent_date'] ) ? $data['recent_date'] : '' );

    $args = array(
        'post_type' => 'notification',
        'post_status' => 'publish',
        'posts_per_page' => $per_page,
        'author' => $user_id,
        'paged' => $paged
    );

    $query = new WP_Query($args);
    $content = '';
    $dates = array();

    if( $query->have_posts() ):

        ob_start();

        while( $query->have_posts() ): $query->the_post();

            global $post;

            $post_date_1 = get_the_date();

            if( $recent_date != date( 'Y-m-d' , strtotime( $post->post_date ) ) && !in_array( $post_date_1 , $dates ) ){ ?>

                <div class="date_notify">

                    <h4><span><?php echo extretion_get_day_name( strtotime( $post->post_date ) ); ?></span></h4>

                </div>

                <div class="clearfix"></div>

                <?php

                array_push( $dates , $post_date_1 );

            }

            $post_date = date( 'Y-m-d' , strtotime( get_the_date() ) );
            extretion_get_notification_types( $post );
            update_post_meta( $post->ID, 'notification_read', true );

        endwhile;

        $content .= ob_get_clean();
        $next_page = $paged + 1;

    else:

        $content = null;
        $post_date = null;

    endif;

    wp_reset_postdata();

    echo json_encode(
        array(
            'content' => $content,
            'page_no' => ( $query->post_count < $per_page ? null : $next_page ),
            'recent_date' => $post_date,
            'unread_notifications' => extretion_get_notification_number()
        )
    );

    die;

}

function extretion_get_notification_types( $post ){

    $category = wp_get_post_terms( $post->ID, 'notification_type' );

    if( !empty( $category ) && is_array( $category ) ){

        switch ( $category[0]->slug ) {

            case 'extretion_notification_change_password':
                extretion_get_password_change_notification( $post );
                break;

            case 'extretion_notification_waiting_approval':
                extretion_get_waiting_approval_notification( $post );
                break;

            case 'extretion_notification_booking_accepted':
                extretion_get_booking_accepted_notification( $post );
                break;

            case 'extretion_notification_confirmed_booking':
                extretion_get_confirmed_booking_notification( $post );
                break;

            case 'extretion_notification_booking_cancelled_by_traveler':
                extretion_get_booking_cancelled_by_traveler_notification( $post );
                break;

            case 'extretion_notification_booking_denied_by_host':
                extretion_get_booking_denied_by_host_notification( $post );
                break;

            case 'extretion_notification_booking_exceeded_check_in_date':
                extretion_get_booking_exceeded_check_in_date_notification( $post );
                break;

            case 'extretion_notification_booking_exceeded_14_days':
                extretion_get_booking_exceeded_14_days_notification( $post );
                break;

            case 'extretion_notification_payment_not_done_after_48hrs':
                extretion_booking_payment_not_done_after_48hrs( $post );
                break;
            
            default:
                # code...
                break;
        }

    }

}

function extretion_get_day_name($timestamp) {

    $date = date('d/m/Y', $timestamp);

    if($date == date('d/m/Y')) {
      	$date = esc_html__( 'Today', 'extretion' );
      	return $date;
    } 
    else if($date == date('d/m/Y',time() - (24 * 60 * 60))) {
      	$date = esc_html__( 'Yesterday' , 'extretion' );;
      	return $date;
    }

    return date( 'F j, Y' , $timestamp );
}

function extretion_get_password_change_notification( $post ){ ?>

	<!-- Successfully Password Change -->
	<div class="single_notification">

        <div class="col-sm-12">
        	<p class="label label-success password_notification_settings_label" style="background: <?php echo get_option( 'password_notification_settings_color_label' ); ?>">
        		<?php 
        		$title = get_option( 'password_notification_settings_label' );
        		$title = !empty( $title ) ? $title : esc_html__( 'Password Successfully Changed' , 'extretion' );
        		echo esc_html( $title ); ?>
        	</p>
        	<p class="notification_message password_notification_settings_sublabel">
        		<?php 
        		$subtitle = get_option( 'password_notification_settings_sublabel' );
        		$subtitle = !empty( $subtitle ) ? $subtitle : esc_html__( 'You have successfully changed your password.' , 'extretion' );
        		echo esc_html( $subtitle );
        		?>
        	</p>
        	<p class="notification_date">
        		<i class="fa fa-calendar" aria-hidden="true"></i> 
        		<span class="date_text"><?php echo get_the_date( null , $post->ID ); ?></span>
        	</p>
        </div>

	</div>

	<?php
}

function extretion_get_room_name( $room_id ){

	$post = get_post( $room_id );

	if( is_object( $post ) ){
		return get_the_title( $room_id );
	} else {
		return '<del>' . esc_html__( 'Room Deleted', 'extretion' ) . '</del>';
	}

}

function extretion_booking_payment_not_done_after_48hrs( $post ){ ?>
    
    <div class="single_notification">

        <div class="col-sm-10">
            <p class="label label-danger after_48_hrs_no_payment_notification_settings_label" style="background: <?php echo get_option( 'after_48_hrs_no_payment_notification_settings_color_label' ); ?>">
                <?php 
                $title = get_option( 'after_48_hrs_no_payment_notification_settings_label' );
                $title = !empty( $title ) ? esc_html( $title ) : esc_html__( 'Deleted Booking Request', 'extretion' );
                echo $title;
                ?>
            </p>
            <p class="notification_message after_48_hrs_no_payment_notification_settings_sublabel">
                <?php 
                $subtitle = get_option( 'after_48_hrs_no_payment_notification_settings_sublabel' );
                $subtitle = !empty( $subtitle ) ? esc_html( $subtitle ) : esc_html__( 'Booking fee of [invoice_name] has not been paid by the traveler within 48hrs so we have deleted the booking request.' , 'extretion' );

                $room_id = get_post_meta( $post->ID, 'room_id' , true );

                if( !empty( $room_id ) ){
                    $room_name = '<strong><i>' . extretion_get_room_name( $room_id ) . '</i></strong>';
                    $subtitle_new = str_replace( '[invoice_name]', $room_name, $subtitle );
                } else{
                    $subtitle_new = str_replace( '[invoice_name]', '<del>' . esc_html__( 'Room Deleted', 'extretion' ) . '</del>', $subtitle );
                }
                echo $subtitle_new;
                ?>
            </p>
            <p class="notification_date">
                <i class="fa fa-calendar" aria-hidden="true"></i> <span class="date_text">
                    <?php echo get_the_date( null , $post->ID ); ?>
                </span>
            </p>
        </div>

    </div>

    <?php
}

function extretion_get_booking_exceeded_14_days_notification( $post ){ ?>
	
	<div class="single_notification">

        <div class="col-sm-10">
        	<p class="label label-danger after_14_days_exceeded_notification_settings_label" style="background: <?php echo get_option( 'after_14_days_exceeded_notification_settings_color_label' ); ?>">
        		<?php 
        		$title = get_option( 'after_14_days_exceeded_notification_settings_label' );
        		$title = !empty( $title ) ? esc_html( $title ) : esc_html__( 'Deleted Booking Request', 'extretion' );
        		echo $title;
        		?>
        	</p>
        	<p class="notification_message after_14_days_exceeded_notification_settings_sublabel">
        		<?php 
        		$subtitle = get_option( 'after_14_days_exceeded_notification_settings_sublabel' );
        		$subtitle = !empty( $subtitle ) ? esc_html( $subtitle ) : esc_html__( 'Booking request [invoice_name] has not been answered by the owner for last 14 days and now has been removed.' , 'extretion' );

        		$room_id = get_post_meta( $post->ID, 'room_id' , true );

        		if( !empty( $room_id ) ){
        			$room_name = '<strong><i>' . extretion_get_room_name( $room_id ) . '</i></strong>';
        			$subtitle_new = str_replace( '[invoice_name]', $room_name, $subtitle );
        		} else{
        			$subtitle_new = str_replace( '[invoice_name]', '<del>' . esc_html__( 'Room Deleted', 'extretion' ) . '</del>', $subtitle );
        		}
        		echo $subtitle_new;
        		?>
        	</p>
        	<p class="notification_date">
        		<i class="fa fa-calendar" aria-hidden="true"></i> <span class="date_text"><?php echo get_the_date( null , $post->ID ); ?></span>
        	</p>
        </div>

	</div>

	<?php
}

function extretion_get_booking_exceeded_check_in_date_notification( $post ){ ?>

	<div class="single_notification">

        <div class="col-sm-10">
        	<p class="label label-danger check_in_date_exceeded_notification_settings_label" style="background: <?php echo get_option( 'check_in_date_exceeded_notification_settings_color_label' ); ?>">
        		<?php 
        		$title = get_option( 'check_in_date_exceeded_notification_settings_label' );
        		$title = !empty( $title ) ? esc_html( $title ) : esc_html__( 'Deleted Booking Request', 'extretion' );
        		echo $title;
        		?>
        	</p>
        	<p class="notification_message check_in_date_exceeded_notification_settings_sublabel">
        		<?php 
        		$subtitle = get_option( 'check_in_date_exceeded_notification_settings_sublabel' );
        		$subtitle = !empty( $subtitle ) ? esc_html( $subtitle ) : esc_html__( 'Booking request [invoice_name] has been removed because it has not been answered by the owner and it has exceeded the Check In Date.' , 'extretion' );

        		$room_id = get_post_meta( $post->ID, 'room_id' , true );

        		if( !empty( $room_id ) ){
        			$room_name = '<strong><i>' . extretion_get_room_name( $room_id ) . '</i></strong>';
        			$subtitle_new = str_replace( '[invoice_name]', $room_name, $subtitle );
        		} else{
        			$subtitle_new = str_replace( '[invoice_name]', '<del>' . esc_html__( 'Room Deleted', 'extretion' ) . '</del>', $subtitle );
        		}
        		echo $subtitle_new;
        		?>
        	</p>
        	<p class="notification_date">
        		<i class="fa fa-calendar" aria-hidden="true"></i> <span class="date_text">
        			<?php echo get_the_date( null , $post->ID ); ?>
        		</span>
        	</p>
        </div>

	</div>

	<?php
}

function extretion_get_booking_denied_by_host_notification( $post ){ ?>

	<div class="single_notification">
	
        <div class="col-sm-10">
        	<p class="label label-danger denied_booking_by_host_notification_settings_label" style="background: <?php echo get_option( 'denied_booking_by_host_notification_settings_color_label' ); ?>">
        		<?php 
        		$title = get_option( 'denied_booking_by_host_notification_settings_label' );
        		$title = !empty( $title ) ? esc_html( $title ) : esc_html__( 'Cancelled Booking Request', 'extretion' );
        		echo $title;
        		?>
        	</p>
        	<p class="notification_message denied_booking_by_host_notification_settings_sublabel">
        		<?php 
        		$subtitle = get_option( 'denied_booking_by_host_notification_settings_sublabel' );
        		$subtitle = !empty( $subtitle ) ? esc_html( $subtitle ) : esc_html__( 'Booking request [invoice_name] was denied by host.' , 'extretion' );

        		$room_id = get_post_meta( $post->ID, 'room_id' , true );

        		if( !empty( $room_id ) ){
        			$room_name = '<strong><i>' . extretion_get_room_name( $room_id ) . '</i></strong>';
        			$subtitle_new = str_replace( '[invoice_name]', $room_name, $subtitle );
        		} else{
        			$subtitle_new = str_replace( '[invoice_name]', '<del>' . esc_html__( 'Room Deleted', 'extretion' ) . '</del>', $subtitle );
        		}
        		echo $subtitle_new;
        		?>
        	</p>
        	<p class="notification_date">
        		<i class="fa fa-calendar" aria-hidden="true"></i> <span class="date_text"><?php echo get_the_date( null , $post->ID ); ?></span>
        	</p>
        </div>

	</div>

	<?php
}

function extretion_get_booking_cancelled_by_traveler_notification( $post ){ ?>

	<div class="single_notification">

        <div class="col-sm-10">
        	<p class="label label-danger cancelled_booking_by_traveler_notification_settings_label" style="background: <?php echo get_option( 'cancelled_booking_by_traveler_notification_settings_color_label' ); ?>">
        		<?php 
        		$title = get_option( 'cancelled_booking_by_traveler_notification_settings_label' );
        		$title = !empty( $title ) ? esc_html( $title ) : esc_html__( 'Cancelled Booking Request', 'extretion' );
        		echo $title;
        		?>
        	</p>
        	<p class="notification_message cancelled_booking_by_traveler_notification_settings_sublabel">
        		<?php 
        		$subtitle = get_option( 'cancelled_booking_by_traveler_notification_settings_sublabel' );
        		$subtitle = !empty( $subtitle ) ? esc_html( $subtitle ) : esc_html__( 'Booking request [invoice_name] was cancelled by Traveler.' , 'extretion' );

        		$room_id = get_post_meta( $post->ID, 'room_id' , true );

        		if( !empty( $room_id ) ){
        			$room_name = '<strong><i>' . extretion_get_room_name( $room_id ) . '</i></strong>';
        			$subtitle_new = str_replace( '[invoice_name]', $room_name, $subtitle );
        		} else{
        			$subtitle_new = str_replace( '[invoice_name]', '<del>' . esc_html__( 'Room Deleted', 'extretion' ) . '</del>', $subtitle );
        		}

        		echo $subtitle_new;
        		?>
        	</p>
        	<p class="notification_date">
        		<i class="fa fa-calendar" aria-hidden="true"></i> <span class="date_text"><?php echo get_the_date( null , $post->ID ); ?></span>
        	</p>
        </div>

	</div>

	<?php
}

function extretion_get_confirmed_booking_notification( $post ){ ?>

	<div class="single_notification">

        <div class="col-sm-10">
        	<p class="label label-success successful_payment_notification_settings_label" style="background: <?php echo get_option( 'successful_payment_notification_settings_color_label' ); ?>">
        		<?php 
        		$title = get_option( 'successful_payment_notification_settings_label' );
        		$title = !empty( $title ) ? esc_html( $title ) : esc_html__( 'Payment Successful', 'extretion' );
        		echo $title;
        		?>
        	</p>
        	<p class="notification_message successful_payment_notification_settings_sublabel">
        		<?php 
        		$subtitle = get_option( 'successful_payment_notification_settings_sublabel' );
        		$subtitle = !empty( $subtitle ) ? esc_html( $subtitle ) : esc_html__( 'You have successfully paid for [room_name].' , 'extretion' );

        		$room_id = get_post_meta( $post->ID, 'room_id' , true );

        		if( !empty( $room_id ) ){
        			$room_name = '<a target="_blank" href="' . get_permalink( $room_id ) . '">' . extretion_get_room_name( $room_id ) . '</a>';
        			$subtitle_new = str_replace( '[room_name]', $room_name, $subtitle );
        		} else{
        			$subtitle_new = str_replace( '[room_name]', '<del>' . esc_html__( 'Room Deleted', 'extretion' ) . '</del>', $subtitle );
        		}

        		echo $subtitle_new;
        		?>
        	</p>
        	<p class="notification_date">
        		<i class="fa fa-calendar" aria-hidden="true"></i> <span class="date_text"><?php echo get_the_date( null , $post->ID ); ?></span>
        	</p>
        </div>

	</div>	

	<?php
}

function extretion_get_booking_accepted_notification( $post ){ ?>
	
	<div class="single_notification">

        <div class="col-sm-10">
        	<p class="label label-warning pending_payment_notification_settings_label" style="background: <?php echo get_option( 'pending_payment_notification_settings_color_label' ); ?>">
        		<?php 
        		$title = get_option( 'pending_payment_notification_settings_label' );
        		$title = !empty( $title ) ? esc_html( $title ) : esc_html__( 'Pending Payment', 'extretion' );
        		echo $title;
        		?>
        	</p>
        	<p class="notification_message pending_payment_notification_settings_sublabel">
        		<?php 
        		$subtitle = get_option( 'pending_payment_notification_settings_sublabel' );
        		$subtitle = !empty( $subtitle ) ? esc_html( $subtitle ) : esc_html__( 'You have a pending payment for [room_name].' , 'extretion' );

        		$room_id = get_post_meta( $post->ID, 'room_id' , true );

        		$room_name = '<a target="_blank" href="' . get_permalink( $room_id ) . '">' . extretion_get_room_name( $room_id ) . '</a>';
        		$subtitle_new = str_replace( '[room_name]', $room_name, $subtitle );

        		echo $subtitle_new;
        		?>
        	</p>
        	<p class="notification_date">
        		<i class="fa fa-calendar" aria-hidden="true"></i> <span class="date_text"><?php echo get_the_date( null , $post->ID ); ?></span>
        	</p>
        </div>

	</div>

	<?php
}

function extretion_get_waiting_approval_notification( $post ){ ?>

	<!-- Booking Request -->
	<div class="single_notification">

        <div class="col-sm-12">
        	<p class="label label-success booking_request_notification_settings_label" style="background: <?php echo get_option( 'booking_request_notification_settings_color_label' ); ?>">
        		<?php 
        		$title = get_option( 'booking_request_notification_settings_label' );
        		$title = !empty( $title ) ? esc_html( $title ) : esc_html__( 'Booking Request', 'extretion' );
        		echo $title;
        		?>
        	</p>
        	<p class="notification_message booking_request_notification_settings_sublabel">
        		<?php 
        		$subtitle = get_option( 'booking_request_notification_settings_sublabel' );
        		$subtitle = !empty( $subtitle ) ? esc_html( $subtitle ) : esc_html__( 'You have received a booking request for [room_name].' , 'extretion' );

        		$room_id = get_post_meta( $post->ID, 'room_id' , true );

        		$room_name = '<a target="_blank" href="' . get_permalink( $room_id ) . '">' . extretion_get_room_name( $room_id ) . '</a>';
        		$subtitle_new = str_replace( '[room_name]', $room_name, $subtitle );

        		echo $subtitle_new;
        		?>
        	</p>
        	<p class="notification_date">
        		<i class="fa fa-calendar" aria-hidden="true"></i> 
        		<span class="date_text"><?php echo get_the_date( null , $post->ID ); ?></span>
        	</p>
        </div>

	</div>

	<?php
}

/**
* After Payment Successful
*/

add_action( 'extretion_after_payment_successful' , 'extretion_after_payment_successful_notification' );
function extretion_after_payment_successful_notification( $invoice_id ){

	$invoice_object = get_post( $invoice_id );

	if( !is_object( $invoice_object ) ){
		return;
	}

	$hotel_id = get_post_meta( $invoice_id, 'hotel_owner', true );
	$traveller_id = $invoice_object->post_author;

	$invoice_details = get_post_meta( $invoice_id, 'invoice_details', true );
	$room_id = $invoice_details['post_id'];

	$title = 'Confirmed Booking';
	$category = 'extretion_notification_confirmed_booking';

	$notification_id = extretion_save_notification( $title , $hotel_id , $category );
	update_post_meta( $notification_id, 'room_id', $room_id );

	$notification_id = extretion_save_notification( $title , $traveller_id , $category );
	update_post_meta( $notification_id, 'room_id', $room_id );

}

/**
* After booking request sent save it to the notification
*/

add_action( 'extretion_after_booking_request_send' , 'extretion_after_booking_request_send_notification' );
function extretion_after_booking_request_send_notification( $invoice_id ){

	$invoice_details = get_post_meta( $invoice_id, 'invoice_details', true ); // Get Invoice Details

	$room_object = get_post( $invoice_details['post_id'] ); // Get room object ( host )

	$user_id = $room_object->post_author; // Host id

	$title = 'Waiting For Approval From Host ( Accept/Deny )';
	$category = 'extretion_notification_waiting_approval';
	$notification_id = extretion_save_notification( $title , $user_id , $category );
	update_post_meta( $notification_id, 'room_id', $invoice_details['post_id'] );

}

/**
* After booking is accepted by the host
*/

add_action( 'extretion_after_booking_request_accept' , 'extretion_after_booking_request_accept_notification' , 10 , 3 );
function extretion_after_booking_request_accept_notification( $host_id , $traveler_id , $invoice_id ){

	$invoice_details = get_post_meta( $invoice_id, 'invoice_details', true ); // Get Invoice Details

	$title = 'Booking has been accepted by the host';
	$category = 'extretion_notification_booking_accepted';
	$notification_id = extretion_save_notification( $title , $traveler_id , $category );
	update_post_meta( $notification_id, 'room_id', $invoice_details['post_id'] );

}

add_action( 'extretion_after_cancelled_booking_by_traveller' , 'extretion_after_cancelled_booking_by_traveller_notification' , 10 , 2 );
function extretion_after_cancelled_booking_by_traveller_notification( $room_id , $traveller_id ){

	$room_object = get_post( $room_id );
	$host_id = $room_object->post_author;

	$title = 'Booking request cancelled by traveler';
	$category = 'extretion_notification_booking_cancelled_by_traveler';
	$notification_id = extretion_save_notification( $title , $host_id , $category );
	update_post_meta( $notification_id, 'room_id', $room_id );

}

add_action( 'extretion_after_cancelled_booking_by_hotel' , 'extretion_after_cancelled_booking_by_hotel_notification', 10, 2 );
function extretion_after_cancelled_booking_by_hotel_notification( $room_id , $traveller_id ){

	$title = 'Booking request denied by the host';
	$category = 'extretion_notification_booking_denied_by_host';
	$notification_id = extretion_save_notification( $title , $traveller_id , $category );
	update_post_meta( $notification_id, 'room_id', $room_id );

}

add_action( 'extretion_after_delete_invoices_check_in_date' , 'extretion_after_delete_invoices_check_in_date_notification', 10 , 3 );
function extretion_after_delete_invoices_check_in_date_notification( $room_id , $traveller_id , $host_id ){

	$title = 'Booking exceeded Check-in-date';
	$category = 'extretion_notification_booking_exceeded_check_in_date';

	$notification_id = extretion_save_notification( $title , $traveller_id , $category );
	update_post_meta( $notification_id, 'room_id', $room_id );

	//$notification_id = extretion_save_notification( $title , $host_id , $category );
	//update_post_meta( $notification_id, 'room_id', $room_id );

}

add_action( 'extretion_after_delete_invoices_after_14_days' , 'extretion_after_delete_invoices_after_14_days_notification' , 10 , 3 );
function extretion_after_delete_invoices_after_14_days_notification( $room_id , $traveller_id , $host_id ){

	$title = 'Booking exceeded 14 days';
	$category = 'extretion_notification_booking_exceeded_14_days';

	$notification_id = extretion_save_notification( $title , $traveller_id , $category );
	update_post_meta( $notification_id, 'room_id', $room_id );

	//$notification_id = extretion_save_notification( $title , $host_id , $category );
	//update_post_meta( $notification_id, 'room_id', $room_id );

}

add_action( 'extretion_delete_booking_after_no_payment_48hrs' , 'extretion_delete_booking_after_no_payment_48hrs_notification' , 10 , 3 );
function extretion_delete_booking_after_no_payment_48hrs_notification( $room_id, $traveller_id, $host_id ){

    $title = 'Payment not done after 48hrs';
    $category = 'extretion_notification_payment_not_done_after_48hrs';

    $notification_id = extretion_save_notification( $title , $host_id , $category );
    update_post_meta( $notification_id, 'room_id', $room_id );

}