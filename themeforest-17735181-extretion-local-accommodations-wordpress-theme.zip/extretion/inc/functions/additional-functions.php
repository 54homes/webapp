<?php

/**
* Add new price section on the "Room Key Facts" on the single room page.
*/

add_filter( 'extretion_room_key_facts' , 'extretion_add_prices_details_room_key_facts' , 10 , 2 );
function extretion_add_prices_details_room_key_facts( $args , $post_id ){

	$cancellation_policy = get_post_meta( $post_id, 'cancellation_policy' , true );
	$weekly_discount = get_post_meta( $post_id, 'weekly_discount' , true );
	$monthly_discount = get_post_meta( $post_id, 'monthly_discount' , true );

	$space = $args[0];
	unset( $args[0] );

	$prices_details = array(
		'title' => esc_html__( 'Prices' , 'extretion' ),
		'outer_wrapper_start' => '<div class="row">',
		'outer_wrapper_end' => '</div>',
		'inner_wrapper_start' => '<div class="col-sm-12">',
		'inner_wrapper_end' => '</div>',
		'fields' => array(
			'extra_charge' => 
			sprintf(
				__( 'Extra people : <strong>%s / night after the first guest</strong>' , 'extretion' ), 
				get_extra_people_price_single_room( $post_id )
			),
			'cancellation_policy' => 
			sprintf(
				__( 'Cancellation Policy : <strong>%s</strong>' , 'extretion' ),
				sanitize_text_field( ucfirst( $cancellation_policy ) ) 
			),
		)
	);

	/**
	* If Weekly discount is not null
	*/

	if( ctype_digit( $weekly_discount ) && $weekly_discount > 0 ){

		$prices_details['fields']['weekly_discount'] = sprintf(
			__( 'Weekly Discount : <strong>%s&#37;</strong>' , 'extretion' ),
			(int) $weekly_discount
		);

	}

	/**
	* If Monthly discount is not null
	*/
	
	if( ctype_digit( $monthly_discount ) && $monthly_discount > 0 ){

		$prices_details['fields']['monthly_discount'] = sprintf(
			__( 'Monthly Discount : <strong>%s&#37;</strong>' , 'extretion' ), 
			(int) $monthly_discount
		);

	}

	$join = array_merge( array( $space ) , array( $prices_details ) , $args );

	return $join;

}

add_filter( 'extretion_room_key_facts' , 'extretion_room_pet_policy' , 20 , 2 );
function extretion_room_pet_policy( $args , $post_id ){

	/**
	* Pet policy field
	*/

	$pet_policy = get_post_meta( $post_id, 'pet_policy' , true );
	$pet_policy_field = array(
		'title' => esc_html__( 'Pet Policy' , 'extretion' ),
		'outer_wrapper_start' => '<div>',
		'outer_wrapper_end' => '</div>',
		'inner_wrapper_start' => '<div>',
		'inner_wrapper_end' => '</div>',
		'fields' => array(
			'required_at' => extretion_addLineBreak( $pet_policy ),
		)
	);

	array_push( $args, $pet_policy_field );

	/**
	* Cancellation policy field
	*/

	$cancellation_policy = get_post_meta( $post_id, 'cancellation_policy_room' , true );
	$cancellation_policy_field = array(
		'title' => esc_html__( 'Cancellation Policy' , 'extretion' ),
		'outer_wrapper_start' => '<div>',
		'outer_wrapper_end' => '</div>',
		'inner_wrapper_start' => '<div>',
		'inner_wrapper_end' => '</div>',
		'fields' => array(
			'required_at' => extretion_addLineBreak( $cancellation_policy ),
		)
	);

	array_push( $args, $cancellation_policy_field );

	/**
	* Payment policy field
	*/

	$payment_policy = get_post_meta( $post_id, 'payment_policy_room' , true );
	$payment_policy_field = array(
		'title' => esc_html__( 'Payment Policy' , 'extretion' ),
		'outer_wrapper_start' => '<div>',
		'outer_wrapper_end' => '</div>',
		'inner_wrapper_start' => '<div>',
		'inner_wrapper_end' => '</div>',
		'fields' => array(
			'required_at' => extretion_addLineBreak( $payment_policy ),
		)
	);

	array_push( $args, $payment_policy_field );

	return $args;

}

add_filter( 'extretion_room_key_facts' , 'extretion_add_availability_details_room_key_facts' , 30 , 2 );
function extretion_add_availability_details_room_key_facts( $args , $post_id ){

	$min_booking_duration = get_post_meta( $post_id, 'min_booking_duration' , true );

	$availability = array(
		'title' => esc_html__( 'Availability' , 'extretion' ),
		'outer_wrapper_start' => '<div class="row">',
		'outer_wrapper_end' => '</div>',
		'inner_wrapper_start' => '<div class="col-sm-4">',
		'inner_wrapper_end' => '</div>',
		'fields' => array(
			'min_booking_duration' => 
			sprintf(
				_n( 
					'%d night minimum stay', 
					'%d nights minimum stay', 
					(int) $min_booking_duration, 
					'extretion' 
				),
				(int) $min_booking_duration
			)
		)
	);

	/**
	* Hide view calendar buttom from the hotel owner
	*/

	$post = get_post( $post_id );
	$user_id = get_current_user_id();

	if( $user_id != $post->post_author ){
		$availability['fields']['view_calendar'] = '<a href="#" class="single_page_view_calendar_btn">' . esc_html__( 'View Calendar' , 'extretion' ) . '</a>';
	}

	array_push( $args, $availability );

	return $args;

}

function get_per_night_price( $post_id ){

	$price_per_day = get_post_meta( $post_id, 'per_night_price', true );
	$user_currency = get_post_meta( $post_id, 'user_currency', true );
	$only_currency = extretion_exchange_currency( $price_per_day , $user_currency , true );

	$price = extretion_exchange_currency( $price_per_day , $user_currency );

	$content = '<span class="currency_symbol">' . extretion_currency_symbol( $only_currency ) . '</span> ';

	// Get only price ( Exclude currency )
	return $content . preg_replace("/[^0-9\.]/", null, $price ); 

}

function get_extra_people_price_single_room( $post_id ){

	$charge_extra_people = get_post_meta( $post_id, 'charge_extra_people' , true );

	if( $charge_extra_people == 'yes' ){
		return get_per_night_price( $post_id );
	} else {
		return esc_html__( 'No Charge', 'extretion' );
	}

}

/**
* Remove the additional CSS section, introduced in 4.7, from the Customizer.
* @param $wp_customize WP_Customize_Manager
*/

add_action( 'customize_register', 'extretion_prefix_remove_css_section', 15 );
function extretion_prefix_remove_css_section( $wp_customize ) {
	//echo '<pre>'; print_r($wp_customize); echo '</pre>';
	$wp_customize->remove_section( 'custom_css' );
	$wp_customize->remove_section( 'background_image' );
	$wp_customize->remove_section( 'header_image' );
	$wp_customize->remove_section( 'colors' );	
	
}

/**
* Get image id from url
* @src https://pippinsplugins.com/retrieve-attachment-id-from-image-url/
* @return integer
*/

function extretion_get_image_id( $image_url ) {
	
	global $wpdb;
	
	if( !empty( $image_url ) ){
		$attachment = $wpdb->get_col($wpdb->prepare("SELECT ID FROM $wpdb->posts WHERE guid='%s';", $image_url )); 
		if( !empty( $attachment ) ){
			return $attachment[0];	
		} else {
			return false;
		}
        	
	}

	return false;
	 
}

/**
* This is for the kirki select fields
*/

function extretion_get_post_type_options( $post_type ){

	$data = array();
	$args = array(
		'post_type' => $post_type,
		'post_status' => 'publish',
		'posts_per_page' => -1
	);

	$query = new WP_Query( $args );

	if( $query->have_posts() ):

		$data[''] = '- Select -';

		while( $query->have_posts() ): $query->the_post();

			global $post;
			$data[$post->ID] = get_the_title( $post );

		endwhile;

	endif;

	wp_reset_postdata();

	return $data;
}

function extretion_get_terms( $taxonomy ){

	$terms = get_terms( array(
	    'taxonomy' => $taxonomy,
	    'hide_empty' => false,
	) );
	$data = array();
	if( !empty( $terms ) && is_array( $terms ) ){
		
		foreach($terms as $term) {

		    if ($term->parent != 0) { // avoid parent categories
		       $data[$term->term_id] = $term->name;
		    }

		}

	}

	return $data;	

}

function extretion_get_preloader(){

	$status = get_option( 'options_header_preloader' );

	if( $status == 1 ){
		echo '<div id="introLoader" class="introLoading"></div>';
	}

}

/**
* Add google api key to the acf google map backend
*/

add_filter('acf/fields/google_map/api', 'extretion_acf_google_map_api');
function extretion_acf_google_map_api( $api ){

	$google_map_key_default = 'AIzaSyBdVZzc9OkLOkR-t5dIt7mgnsg4vnrO1Pk';
	$db_google_api = get_option( 'options_lmh_google_map_api' , '' );
	$db_google_api = !empty( $db_google_api ) ? $db_google_api : $google_map_key_default;

	$api['key'] = $db_google_api;
	return $api;	
}

add_action( 'pre_get_posts', 'extretion_modify_taxonomy_query' );

function extretion_modify_taxonomy_query( $query ) {

	if ( !is_admin() && $query->is_main_query() ) {

  		if ( is_tax() ) {
  			$no_of_rooms_category_page = get_option( 'options_no_of_rooms_category_page' );
    		$query->set( 'posts_per_page', $no_of_rooms_category_page );
  		} 

	}

	//echo '<pre>'; print_r($query); echo '</pre>';

}

/**
* Remove admin menu 
*/

add_action( 'admin_menu', 'extretion_remove_admin_menus' );
function extretion_remove_admin_menus() {
    remove_menu_page( 'edit.php?post_type=notification' );
    remove_menu_page( 'edit.php?post_type=messages' );
}

/*
* Hide admin bar for non admins
*/

add_action( 'after_setup_theme', 'extretion_remove_admin_bar');
function extretion_remove_admin_bar() {
    if (!current_user_can('administrator') && !is_admin()) {
      	show_admin_bar(false);
    }
}

/**
* Get page id ny page template
*/

//add_action( 'init' , 'extretion_get_page_id_by_page_template' );
function extretion_get_page_id_by_page_template( $page_template = null ){

	$args = array(
	    'post_type' => 'page',
	    'fields' => 'ids',
	    'nopaging' => true,
	    'meta_key' => '_wp_page_template',
	    'meta_value' => $page_template,
	    'posts_per_page' => 1
	);

	$pages = get_posts( $args );

	if( !empty( $pages ) && is_array( $pages ) ){
		return $pages[0];	
	} else {
		return false;
	}
}

/**
* Disable verification email
*/

add_action( 'wp_head', 'extretion_remove_email_notify_action' );
function extretion_remove_email_notify_action(){

	if( get_option( 'options_email_verification' ) == 2 ){
		remove_action( 'extretion_after_registration_complete' , 'extretion_verification_mail' , 10 );
	}
	
}

/**
* Send email to host of booking
*/

add_action( 'wp_ajax_extretion_book_by_email_action' , 'extretion_book_by_email_action' );
add_action( 'wp_ajax_nopriv_extretion_book_by_email_action' , 'extretion_book_by_email_action' );

function extretion_book_by_email_action(){

	parse_str( $_POST['values'], $data );

	$empty_removed = array_filter($data);

	$compulsory_fields = array(
		'booking_first_name',
		'booking_last_name',
		'booking_email',
		'booking_phone'
	);

	$error_status = false;
	$error_msg = '';
	$error_field = array();

	foreach( $compulsory_fields as $field ){

		if( !array_key_exists( $field , $empty_removed ) ){

			$error_status = true;

			switch ( $field ) {
				case 'booking_first_name':
					$error_msg .= '<li>' . esc_html__( 'Please write your first name.' , 'extretion' ) . '</li>';
					$error_field[] = '[id="booking_first_name"]';
					break;

				case 'booking_last_name':
					$error_msg .= '<li>' . esc_html__( 'Please write your last name.' , 'extretion' ) . '</li>';
					$error_field[] = '[id="booking_last_name"]';
					break;

				case 'booking_email':
					$error_msg .= '<li>' . esc_html__( 'Please write your email.' , 'extretion' ) . '</li>';
					$error_field[] = '[id="booking_email"]';
					break;

				case 'booking_phone':
					$error_msg .= '<li>' . esc_html__( 'Please write your phone no.' , 'extretion' ) . '</li>';
					$error_field[] = '[id="booking_phone"]';
					break;
				
				default:
					# code...
					break;
			}			

		}

	}

	$empty_removed['booking_email'] = empty( $empty_removed['booking_email'] ) ? '' : $empty_removed['booking_email'];

	if( !is_email( $empty_removed['booking_email'] ) ){
		$error_status = true;
		$error_msg .= '<li>' . esc_html__( 'Please enter valid email.' , 'extretion' ) . '</li>';
		$error_field[] = '[id="booking_email"]';
	}

	// If there are no error then create new booking invoice on the backend
	if( $error_status == false ){
		$booking_email_id = extretion_create_booking_email_post( $data );
		do_action( 'extretion_after_booking_email_saved' , $booking_email_id );
	}

	echo json_encode(
		array(
			'status' => $error_status,
			'error_message' => $error_msg,
			'success_message' => esc_html__( 'Your booking request has been sent. The host will contact you as soon as possible.', 'extretion' ),
			'error_fields' => implode( ',' , $error_field )
		)
	);

	//print_r( $error_msg );
	//print_r( $data );
	//print_r( $empty_removed );

	die; 

}

function extretion_create_booking_email_post( $data ){

	//print_r( $data );
	$my_post = array(
	    'post_title'    => get_the_title( $data['room_id'] ),
	    'post_content'  => !empty( $data['booking_additional_note'] ) ? $data['booking_additional_note'] : '',
	    'post_status'   => 'publish',
	    'post_type'     => 'email_bookings'
	);
	 
	$post_id = wp_insert_post( $my_post );

	update_post_meta( $post_id, 'traveler_firstname', $data['booking_first_name'] );
	update_post_meta( $post_id, 'traveler_lastname', $data['booking_last_name'] );
	update_post_meta( $post_id, 'traveler_email', $data['booking_email'] );
	update_post_meta( $post_id, 'traveler_address', $data['booking_address'] );
	update_post_meta( $post_id, 'traveler_phone', $data['booking_phone'] );

	update_post_meta( $post_id, 'booked_for_room_id', $data['room_id'] );
	update_post_meta( $post_id, 'secret_code', $data['secret_code'] );

	$order_details = extretion_get_order_id( $data['room_id'] , $data['secret_code'] );
	update_post_meta( $post_id, 'order_details', $order_details );
	return $post_id;

}

add_filter( 'manage_edit-email_bookings_columns', 'extretion_email_bookings_colum_added' ) ;
function extretion_email_bookings_colum_added( $columns ) {

	$date = $columns['date'];

	unset( $columns['date'] );
	$columns['title'] = esc_html__( 'Booked Room', 'extretion' );
	$columns['guest_info'] = esc_html__( 'Guest Info', 'extretion' );
	$columns['host_info'] = esc_html__( 'Host Info', 'extretion' );
	$columns['pricing_info'] = esc_html__( 'Pricing Info', 'extretion' );
	$columns['date'] = $date;

	return $columns;
}

add_filter( 'page_row_actions', 'extretion_email_booking_row_actions', 10, 2 );
function extretion_email_booking_row_actions( $actions, $post ) {

	//print_r($actions);
	$custom_actions = array();
    if ( 'email_bookings' == $post->post_type ) {

    	$booked_room_id = get_post_meta( $post->ID, 'booked_for_room_id', true );

    	if( !empty( $actions['trash'] ) ){
    		$custom_actions['trash'] = $actions['trash'];	
    	}
    	
    	if( !empty( $actions['untrash'] ) ){
    		$custom_actions['untrash'] = $actions['untrash'];
    	}

    	if( !empty( $actions['delete'] ) ){
    		$custom_actions['delete'] = $actions['delete'];
    	}
    	
    	$custom_actions['title'] = '<a target="_blank" href="' . get_permalink( $booked_room_id ) . '">' . esc_html__( 'View Room' , 'extretion' ) . '</a>';

    	return $custom_actions;

    } elseif( 'report_listings' == $post->post_type ){

    	unset( $actions['edit'] );
        unset( $actions['view'] );
        unset( $actions['inline hide-if-no-js'] );

    } elseif( 'lmh_invoice' == $post->post_type ){

    	unset( $actions['edit'] );
        unset( $actions['view'] );
        unset( $actions['inline hide-if-no-js'] );

    } elseif( 'guide' == $post->post_type ){

    	unset( $actions['edit'] );
        unset( $actions['view'] );
        unset( $actions['inline hide-if-no-js'] );
    	
    } elseif( 'testimonials' == $post->post_type || 'faqs' == $post->post_type || 'lmh_slider' == $post->post_type ){

        unset( $actions['view'] );
    	
    }
    
    return $actions;
   
}

add_action( 'manage_email_bookings_posts_custom_column', 'extretion_manage_email_bookings_columns', 10, 2 );

function extretion_manage_email_bookings_columns( $column, $post_id ) {

	$firstname = get_post_meta( $post_id, 'traveler_firstname', true );
	$lastname = get_post_meta( $post_id, 'traveler_lastname', true );
	$guest_email = get_post_meta( $post_id, 'traveler_email', true );
	$guest_address = get_post_meta( $post_id, 'traveler_address', true );
	$guest_phone = get_post_meta( $post_id, 'traveler_phone', true );

	$booked_room_id = get_post_meta( $post_id, 'booked_for_room_id', true );

	$order_id = get_post_meta( $post_id, 'order_details', true );

	global $post;

	switch( $column ) {

		case 'pricing_info':
			echo extretion_get_html_price_booking($order_id);
			break;

		case 'guest_info':
			echo '<strong>' . esc_html__( 'Full Name : ', 'extretion' ) . '</strong>';
			echo $firstname . ' ' . $lastname . '<br>';

			echo '<strong>' . esc_html__( 'Email : ', 'extretion' ) . '</strong>';
			echo $guest_email . '</br>';

			echo '<strong>' . esc_html__( 'Address : ', 'extretion' ) . '</strong>';
			echo $guest_address . '</br>';

			echo '<strong>' . esc_html__( 'Phone : ', 'extretion' ) . '</strong>';
			echo $guest_phone . '</br>';

			echo '<strong>' . esc_html__( 'Additional Info : ', 'extretion' ) . '</strong>';
			echo $post->post_content . '</br>';

			break;

		case 'host_info':

			$room_object = get_post( $booked_room_id );

			$host_id = $room_object->post_author;

			echo '<strong>' . esc_html__( 'Full Name : ', 'extretion' ) . '</strong>';
			echo get_user_meta( $host_id, 'first_name', true ) . ' ' . get_user_meta( $host_id, 'last_name', true ) . '<br>';

			echo '<strong>' . esc_html__( 'Email : ', 'extretion' ) . '</strong>';
			echo get_the_author_meta( 'user_email', $host_id ) . '</br>';

			echo '<strong>' . esc_html__( 'Phone : ', 'extretion' ) . '</strong>';
			echo get_user_meta( $host_id, 'phone_no', true ) . '</br>';

			echo '<strong>' . esc_html__( 'Mobile : ', 'extretion' ) . '</strong>';
			echo get_user_meta( $host_id, 'mobile_no', true ) . '</br>';

			break;

		default :
			break;

	}

}

add_action( 'extretion_after_booking_email_saved' , 'extretion_after_booking_email_saved_sent_mail_to_host' );
function extretion_after_booking_email_saved_sent_mail_to_host( $post_id ){

	$room_id = get_post_meta( $post_id, 'booked_for_room_id', true );
	$room_object = get_post( $room_id );

	$to = get_the_author_meta( 'user_email' , $room_object->post_author );

	// Subject
	$subject_db = get_option( 'options_booking_request_from_email_subject' );
	$subject = !empty( $subject_db ) ? $subject_db : 'You have received a booking request for [room_name] at [site_name].';
	$subject = str_replace( '[room_name]' , get_the_title( $room_id ) , $subject );
	$subject = str_replace( '[site_name]' , get_bloginfo( 'name' ) , $subject );

	// Message
	$message_db = get_option( 'options_booking_request_from_email_message' );
	$message = !empty( $message_db ) ? $message_db : 'Hello [username],
		You have received a booking request for [room_name] at [site_name].

		<strong>Guest Info</strong>

		Full Name : [guest_full_name]
		Email : [guest_email]
		Address : [guest_address]
		Phone : [guest_phone]
		Additional Info : [additional_info]

		<strong>Check In Details</strong>

		Check-in : [check_in]
		Check-out : [check_out]
		Guest : [guest]
		Booking Fee : [booking_fee]
		Your rent : [fees]';

	$username = get_the_author_meta( 'user_login' , $room_object->post_author );
	$room_name = get_the_title( $room_object );

	$fullname = get_post_meta( $post_id, 'traveler_firstname', true ) . ' ' . get_post_meta( $post_id, 'traveler_lastname', true );
	$email = get_post_meta( $post_id, 'traveler_email', true );
	$address = get_post_meta( $post_id, 'traveler_address', true );
	$phone = get_post_meta( $post_id, 'traveler_phone', true );

	$invoice_details = get_post_meta( $post_id, 'order_details', true ); // Get Invoice Details
	$check_in = date( 'd M, Y' , strtotime( $invoice_details['check_in'] ) );
	$check_out = date( 'd M, Y' , strtotime( $invoice_details['check_out'] ) );
	$guest = $invoice_details['guests'];

	/* In Traveller chosen currency */
	$security_deposit = !empty( $invoice_details['security_deposit'] ) ? $invoice_details['security_deposit'] : 0; 
	$total_price = $invoice_details['total_price'] + $security_deposit;
	$fees = number_format( $total_price , 2,'.',',' ) . ' ' . $invoice_details['currency'];

	$hotel_owner_currency = get_post_meta( $room_object->ID, 'user_currency', true ); // Get the room currency

	/* Booking Fee */
	$extretion_get_first_installment_price = number_format( extretion_get_first_installment_price( $invoice_details ),2,'.',',');
	$fee_at_booking = $extretion_get_first_installment_price . ' ' . $invoice_details['currency'];
	

	/* In Host chosen currency */
	if( $invoice_details['currency'] != $hotel_owner_currency ){

		$fees .= ' ( ' .extretion_exchange_currency( $total_price , $from = $invoice_details['currency'], $currency_only = NULL , $to_currency = $hotel_owner_currency , $commission = false ) . ' )';
		$fee_at_booking .= ' ( ' .extretion_exchange_currency( $extretion_get_first_installment_price, $from = $invoice_details['currency'], $currency_only = NULL , $to_currency = $hotel_owner_currency , $commission = false ) . ' )';

	}
	

	$message = str_replace( '[username]' , $username , $message );
	$message = str_replace( '[room_name]' , $room_name , $message );
	$message = str_replace( '[site_name]' , get_bloginfo( 'name' ) , $message );
	$message = str_replace( '[guest_full_name]' , $fullname , $message );
	$message = str_replace( '[guest_email]' , $email , $message );
	$message = str_replace( '[guest_address]' , $address , $message );
	$message = str_replace( '[guest_phone]' , $phone , $message );
	$message = str_replace( '[additional_info]' , sanitize_text_field( get_post_field( 'post_content', $post_id ) ) , $message );

	$message = str_replace( '[check_in]' , $check_in , $message );
	$message = str_replace( '[check_out]' , $check_out , $message );
	$message = str_replace( '[guest]' , $guest , $message );
	$message = str_replace( '[fees]' , $fees , $message );
	$message = str_replace( '[booking_fee]' , $fee_at_booking , $message );

	wp_mail( $to, $subject, nl2br($message) , extretion_mail_headers() );

}

add_filter( 'pt-ocdi/import_files', 'extretion_import_files' );
function extretion_import_files() {
  	return array(
    	array(
      		'import_file_name'             => 'Extretion Demo Content',
	      	'local_import_file'            => trailingslashit( get_template_directory() ) . 'assets/data/demo-content.xml',
	      	'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'assets/data/widgets.wie',
	      	'local_import_customizer_file' => trailingslashit( get_template_directory() ) . 'assets/data/customizer.dat',
    	),
  	);
}

add_action( 'pt-ocdi/after_import', 'extretion_after_import_setup' );
function extretion_after_import_setup() {
    // Assign menus to their locations.
    $main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );
    $dashboard = get_term_by( 'name', 'Dashboard Menu', 'nav_menu' );

    set_theme_mod( 'nav_menu_locations', array(
            'primary' => $main_menu->term_id,
            'dashboard' => $dashboard->term_id
        )
    );
    flush_rewrite_rules();
}

add_filter( 'cei_export_option_keys', 'extretion_export_option_keys' );
function extretion_export_option_keys( $keys ) {
    $keys[] = 'permalink_structure';
    $keys[] = 'options_user_verification_subject';
    $keys[] = 'options_user_verification_message';
    $keys[] = 'options_user_verification_success_message';
    $keys[] = 'options_successfully_registration_message';
    $keys[] = 'options_forgot_your_password_subject';
    $keys[] = 'options_forgot_your_password_message';
    $keys[] = 'options_after_resetting_password_subject';
    $keys[] = 'options_after_resetting_password';
    $keys[] = 'options_booking_request_notification_subject';
    $keys[] = 'options_booking_request_message_notification';
    $keys[] = 'options_cancel_booking_by_traveller_subject';
    $keys[] = 'options_cancel_booking_by_traveller_message';
    $keys[] = 'options_cancel_booking_by_hotel_subject';
    $keys[] = 'options_cancel_booking_by_hotel_message';
    $keys[] = 'options_approved_booking_subject';
    $keys[] = 'options_approved_booking_message';
    $keys[] = 'options_booking_confirmed_subject';
    $keys[] = 'options_booking_confirmed_message';
    $keys[] = 'options_booking_delete_check_in_subject';
    $keys[] = 'options_booking_delete_check_in_message';
    $keys[] = 'options_booking_delete_after_14_days_subject';
    $keys[] = 'options_booking_delete_after_14_days_message';
    $keys[] = 'options_booking_delete_after_48hrs_no_payment_subject';
    $keys[] = 'options_booking_delete_after_48hrs_no_payment_message';
    $keys[] = 'options_booking_request_from_email_subject';
    $keys[] = 'options_booking_request_from_email_message';
    $keys[] = 'options_messages_subject';
    $keys[] = 'options_private_message';
    $keys[] = 'show_on_front';
    $keys[] = 'page_on_front';
    return $keys;
}

function extretion_get_similar_rooms( $post_id , $count = false , $limit = false ){

	$post_object = get_post( $post_id );
	$author = $post_object->post_author;

	$args = array(
		'post_type' => 'room',
		'posts_per_page' => ( $limit == false ? -1 : $limit ),
		'post_status' => 'publish',
		'post__not_in' => array( $post_id ),
		'author' => $author
	);

	$similar_listings_query = new WP_Query( $args ); 

	if( $count == true ){
		return $similar_listings_query->found_posts;	
	}
	
	if( $similar_listings_query->have_posts() ):

		$defaults = extretion_default_labels();

		echo '<div class="top-hotel-grid-wrapper similar_listings_wrapper"><div class="row gap-20 min-height-alt">';

		while( $similar_listings_query->have_posts() ): $similar_listings_query->the_post();

			global $post;
			$image = extretion_get_first_image_room( $post->ID );
			extretion_get_grid_view_search( $image, $post, $defaults, null, true );

		endwhile;

		echo '</div></div>';

		wp_reset_postdata();

	endif;

}

function extretion_get_first_installment_price( $order_id ){

	//echo '<pre>'; print_r( $order_id ); echo '</pre>';

	$security_deposit = !empty( $order_id['security_deposit'] ) ? $order_id['security_deposit'] : 0;
	$total_price = $order_id['total_price'];

	$partial_payment = (extretion_get_first_installment_percentage() / 100) * $total_price;

	return ( $partial_payment + $security_deposit );

}

function extretion_get_first_installment_percentage(){

	$commision_rate = (int) get_option( 'options_commision_rate', '15' );
	$commision_rate = $commision_rate != 0 ? $commision_rate : 15;
	return ( $commision_rate * 2 );

}

function extretion_get_first_installment_amt( $first_installment_percenetage , $total_price ){

	return ($first_installment_percenetage / 100) * $total_price;

}

function extretion_get_price_breakdown_html( $value ){ 

	$currency_symbol = extretion_currency_symbol( $value['attributes']['currency'] );
	$security_deposit = !empty( $value['attributes']['security_deposit'] ) ? (int) $value['attributes']['security_deposit'] : 0;
	$total_price = $value['attributes']['total_price']; 
	$first_installment = extretion_get_first_installment_percentage();
	$first_installment_amt = extretion_get_first_installment_amt( $first_installment , $total_price ); ?>

	<div class="modal fade modal-login modal-border-transparent" id="break_down_price_modal" tabindex="-1" role="dialog" aria-hidden="true">

		<div class="modal-dialog">

			<div class="modal-content">
				
				<div class="clear"></div>
				
				<!-- Begin # DIV Form -->
				<div id="">

					<div class="modal-body pb-10">
					
						<div class="text-center mb-15">
							<h5><?php esc_html_e( 'Price Breakdown', 'extretion' ); ?></h5>
						</div>

						<table class="">
							<tr>
								<td><?php esc_html_e( 'Security Deposit', 'extretion' ); ?></td>
								<td><?php echo $currency_symbol . number_format( $security_deposit , 2, '.', ',' ); ?></td>
							</tr>
							<tr>
								<td>

									<?php
									printf(
										esc_html__( '%d&#37; of %s%d', 'extretion' ),
										$first_installment,
										$currency_symbol,
										$total_price
									);
									?>
										
								</td>
								<td><?php echo $currency_symbol . number_format( $first_installment_amt , 2, '.', ',' );?></td>
							</tr>
							<tr>
								<td><strong><?php esc_html_e( 'Total', 'extretion' ); ?></strong></td>
								<td><strong><?php echo $currency_symbol . number_format( $first_installment_amt +  $security_deposit, 2, '.', ',' ); ?></strong></td>
							</tr>											
							
						</table>
						
					</div>

				</div>

			</div>

		</div>

	</div>

	<?php
}

function extretion_price_breakdown_pop_up(){

	$post_id = get_query_var( 'post_id' );

	$post = get_post( $post_id );
	
	/**
	* If the page is trip or reservation
	*/

	if( is_object( $post ) ){

		$invoice_details = get_post_meta( $post_id, 'invoice_details' , true );

		if( is_array( $invoice_details ) ){

			$data = array();
			$data['attributes'] = $invoice_details;
			extretion_get_price_breakdown_html( $data );
			return;

		}

	}

	/**
	* If the page is booking page
	*/

	$secret = get_query_var( 'secret' );

	if( !is_numeric( $post_id ) || empty( $secret ) ){
		return;
	}

	$order_ids = get_post_meta( $post_id, 'order_ids', true );

	if( is_array( $order_ids ) ){

		foreach( $order_ids as $value ){

			if( $value['attributes']['secret_key'] == $secret ){ 

				extretion_get_price_breakdown_html( $value );

			}

		}

	}

}

function extretion_get_amount_in_usd( $order_id ){

	$total_price = $order_id['total_price']; 
	$first_installment = extretion_get_first_installment_percentage();
	$first_installment_amt = extretion_get_first_installment_amt( $first_installment , $total_price );
	$security_deposit = !empty( $order_id['security_deposit'] ) ? (int) $order_id['security_deposit'] : 0;

	$total_price_after_security = $first_installment_amt + $security_deposit;

	$in_usd_amt = extretion_exchange_currency( 
		$total_price_after_security, 
		$from_currency = $order_id['currency'], 
		$currency_only = NULL , 
		$to_currency = 'USD' , 
		$commission = false,
		$round = false 
	);

	// Get Currency
	$extract_currency = preg_replace("/[0-9\s.]/", null, $in_usd_amt );

	// Get only price ( Exclude currency )
	$amt = preg_replace("/[^0-9\.]/", null, $in_usd_amt );

	return number_format($amt,2,'.',',') . ' ' . $extract_currency;

}

add_action( 'wp_ajax_extretion_report_listing' , 'extretion_report_listing' );
add_action( 'wp_ajax_nopriv_extretion_report_listing' , 'extretion_report_listing' );
function extretion_report_listing(){

	$data = array_map( 'sanitize_text_field' , $_POST );
	$room_id = $data['post_id'];
	$message = $data['message'];

	$my_post = array(
		'post_type'     => 'report_listings',
  		'post_title'    => get_the_title( $room_id ),
  		'post_content'  => sanitize_text_field( $message ),
  		'post_status'   => 'publish',
	);
 
	$post_id = wp_insert_post( $my_post );
	update_post_meta( $post_id, 'related_room_id' , $room_id );

	do_action( 'extretion_after_report_listing_saved', $post_id );

	echo json_encode(
		array(
			'status' => 'success'
		)
	);

	die;

}

add_action( 'extretion_after_report_listing_saved' , 'extretion_send_report_mail_to_admin' );
function extretion_send_report_mail_to_admin( $post_id ){

	$room_id = get_post_meta( $post_id, 'related_room_id' , true );
	$link = get_permalink( $room_id );

	$post = get_post( $post_id );

	$to = get_option( 'admin_email' );
	$subject = 'Someone reported a listing on ' . get_bloginfo( 'name' );
	$message = 'Hi admin,

	Someone reported a listing on ' . get_bloginfo( 'name' ) . '.

	<strong>Details</strong>

	Room Name : ' . get_the_title( $room_id ) . '
	Room Link : <a href="' . $link . '">' . $link . '</a>
	Message : ' . $post->post_content;

	wp_mail( $to, $subject, nl2br($message), extretion_mail_headers() );

}

add_filter( 'manage_edit-report_listings_columns', 'extretion_report_listings_colunm_added' ) ;
function extretion_report_listings_colunm_added( $columns ) {

	$date = $columns['date'];

	unset( $columns['date'] );
	$columns['title'] = esc_html__( 'Room Name', 'extretion' );
	$columns['room_url'] = esc_html__( 'Room URL', 'extretion' );
	$columns['message'] = esc_html__( 'Message', 'extretion' );
	$columns['date'] = $date;

	return $columns;
}

add_action( 'manage_report_listings_posts_custom_column', 'extretion_manage_report_listings_columns', 10, 2 );

function extretion_manage_report_listings_columns( $column, $post_id ) {

	$related_room_id = get_post_meta( $post_id, 'related_room_id', true );
	global $post;

	switch( $column ) {

		case 'room_url':
			echo '<a target="_blank" href="' . get_permalink( $related_room_id ) . '">' . esc_html__( 'View Room' , 'extretion' ) . '</a>';
			break;

		case 'message':
			echo sanitize_text_field( $post->post_content );
			break;

		default :
			break;

	}

}

add_action( 'wp_ajax_extretion_save_invoice_notes' , 'extretion_save_invoice_notes' );
function extretion_save_invoice_notes(){

	if( !is_admin() ){
		echo json_encode(
			array(
				'result' => 'error'
			)
		);
		die;
	}

	$data = array_map( 'sanitize_text_field' , $_POST );

	update_post_meta( $data['post_id'] , 'additional_note' , $data['note'] );

	echo json_encode(
		array(
			'result' => 'success'
		)
	);
	
	die;

}

add_action( 'wp_ajax_extretion_change_mobile_number' , 'extretion_change_mobile_number' );
function extretion_change_mobile_number(){

	$user_info = twitterVerifyAuth( $_POST['apiUrl'] , wp_unslash( $_POST['authHeader'] ) );
	$user_id = get_current_user_id();

	$result = array();

	if( empty( $user_info ) ){
		$result['status'] = 'error';
		echo wp_json_encode( $result );
		die;
	}

	$args = array(
		'meta_query' => array(
			array(
				'key'     => 'mobile_no',
				'value'   => $user_info['phone_number'], //'+9779849196363',
				//'value'   => '12', // For localhost
	 			'compare' => '='
			)
		)
	);

	$user_query = new WP_User_Query( $args );

	/**
	* Check mobile no on the database.
	* If no user found on the database save the mobile number
	*/

	if( empty( $user_query->results ) ){

		// Update user mobile no
		update_user_meta( $user_id, 'mobile_no' , $user_info['phone_number'] );
		$result['status'] = 'success';
		do_action( 'after_mobile_verification_success' , $user_id );

	} else {
		$result['status'] = 'mobile_no_exists';
	}

	echo json_encode( $result );

	die;

}

add_filter( 'manage_edit-room_columns', 'extretion_room_colunm_added' ) ;
function extretion_room_colunm_added( $columns ) {

	$date = $columns['date'];

	unset( $columns['date'] );
	$columns['host'] = esc_html__( 'Host', 'extretion' );
	$columns['date'] = $date;

	return $columns;

}

add_action( 'manage_room_posts_custom_column', 'extretion_manage_room_columns', 10, 2 );
function extretion_manage_room_columns( $column, $post_id ) {

	global $post;
	switch( $column ) {

		case 'host':
			echo '<a target="_blank" href="' . admin_url( 'user-edit.php?user_id=' ) . $post->post_author .'">' . get_the_author() . '</a>';
			break;

		default :
			break;

	}

}

add_action( 'extretion_after_booking_email_saved' , 'extretion_sent_confirmation_mail_to_traveler' );
function extretion_sent_confirmation_mail_to_traveler( $post_id ){

	$firstName = get_post_meta( $post_id, 'traveler_firstname', true );
	$to = get_post_meta( $post_id, 'traveler_email', true );

	$subject = get_option( 'options_inquiery_subject' );
	$subject = empty( $subject ) ? 'Inquiry sent successfully on [site_name]' : $subject;
	$subject = str_replace( '[site_name]' , get_bloginfo( 'name' ) , $subject );

	$message = get_option( 'options_inquiry_message' );
	$message = empty( $message ) ? "Hello [traveler_name],\n\nWe have received your booking request. We will check the request and reply you as soon as possible.\n\nThanks" : $message;
	$message = str_replace( '[traveler_name]' , $firstName , $message );
	
	wp_mail( $to, $subject, nl2br( $message ) , extretion_mail_headers() );

}