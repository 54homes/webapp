<?php

add_action( 'wp_ajax_extretion_stripe_payment' , 'extretion_stripe_payment' );
function extretion_stripe_payment(){

	$data = $_POST['card_details'];

	$invoice_id = (int) $_POST['invoice_id'];
	$room_id = get_post_meta( $invoice_id, 'related_room_id', true );
	$room_object = get_post( $room_id );
	$host_id = $room_object->post_author;

	$db_strip_details = get_user_meta( $host_id, 'stripe_details', true );
	$stripe_user_id = $db_strip_details['stripe_user_details']['stripe_user_id'];

	$invoice_details = get_post_meta( $invoice_id, 'invoice_details', true );

	// Get price in USD
	$only_price = extretion_get_total_price_in_usd( $invoice_details ); 

	$commission = number_format( ($only_price / 2) , 2, '.', ''); // Price for the site owner
	$security_deposit = !empty( $invoice_details['security_deposit'] ) ? (int) $invoice_details['security_deposit'] : 0;

	$payment_hotel_owner = number_format( ($commission + $security_deposit) , 2, '.', '');

	// Set your secret key: remember to change this to your live secret key in production
	// See your keys here: https://dashboard.stripe.com/account/apikeys
	\Stripe\Stripe::setApiKey( extretion_get_secret_key() );

	// Token is created using Stripe.js or Checkout!
	// Get the payment token submitted by the form:
	$token = $data['id'];
	$description = 'Paid for Room ( ' . get_the_title( $room_id ) . ' ) at ' . get_bloginfo( 'name' );

	// Charge the user's card:

	try {
	  	// Use a Stripe PHP library method that may throw an exception....
	  	$charge = \Stripe\Charge::create(
			array(
			  	"amount" => $payment_hotel_owner * 100,
			  	"currency" => "usd",
			  	"description" => $description,
			  	"source" => $token,
			  	"application_fee" => $commission * 100,
			), array("stripe_account" => $stripe_user_id )
		);
	} catch(Stripe_CardError $e) {
	  	
	  	echo json_encode( 
			array(
				'status' => 'error',
				'message' => $e->getMessage()
			) 
		);
		die;

	} catch (Stripe_InvalidRequestError $e) {
	  	// Invalid parameters were supplied to Stripe's API
	  	echo json_encode( 
			array(
				'status' => 'error',
				'message' => $e->getMessage()
			) 
		);
		die;
	} catch (Stripe_AuthenticationError $e) {
	  	// Authentication with Stripe's API failed
	  	echo json_encode( 
			array(
				'status' => 'error',
				'message' => $e->getMessage()
			) 
		);
		die;
	} catch (Stripe_ApiConnectionError $e) {
	  	// Network communication with Stripe failed
	  	echo json_encode( 
			array(
				'status' => 'error',
				'message' => $e->getMessage()
			) 
		);
		die;
	} catch (Stripe_Error $e) {
	  	// Display a very generic error to the user, and maybe send
	  	// yourself an email
	  	echo json_encode( 
			array(
				'status' => 'error',
				'message' => $e->getMessage()
			) 
		);
		die;
	} catch (Exception $e) {
	  	// Something else happened, completely unrelated to Stripe
	  	echo json_encode( 
			array(
				'status' => 'error',
				'message' => $e->getMessage()
			) 
		);
		die;
	}

	update_post_meta( $invoice_id, 'payment_status' , 'payment_successful' );
	update_post_meta( $invoice_id, 'payment_method' , 'stripe' );
	$payment_successful_key = wp_generate_password( $length = 32 , false , false );
	update_post_meta( $invoice_id , 'payment_successful_key' , $payment_successful_key );

	$booking_confirmation_n_payment = get_option( 'options_select_booking_confirmation_n_payment' );
	$booking_confirmation_n_payment_url = $booking_confirmation_n_payment ? get_permalink( $booking_confirmation_n_payment ) . '/' . $invoice_id . '/?paysecret=' . $payment_successful_key : '#';

	echo json_encode( 
		array(
			'status' => 'success',
			'redirect_url' => esc_url( $booking_confirmation_n_payment_url )
		) 
	);

	die;

}

function extretion_get_publishable_key(){

	$options_stripe_status = get_option( 'options_stripe_sandbox_live' );

	if( $options_stripe_status == 'sandbox' ){
		return get_option( 'options_test_publishable_key' );
	} else {
		return get_option( 'options_live_publishable_key' );
	}

}

function extretion_get_secret_key(){

	$options_stripe_status = get_option( 'options_stripe_sandbox_live' );

	if( $options_stripe_status == 'sandbox' ){
		return get_option( 'options_test_secret_key' );
	} else {
		return get_option( 'options_live_secret_key' );
	}

}

function extretion_get_client_id(){

	$options_stripe_status = get_option( 'options_stripe_sandbox_live' );

	if( $options_stripe_status == 'sandbox' ){
		return get_option( 'options_test_client_id' );
	} else {
		return get_option( 'options_live_client_id' );
	}

}