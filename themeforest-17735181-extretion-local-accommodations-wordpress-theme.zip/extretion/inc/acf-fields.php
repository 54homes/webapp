<?php

/**
* Advanced Custom Field data
*/

if(function_exists("register_field_group"))
{
	register_field_group(array (
		'id' => 'acf_contact-us-fields',
		'title' => 'Contact Us Fields',
		'fields' => array (
			array (
				'key' => 'field_574c0c41c27a2',
				'label' => 'Address',
				'name' => 'contact_address',
				'type' => 'google_map',
				'required' => 1,
				'center_lat' => '',
				'center_lng' => '',
				'zoom' => '',
				'height' => 300,
			),
			array (
				'key' => 'field_574c0c84c27a3',
				'label' => 'Contact Number',
				'name' => 'contact_number',
				'type' => 'text',
				'default_value' => '',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
				'formatting' => 'html',
				'maxlength' => '',
			),
			array (
				'key' => 'field_574c0c9fc27a4',
				'label' => 'Email',
				'name' => 'email',
				'type' => 'email',
				'default_value' => '',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
			),
		),
		'location' => array (
			array (
				array (
					'param' => 'page_template',
					'operator' => '==',
					'value' => 'page-templates/contact.php',
					'order_no' => 0,
					'group_no' => 0,
				),
			),
		),
		'options' => array (
			'position' => 'normal',
			'layout' => 'default',
			'hide_on_screen' => array (
				0 => 'featured_image',
			),
		),
		'menu_order' => 0,
	));
	register_field_group(array (
		'id' => 'acf_destination-photos',
		'title' => 'Destination Photos',
		'fields' => array (
			array (
				'key' => 'field_57735a5b3ebf4',
				'label' => 'Image',
				'name' => 'image_destination',
				'type' => 'image',
				'save_format' => 'id',
				'preview_size' => 'thumbnail',
				'library' => 'all',
			),
		),
		'location' => array (
			array (
				array (
					'param' => 'ef_taxonomy',
					'operator' => '==',
					'value' => 'destinations',
					'order_no' => 0,
					'group_no' => 0,
				),
			),
		),
		'options' => array (
			'position' => 'normal',
			'layout' => 'default',
			'hide_on_screen' => array (
			),
		),
		'menu_order' => 0,
	));
	register_field_group(array (
		'id' => 'acf_faq-fields',
		'title' => 'FAQ Fields',
		'fields' => array (
			array (
				'key' => 'field_574add6177118',
				'label' => 'Layout',
				'name' => 'faq_layout',
				'type' => 'select',
				'choices' => array (
					1 => 'Layout 1',
					2 => 'Layout 2',
				),
				'default_value' => 1,
				'allow_null' => 0,
				'multiple' => 0,
			),
			array (
				'key' => 'field_574ade840c2f8',
				'label' => 'Sidebar Title',
				'name' => 'faq_sidebar_title',
				'type' => 'text',
				'required' => 1,
				'default_value' => '',
				'placeholder' => 'eg. Faq Categories',
				'prepend' => '',
				'append' => '',
				'formatting' => 'html',
				'maxlength' => '',
			),
			array (
				'key' => 'field_574adf10746f5',
				'label' => 'Main Title',
				'name' => 'faq_main_title',
				'type' => 'text',
				'required' => 1,
				'default_value' => '',
				'placeholder' => 'eg.	Hello, how can we help you?',
				'prepend' => '',
				'append' => '',
				'formatting' => 'html',
				'maxlength' => '',
			),
			array (
				'key' => 'field_574adf9656944',
				'label' => 'Select Categories',
				'name' => 'faq_categories',
				'type' => 'taxonomy',
				'instructions' => 'You can select multiple categories by pressing ctrl and clicking.',
				'required' => 1,
				'taxonomy' => 'faq_cat',
				'field_type' => 'multi_select',
				'allow_null' => 0,
				'load_save_terms' => 1,
				'return_format' => 'id',
				'multiple' => 0,
			),
			array (
				'key' => 'field_574ae02f90866',
				'label' => 'Add Content',
				'name' => 'faq_add_content',
				'type' => 'select',
				'choices' => array (
					1 => 'To Bottom',
					2 => 'To Top',
				),
				'default_value' => 1,
				'allow_null' => 0,
				'multiple' => 0,
			),
		),
		'location' => array (
			array (
				array (
					'param' => 'page_template',
					'operator' => '==',
					'value' => 'page-templates/faq.php',
					'order_no' => 0,
					'group_no' => 0,
				),
			),
		),
		'options' => array (
			'position' => 'normal',
			'layout' => 'default',
			'hide_on_screen' => array (
				0 => 'featured_image',
			),
		),
		'menu_order' => 0,
	));
	register_field_group(array (
		'id' => 'acf_guide-fields',
		'title' => 'Guide Fields',
		'fields' => array (
			array (
				'key' => 'field_578dfb35e9558',
				'label' => 'Icon',
				'name' => 'icon',
				'type' => 'text',
				'default_value' => '',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
				'formatting' => 'html',
				'maxlength' => '',
			),
			array (
				'key' => 'field_578dfb3ce9559',
				'label' => 'Background Color',
				'name' => 'background_color',
				'type' => 'color_picker',
				'default_value' => '#6331AE',
			),
		),
		'location' => array (
			array (
				array (
					'param' => 'ef_taxonomy',
					'operator' => '==',
					'value' => 'guide_cat',
					'order_no' => 0,
					'group_no' => 0,
				),
			),
		),
		'options' => array (
			'position' => 'normal',
			'layout' => 'no_box',
			'hide_on_screen' => array (
			),
		),
		'menu_order' => 0,
	));
	register_field_group(array (
		'id' => 'acf_slider-options',
		'title' => 'Slider Options',
		'fields' => array (
			array (
				'key' => 'field_57a9a1ff4c5d8',
				'label' => 'Sub Title',
				'name' => 'sub_title',
				'type' => 'textarea',
				'default_value' => '',
				'placeholder' => '',
				'maxlength' => '',
				'rows' => '',
				'formatting' => 'br',
			),
			array (
				'key' => 'field_57a9a22a4c5d9',
				'label' => 'Read More Link',
				'name' => 'read_more_link',
				'type' => 'page_link',
				'post_type' => array (
					0 => 'post',
					1 => 'page',
					2 => 'room',
				),
				'allow_null' => 1,
				'multiple' => 0,
			),
			array (
				'key' => 'field_57a9a2e74215e',
				'label' => 'Read More Text',
				'name' => 'read_more_text',
				'type' => 'text',
				'default_value' => 'More Details',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
				'formatting' => 'html',
				'maxlength' => '',
			),
			array (
				'key' => 'field_57a9a3184215f',
				'label' => 'Another Read More Link',
				'name' => 'another_read_more_link',
				'type' => 'text',
				'default_value' => '',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
				'formatting' => 'html',
				'maxlength' => '',
			),
			array (
				'key' => 'field_57a9a32c42160',
				'label' => 'Another Read More Text',
				'name' => 'another_read_more_text',
				'type' => 'text',
				'default_value' => '',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
				'formatting' => 'html',
				'maxlength' => '',
			),
		),
		'location' => array (
			array (
				array (
					'param' => 'post_type',
					'operator' => '==',
					'value' => 'lmh_slider',
					'order_no' => 0,
					'group_no' => 0,
				),
			),
		),
		'options' => array (
			'position' => 'normal',
			'layout' => 'no_box',
			'hide_on_screen' => array (
			),
		),
		'menu_order' => 0,
	));
	register_field_group(array (
		'id' => 'acf_testimonials-fields',
		'title' => 'Testimonials Fields',
		'fields' => array (
			array (
				'key' => 'field_5774f672723b9',
				'label' => 'Testimonial',
				'name' => 'testimonial',
				'type' => 'textarea',
				'default_value' => '',
				'placeholder' => '',
				'maxlength' => '',
				'rows' => '',
				'formatting' => 'br',
			),
			array (
				'key' => 'field_5774f62d723b6',
				'label' => 'Author Name',
				'name' => 'author_name',
				'type' => 'text',
				'default_value' => '',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
				'formatting' => 'html',
				'maxlength' => '',
			),
			array (
				'key' => 'field_5774f643723b7',
				'label' => 'Country',
				'name' => 'country',
				'type' => 'text',
				'default_value' => '',
				'placeholder' => '',
				'prepend' => '',
				'append' => '',
				'formatting' => 'html',
				'maxlength' => '',
			),
		),
		'location' => array (
			array (
				array (
					'param' => 'post_type',
					'operator' => '==',
					'value' => 'testimonials',
					'order_no' => 0,
					'group_no' => 0,
				),
			),
		),
		'options' => array (
			'position' => 'normal',
			'layout' => 'no_box',
			'hide_on_screen' => array (
			),
		),
		'menu_order' => 0,
	));
}
