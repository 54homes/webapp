<?php

get_header(); 

get_template_part( 'template-parts/content', 'blog' ); ?>

<div class="clear"></div>

<?php
get_footer();
