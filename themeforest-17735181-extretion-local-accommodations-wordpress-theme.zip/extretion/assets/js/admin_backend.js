jQuery( document ).on( 'click' , '.extretion_save_invoice_notes' , function(){

	var post_id = jQuery(this).attr( 'post_id' );
	var note = jQuery(this).prevAll( 'textarea' ).val();
	var selected = jQuery(this);

	jQuery.ajax({
		url : ajaxurl,
		type : 'post',
		dataType : 'json',
		data : {
			action : 'extretion_save_invoice_notes',
			post_id : post_id,
			note : note
		},
		beforeSend : function(){
			selected.text( 'Saving ...' );
		},
		success : function(){
			selected.text( 'Saved' );
		}
	});

});