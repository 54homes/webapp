jQuery(document).ready(function($){
	"use strict";
	
	checkStripe();
	equal_height_room_page();
	validate_reply_message_form();
	validateRegister();
	validateEditProfile();
	validateLogin();
	forgoturpassword();
	resetPassword();
	listMyRoomValidate();
	billingFormValidate();
	searchPageGoogleMap();
	searchPageForm();
	changeCurrencyListRoom();
	room_photos_sortable();
	changeCurrencyHeader();
	room_dates_calendar();
	add_commission_to_price();
	guide_page_google_map();
	get_the_author_description();
	validate_change_password();
	logo_on_scroll();
	get_new_avatar_profile();
	equal_content_sidebar();
	
	/**
	* Fixed header when user logged in
	*/

	$(window).on("load resize",function(e){
	  	
		var width = $(window).width();

		if( jQuery( 'body > #wpadminbar' ).length != 0 && width > 991 ){
			jQuery('.navbar-fixed-top').css({
				top : '32px'
			});
		} else {
			jQuery('.navbar-fixed-top').removeAttr( 'style' );
		}

	});

	function equal_content_sidebar(){

		/**
	  	* Equal Content and Sidebar by Js
	  	*/
		var widthForEqualContentSidebar = $(window).width();
		if ((widthForEqualContentSidebar > 768)) {
		  
		  	// placing objects inside variables
		  	var content = $('.equal-content-sidebar-by-js .content-wrapper');
		  	var sidebar = $('.equal-content-sidebar-by-js .sidebar-wrapper');

		  	// get content and sidebar height in variables
		  	var getContentHeight = content.outerHeight();
		  	var getSidebarHeight = sidebar.outerHeight();

		  	// check if content height is bigger than sidebar
		  	if ( getContentHeight > getSidebarHeight ) {
		   		sidebar.css('min-height', getContentHeight);
		  	}

		  	// check if sidebar height is bigger than content
		  	if ( getSidebarHeight > getContentHeight ) {
		   		content.css('min-height', getSidebarHeight);
		  	}
		}

	}

	jQuery('.confirm_delete_room').on( 'click' , function(){
		
		var delete_id = jQuery(this).attr( 'delete_id' );
		jQuery(this).prop( 'disabled' , true );

		jQuery.ajax({
			url : lmhAjax.ajaxUrl,
			type : 'post',
			dataType : 'json',
			data : {
				action : 'confirm_delete_room',
				room_id : delete_id
			},
			beforeSend : function(){
				jQuery('#ballloader').modal({
					'backdrop' : 'static',
					'show' : true
				});
			}, 
			success : function( data ){

				if( data.result == 'error' ){
					location.reload();
				} else {
					var redirect_url = window.location.protocol + "//" + window.location.hostname + window.location.pathname + '?status=deleted';
					window.location.href = redirect_url;
				}

			}
		});
	});

	jQuery('.guide_delete').on( 'click' , function(){
		var delete_id = jQuery(this).attr( 'delete_id' );
		jQuery('#deleteRoom').modal('show');
		jQuery('.confirm_delete_room').attr( 'delete_id' , delete_id );
	});

	jQuery(document).on( 'click', '.confirm_edit_guide', function(){

		var title = jQuery('#edit_guide_title').val();
		var category = jQuery('.edit_guide_cat option:selected').val();

		var formdata = new FormData();
		formdata.append( "action", 'lmh_edit_guide_content' );
		formdata.append( "name", title );
		formdata.append( "guide_id", jQuery('.confirm_edit_guide').attr( 'edit_id' ) );
		formdata.append( "category", category );
		formdata.append( 'image', jQuery('.edit_guide_image')[0].files[0] );

		formdata.append( "lat", '123' ); //Just for demo, will not be saved in the database
		formdata.append( "lng", '654' ); //Just for demo, will not be saved in the database

		jQuery.ajax({
			url : lmhAjax.ajaxUrl,
			type : 'post',
			dataType : 'json',
			data : formdata,
			processData: false,
    		contentType: false,
			beforeSend : function(){
				jQuery('.guide_error_modal').hide();
				jQuery('#ballloader').modal({
					'show' : true,
					'backdrop' : 'static'
				});
			},
			success : function( data ){

				if( data.result == 'error' ){
					jQuery('.guide_error_modal').empty().append( data.message ).show();
					jQuery('#ballloader').modal('hide');
					return;
				}

				if( data.result == 'error_user' ){
					location.reload();
				}

				if( data.result == 'success' ){
					var id = getUrlParameter( 'id' );
					var page = getUrlParameter( 'page' );
					var redirect_url = window.location.protocol + "//" + window.location.hostname + window.location.pathname + '?id=' + id + '&page=' + page + '&status=updated'; 
					window.location.href = redirect_url;
				}
				

			}
		});

	});

	jQuery('.edit_guide_wrapper li').matchHeight();

	jQuery(document).on( 'click' , '.edit_guide' , function(){
		jQuery('#editGuide').modal('show');
		var edit_id = jQuery(this).attr( 'edit_id' );
		jQuery('.confirm_edit_guide').attr( 'edit_id' , edit_id );

		jQuery.ajax({
			url : lmhAjax.ajaxUrl,
			type : 'post',
			dataType : 'json',
			data : {
				action : 'lmh_get_guide_details',
				edit_id : edit_id
			},
			beforeSend : function(){
				jQuery('.edit_guide_loader').show();
				jQuery('.edit_guide_form').hide().empty();
			},
			success : function( data ){
				jQuery('.edit_guide_loader').hide();
				jQuery('.edit_guide_form').show().append( data.content );

				jQuery('.edit_guide_cat').selectpicker( 'refresh' );
				jQuery('.edit_guide_cat').selectpicker( 'val' , data.selected );
			}
		});

	});

	jQuery( document ).on( 'click' , '.delete_guide' , function(){
		jQuery('#deleteGuide').modal( 'show' );
		var delete_id = jQuery(this).attr( 'delete_id' );
		jQuery('.confirm_delete_guide').attr( 'delete_id' , delete_id );
	});

	jQuery( document ).on( 'click' , '.confirm_delete_guide' , function(){
		var delete_id = jQuery(this).attr( 'delete_id' );
		jQuery.ajax({
			url : lmhAjax.ajaxUrl,
			type : 'post',
			dataType : 'json',
			data : {
				action : 'lmh_delete_guide',
				delete_id : delete_id
			},
			beforeSend : function(){
				jQuery('#ballloader').modal({
					'show' : 'true',
					'backdrop' : 'static'
				});
			},
			success : function( data ){

				if( data.status == 'success' ){
					jQuery('.guide_delete_info').show();
					jQuery('.guide_delete_info ul').prepend( '<li>' + data.message + '</li>' );
					jQuery('#ballloader').modal( 'hide' );
					jQuery('#deleteGuide').modal( 'hide' );

					// Remove the guide row
					$(".edit_guide_btn_wrapper [delete_id='" + delete_id + "']").closest( 'li' ).remove();

					$('html, body').animate({
					    scrollTop: $(".guide_delete_info").offset().top - 60
					}, 'slow' );

				} else {
					location.reload();
				}

			}
		});
	});

	function get_new_avatar_profile(){

		if( lmhAjax.new_avatar == true ){

			jQuery.ajax({
				url : lmhAjax.ajaxUrl,
				type : 'post',
				dataType : 'json',
				data : {
					action : 'lmh_get_new_avatar'
				},
				success : function( data ){
					jQuery('.user_avatar_wrap').empty().append( data.image );
					jQuery('.user_name_wrap').empty().append( data.name );
					jQuery('.user_avatar_header').data('size','big');
				}
			});

		}

	}

	function logo_on_scroll(){
		
		$('.navbar-image').data('size','big');
		$('.user_avatar_header').data('size','big');

		$(window).scroll(function(){


			// For logo
		  	if($(document).scrollTop() > 0){

		    	if($('.navbar-image').data('size') == 'big'){

		        	$('.navbar-image').data('size','small');
		        	$('.navbar-image').stop().animate({
		            	width:'135px'
		        	},600);

		    	}

			} else {

			    if( $('.navbar-image').data('size') == 'small' ){

			        $('.navbar-image').data('size','big');
			        $('.navbar-image').stop().animate({
			            width:'160px'
			        },600);

			    } 

			}

			// For User avatar
		  	if($(document).scrollTop() > 0){

		    	if($('.user_avatar_header').data('size') == 'big'){

		        	$('.user_avatar_header').data('size','small');
		        	$('.user_avatar_header').stop().animate({
		            	width:'35px',
		            	height:'35px',
		        	},600);

		    	}

			} else {

			    if( $('.user_avatar_header').data('size') == 'small' ){

			        $('.user_avatar_header').data('size','big');
			        $('.user_avatar_header').stop().animate({
			            width:'40px',
			            height:'40px',
			        },600);

			    } 

			}

		});

	}

	function validate_change_password(){

		jQuery("#lmh_change_password").validate({

			errorClass : 'change_pass_error_fields error',
			rules: {
				'old_password' : {
					required: true,
				},
				'new_password' : {
					required: true,
					atleastNum : ( lmhAjax.password_strength == 2 ? true : false ),
					atleastlowercase : ( lmhAjax.password_strength == 2 ? true : false ),
					atleastuppercase : ( lmhAjax.password_strength == 2 ? true : false ),
					minlength : 5,
					specialcharacter : ( lmhAjax.password_strength == 2 ? true : false )
				},
				'confirm_password' : {
					required: true,
					equalTo: '[name="new_password"]'
				},
			},
			submitHandler : function(){

				jQuery.ajax({
					url : lmhAjax.ajaxUrl,
					type : 'post',
					dataType : 'json',
					data : {
						action : 'lmh_change_password',
						old_password : jQuery('.old_password').val(),
						new_password : jQuery('.new_password').val(),
						confirm_password : jQuery('.confirm_password').val(),
					},
					beforeSend : function(){
						jQuery('.lmh_change_password').prop( 'disabled' , true );
						jQuery('.change_pass_error_wrapper').hide();
						jQuery('#ballloader').modal({
							'backdrop' : 'static',
							'show' : true
						});
					},
					success : function( data ){
						jQuery('#ballloader').modal('hide');
						jQuery('.lmh_change_password').prop( 'disabled' , false );

						if( data.result == 'error' ){
							jQuery('.change_pass_error_wrapper').show();
							jQuery('.change_pass_error_wrapper ul').empty().append( data.message );
						} else {
							jQuery('#success_changed_password').modal({
								'backdrop' : 'static',
								'show' : true
							});
						}
					}
				});

			}

		});

	}

	jQuery(document).on( 'change' , '.payment-select [name="payments"]' , function(){

		if( jQuery(this).is(':checked') && jQuery(this).val() == 'payment_stripe' ){
			
			jQuery('#payment_stripe_content').show();
			jQuery('#paymentPaypal').hide();

		} else {

			jQuery('#payment_stripe_content').hide();
			jQuery('#paymentPaypal').show();

		}

	});

	/* Confirm Payment By Traveller */
	jQuery(document).on( 'click' , '.confirm_payment_paypal' , function(){		

		jQuery.ajax({
			url : lmhAjax.ajaxUrl,
			type : 'post',
			dataType : 'json',
			data : {
				action : 'get_paypal_payment_details',
				invoice_id : lmhAjax.booking_room_id
			},
			beforeSend : function(){
				jQuery('.confirm_payment_paypal').prop( 'disabled' , true );
				jQuery('#ballloader').modal({
					'backdrop' : 'static',
					'show' : true
				});
			},
			success : function( data ){
				if( data.result == 'success' ){
					window.location.href = data.redirect_url;
				}
			}

		});
	});

	/* Get author details on the profile page */
	function get_the_author_description(){

		jQuery.ajax({
			url : lmhAjax.ajaxUrl,
			type : 'post',
			dataType : 'json',
			data : {
				action : 'get_current_user_details',
			},
			beforeSend : function(){

			},
			success : function( data ){
				jQuery('.author_description_wrapper').append( data.result );
			}
		});
	}

	/**
	 * Slicknav - a Dashboard Mobile Menu
	 */
	$('#responsive-menu-dashboard').slicknav({
		duration: 500,
		easingOpen: 'easeInExpo',
		easingClose: 'easeOutExpo',
		closedSymbol: '<i class="fa fa-plus"></i>',
		openedSymbol: '<i class="fa fa-minus"></i>',
		prependTo: '#slicknav-mobile-dashboard',
		allowParentLinks: true,
		label:"Dashboard Menu" 
	});

	/**
	 * Navbar Vertical - For example: use for dashboard menu
	 */
	if (screen && screen.width > 767 ) {
		// Mouse-enter dropdown
		$('.navbar-vertical li').on("mouseenter", function() {
		$(this).find('ul').first().stop(true, true).delay(450).slideDown(500, 'easeInOutQuad');
		});

		// Mouse-leave dropdown
		$('.navbar-vertical li').on("mouseleave", function() {
				$(this).find('ul').first().stop(true, true).delay(0).slideUp(150, 'easeInOutQuad');
		});
	}

	/* Approved Booking by hotel */
	jQuery(document).on( 'click' , '.accept_contract_by_hotel' , function(){
		jQuery.ajax({
			url : lmhAjax.ajaxUrl,
			type : 'post',
			dataType : 'json',
			data : {
				action : 'approved_booking_by_hotel',
				invoice_id : lmhAjax.booking_room_id // Invoice id
			},
			beforeSend : function(){
				jQuery('#ballloader').modal({
					backdrop : 'static',
					show : true
				});
			},
			success : function( data ){
				window.location.href = data.redirect_url;
			}
		});
	});

	/* Reject Booking by Hotel */
	jQuery(document).on( 'click' , '.confirm_cancel_booking_hotel' , function(){

		jQuery.ajax({
			url : lmhAjax.ajaxUrl,
			type : 'post',
			dataType : 'json',
			data : {
				action : 'cancel_booking_by_hotel',
				invoice_id : lmhAjax.booking_room_id // Invoice id
			},
			beforeSend : function(){
				jQuery('#ballloader').modal({
					backdrop : 'static',
					show : true
				});
			},
			success : function( data ){
				window.location.href = data.redirect_url;
			}
		});

	});

	/* Cancel booking request by traveller */
	jQuery(document).on( 'click' , '.confirm_cancel_booking_traveller' , function(){

		jQuery.ajax({
			url : lmhAjax.ajaxUrl,
			type : 'post',
			dataType : 'json',
			data : {
				action : 'cancel_booking_by_traveller',
				invoice_id : lmhAjax.booking_room_id // Invoice id
			},
			beforeSend : function(){
				jQuery('#ballloader').modal({
					backdrop : 'static',
					show : true
				});
			},
			success : function( data ){
				window.location.href = data.redirect_url;
			}
		});

	});

	/* Equal Height on booking details */
    jQuery('.billing_price_details .equal-height1').matchHeight('remove').matchHeight();

	jQuery(document).on( 'click' , '.booking_step_2_confirm' , function(){

		jQuery.ajax({
			url : lmhAjax.ajaxUrl,
			type : 'post',
			dataType : 'json',
			data : {
				action : 'send_booking_request',
				secret : lmhAjax.secret_key_booking,
				post_id : lmhAjax.booking_room_id,
			},
			beforeSend : function(){
				jQuery('#ballloader').modal({
					backdrop : 'static',
					show : true
				});
			},
			success : function( data ){

				if( data.result == 'success' ){
					window.location.href = data.redirect_url;
				} else {
					window.location.href = data.redirect_url;
				}

			}
		});

	});

	jQuery(document).on( 'change' , '.guide_category_label input' , function(){

		var selector = jQuery(this).parent().attr('class').replace( 'guide_category_label' , '' ).trim();

		if( jQuery(this).is(':checked') ){
			jQuery( '.map-icon-label .' + selector ).show();
		} else {
			jQuery( '.map-icon-label .' + selector ).hide();
		}

	});

	jQuery('.save_guide').on( 'click' , function(){

		var guideData = new FormData();
		guideData.append( 'image', jQuery('#guide_image')[0].files[0] );
		guideData.append( 'action', 'save_guide_details' );
		guideData.append( 'lat', jQuery('[name="lat"]').val() );
		guideData.append( 'lng', jQuery('[name="lng"]').val() );
		guideData.append( 'name', jQuery('[name="guide_place_name"]').val() );
		guideData.append( 'category', jQuery('.guide_cat option:selected').val() );
		guideData.append( 'description', jQuery('[name="why_recommend"]').val() );
		guideData.append( 'for_post_id', lmhAjax.room_id );

		jQuery.ajax({
			url : lmhAjax.ajaxUrl,
			type : 'post', 
			contentType: false,
            processData: false,
            dataType : 'json',
			data : guideData,
			beforeSend : function(){
				jQuery('.guide_error_msg').hide();
				jQuery('#ballloader').modal({
					'backdrop' : 'static',
					'show' : true
				})
			},
			success : function( data ){
				
				if( data.result == 'error' ){

					jQuery('#ballloader').modal('hide');
					jQuery('.guide_error_msg').html( data.message ).show();

					$('html, body').animate({
					    scrollTop: $(".guide_error_msg").offset().top - 60
					}, 'slow' );

				} else {
					
					var id = getUrlParameter( 'id' );
					var page = getUrlParameter( 'page' );
					var redirect_url = window.location.protocol + "//" + window.location.hostname + window.location.pathname + '?id=' + id + '&page=' + page + '&status=added'; 
					window.location.href = redirect_url;

				}
			}
		});

		return;

	});

	function guide_page_google_map(){

		var options = {
          	map: "#guide_google_map",
          	location: lmhAjax.guide_page_location,
          	details: ".guide_lat_lng",
          	types : ['geocode' , 'establishment'],
          	markerOptions : {
				draggable : true,
				icon : lmhAjax.contactMarker
			},
			mapOptions: {
	          	zoom: 15,
	        }
        };
        
        var guide_place_name = $(".guide_place_name").geocomplete(options);

        if( $(".guide_place_name").length == 0 ){
        	return;
        }

        var map = $(".guide_place_name").geocomplete('map');
        var places = lmhAjax.guide_places,
		infowindow = new google.maps.InfoWindow();
		window.map_marker = [];

		if( places != '' ){

			// a div where we will place the buttons
			var ctrl = $('<div/>').css({
				background: '#fff',
				border: '1px solid #000',
				padding: '4px',
				margin: '2px',
				textAlign: 'center',
				clear: 'both',
			})[0];
			
			map.controls[google.maps.ControlPosition.RIGHT_TOP].push(ctrl);
			ctrl=$(ctrl);

			/*
			* if no place found hide Clear all-button
			*/

			ctrl.append($('<input>', {
				type: 'button',
				value: 'clear all'
			})
			.click(function () {

				$(this).parent().find('input[type="checkbox"]')
					.prop('checked', false).trigger('change');
				$('.map-icon-label .map-icon').hide();

			}));
			ctrl.append($('<div style="clear:both"></div>'));

			/**
			* now loop over the categories
			*/

			$.each(places, function (c, category) {

				var label_class = (category.label)
				.replace(/ /g,"_")
				.toLowerCase()
				.replace( '&amp;' , "");

				var marker_class = label_class;

				//a checkbox fo the category
				var cat = $('<input>', {
					type: 'checkbox'
				}).change(function () {
					$(this).data('goo').set('map', (this.checked) ? map : null);
				})
				//create a data-property with a google.maps.MVCObject
				//this MVC-object will do all the show/hide for the category 
				.data('goo', new google.maps.MVCObject)
					.prop('checked', !! category.checked)

				//this will initialize the map-property of the MVCObject
				.trigger('change')

				//label for the checkbox
				.appendTo($('<label>').css({
					whiteSpace: 'nowrap',
					textAlign: 'left'
				})
				.addClass( label_class + ' guide_category_label' ) // replace space with underscore
				.appendTo(ctrl))
				.after(category.label);

				//loop over the items(markers)
				$.each(category.items, function (m, item) {
					
					var guide_data = item.toString().split(",");
					var marker = new Marker({
						map: map,
						position: new google.maps.LatLng( guide_data[1].trim(), guide_data[2].trim() ),
						icon: {
					        path: MAP_PIN,
					        fillColor: category.background_color,
					        fillOpacity: 1,
					        strokeColor: '',
					        strokeWeight: 0
					    },
					    map_icon_label: '<span class="map-icon ' + marker_class + ' ' + category.icon + '"></span>'
					});

					marker.html = guide_data[0];
					map_marker.push(marker);

					//bind the map-property of the marker to the map-property
					//of the MVCObject that has been stored as checkbox-data 
					marker.bindTo('map', cat.data('goo'), 'map');
					google.maps.event.addListener(marker, 'click', function () {
						infowindow.setContent(guide_data[0]);
						infowindow.open(map, this);
					});
				});

			});
			
			/**
			* if no place found hide Show all-button
			*/

			ctrl.prepend($('<br/>'));
			$('<input>', {
				type: 'button',
				value: 'show all'
			})
			.click(function () {
				
				$(this).parent().find('input[type="checkbox"]')
					.prop('checked', true).trigger('change');
				$('.map-icon-label .map-icon').show();

			}).prependTo(ctrl).click();

			/**
			* If zoom changed hide the map icons on the google map
			*/
			google.maps.event.addListener( map, 'zoom_changed', function() {
				
				setTimeout(function(){ 
					
					jQuery('.guide_category_label input').each( function(){

						var selector = jQuery(this).parent().attr('class').replace( 'guide_category_label' , '' ).trim();

						if( jQuery(this).is(':checked') ){
							jQuery( '.map-icon-label .' + selector ).show();
						} else {
							jQuery( '.map-icon-label .' + selector ).hide();
						}

					});

				}, 10 );

			});

		}

		jQuery(document).on( 'click' , '.show_on_map' , function(){
			var lat = jQuery(this).attr( 'lat' );
      		var lng = jQuery(this).attr( 'lng' );
      		var position = new google.maps.LatLng(lat,lng);
     		map.setCenter( position );
     		map.setZoom(16);

     		for( var i = 0 ; i < map_marker.length ; i++ ){

         		if( map_marker[i].position.lat() == lat && map_marker[i].position.lng() == lng ){
            		infowindow.setContent( map_marker[i].html.toString() );
            		infowindow.open(map, map_marker[i]);
         		}
      		}

     		$('html,body').animate({
	         	scrollTop: $("#guide_google_map").offset().top - 50 },
	      	'slow');
		});

	}

	jQuery(".guide_place_name").bind("geocode:dragged", function(event, latLng){
        jQuery(".guide_lat_lng [name=lat]").val(latLng.lat());
        jQuery(".guide_lat_lng [name=lng]").val(latLng.lng());            
    });

	jQuery('.without_tab_layout').on( 'click' , function(){
		$('html, body').animate({
		    scrollTop: $("#detail-content-sticky-nav-04").offset().top - 82
		}, 'slow' );
	});

	jQuery('.save_calendar_btn').on( 'click' , function(){

		jQuery.ajax({
			url : lmhAjax.ajaxUrl,
			type : 'post',
			data : {
				action : 'change_room_calendar_dates',
				start_date : jQuery('#calendar_start_date').val(),
				end_date : jQuery('#calendar_end_date').val(),
				post_id : lmhAjax.room_id,
				date_status : jQuery( '[name="room_dates_option"]:checked' ).val()
			},
			beforeSend : function(){
				jQuery('.save_calendar_btn').val( lmhAjax.saving ).prop( 'disabled' , true );
				jQuery('.save_calendar_btn_cancel').prop( 'disabled' , true );
			},
			success : function(){
				var enddate = jQuery('#calendar_end_date').val();
				var location = window.location.href; // Get current Url
				location = removeParam( 'status' , location ); // Remove '&status=success' from url
				location = removeParam( 'defaultdate' , location );
				window.location.href = location  + '&status=success&defaultdate=' + enddate; // New reload url
			}
		});

	});

	function removeParam( key, sourceURL ) {
	    var rtn = sourceURL.toString().split("?")[0],
	        param,
	        params_arr = [],
	        queryString = (sourceURL.toString().indexOf("?") !== -1) ? sourceURL.toString().split("?")[1] : "";
	    if (queryString !== "") {
	        params_arr = queryString.split("&");
	        for (var i = params_arr.length - 1; i >= 0; i -= 1) {
	            param = params_arr[i].split("=")[0];

	            if (param === key) {
	                params_arr.splice(i, 1);
	            }
	        }
	        rtn = rtn + "?" + params_arr.join("&");
	    }
	    return rtn;
	}

	jQuery( '.save_calendar_btn_cancel' ).on( 'click' , function(){
		jQuery( '#calendar_start_date,#calendar_end_date' ).val('');
	});

	jQuery('.top-destination-wrapper .top-destination-item').matchHeight();
	jQuery('.sell-or-buy').matchHeight();

	jQuery('.navigation.posts-navigation').closest('.result-paging-wrapper').css({
		'border-top' : 'none',
		'padding-top' : 0,
	});

	jQuery.validator.addMethod( "checkSpaces" , function(value, element) {
	  	
	  	var new_val = value.trim();
	  	if( new_val.length > 0 ){
	  		return true;
	  	}

	}, 'This field is required.' );

	/**
	* Created custom email validation
	*/

	jQuery.validator.addMethod( "laxEmail" , function(value, element) {
	  	// allow any non-whitespace characters as the host part
	  	var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
	  	return this.optional( element ) || pattern.test( value );
	}, 'Please enter a valid email address.');

	/**
	* Atleast one number required
	*/

	jQuery.validator.addMethod( "atleastNum" , function(value, element) {
	  	return this.optional( element ) || /\d/.test( value );
	}, 'Your password should contain atleast 1 number.');

	/**
	* Atleast one lowercase required
	*/

	jQuery.validator.addMethod( "atleastlowercase" , function(value, element) {
	  	return this.optional( element ) || /[a-z]/.test( value );
	}, 'Your password should contain atleast 1 lowercase.');

	/**
	* Atleast one Uppercase required
	*/

	jQuery.validator.addMethod( "atleastuppercase" , function(value, element) {
	  	return this.optional( element ) || /[A-Z]/.test( value );
	}, 'Your password should contain atleast 1 uppercase.');

	/**
	* Atleast one Special Character required
	*/

	jQuery.validator.addMethod( "specialcharacter" , function(value, element) {
	  	return this.optional( element ) || /[\!\@\#\$\%\^\&\*\(\)\_\+\.\,\;\:\-\=\{\}\<\>]/.test( value );
	}, 'Your password should contain atleast 1 special character.');

	function changeCurrencyHeader(){

		jQuery('.currency-dropdown-menu li a').on( 'click' , function(){

			var currency = jQuery(this).attr( 'title' );

			jQuery.ajax({
				url : lmhAjax.ajaxUrl,
				type : 'post',
				data : {
					action : 'change_currency',
					change_currency : currency
				},
				beforeSend : function(){
					jQuery('#ballloader').modal({
						backdrop : 'static',
						show:true
					});
				},
				success : function(){
					location.reload();
				}
			});

		});

	}

	function billingFormValidate(){

		jQuery("#billingInfoForm").validate({
			errorClass : 'billingfields_error_fields error',
			rules: lmhAjax.billingfield_rules,
			focusInvalid: false,
		    invalidHandler: function(form, validator) {

		        if (!validator.numberOfInvalids())
		            return;

		        jQuery('html, body').animate({
		            scrollTop: jQuery(validator.errorList[0].element).offset().top - 100
		        }, 'slow' );

		    },
			submitHandler : function(){

				var orig = $('#billingInfoForm').serialize();
				var withoutEmpties = orig.replace(/[^&]+=\.?(?:&|$)/g, '');

				jQuery.ajax({
					url : lmhAjax.ajaxUrl,
					type : 'post',
					dataType : 'json',
					data : {
						action : 'save_billing_info',
						datas : withoutEmpties
					},
					beforeSend : function(){

						jQuery('html, body').animate({
					        scrollTop: jQuery(".payment-congrate").offset().top - 80
					    }, 'slow' );
					    jQuery('.book_now_step_2').val( lmhAjax.processing ).prop( 'disabled' , true );

					},
					success : function( data ){

						if( data.result == 'error' ){
							jQuery('html, body').animate({
						        scrollTop: jQuery("#error_message").show().offset().top - 80
						    }, 'slow' );
						    jQuery('.book_now_step_2').val( 'Book Now' );
						} else {
							window.location.href = data.redirect_to;
							jQuery('.book_now_step_2').val( lmhAjax.redirecting ).prop( 'disabled' , true );;
						}					

					}

				});

			}
			
		});

	}

	function listMyRoomValidate(){
		jQuery("#listYourRoomForm").validate({
			
			errorClass : 'listyourroom_error_fields error',
			ignore: [],
			rules: lmhAjax.list_your_room_rules,
			messages: lmhAjax.list_your_room_message,
			errorPlacement: function(error, element) {

				var availableFields1 = [ 'file' ];
				var availableFields2 = [ 'checkbox' ];

	 			if ( element.is('select') || jQuery.inArray( element.attr("type") , availableFields1 ) !== -1 ) {
			    	jQuery(element).closest('div').nextAll('.error_label').html(error);
			    } else if( jQuery.inArray( element.attr("type") , availableFields2 ) !== -1 ){
			    	jQuery(element).parent().parent().parent().nextAll('.error_label').html(error);
			    } else if( element.hasClass( 'googleClass' ) ) {
			    	jQuery(element).after(error);
			    } else {
			    	jQuery(element).nextAll('.error_label').html(error);
			    }

			},
			focusInvalid: false,
			invalidHandler: function(form, validator) {

		        if (!validator.numberOfInvalids())
		            return;

		        jQuery('html, body').animate({
		            scrollTop: jQuery(validator.errorList[0].element).parent('div').offset().top - 100
		        }, 'slow' );

		    }

		});
	}

	function resetPassword(){

		jQuery('#user-reset-pass').validate({
			errorClass : 'login_error_fields error',
			rules : {
				reset_pass: {
					required : true,
					atleastNum : true,
					atleastlowercase : true,
					atleastuppercase : true,
					minlength : 5,
					specialcharacter : true
				},
				confirm_reset_pass: {
					required : true,
					equalTo : "#reset_pass"
				},				
			},
			submitHandler: function (form) {

				jQuery.ajax({
					url : lmhAjax.ajaxUrl,
					type : 'post',
					dataType : 'json',
					data : {
						action : 'reset_password',
						pass : jQuery( '#reset_pass' ).val(),
						confirm_pass : jQuery( '#confirm_reset_pass' ).val(),
						reset_key : jQuery('#browser_reset_pass').val(),
						user_id : jQuery('#browser_reset_user_id').val(),
						nonce : jQuery('#reset_pass_nonce').val(),
					},
					beforeSend : function(){
						jQuery('.reset_password_btn').text( 'resetting ...' ).prop( 'disabled' , true );
					},
					success : function(data){
						
						jQuery('.reset_password_btn').text( 'reset' ).prop( 'disabled' , false );;
						
						if( (data.result == false) || (data.result == null) ){

							jQuery('.reset_error_modal').html( '<li>' + data.message + '</li>' ).show().removeClass( 'reset_success_modal' );

						} else {
							
							jQuery('.reset_error_modal').html( '<li>' + data.message + '</li>' ).show().addClass( 'reset_success_modal' );
							jQuery('#user-reset-pass')[0].reset();

						}
					}
				});
			}

		});

	}

	function forgoturpassword(){

		jQuery('#lost-form').validate({
			errorClass : 'login_error_fields error',
			rules : {
				lost_email: {
					required : true,
					laxEmail : true
				},
			},
			submitHandler: function (form) {

				jQuery.ajax({
					url : lmhAjax.ajaxUrl,
					type : 'post',
					dataType : 'json',
					data : {
						action : 'forgot_password',
						email : jQuery( '[name="lost_email"]' ).val()
					},
					beforeSend : function(){
						jQuery('.lmh_forgot_pass').text( lmhAjax.submitting ).prop( 'disabled' , true );
						jQuery('.forgot_modal_error').hide();
					},
					success : function( data ){

						jQuery('.lmh_forgot_pass').text( lmhAjax.submit ).prop( 'disabled' , false );;
						if( data.result == 'error' ){
							jQuery('.forgot_modal_error').empty().html( '<li>' + data.message + '</li>' ).show().removeClass( 'success_forgot_modal' );;
						} else {
							jQuery('.forgot_modal_error').empty().html( '<li>' + data.message + '</li>' ).show().addClass( 'success_forgot_modal' );
							jQuery('#lost-form')[0].reset();
						}

					}
				});
			}

		});

	}

	function validateLogin(){

		jQuery('#login-form').validate({
			errorClass : 'login_error_fields error',
			rules : {
				login_username: {
					required: true,
				},
				login_password: {
					required: true,
				},
			},
			submitHandler: function (form) {

				jQuery.ajax({
					url : lmhAjax.ajaxUrl,
					type : 'post',
					dataType : 'json',
					data : {
						action : 'lmh_login_user',
						username : jQuery('[name="login_username"]').val(),
						pass : jQuery('[name="login_password"]').val(),
						remember : jQuery('[name="remember_me_checkbox"]:checked').val(),
						nonce : jQuery('[name="login_nonce"]').val(),
						current_url : lmhAjax.current_page_url
					},
					beforeSend : function(){
						jQuery('.modal_login_in').text( lmhAjax.signing_in ).prop( 'disabled' , true );
					},
					success : function( data ){

						jQuery('.modal_login_in').prop( 'disabled' , false );
						if( data.result == 'error' ){
							jQuery('.login_modal_error').empty().html( '<li>' + data.message + '</li>' ).show();
							jQuery('.modal_login_in').text( lmhAjax.sign_in );
						} else {
							jQuery('.login_modal_error').hide();
							jQuery('#login-form')[0].reset();
							window.location.href = data.redirect;
						}

					}
				});

			}
		});

	}

	function validateRegister(){

		jQuery(".register_form_modal").validate({

	 		errorClass : 'register_error_fields error',
			rules: lmhAjax.register_modal_rules,
			messages: lmhAjax.register_modal_message,

		});

	}

	function validateEditProfile(){

		jQuery("#lmh_edit_profile").validate({

	 		errorClass : 'register_error_fields error',
	 		ignore: [],
			rules: lmhAjax.register_modal_rules,
			messages: lmhAjax.register_modal_message,
			errorPlacement: function(error, element) {

				var availableFields1 = [ 'file' ];

				if ( element.is('select') || jQuery.inArray( element.attr("type") , availableFields1 ) !== -1 ) {
			    	jQuery(element).closest('div').nextAll('.error_label').html(error);
			    } else if( element.hasClass( 'googleClass' ) ) {
			    	jQuery(element).after(error);
			    } else {
			    	jQuery(element).nextAll('.error_label').html(error);
			    }

			},
			focusInvalid: false,
			invalidHandler: function(form, validator) {

		        if (!validator.numberOfInvalids())
		            return;

		        jQuery('html, body').animate({
		            scrollTop: jQuery(validator.errorList[0].element).parent('div').offset().top - 100
		        }, 'slow' );

		    }

		});

	}

	/**
	* When click on register user button on register modal
	*/

	jQuery( document ).on( 'click' , '.register_modal', function(){
		
		var username = jQuery( '#register_username' ).val();
		var email = jQuery( '#register_email' ).val();
		var register_password = jQuery( '#register_password' ).val();
		var register_password_confirm = jQuery( '#register_password_confirm' ).val();

		jQuery(".register_form_modal").validate();
		
	});

	/**
	* When click on sign up button on header
	*/

	jQuery( document ).on( 'click' , '.register_sign_up' , function(){

		jQuery( '#loginModal' ).modal('show');
		jQuery( '#login-form,#lost-form' ).hide();
		jQuery( '#register-form' ).show();

	});

	/**
	* When click on login btn on header
	* When click on verification sign in btn
	*/

	jQuery( document ).on( 'click' , '.login_modal_lmh,.verification_sign_in' , function(){

		jQuery('#userVerifiedMsg').modal('hide'); // hide verification modal
		jQuery('#userRegistrationMsg').modal('hide'); // hide registration modal
		jQuery( '#loginModal' ).modal('show');
		jQuery( '#register-form,#lost-form' ).hide();
		jQuery( '#login-form' ).show();
		
	});

	jQuery('#per_night_price').on( 'keyup' , function(){

		var str = jQuery(this).val();
		per_night_price_with_commission(str);
		
	});

	function add_commission_to_price(){

		var price_before_commission = jQuery('#per_night_price').val();
		per_night_price_with_commission(price_before_commission);

	}

	function per_night_price_with_commission(str){

		var intRegex = /^\d+$/;
		var totalVal;
		var commission = parseInt( lmhAjax.commision_rate );

		if(intRegex.test(str)) {
			totalVal = parseInt(str) + parseInt(str) * ( commission / 100 );
			jQuery('#total_price_per_night').val( Math.ceil(totalVal) );
		} else {
			jQuery('#total_price_per_night').val('');
		}

	}

	jQuery.fn.raty.defaults.path = lmhAjax.theme_path + '/images/raty';
	jQuery('.rating-cleanliness').raty({ 
		score: 1,
		half: true,
		scoreName: 'room_cleanliness',
		hints: ['Bad', 'Poor', 'Regular', 'Good', 'Excellent']
	});
	jQuery('.rating-service').raty({ 
		score: 2,
		half: true,
		scoreName: 'room_service',
		hints: ['Bad', 'Poor', 'Regular', 'Good', 'Excellent']
	});
	jQuery('.rating-comfort').raty({ 
		score: 3,
		half: true,
		scoreName: 'room_comfort',
		hints: ['Bad', 'Poor', 'Regular', 'Good', 'Excellent']
	});
	jQuery('.rating-condition').raty({ 
		score: 4,
		half: true,
		scoreName: 'room_condition',
		hints: ['Bad', 'Poor', 'Regular', 'Good', 'Excellent']
	});
	jQuery('.rating-neighbourhood').raty({ 
		score: 5,
		half: true,
		scoreName: 'room_neighbourhood',
		hints: ['Bad', 'Poor', 'Regular', 'Good', 'Excellent']
	});

	/** 
	* Search page datepickers
	*/

	var checkin = $('#arrival_date').datepicker({
		format: 'dd-mm-yyyy',
		startDate: current_date(),
		autoclose: true,
		orientation: 'bottom',
	}).on('changeDate', function(e){

		var nextDay = new Date(e.date);

		// Add min Bookign Durationto the chout out date
		nextDay.setDate( nextDay.getDate() + 1 );
		checkout.datepicker('setStartDate', nextDay);

		checkout.datepicker( 'update', nextDay );
		checkout.focus();

	});

	var checkout = $('#departure_date').datepicker({
		format: 'dd-mm-yyyy',
		startDate: current_date(),
		autoclose: true,
		orientation: 'bottom',
	});

	/**
	* Search page place search validate
	*/

	function searchPageForm(){
		
		jQuery(".search_page_form_home,.search_page_form").validate({
			errorClass : 'searchfields_error_fields error',
			ignore : [],
			rules : {
				s : {
					required : true
				},
				place : {
					required : true	
				},
				formatted_address : {
					required : true	
				},
				lat : {
					required : true	
				},
				lng : {
					required : true	
				},
			},
			errorPlacement: function(error, element) {

	 			if ( element.is('input') ) {
			    	jQuery( '#search_page_type_place,#destination-search-homepage' ).closest('div').nextAll('.error_label').html(error);
			    } 

			},
		});

	}

	/**
	* On pagination get content through ajax
	*/

	jQuery( document ).on( 'click' , '.paging li a' , function(){

		var page_no = jQuery(this).attr( 'data-page_no' );
		
		var arr = get_sort_by_value();
		var sliderValue = get_slider_value();
		get_ajax_content( page_no , arr[0] , arr[1] , arr[2] , sliderValue[0] , sliderValue[1] , get_selected_facilities() , get_selected_type_of_place() , get_selected_room_type() , get_selected_bedroom_filter() , get_selected_bathroom_filter() , get_selected_beds_filter() );

	});

	/**
	* Clicked on sort by
	*/

	function remove_active_class_sort(){

		jQuery( '.sort-wrapper li' ).each(function(){

			jQuery(this).removeClass('active');

		});

	}

	jQuery( document ).on( 'click' , '.sort-wrapper li a' , function(){

		var distance = null;
		var name = null;
		var price = null;
		var sliderValue = get_slider_value();

		if( jQuery(this).attr('data-sort_by') == 'distance' ){

			remove_active_class_sort();
			jQuery(this).closest('li').addClass('active');

			if( jQuery(this).attr('title') == 'ASC' ){
				jQuery(this).attr( 'title' , 'DESC' );
				jQuery(this).find('i').removeClass('fa-sort-amount-asc');
				jQuery(this).find('i').addClass('fa-sort-amount-desc');
			} else {
				jQuery(this).attr( 'title' , 'ASC' );
				jQuery(this).find('i').addClass('fa-sort-amount-asc');
				jQuery(this).find('i').removeClass('fa-sort-amount-desc');
			}

			distance = jQuery('.sort-wrapper li a.sort_by_distance').attr('title');
			get_ajax_content( null , distance , null , null , sliderValue[0] , sliderValue[1] , get_selected_facilities() , get_selected_type_of_place() , get_selected_room_type() , get_selected_bedroom_filter() , get_selected_bathroom_filter() , get_selected_beds_filter() );

		} else if( jQuery(this).attr('data-sort_by') == 'name' ){

			remove_active_class_sort();
			jQuery(this).closest('li').addClass('active');

			if( jQuery(this).attr('title') == 'ASC' ){
				jQuery(this).attr( 'title' , 'DESC' );
				jQuery(this).find('i').removeClass(' fa-sort-alpha-asc ');
				jQuery(this).find('i').addClass(' fa-sort-alpha-desc ');
			} else {
				jQuery(this).attr( 'title' , 'ASC' );
				jQuery(this).find('i').addClass('fa-sort-alpha-asc');
				jQuery(this).find('i').removeClass(' fa-sort-alpha-desc ');
			}

			name = jQuery('.sort-wrapper li a.sort_by_name').attr('title');
			get_ajax_content( null , null , name , null , sliderValue[0] , sliderValue[1] , get_selected_facilities() , get_selected_type_of_place() , get_selected_room_type() , get_selected_bedroom_filter() , get_selected_bathroom_filter() , get_selected_beds_filter() );

		} else if( jQuery(this).attr('data-sort_by') == 'price' ){

			remove_active_class_sort();
			jQuery(this).closest('li').addClass('active');

			if( jQuery(this).attr('title') == 'ASC' ){
				jQuery(this).attr( 'title' , 'DESC' );
				jQuery(this).find('i').removeClass('  fa-sort-numeric-asc  ');
				jQuery(this).find('i').addClass('  fa-sort-numeric-desc ');
			} else {
				jQuery(this).attr( 'title' , 'ASC' );
				jQuery(this).find('i').addClass(' fa-sort-numeric-asc ');
				jQuery(this).find('i').removeClass('  fa-sort-numeric-desc ');
			}

			price = jQuery('.sort-wrapper li a.sort_by_price').attr('title');
			get_ajax_content( null , null , null , price , sliderValue[0] , sliderValue[1] , get_selected_facilities() , get_selected_type_of_place() , get_selected_room_type() , get_selected_bedroom_filter() , get_selected_bathroom_filter() , get_selected_beds_filter() );

		}	

	});

	jQuery(document).on( 'change' , '.facility_search input' , function(){

		var arr = get_sort_by_value();
		var sliderValue = get_slider_value();

		if( lmhAjax.view == 'map' ){

			get_search_content( mapObject.getBounds() , sliderValue[0] , sliderValue[1] , get_selected_facilities() , get_selected_type_of_place() , get_selected_room_type() , get_selected_bedroom_filter() , get_selected_bathroom_filter() , get_selected_beds_filter() );
			
		} else {
			get_ajax_content( null , arr[0] , arr[1] , arr[2] , sliderValue[0] , sliderValue[1] , get_selected_facilities() , get_selected_type_of_place() , get_selected_room_type() , get_selected_bedroom_filter() , get_selected_bathroom_filter() , get_selected_beds_filter() );
		}

	});

	jQuery(document).on( 'change' , '.type_of_place_filter input' , function(){

		var arr = get_sort_by_value();
		var sliderValue = get_slider_value();

		if( lmhAjax.view == 'map' ){

			get_search_content( mapObject.getBounds() , sliderValue[0] , sliderValue[1] , get_selected_facilities() , get_selected_type_of_place() , get_selected_room_type() , get_selected_bedroom_filter() , get_selected_bathroom_filter() , get_selected_beds_filter() );

		} else {

			get_ajax_content( null , arr[0] , arr[1] , arr[2] , sliderValue[0] , sliderValue[1] , get_selected_facilities() , get_selected_type_of_place() , get_selected_room_type() , get_selected_bedroom_filter() , get_selected_bathroom_filter() , get_selected_beds_filter() );

		}

	});

	jQuery('.room_type').fancySelect().on('change.fs', function () {
		var arr = get_sort_by_value();
		var sliderValue = get_slider_value();

		if( lmhAjax.view == 'map' ){

			get_search_content( mapObject.getBounds() , sliderValue[0] , sliderValue[1] , get_selected_facilities() , get_selected_type_of_place() , get_selected_room_type() , get_selected_bedroom_filter() , get_selected_bathroom_filter() , get_selected_beds_filter() );

		} else {
			get_ajax_content( null , arr[0] , arr[1] , arr[2] , sliderValue[0] , sliderValue[1] , get_selected_facilities() , get_selected_type_of_place() , get_selected_room_type() , get_selected_bedroom_filter() , get_selected_bathroom_filter() , get_selected_beds_filter() );
		}

	});

	jQuery('.bedroom_filter').fancySelect().on('change.fs', function () {
		var arr = get_sort_by_value();
		var sliderValue = get_slider_value();

		if( lmhAjax.view == 'map' ){

			get_search_content( mapObject.getBounds() , sliderValue[0] , sliderValue[1] , get_selected_facilities() , get_selected_type_of_place() , get_selected_room_type() , get_selected_bedroom_filter() , get_selected_bathroom_filter() , get_selected_beds_filter() );
			
		} else {
 
			get_ajax_content( null , arr[0] , arr[1] , arr[2] , sliderValue[0] , sliderValue[1] , get_selected_facilities() , get_selected_type_of_place() , get_selected_room_type() , get_selected_bedroom_filter() , get_selected_bathroom_filter() , get_selected_beds_filter() );

		}

	});

	jQuery('.bathroom_filter').fancySelect().on('change.fs', function () {
		var arr = get_sort_by_value();
		var sliderValue = get_slider_value();

		if( lmhAjax.view == 'map' ){
			get_search_content( mapObject.getBounds() , sliderValue[0] , sliderValue[1] , get_selected_facilities() , get_selected_type_of_place() , get_selected_room_type() , get_selected_bedroom_filter() , get_selected_bathroom_filter() , get_selected_beds_filter() );
		} else {
			get_ajax_content( null , arr[0] , arr[1] , arr[2] , sliderValue[0] , sliderValue[1] , get_selected_facilities() , get_selected_type_of_place() , get_selected_room_type() , get_selected_bedroom_filter() , get_selected_bathroom_filter() , get_selected_beds_filter() );
		}

	});

	jQuery('.beds_filter').fancySelect().on('change.fs', function () {
		var arr = get_sort_by_value();
		var sliderValue = get_slider_value();

		if( lmhAjax.view == 'map' ){
			get_search_content( mapObject.getBounds() , sliderValue[0] , sliderValue[1] , get_selected_facilities() , get_selected_type_of_place() , get_selected_room_type() , get_selected_bedroom_filter() , get_selected_bathroom_filter() , get_selected_beds_filter() );
		} else {
			get_ajax_content( null , arr[0] , arr[1] , arr[2] , sliderValue[0] , sliderValue[1] , get_selected_facilities() , get_selected_type_of_place() , get_selected_room_type() , get_selected_bedroom_filter() , get_selected_bathroom_filter() , get_selected_beds_filter() );
		}
		
	});

	jQuery('#user_currency').on('change', function () {

		changeCurrencyListRoom();

	});

	jQuery('.modal_login_in,#login_lost_btn').on( 'click' , function(){

		jQuery('.login_modal_error').hide();

	});

	jQuery('#login_lost_btn').on('click',function(){
		jQuery('#login-form')[0].reset();
	});

});


function get_slider_value(){

	var slider = jQuery("#price_range").data("ionRangeSlider");

	var array = [];

	if( slider ==  undefined ){
		array = ['',''];
		return array;
	}

	// Get values
	var from = slider.result.from;
	var to = slider.result.to;

	array = [from,to];
	return array;

}

function get_selected_beds_filter(){

	return jQuery('.beds_filter').fancySelect().val();

}

function get_selected_bathroom_filter(){

	return jQuery('.bathroom_filter').fancySelect().val();

}

function get_selected_bedroom_filter(){

	return jQuery('.bedroom_filter').fancySelect().val();

}

function get_selected_room_type(){

	return jQuery('.room_type').fancySelect().val();

}

function get_sort_by_value(){

	"use strict";
	var distance = null;
	var name = null;
	var price = null;

	var value = jQuery('.sort-wrapper li.active a').attr( 'data-sort_by' );

	switch( value ){

		case 'distance':
			distance = jQuery('.sort-wrapper li.active a').attr( 'title' );
			break;

		case 'price':
			price = jQuery('.sort-wrapper li.active a').attr( 'title' );
			break;

		case 'name':
			name = jQuery('.sort-wrapper li.active a').attr( 'title' );
			break;

		default:
			break;

	}

	var array = [distance,name,price];
	return array;

}

function get_selected_type_of_place(){

	"use strict";
	var selected = jQuery('.type_of_place_filter input:checked').val();
	return selected;

}
function isNumeric(n) {
	"use strict";
  	return !isNaN(parseFloat(n)) && isFinite(n);
}
function get_selected_facilities(){

	"use strict";
	var selected_facilities = [];
	var i = 0;

	jQuery('.facility_search input').each( function(){

		if( jQuery(this).is(':checked') ){

			selected_facilities[i++] = jQuery(this).val();

		}

	});

	return selected_facilities;

}

function get_ajax_content( page_no , distance , name , price , min_price , max_price , facility , type_of_place , room_type , bedrooms , bathrooms , beds ){

	"use strict";
	jQuery.ajax({
		url : lmhAjax.ajaxUrl,
		dataType : 'json',
		data : {
			action : 'get_room_list_pagination',
			lat : lmhAjax.lat,
			lng : lmhAjax.lng,
			guests : lmhAjax.guests,
			post_id : lmhAjax.post_id,
			arrival_date : lmhAjax.check_in,
			departure_date : lmhAjax.check_out,
			page_no : page_no || 1,
			distance : distance || null,
			name : name || null,
			price : price || null,
			min_price : isNumeric( min_price ) ? min_price : 0,
			max_price : isNumeric( max_price ) ? max_price : 0,
			facility : facility || null,
			type_of_place : type_of_place || null,
			room_type : isNumeric( room_type ) ? room_type : null,
			bedrooms : isNumeric( bedrooms ) ? bedrooms : null,
			bathrooms : isNumeric( bathrooms ) ? bathrooms : null,
			beds : isNumeric( beds ) ? beds : null,
			view : lmhAjax.view,
		},
		type : 'POST',
		beforeSend : function(){
			jQuery('#ballloader').modal({
				show : true,
				backdrop : 'static'
			});
		},
		success : function( data ){

			if( data.found_posts == 0 ){
				jQuery('.sort-wrapper').hide();
				jQuery('.result-paging-wrapper').hide();
			} else {
				jQuery('.sort-wrapper').show();
				jQuery('.result-paging-wrapper').show();
			}

			jQuery('.search_content_wrapper').empty();
			jQuery('.search_content_wrapper').append( data.content );
			jQuery('.found_hotels').text( data.found_posts );

			jQuery('.paging').empty();
			jQuery('.paging').append( data.pagination );

			jQuery('#ballloader').modal('hide');
			jQuery('html, body').animate({
		        scrollTop: jQuery(".search_content_wrapper").offset().top - 250
		    }, 'slow' );

			setTimeout(function(){ 
				
				// Equal Height
			    jQuery('.top-hotel-grid-wrapper > .min-height-alt > div')
	            .matchHeight('remove')
	            .matchHeight();

			}, 1000 );
		    
		}
	});

}

function current_date(){

	"use strict";
	var nowTemp = new Date();
	var now = new Date(nowTemp.getFullYear(), nowTemp.getMonth(), nowTemp.getDate(), 0, 0, 0, 0);
	return now;

}

function findplaces( place , array ){

	'use_strict';
	var name;

	jQuery(array).each( function(i){

		switch (array[i].types[0]) {

			case 'administrative_area_level_1':

				if( place == 'administrative_area_level_1' ){
					name = array[i].long_name;
				}							
				break;

			case 'country':

				if( place == 'country_short' ){
					name = array[i].short_name;
				} else if( place == 'country_long' ) {
					name = array[i].long_name;
				}						
				break;

			case 'administrative_area_level_2':

				if( place == 'sublocality' ){
					name = array[i].long_name;
				}							
				break;

			case 'locality':

				if( place == 'locality' ){
					name = array[i].long_name;
				}							
				break;

			case 'postal_code':

				if( place == 'postal_code' ){
					name = array[i].long_name;
				}							
				break;
			
			default:
				
				break;
		}

	});

	return name;

}

function changeCurrencyListRoom(){

	setTimeout(function(){ 
		
		var selected_value = jQuery('#user_currency').val();
		jQuery('.user_price_change').text( selected_value );

	}, 100);

}
function searchPageGoogleMap(){

	jQuery("#destination-search-homepage,#search_page_type_place,.lmh_quick_search").geocomplete({
		details: ".search_place_attr",
		detailsAttribute: "data-geo"
	});

}

function room_photos_sortable(){

	setTimeout(
		function(){ 
			jQuery( ".image_upload_wrapper .jFiler-items-list" ).sortable({
				stop:  function (event, ui) {
		            jQuery('.confirm_sort').show();
		            jQuery('.confirm_sort_btn').text( lmhAjax.confirm_sort ).prop( 'disabled' , false );
		        }
			}); 
		}, 
	100 );
	
}

jQuery( document ).on( 'click' , '.confirm_sort_btn' , function(){

	var links = {};

	jQuery( '.image_upload_wrapper .jFiler-items-grid > li' ).each( function(i){

		links[i] = jQuery(this).find('.jFiler-item-thumb .jFiler-item-thumb-image img').attr( 'src' );

	});

	jQuery.ajax({
		url : lmhAjax.ajaxUrl,
	    type : 'post',
	    data : {
	    	action : 'sort_room_photos_order',
	    	images : links,
	    	post_id : lmhAjax.room_id
	    },
	    beforeSend : function(){
	    	jQuery('.confirm_sort_btn').text( lmhAjax.saving ).prop( 'disabled' , true );
	    },
	    success : function(){
	    	jQuery('.confirm_sort_btn').text( lmhAjax.saved );
	    }
	});

});

function room_dates_calendar(){

 	jQuery( ".room_dates_calendar" ).datepicker({
 		format: 'dd-mm-yyyy',
		startDate: current_date(),
		beforeShowDay: function(dt) { 
            return unavailable_dates(dt);
        }
 	}).on('changeDate', function (ev) {

	   	if( jQuery('#calendar_start_date').val() == '' ){
	   		jQuery('#calendar_start_date').val( ev.format(0,"mm/dd/yyyy") )
	   	} else {
	   		jQuery('#calendar_end_date').val( ev.format(0,"mm/dd/yyyy") )
	   	}

	   	displayCalendarModal();
	   	
	});

 	// If default date exists update the datepicker 
	jQuery( ".room_dates_calendar" ).datepicker( "update", new Date( getUrlParameter('defaultdate') ) );

}

function getUrlParameter(sParam) {
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : sParameterName[1];
        }
    }
};

function appendDatesToModal(){

	var startdate = new Date( jQuery('#calendar_start_date').val() );
	var enddate = new Date( jQuery('#calendar_end_date').val() );

	var formatStartDate = jQuery.datepicker.formatDate("M d, yy", startdate );
	var formatEndDate = jQuery.datepicker.formatDate("M d, yy", enddate );

	if ( startdate < enddate ){
		jQuery('.chosen_start_date').text( formatStartDate );
		jQuery('.chosen_end_date').text( formatEndDate );
	} else {
		jQuery('.chosen_start_date').text( formatEndDate );
		jQuery('.chosen_end_date').text( formatStartDate );
	}

}

function displayCalendarModal(){

	if( jQuery('#calendar_start_date').val() != '' &&  jQuery('#calendar_end_date').val() != '' ){

		jQuery('#room_calendar_modal').modal({
			'backdrop' : 'static',
			'show' : true
		});

		appendDatesToModal();

	}

}
function unavailable_dates(date) {

	var unAvailableDates = lmhAjax.unavailale_dates;

    dmy = ("0" + date.getDate()).slice(-2) + "-" + ("0" + (date.getMonth() + 1)).slice(-2) + "-" + date.getFullYear();
    if ( jQuery.inArray(dmy, unAvailableDates ) != -1) {
      return {
              classes: 'unavailable_dates'
           };
    } else {
        return true;
    }
}

jQuery( document ).on( 'click' , '.single_page_view_calendar_btn' , function(e){
	jQuery( '[name="arrival_date"]' ).datepicker( 'show' );

	// If sticky sidebar disable then scroll
	if( lmhAjax.sticky_sidebar_room == false ){
		jQuery('html, body').animate({
		    scrollTop: jQuery( '[name="arrival_date"]' ).offset().top - 140
		}, 'slow' );
	}

	minDateMsg();

	e.preventDefault();
  	e.stopPropagation();
  	return false;
});

/**
* Notification pagination
*/

jQuery( document ).on( 'click' , '.notification_load_more_label' , function(){

	var page_no,recent_date;

	page_no = jQuery(this).attr( 'data-page' );
	recent_date = jQuery(this).attr( 'data-post-date' );

	jQuery.ajax({
		url : lmhAjax.ajaxUrl,
		type : 'post',
		dataType : 'json',
		data : {
			action : 'extretion_get_more_notifications',
			page_no : page_no,
			recent_date : recent_date
		},
		beforeSend : function(){
			jQuery('#ballloader').modal({
				'show' : true,
				'backdrop' : 'static'
			});
		},
		success : function( data ){

			jQuery('#ballloader').modal( 'hide' );

			var intRegex = /^\d+$/; // Only number

			if( intRegex.test( data.unread_notifications ) && data.unread_notifications > 0 ){
				jQuery( 'a.icon-msg .count' ).text( data.unread_notifications );
			} else {
				jQuery( 'a.icon-msg .count' ).hide();
			}

			if( data.page_no == null ){
				jQuery('.load_more_wrapper').hide();
				return;
			}

			jQuery( data.content ).insertBefore(".load_more_wrapper");
			jQuery('.load_more_wrapper a').attr( 'data-page' , data.page_no );
			jQuery('.load_more_wrapper a').attr( 'data-post-date' , data.recent_date );
			
		}
	});

});

/**
* Book By Email 
*/

jQuery( document ).on( 'click' , '.book_by_email' , function(){

	var datas = '';
	datas = jQuery('#book_email_form').serialize();
	jQuery.ajax({
		url : lmhAjax.ajaxUrl,
		type : 'post',
		dataType : 'json',
		data : {
			action : 'extretion_book_by_email_action',
			values : datas
		},
		beforeSend : function(){
			jQuery('.book_by_email').attr( 'disabled' , 'disabled' );
			jQuery('#book_now_modal input').removeClass( 'errorphp' );
			jQuery('.email_booking_error').empty();
			jQuery('.email_booking_success').empty().hide();
		},
		success : function( result ){

			jQuery('#book_now_modal').animate({
			    scrollTop: '0'
			}, 'slow' );

			if( result.status == true ){				
				
				jQuery('.email_booking_error').append( result.error_message );
				jQuery('.book_by_email').removeAttr( 'disabled' );

				jQuery( result.error_fields ).addClass( 'errorphp' );

			} else {

				jQuery('#book_email_form')[0].reset();
				jQuery('.book_by_email').removeAttr( 'disabled' );
				jQuery('.email_booking_success').show().append( result.success_message );

			}		

		}

	});

});

jQuery( document ).on( 'click' , '.send_message_btn_wrapper' , function(){

	// If not logged in show login form modal
	if( lmhAjax.check_logged_in_user == 0 ){
		jQuery('#loginModal').modal('show');
		return;
	}

	jQuery.ajax({
		url : lmhAjax.ajaxUrl,
		type : 'post',
		dataType : 'json',
		data : {
			action : 'extretion_get_message_modal',
			room_id : lmhAjax.post_id
		},
		beforeSend : function(){
			jQuery( '.send_message_wrapper' ).text( lmhAjax.working );
			jQuery('.send_message_btn_wrapper').prop( 'disabled' , true );
		},
		success : function( data ){

			jQuery( '.send_message_wrapper' ).text( lmhAjax.send_message );
			jQuery( '.send_message_btn_wrapper' ).prop( 'disabled' , false );
			jQuery( '#send_message_modal' ).remove();

			if( data.status == true ){

				jQuery( data.content ).modal({
					'backdrop' : 'static',
					'show' : true
				});

			}
		}
	});

});

jQuery( document ).on( 'click' , '.send_message_modal_btn' , function(){

	jQuery("#message_form").validate({

		errorClass : 'message_error_fields error',
		rules: {
			'first_message' : {
				required: true,
				minlength: 50
			},
		},
		submitHandler : function(){

			jQuery.ajax({
				url : lmhAjax.ajaxUrl,
				type : 'post',
				dataType : 'json',
				data : {
					action : 'extretion_save_first_message',
					message: jQuery('[name="first_message"]').val(),
					room_id: jQuery('#room_id_modal').val(),
				},
				beforeSend : function(){
					jQuery('#ballloader').modal({
						'backdrop':'static',
						'show':true
					});
					jQuery('.send_message_modal_btn').prop( 'disabled' , true );
					jQuery('.send_message_success,.send_message_error').hide();
				},
				success : function( data ){
					jQuery('#ballloader').modal('hide');
					jQuery('.send_message_modal_btn').prop( 'disabled' , false );

					if( data.status == false ){
						jQuery( '.send_message_error' ).show().html( data.message );
					} else {
						jQuery( '.send_message_success' ).show().html( data.message );
						jQuery('#message_form')[0].reset();
					}

				}
			});

		}

	});

});

jQuery(document).on( 'click' , '.delete_message', function(){

	var message_id = jQuery(this).attr( 'message_id' );
	var selected = jQuery(this);

	var status = confirm( 'Are you sure you want to delete this message?' );

	if( status == false ){
		return;
	}

	jQuery.ajax({
		url : lmhAjax.ajaxUrl,
		type : 'post',
		dataType : 'json',
		data : {
			action : 'extretion_delete_message',
			post_id : message_id
		},
		beforeSend : function(){
			jQuery('#ballloader').modal({
				'backdrop' : 'static',
				'show' : true
			});
		},
		success : function(){
			location.reload();
		}
	});

});

// jQuery( document ).on( 'click' , '.message_inbox_sent_btn a' , function(){

// 	jQuery('.message_inbox_sent_btn a').removeClass( 'active' );
// 	jQuery(this).addClass( 'active' );

// 	if( jQuery(this).hasClass( 'inbox_message' ) ){
// 		jQuery('.inbox_messages_wrapper').show();
// 		jQuery('.sent_messages_wrapper').hide();
// 	} else {
// 		jQuery('.inbox_messages_wrapper').hide();
// 		jQuery('.sent_messages_wrapper').show();
// 	}

// });

function getQueryParams(qs) {
    qs = qs.split('+').join(' ');

    var params = {},
        tokens,
        re = /[?&]?([^=]+)=([^&]*)/g;

    while (tokens = re.exec(qs)) {
        params[decodeURIComponent(tokens[1])] = decodeURIComponent(tokens[2]);
    }

    return params;
}

function validate_reply_message_form(){

	var query = getQueryParams(document.location.search);

	jQuery("#message_reply_form").validate({

		errorClass : 'reply_message_error_fields error',
		rules: {
			'reply_message' : {
				checkSpaces : true
			},
		},
		submitHandler : function(){
			jQuery.ajax({
				url : lmhAjax.ajaxUrl,
				type : 'post',
				dataType : 'json',
				data : {
					action : 'extretion_reply_message',
					post_id : query.reply,
					reply_message : jQuery('[name="reply_message"]').val().trim()
				},
				beforeSend : function(){
					jQuery('#ballloader').modal({
						'backdrop' : 'static',
						'show' : true
					});
				},
				success : function(){
					location.reload();
				}
			});
		}

	});

}

jQuery( document ).on( 'click' , '.detail_message_load_more a' , function(){

	var last_msg_id = jQuery(this).closest( '.detail_message_load_more' ).prev( '.message-item' ).attr( 'data_message_id' );

	var query = getQueryParams(document.location.search);

	jQuery.ajax({
		url : lmhAjax.ajaxUrl,
		type : 'post',
		dataType : 'json',
		data : {
			action : 'extretion_get_more_messages',
			post_id : query.reply,
			last_msg_id : last_msg_id
		},
		beforeSend : function(){
			jQuery('.detail_message_load_more a i').show();
			jQuery('.detail_message_load_more a').attr( 'disabled' , 'disabled' );
		},
		success : function( data ){
			jQuery('.detail_message_load_more a i').hide();
			jQuery('.detail_message_load_more a').removeAttr( 'disabled' );

			if( data.status == 'success' ){
				var selector = jQuery('.detail_message_load_more').prev( '.message-item' );
				jQuery( data.content ).insertAfter( selector );
			} 

			if( data.pagination == false ){

				// Remove the pagination button
				jQuery('.detail_message_load_more').remove();

			}

			// For the message count on the header
			if( data.notification_count > 0 ){
				jQuery('.message_count_header').text( data.notification_count );
			} else {
				jQuery('.message_count_header').remove();
			}

		}
	});

});

jQuery( document ).on( 'click', '.tab_similar_listings', function(){

	setTimeout(function(){ 

		jQuery('.similar_listings_wrapper > .min-height-alt > div')
	    .matchHeight('remove')
	    .matchHeight();

	}, 200 );		

});

function equal_height_room_page(){

	var current_url = lmhAjax.current_page_url;
	var string = current_url.split("/"); 

	if( string[0] != 'room' ){
		return;
	}

	var commentID = document.location.hash.toString();

	setTimeout(function(){

		if( commentID != '' ){
			jQuery( 'a[href="#detailTab3"]' ).click();
		}

		jQuery('.sidebar-wrapper,.content-wrapper').css({
			'padding-bottom' : 0,
	    	'margin-bottom': 0
		});
		
	}, 2000);

	setTimeout(function(){

		jQuery('.sidebar-wrapper,.content-wrapper').css({
			'padding-bottom' : '99999px',
	    	'margin-bottom': '-99999px'
		});

		if( commentID != '' ){

			jQuery('html, body').animate({
			    scrollTop: jQuery( commentID ).offset().top - 150
			}, 'slow' );

		}
		
	}, 4000);

}

jQuery(document).on( 'click' , '.price_breakdown' , function(){
	jQuery('#break_down_price_modal').modal( 'show' );
});

function checkStripe(){

	if( typeof Stripe === "function" ){

		Stripe.setPublishableKey( lmhAjax.publishable_key );

		jQuery( document ).on( 'click' , '.stripe_book_now_btn' , function(){

			var $form = jQuery('#payment-form');
			$form.find('.stripe_book_now_btn').prop('disabled', true);
			$form.find('.payment-errors').hide();

			Stripe.card.createToken( $form, stripeResponseHandler);

		    // Prevent the form from being submitted:
		    return false;
		});

	}

}

function stripeResponseHandler(status, response) {
  	// Grab the form:
  	var $form = jQuery('#payment-form');

  	if (response.error) { // Problem!

    	// Show the errors on the form:
    	$form.find('.payment-errors').text(response.error.message).show();
    	$form.find('.stripe_book_now_btn').prop('disabled', false); // Re-enable submission

  	} else { // Token was created!

    	jQuery.ajax({
    		url : lmhAjax.ajaxUrl,
			type : 'post',
			dataType : 'json',
			data : {
				action : 'extretion_stripe_payment',
				card_details : response,
				invoice_id : lmhAjax.booking_room_id
			},
			beforeSend : function(){

			},
			success : function( result ){
				
				if( result.status == 'success' ){

					window.location.href = result.redirect_url;

				} else {

					$form.find('.payment-errors').text( result.message ).show();
					$form.find('.stripe_book_now_btn').prop('disabled', false);

				}

			}
    	});

  	}
};

jQuery( document ).on( 'click' , '.report_btn' , function(){
	jQuery('#report_listing_modal').modal( 'show' );
});

jQuery( document ).on( 'click' , 'a.report_message:not(.report_message_other)' , function(){

	var selected = jQuery(this);
	report_listings_ajax( selected.attr( 'data-value' ) );
	
});

function report_listings_ajax( message ){

	jQuery.ajax({
		url : lmhAjax.ajaxUrl,
		type : 'post',
		dataType : 'json',
		data : {
			action : 'extretion_report_listing',
			post_id : lmhAjax.post_id,
			message : message
		},
		beforeSend : function(){
			jQuery('.report_listing_success_message').show();
			jQuery('.report_btn_wrapper,.report_btn_footer,.other_reason_wrapper').hide();
		},
		success : function(){
			jQuery("#modal-report-listing-wrapper")[0].reset();
		}
	});

}

jQuery(document).on( 'click' , '.report_message_other' , function(){
	jQuery('.other_reason_wrapper').show();
	jQuery('.report_btn_footer').show();
});

jQuery(document).on( 'click' , '.confirm_other_reason' , function(){
	check_report_listing_other_reason();
});

function check_report_listing_other_reason(){

	jQuery("#modal-report-listing-wrapper").validate({

		errorClass : 'report_listings_error_fields error',
		rules: {
			'other_reason' : {
				checkSpaces : true
			},
		},
		submitHandler : function(){
			report_listings_ajax( jQuery('[name="other_reason"]').val() );
		}

	});

}