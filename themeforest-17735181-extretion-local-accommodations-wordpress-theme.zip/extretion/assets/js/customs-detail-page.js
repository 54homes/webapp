jQuery(document).ready(function ($) {
	
	check_booking_cookies();

	/**
	 * Gallery Slideshow - slick
	 */

	$('.gallery-slideshow').slick({
		slidesToShow: 1,
		slidesToScroll: 1,
		speed: 500,
		arrows: true,
		fade: true,
		asNavFor: '.gallery-nav'
	});
	$('.gallery-nav').slick({
		slidesToShow: 5,
		slidesToScroll: 1,
		speed: 500,
		asNavFor: '.gallery-slideshow',
		dots: false,
		centerMode: true,
		focusOnSelect: true,
		infinite: true,
		responsive: [
			{
			breakpoint: 1199,
			settings: {
				slidesToShow: 7,
				}
			}, 
			{
			breakpoint: 991,
			settings: {
				slidesToShow: 5,
				}
			}, 
			{
			breakpoint: 767,
			settings: {
				slidesToShow: 5,
				}
			}, 
			{
			breakpoint: 480,
			settings: {
				slidesToShow: 3,
				}
			}
		]
	});
	
	
	
	var hotel_lat = parseFloat( lmhAjax.hotel_latitude );
	var hotel_lng = parseFloat( lmhAjax.hotel_longitude );
	
	var map;
	var var_location = new google.maps.LatLng( hotel_lat , hotel_lng );
		
	function map_init() {

		var var_mapoptions = {
			center: {lat:hotel_lat,lng:hotel_lng},
			zoom: 14,
			mapTypeId: google.maps.MapTypeId.ROADMAP,
			panControl: false,
			rotateControl: false,
			streetViewControl: false,
			scrollwheel: false,
		};
		
		map = new google.maps.Map(document.getElementById("map-and-friends"),var_mapoptions);
		
		var var_marker = new google.maps.Marker({
			position: var_location,
			map: map,
			//icon : image,
			icon: lmhAjax.theme_path + '/images/3by2white.svg.png',
			maxWidth: 200,
			maxHeight: 200,
			clickable: false,
		});

		google.maps.event.addListener(var_marker, 'click', function() {
		  var_marker.setVisible(false); // maps API hide call
		});

		var circle = new google.maps.Circle({
		  	map: map,
		  	radius: 400,    // 10 miles in metres
		  	fillColor: '#AA0000',
		  	strokeColor: '#FF0000',
		  	strokeWeight: 1,
		});
		circle.bindTo('center', var_marker, 'position');

		var places = lmhAjax.guide_places,
		infowindow = new google.maps.InfoWindow();

		
		if( places != '' ){

			// a div where we will place the buttons
			ctrl = $('<div/>').css({
				background: '#fff',
				border: '1px solid #000',
				padding: '4px',
				margin: '2px',
				textAlign: 'center',
				clear: 'both',
			})[0];
			
			map.controls[google.maps.ControlPosition.RIGHT_TOP].push(ctrl);
			ctrl=$(ctrl);

			/*
			* if no place found hide Clear all-button
			*/

			ctrl.append($('<input>', {
				type: 'button',
				value: 'clear all'
			})
			.click(function () {

				$(this).parent().find('input[type="checkbox"]')
					.prop('checked', false).trigger('change');
				$('.map-icon-label .map-icon').hide();

			}));
			ctrl.append($('<div style="clear:both"></div>'));

			/**
			* now loop over the categories
			*/

			$.each(places, function (c, category) {

				var label_class = (category.label)
				.replace(/ /g,"_")
				.toLowerCase()
				.replace( '&amp;' , "");

				var marker_class = label_class;

				//a checkbox fo the category
				var cat = $('<input>', {
					type: 'checkbox'
				}).change(function () {
					$(this).data('goo').set('map', (this.checked) ? map : null);
				})
				//create a data-property with a google.maps.MVCObject
				//this MVC-object will do all the show/hide for the category 
				.data('goo', new google.maps.MVCObject)
					.prop('checked', !! category.checked)

				//this will initialize the map-property of the MVCObject
				.trigger('change')

				//label for the checkbox
				.appendTo($('<label>').css({
					whiteSpace: 'nowrap',
					textAlign: 'left'
				})
				.addClass( label_class + ' guide_category_label' ) // replace space with underscore
				.appendTo(ctrl))
				.after(category.label);

				//loop over the items(markers)
				$.each(category.items, function (m, item) {

					//console.log( item );

					var guide_data = item.toString().split(",");
					var marker = new Marker({
						map: map,
						position: new google.maps.LatLng( guide_data[1].trim(), guide_data[2].trim() ),
						icon: {
					        path: MAP_PIN,
					        fillColor: category.background_color,
					        fillOpacity: 1,
					        strokeColor: '',
					        strokeWeight: 0
					    },
					    map_icon_label: '<span class="map-icon ' + marker_class + ' ' + category.icon + '"></span>'
					});

					//console.log( guide_data );

					//bind the map-property of the marker to the map-property
					//of the MVCObject that has been stored as checkbox-data 
					marker.bindTo('map', cat.data('goo'), 'map');
					google.maps.event.addListener(marker, 'click', function () {
						infowindow.setContent(guide_data[0]);
						infowindow.open(map, this);
					});
				});

			});
			
			/**
			* if no place found hide Show all-button
			*/

			ctrl.prepend($('<br/>'));
			$('<input>', {
				type: 'button',
				value: 'show all'
			})
			.click(function () {
				
				$(this).parent().find('input[type="checkbox"]')
					.prop('checked', true).trigger('change');
				$('.map-icon-label .map-icon').show();

			}).prependTo(ctrl).click();

			/**
			* If zoom changed hide the map icons on the google map
			*/
			google.maps.event.addListener( map, 'zoom_changed', function() {
				
				setTimeout(function(){ 
					
					jQuery('.guide_category_label input').each( function(){

						var selector = jQuery(this).parent().attr('class').replace( 'guide_category_label' , '' ).trim();

						if( jQuery(this).is(':checked') ){
							jQuery( '.map-icon-label .' + selector ).show();
						} else {
							jQuery( '.map-icon-label .' + selector ).hide();
						}

					});

					//$('.map-icon-label .map-icon').hide(); 
				}, 10 );

			});

		}

	/**
	* Responsive Tab by tabCollapse
	*/

	jQuery('#detailTab').tabCollapse({
		tabsClass: 'hidden-sm hidden-xs',
		accordionClass: 'visible-sm visible-xs'
	});
	
	jQuery('#detailTab').on('shown.bs.tab', function () {
		google.maps.event.trigger(map, "resize");
		map.setCenter(var_location);
	});
	jQuery('#detailTab').on('shown-accordion.bs.tabcollapse', function(){
		google.maps.event.trigger(map, "resize");
		map.setCenter(var_location);
	});
	jQuery('#detailTab').on('shown-tabs.bs.tabcollapse', function(){
		google.maps.event.trigger(map, "resize");
		map.setCenter(var_location);
	});
	jQuery( '.tab_maps_neighbour' ).on( 'click' , function(){

		setTimeout(function(){ 
			map.setZoom(15);
		},500);
		
	});
}
google.maps.event.addDomListener(window, 'load', map_init);

var stickyHeaders = (function() {
	var $window = $(window),
			$stickies;

	var load = function(stickies) {

		if (typeof stickies === "object" && stickies instanceof jQuery && stickies.length > 0) {

			$stickies = stickies.each(function() {

				var $thisSticky = $(this).wrap('<div class="followWrap" />');
	
				$thisSticky
						.data('originalPosition', $thisSticky.offset().top)
						.data('originalHeight', $thisSticky.outerHeight())
							.parent()
							.height($thisSticky.outerHeight()); 			  
			});

			$window.off("scroll.stickies").on("scroll.stickies", function() {
			_whenScrolling();		
			});
		}
	};

	var _whenScrolling = function() {

		$stickies.each(function(i) {			

			var $thisSticky = $(this),
					$stickyPosition = $thisSticky.data('originalPosition');

			if ($stickyPosition <= $window.scrollTop()) {        
				
				var $nextSticky = $stickies.eq(i + 1),
						$nextStickyPosition = $nextSticky.data('originalPosition') - $thisSticky.data('originalHeight');

				$thisSticky.addClass("fixed");

				if ($nextSticky.length > 0 && $thisSticky.offset().top >= $nextStickyPosition) {

					$thisSticky.addClass("absolute").css("top", $nextStickyPosition);
				}

			} else {
				
				var $prevSticky = $stickies.eq(i - 1);

				$thisSticky.removeClass("fixed");

				if ($prevSticky.length > 0 && $window.scrollTop() <= $thisSticky.data('originalPosition') - $thisSticky.data('originalHeight')) {

					$prevSticky.removeClass("absolute").removeAttr("style");
				}
			}
		});
	};

	return {
		load: load
	};
})();

$(function() {
	stickyHeaders.load($(".multiple-sticky"));
});

// Cache selectors
var lastId,
    topMenu = $("#multiple-sticky-menu"),
    topMenuHeight = topMenu.outerHeight()+95,
    // All list items
    menuItems = topMenu.find("a"),
    // Anchors corresponding to menu items
    scrollItems = menuItems.map(function(){
      var item = $($(this).attr("href"));
      if (item.length) { return item; }
    });

	// Bind click handler to menu items
	// so we can get a fancy scroll animation
	menuItems.click(function(e){
		var href = $(this).attr("href"),
				offsetTop = href === "#" ? 0 : $(href).offset().top-140;
				// offsetTop = href === "#" ? 0 : $(href).offset().top-topMenuHeight+1;
		$('html, body').stop().animate({ 
				scrollTop: offsetTop
		}, 300);
		e.preventDefault();
	});

	// Bind to scroll
	$(window).scroll(function(){
		 // Get container scroll position
		 var fromTop = $(this).scrollTop()+topMenuHeight;
		 
		 // Get id of current scroll item
		 var cur = scrollItems.map(function(){
			 if ($(this).offset().top < fromTop)
				 return this;
		 });
		 // Get the id of the current element
		 cur = cur[cur.length-1];
		 var id = cur && cur.length ? cur[0].id : "";
		 
		 if (lastId !== id) {
				 lastId = id;
				 // Set/remove active class
				 menuItems
					 .parent().removeClass("active")
					 .end().filter("[href='#"+id+"']").parent().addClass("active");
		 }                   
	});


});

function check_booking_cookies(){

	if( document.getElementById("change-search-room") == null ){
		return;
	}

	var check_in = getCookie('check_in_date');
    var check_out = getCookie('check_out_date'); 
    var guests = getCookie('room_guest');  

    if( check_in == null && check_out == null ){
     	return;
    }

    var guest_size = document.getElementById("change-search-room").length;
    
	if( guests <= guest_size ){
		jQuery('#change-search-room').val(guests);
		jQuery('#change-search-room').nextAll('.form-control').text(guests);
	}

   	jQuery('#dpd1').val(check_in);
   	jQuery('#dpd2').val(check_out);

   	/*
	* Start if saved in cookie, set the dates on the datepicker and highlight it
	*/

	var check_in_cookie = Date.parse( lmhAjax.check_in_cookie );
	jQuery('#dpd1').datepicker( 'update' , new Date( check_in_cookie ) );

	var check_out_cookie = Date.parse( lmhAjax.check_out_cookie );
	jQuery('#dpd2').datepicker( 'update' , new Date( check_out_cookie ) );

	/*
	* End if saved in cookie, set the dates on the datepicker and highlight it
	*/

    get_booing_prices();

}

function getCookie(name) {
    var re = new RegExp(name + "=([^;]+)");
    var value = re.exec(document.cookie);
    return (value != null) ? unescape(value[1]) : null;
}