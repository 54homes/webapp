
jQuery(document).ready(function($) {
	
	//Example 1
	$('.guide_input').filer({
		showThumbs: true,
		limit : 1,
		extensions: ['png','jpg','jpeg','gif','bmp'],
		changeInput: '<div class="jFiler-custom-wrapper"><a class="jFiler-btn-form">' + lmhAjax.guide_error_msg + '</a></div>',
		captions: {
					button: "Choose Photo",
			},
		templates: {
			box: '<ul class="jFiler-items-list jFiler-items-grid"></ul>',
			item: '<li class="jFiler-item">\
						<div class="jFiler-item-container">\
							<div class="jFiler-item-inner">\
								<div class="jFiler-item-thumb">\
									<div class="jFiler-item-status"></div>\
										<div class="jFiler-item-info">\
											<span class="jFiler-item-title"><b title="{{fi-name}}">{{fi-name | limitTo: 23}}</b></span>\
											<span class="jFiler-item-others">{{fi-size2}}</span>\
										</div>\
										{{fi-image}}\
									</div>\
									<div class="jFiler-item-assets jFiler-row">\
										<ul class="list-inline pull-left">\
											<li>{{fi-progressBar}}</li>\
										</ul>\
										<ul class="list-inline pull-right">\
											<li><a class="icon-jfi-trash jFiler-item-trash-action"></a></li>\
										</ul>\
									</div>\
								</div>\
							</div>\
						</li>',
			itemAppend: '<li class="jFiler-item">\
							<div class="jFiler-item-container">\
								<div class="jFiler-item-inner">\
									<div class="jFiler-item-thumb">\
										<div class="jFiler-item-status"></div>\
										<div class="jFiler-item-info">\
											<span class="jFiler-item-title"><b title="{{fi-name}}">{{fi-name | limitTo: 23}}</b></span>\
											<span class="jFiler-item-others">{{fi-size2}}</span>\
										</div>\
										{{fi-image}}\
									</div>\
									<div class="jFiler-item-assets jFiler-row">\
										<ul class="list-inline pull-left">\
											<li><span class="jFiler-item-others">{{fi-icon}}</span></li>\
										</ul>\
										<ul class="list-inline pull-right">\
											<li><a class="icon-jfi-trash jFiler-item-trash-action"></a></li>\
										</ul>\
									</div>\
								</div>\
							</div>\
						</li>',
			progressBar: '<div class="bar"></div>',
			itemAppendToEnd: false,
			removeConfirmation: true,
			_selectors: {
					list: '.jFiler-items-list',
					item: '.jFiler-item',
					progressBar: '.bar',
					remove: '.jFiler-item-trash-action'
			}
		},
			
	});

	$('.add_more_room_photos').filer({
	    changeInput: '<div class="jFiler-input-dragDrop"><div class="jFiler-input-inner"><div class="jFiler-input-icon"><i class="icon-jfi-cloud-up-o"></i></div><div class="jFiler-input-text"><h3>' + lmhAjax.drag_n_drop_files_here + '</h3> <span style="display:inline-block; margin: 15px 0">' + lmhAjax.text_or + '</span></div><a class="jFiler-input-choose-btn blue">' + lmhAjax.browse_files + '</a></div></div>',
	    showThumbs: true,
	    extensions: ['png','jpg','jpeg','gif','bmp'],
	    theme: "dragdropbox",
	    templates: {
	        box: '<ul class="jFiler-items-list jFiler-items-grid"></ul>',
	        item: '<li class="jFiler-item">\
	                    <div class="jFiler-item-container">\
	                        <div class="jFiler-item-inner">\
	                            <div class="jFiler-item-thumb">\
	                                <div class="jFiler-item-status"></div>\
	                                <div class="jFiler-item-info">\
	                                    <span class="jFiler-item-title"><b title="{{fi-name}}">{{fi-name | limitTo: 25}}</b></span>\
	                                    <span class="jFiler-item-others">{{fi-size2}}</span>\
	                                </div>\
	                                {{fi-image}}\
	                            </div>\
	                            <div class="jFiler-item-assets jFiler-row">\
	                                <ul class="list-inline pull-left">\
	                                    <li>{{fi-progressBar}}</li>\
	                                </ul>\
	                                <ul class="list-inline pull-right">\
	                                    <li><a class="icon-jfi-trash jFiler-item-trash-action"></a></li>\
	                                </ul>\
	                            </div>\
	                        </div>\
	                    </div>\
	                </li>',
	        itemAppend: '<li class="jFiler-item">\
	                        <div class="jFiler-item-container">\
	                            <div class="jFiler-item-inner">\
	                                <div class="jFiler-item-thumb">\
	                                    <div class="jFiler-item-status"></div>\
	                                    <div class="jFiler-item-info">\
	                                        <span class="jFiler-item-title"><b title="{{fi-name}}">{{fi-name | limitTo: 25}}</b></span>\
	                                        <span class="jFiler-item-others">{{fi-size2}}</span>\
	                                    </div>\
	                                    {{fi-image}}\
	                                </div>\
	                                <div class="jFiler-item-assets jFiler-row">\
	                                    <ul class="list-inline pull-left">\
	                                        <li><span class="jFiler-item-others">{{fi-icon}}</span></li>\
	                                    </ul>\
	                                    <ul class="list-inline pull-right">\
	                                        <li><a class="icon-jfi-trash jFiler-item-trash-action"></a></li>\
	                                    </ul>\
	                                </div>\
	                            </div>\
	                        </div>\
	                    </li>',
	        progressBar: '<div class="bar"></div>',
	        itemAppendToEnd: false,
	        removeConfirmation: true,
	        _selectors: {
	            list: '.jFiler-items-list',
	            item: '.jFiler-item',
	            progressBar: '.bar',
	            remove: '.jFiler-item-trash-action'
	        }
	    },
	    dragDrop: {
	        dragEnter: null,
	        dragLeave: null,
	        drop: null,
	    },
	    uploadFile: {
	        url: lmhAjax.ajaxUrl,
	        data: {
	        	action: 'add_more_photos_room',
	        	post_id : lmhAjax.room_id
	        },
	        type: 'POST',
	        synchron: true,
	        enctype: 'multipart/form-data',
	        beforeSend: function(){
	        	jQuery('.image_upload_wrapper .jFiler-input-dragDrop').remove();
	        	jQuery('html, body').animate({
		            scrollTop: jQuery('.edit_room_photos').offset().top - 60
		        }, 'slow' );
		        jQuery('.confirm_sort').remove();
		        jQuery('.deleting_image_info').remove();
		        jQuery('.drag_photos_message').remove();
		        jQuery('.image_upload_wrapper .icon-jfi-trash').hide();
	        },
	        success: function(data, el){
	            var parent = el.find(".jFiler-jProgressBar").parent();
	            el.find(".jFiler-jProgressBar").fadeOut("slow", function(){
	                $("<div class=\"jFiler-item-others text-success\"><i class=\"icon-jfi-check-circle\"></i> Success</div>").hide().appendTo(parent).fadeIn("slow");    
	            });
	        },
	        error: function(el){
	            var parent = el.find(".jFiler-jProgressBar").parent();
	            el.find(".jFiler-jProgressBar").fadeOut("slow", function(){
	                $("<div class=\"jFiler-item-others text-error\"><i class=\"icon-jfi-minus-circle\"></i> Error</div>").hide().appendTo(parent).fadeIn("slow");    
	            });
	        },
	        statusCode: null,
	        onProgress: null,
	        onComplete: function(){
	        	location.reload();
	        },
	    },
	    onRemove: function( data , item_details ){

	    	if ( jQuery('.image_upload_wrapper .jFiler-items-grid > li').length == 2 ) {
	    		 jQuery('.image_upload_wrapper .icon-jfi-trash').hide();
	    	}

	    	var rand = Math.floor(Math.random()*9999999999)+1;

	    	jQuery.ajax({
	    		url : lmhAjax.ajaxUrl,
	    		type : 'post',
	    		dataType : 'json',
	    		data : {
	    			action : 'delete_room_photos',
	    			image_id : item_details.id,
	    			post_id : lmhAjax.room_id
	    		},
	    		beforeSend : function(){
	    			jQuery('<div class="alert alert-warning deleting_image_info deleting_image_info_' + rand + '">Deleting file <strong>' + item_details.name + '</strong></div>').insertAfter('.image_upload_wrapper .jFiler-input-dragDrop');
	    		},
	    		success : function( result ){

	    			//console.log( result );

	    			if( result.status == 'error' ){
	    				jQuery('.image_upload_wrapper .jFiler-input-dragDrop').remove();
	    				jQuery( '.deleting_image_info_' + rand ).html( result.message );
	    				jQuery('.drag_photos_message').remove();
	    				jQuery('html, body').animate({
				            scrollTop: jQuery( '.deleting_image_info_' + rand ).offset().top - 60
				        }, 'slow' );
	    				return;
	    			}

	    			jQuery( '.deleting_image_info_' + rand ).removeClass( 'alert-warning' ).addClass( 'alert-info' ).html( 'Successfully deleted file ' + item_details.name + '.' );
	    		}
	    	});
	    },
	    files : lmhAjax.edit_room_photos,
	});
	
});