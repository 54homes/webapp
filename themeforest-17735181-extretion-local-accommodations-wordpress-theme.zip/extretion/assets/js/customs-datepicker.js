jQuery(document).ready(function ($) {

	"use_strict";

	window.bookingAttributes = '';
	
	//disable typing in date picker input
	$('#dpd1,#dpd2,#dpdFlight1,#dpdFlight2,#start_date,#end_date,#arrival_date,#departure_date').keydown(function(e) {
		 e.preventDefault();
		 return false;
	});
	//disable typing in date picker input end

	window.min_booking_duration = parseInt( lmhAjax.min_booking_duration );

	var unAvailableDates = lmhAjax.booking_unavailable_dates;

	function unavailable(date) {
	    
	    dmy = ("0" + date.getDate()).slice(-2) + "-" + ("0" + (date.getMonth() + 1)).slice(-2) + "-" + date.getFullYear();
	    
	    // console.log( ("0" + date.getDate()).slice(-2) );
	    // console.log( ("0" + (date.getMonth() + 1)).slice(-2) );
	    // console.log( date.getFullYear() );
	    
	    if ($.inArray(dmy, unAvailableDates ) != -1) {
	        return false;
	    } else {
	        return true;
	    }
	}

	// On change guests call ajax function
	jQuery('#change-search-room').fancySelect().on('change.fs', function () {

		if( checkout.val() == '' || checkin.val() == '' ){
			return;
		}
		get_booing_prices();
	});

	//main date picker
	
	var checkin = $('#dpd1,#dpdFlight1').datepicker({
		format: 'dd-mm-yyyy',
		startDate: current_date(),
		todayHighlight: true,
		autoclose: true,
		orientation: 'bottom',
		//clearBtn: true,
		//setDate: lmhAjax.check_in_cookie,
		beforeShowDay: function(dt) { 
            return unavailable(dt);
        },        
	})
	.on('changeDate', function(e){	

		selStartDate = e.date;

		var nextDay = new Date(e.date);

		// Add min Bookign Durationto the chout out date
		nextDay.setDate(nextDay.getDate() + min_booking_duration );
		$('#dpd2,#dpdFlight2').datepicker('setStartDate', nextDay);

		var startDate = new Date( e.date );
		var endDate = new Date( toDate( jQuery('#dpd2').val() ) );

		if( checkout.val() == '' || checkout.val() == null){

			// If check out val null do not set date
			checkout.focus();

		} else if( startDate > endDate ){

			// If check in val greater than check out value then empty checkout value
			jQuery('#dpd2').val('');
			checkout.focus();

		} else {

			// Get the price
			get_booing_prices();

		}

		if (checkout.datepicker('getDate') == 'Invalid Date') {

			var newDate = new Date(e.date);

			// Add min Bookign Durationto the chout out date
			newDate.setDate( newDate.getDate() + min_booking_duration );
			checkout.datepicker( 'update', newDate );
			checkout.focus();	

		}

	});

	var checkout = $('#dpd2,#dpdFlight2').datepicker({
		format: 'dd-mm-yyyy',
		startDate: current_date(),
		autoclose: true,
		orientation: 'bottom',
		beforeShowDay: function(dt) { 
            return unavailable(dt);
        }
	})
	.on('changeDate', function(e){	
		get_booing_prices();				
	});	
	//main date picker end

	jQuery(document).on( 'click' , '.book_now_step_1' , function(){

		if( lmhAjax.check_logged_in_user == 0 && lmhAjax.paypal_disable_status == false ){
			jQuery('#loginModal').modal('show');
			return;
		}

		if( bookingAttributes != '' ){

			jQuery.ajax({

				url : lmhAjax.ajaxUrl,
				dataType : 'json',
				data : {
					action : 'booking_step_1',
					attributes : bookingAttributes
				},
				type : 'POST',
				beforeSend : function(){
					jQuery( '.booking_type_wrapper' ).text( lmhAjax.working );
					jQuery( '.book_now_step_1' ).prop( 'disabled' , true );

					// Disable checkin out and guest
					jQuery('#dpd1,#dpd2').attr( 'disabled' , true );
					jQuery('#change-search-room').nextAll('.options').hide();
				},
				success : function( data ){
					jQuery( '.booking_type_wrapper' ).text( lmhAjax.redirecting );
					
					if( data.redirect_to != '' ){
						window.location.href = data.redirect_to;
					} else {
						jQuery( '#book_now_modal' ).remove(); // Remove previous append modal if any
						jQuery( data.modal ).modal({
							'backdrop' : 'static',
							'show' : true
						});
						jQuery( '.booking_type_wrapper' ).text( lmhAjax.request_to_book );
						jQuery( '.book_now_step_1' ).prop( 'disabled' , false );

						// Disable checkin out and guest
						jQuery('#dpd1,#dpd2').attr( 'disabled' , false );
						jQuery('#change-search-room').nextAll('.options').show();
					}
					
				}

			});

		}

	});

	jQuery( '#dpd1,#dpd2' ).on( {
		focus: function() {
	      	minDateMsg();
	    },
	    keyup: function() {
			minDateMsg();
	    },
	});

	//$('#dpd1').datepicker( 'setDate', new Date(30, 12, 2016) );
	//$('#dpd1').datepicker( 'update' );

});

function minDateMsg(){
		
	setTimeout( function(){

		jQuery('.tr_min_date').remove();
		jQuery('.datepicker-days table tbody').append('<tr class="tr_min_date"><td colspan="7">' +
        	'<div class="min_date_message">' + 
        		'<div class="pull-left"><a onclick="clear_dates()" class="clear_dates" href="javascript:void(0)">Clear Dates</a></div>'+
        		'<div class="pull-right"><div>' + min_booking_duration + ' night minimum stay</div><div>' + lmhAjax.calendar_updated_at + '</div></div>'+
        	'</div>' + 
        	'</td></tr>' );

	}  , 1 );

}

function get_booing_prices(){

	jQuery.ajax({
		url : lmhAjax.ajaxUrl,
		dataType : 'json',
		data : {
			action : 'get_total_booking_price',
			check_in : jQuery('#dpd1').val(),
			check_out : jQuery('#dpd2').val(),
			guests : jQuery('#change-search-room').val(),
			post_id : lmhAjax.post_id
		},
		type : 'POST',
		beforeSend : function(){
			jQuery( '.content_price_sidebar' ).show();
			jQuery( '.preloader .loader' ).show();
			jQuery( '.booking_prices_details' ).empty();
			jQuery( '.error_booking_msg' ).hide();

			// Disable Submit Button
			jQuery('.book_now_step_1').attr( 'disabled' , true );

			// Disable checkin out and guest
			jQuery('#dpd1,#dpd2').attr( 'disabled' , true );
			jQuery('#change-search-room').nextAll('.options').hide();
		},
		success : function( data ){

			jQuery('.preloader .loader').hide();

			// Disable checkin out and guest
			jQuery('#dpd1,#dpd2').attr( 'disabled' , false );
			jQuery('#change-search-room').nextAll('.options').show();

			if( data.result == 'error' ){
				jQuery('.error_booking_msg p').text( data.message );
				jQuery('.error_booking_msg').show();
				return;
			}
			
			jQuery('.booking_prices_details').empty().html( data.message );

			// Enable Submit Button
			jQuery('.book_now_step_1').attr( 'disabled' , false );

			bookingAttributes = data.result;

			//console.log( bookingAttributes );
			
		}

	});

}

function clear_dates(){
	jQuery( '#dpd1,#dpd2' ).datepicker('update','');
}
function toDate(dateStr) {
    var parts = dateStr.split("-");
    return new Date(parts[2], parts[1] - 1, parts[0]);
}