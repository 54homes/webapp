(function(A) {

	if (!Array.prototype.forEach)
		A.forEach = A.forEach || function(action, that) {
			for (var i = 0, l = this.length; i < l; i++){
				if (i in this){
					action.call(that, this[i], i, this);
				}
			}
		};

})(Array.prototype);

var
mapObject,
markers = [],
markersData = {
	'result-map': ''
};

var mapOptions = {
	zoom: 13,
	center: new google.maps.LatLng( lmhAjax.lat , lmhAjax.lng ),
	mapTypeId: google.maps.MapTypeId.ROADMAP,

	mapTypeControl: false,
	mapTypeControlOptions: {
		style: google.maps.MapTypeControlStyle.DROPDOWN_MENU,
		position: google.maps.ControlPosition.LEFT_CENTER
	},
	panControl: false,
	panControlOptions: {
		position: google.maps.ControlPosition.TOP_RIGHT
	},
	zoomControl: true,
	zoomControlOptions: {
		style: google.maps.ZoomControlStyle.LARGE,
		position: google.maps.ControlPosition.TOP_RIGHT
	},
	scrollwheel: false,
	scaleControl: false,
	scaleControlOptions: {
		position: google.maps.ControlPosition.TOP_LEFT
	},
	//streetViewControl: true,
	// streetViewControlOptions: {
	// 	position: google.maps.ControlPosition.LEFT_TOP
	// },
	styles: [/*map styles*/]
};
var marker;
var checkevent = false;
		
mapObject = new google.maps.Map(document.getElementById('bali-map'), mapOptions);

 var options = {
    imagePath: lmhAjax.theme_path + '/images/markercluster/'
};
var markerCluster = new MarkerClusterer(mapObject , markers , options );

function get_the_google_map_content( markersData , mapObject , markers ){
	
	for (var key in markersData){
		markersData[key].forEach(function (item) {
			marker = new google.maps.Marker({
				position: new google.maps.LatLng(item.location_latitude, item.location_longitude),
				map: mapObject,
				icon: lmhAjax.theme_path + '/images/map-marker/' + key + '.png',
			});

			if ('undefined' === typeof markers[key]){
				markers[key] = [];
			}

			markers[key].push(marker);
			google.maps.event.addListener( marker, 'click', ( 
				function () {

	  					closeInfoBox();
	  					getInfoBox(item).open(mapObject, this);
	  					mapObject.setCenter(new google.maps.LatLng(item.location_latitude, item.location_longitude));

	  					jQuery('html, body').animate({
					        scrollTop: jQuery(".result-status").offset().top - 50
					    }, 'slow' );

					    checkevent = true;
						setTimeout('checkevent = false', 3000); 

	 				}
					)
				);
		});
	}

}	

function hideAllMarkers () {
	for (var key in markers)
		markers[key].forEach(function (marker) {
			marker.setMap(null);
		});
	markers = [];
};

function closeInfoBox() {
	jQuery('div.infoBox').remove();
};

function getInfoBox(item) {
	return new InfoBox({
		content:
		'<div class="infobox-hotel-item hotel-item-grid">' +
		'<a href="' + item.url_point + '">' +
		'<div class="image">' + '<img src="' + item.image_url + '" alt="Image"/>' + '</div>' +
		'<div class="heading">' + item.star_point + 
		'<h4>' + item.name_point + '</h4>' +
		'<p class="font400"> <i class="fa fa-map-marker text-primary"></i> ' + item.location_point + '</p>' +
		'</div>' +
		'<div class="content"> <div class="row gap-5"> ' +
		'<div class="col-xs-6 col-sm-6">' +
		'<div class="tripadvisor-module">'+
		'<div class="texting font700 line14" style="font-size: 15px; margin-bottom: 3px;">'+ item.tripadvisor_rating_point +
		'</div>'+
		'<div class="hover-underline">'+ item.review_count_point +
		' ' + item.review_text +' </div>'+
		'</div>' +
		'</div>' +
		'<div class="col-xs-6 col-sm-6">' +
		'<p class="price">' + item.price + '</p>' +
		'</div>' +
		'</div></div>' +
		'</a>' +
		'</div>',
		disableAutoPan: true,
		maxWidth: 0,
		pixelOffset: new google.maps.Size(-130, -385),
		closeBoxMargin: '5px -20px 2px 2px',
		closeBoxURL: "http://www.google.com/intl/en_us/mapfiles/close.gif",
		isHidden: false,
		pane: 'floatPane',
		enableEventPropagation: true
	});


};

jQuery(document).on( 'click' , '.redo_search_here' , function(){

	var sliderValue = get_slider_value();
	get_search_content( mapObject.getBounds() , sliderValue[0] , sliderValue[1] , get_selected_facilities() , get_selected_type_of_place() , get_selected_room_type() , get_selected_bedroom_filter() , get_selected_bathroom_filter() , get_selected_beds_filter());
	jQuery('.move_marker_option').show();
	jQuery('.redo_search_here').hide();
	
});

/* For WordPress */

var tilesload_once = 0;

// Get the content when bounds changes
google.maps.event.addListener( mapObject , 'bounds_changed', function() {

	setTimeout(function(){ 
		
		if( tilesload_once > 0 && checkevent == false && jQuery('.move_marker').is(':checked') ){
			var sliderValue = get_slider_value();
	        get_search_content( mapObject.getBounds() , sliderValue[0] , sliderValue[1] , get_selected_facilities() , get_selected_type_of_place() , get_selected_room_type() , get_selected_bedroom_filter() , get_selected_bathroom_filter() , get_selected_beds_filter());
		} else {

			if( tilesload_once > 0 ){
				jQuery('.move_marker_option').hide();
				jQuery('.redo_search_here').show();
			}

		}

	}, 100 );
	
	
});

// Load once when page loads
google.maps.event.addListener( mapObject , 'tilesloaded', function() {

    if( tilesload_once == 0 ){
    	var sliderValue = get_slider_value();
        get_search_content( mapObject.getBounds() , sliderValue[0] , sliderValue[1] , get_selected_facilities() , get_selected_type_of_place() , get_selected_room_type() , get_selected_bedroom_filter() , get_selected_bathroom_filter() , get_selected_beds_filter());
        tilesload_once++;
    }

}); 

function get_search_content( bounds , min_price , max_price , facility , type_of_place , room_type , bedrooms , bathrooms , beds ){

	jQuery.ajax({

        url : lmhAjax.ajaxUrl,
        type : 'POST',
        dataType : 'json',
        data : {
            action : 'map_room_search',
            ne_lat : bounds.getNorthEast().lat(),
            ne_lng : bounds.getNorthEast().lng(),
            sw_lat : bounds.getSouthWest().lat(),
            sw_lng : bounds.getSouthWest().lng(),
            guests : lmhAjax.guests,
			arrival_date : lmhAjax.check_in,
			departure_date : lmhAjax.check_out,
			min_price : isNumeric( min_price ) ? min_price : 0,
			max_price : isNumeric( max_price ) ? max_price : 0,
			facility : facility || null,
			type_of_place : type_of_place || null,
			room_type : isNumeric( room_type ) ? room_type : null,
			bedrooms : isNumeric( bedrooms ) ? bedrooms : null,
			bathrooms : isNumeric( bathrooms ) ? bathrooms : null,
			beds : isNumeric( beds ) ? beds : null,
			place_name : lmhAjax.place_name
        },
        beforeSend : function(){

        	closeInfoBox();
        	jQuery('#ballloader').modal({
				show : true,
				backdrop : 'static'
			});

        },
        success : function( result ){
        	
        	markersData = {
				'result-map': result.content
			};

			markerCluster.clearMarkers();
			hideAllMarkers();

			// publish all the marker to the map
			get_the_google_map_content( markersData , mapObject , markers );

			if( markers['result-map'] !== undefined ){
				markerCluster.addMarkers( markers['result-map'] );	
			}
			

			// Hide the loader
			jQuery('#ballloader').modal('hide');

			jQuery('.result-status p').html( result.message );

			jQuery('html, body').animate({
		        scrollTop: jQuery(".result-status").offset().top - 50
		    }, 'slow' );
        }

    });

}