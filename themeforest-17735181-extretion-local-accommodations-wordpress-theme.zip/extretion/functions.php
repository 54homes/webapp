<?php

/**
 * extretion functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package extretion
 */

if ( ! function_exists( 'extretion_setup' ) ) :

	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */

	function extretion_setup() {

		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on extretion, use a find and replace
		 * to change 'extretion' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'extretion', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'primary' => esc_html__( 'Primary', 'extretion' ),
			'dashboard' => esc_html__( 'Dashboard Menu', 'extretion' ),
		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 
			'html5', 
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
			) 
		);

		/*
		 * Enable support for Post Formats.
		 * See https://developer.wordpress.org/themes/functionality/post-formats/
		 */
		add_theme_support( 
			'post-formats', 
			array(
				'aside',
				'image',
				'video',
				'quote',
				'link',
			) 
		);

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 
				'extretion_custom_background_args', 
				array(
					'default-color' => 'ffffff',
					'default-image' => '',
				) 
			) 
		);

		// Set image sizes
		add_image_size( 'extretion_medium_large', '300', '300', array( "1", "") );
		add_image_size( 'extretion_blog-page', '900', '400', array( "1", "") );
		add_image_size( 'extretion_room_gallery_image', '1000', '667', array( "1", "") );
		add_image_size( 'extretion_room_gallery_image_thumb', '250', '167', array( "1", "") );
		add_image_size( 'extretion_booking_page_thumbnail', '600', '400', array( "1", "") );
		add_image_size( 'extretion_search_page_image', '500', '334', array( "1", "") );
		add_image_size( 'extretion_banner-homepage', '1660', '922', array( "1", "") ); 
	}

endif;

add_action( 'after_setup_theme', 'extretion_setup' );

/**
* All new functions after version 1.0 will be created on "additional-functions.php"
*/

require_once( get_template_directory() . '/wp-comment-walker.php' );
require_once( get_template_directory() . '/inc/functions/widgets/category.php' );
require_once( get_template_directory() . '/inc/functions/widgets/popular-posts.php' );
require_once( get_template_directory() . '/inc/functions/widgets/faq.php' );
require_once( get_template_directory() . '/inc/functions/widgets/search-form.php' );
require_once( get_template_directory() . '/inc/class-tgm-plugin-activation.php' );
require_once( get_template_directory() . '/inc/acf-fields.php' );
require_once( get_template_directory() . '/inc/update-notifier.php' );

require_once( get_template_directory() . '/inc/functions/additional-functions.php');
require_once( get_template_directory() . '/inc/kirki-fields.php');

require_once( get_template_directory() . '/inc/functions/notifications.php' );
require_once( get_template_directory() . '/inc/functions/message.php' );

require_once( get_template_directory() . '/inc/functions/stripe.php' );

add_action( 'tgmpa_register', 'extretion_require_plugins' );
 
function extretion_require_plugins() {
 
    $plugins =array(
	    array(
	        'name'      => esc_html__( 'Contact Form 7', 'extretion' ),
	        'slug'      => 'contact-form-7',
	        'required'  => true,
	    ),
	    array(
	        'name'      => esc_html__( 'Advanced Custom Fields', 'extretion' ),
	        'slug'      => 'advanced-custom-fields',
	        'required'  => true,
	    ),
	    array(
	        'name' => esc_html__( 'Data Types For Extretion', 'extretion' ),
	        'slug' => 'data-types-for-listmyhotel',
	        'source' => get_template_directory_uri() . '/plugins/data-types-for-listmyhotel.zip',
	        'required'           => true,
	        'force_activation'   => false,
	        'version'            => '1.5',
	    ),
	    array(
	        'name'      => esc_html__( 'Nav Menu Roles', 'extretion' ),
	        'slug'      => 'nav-menu-roles',
	        'required'  => true,
	    ),
	    array(
	        'name'      => esc_html__( 'Kirki', 'extretion' ),
	        'slug'      => 'kirki',
	        'required'  => true,
	    ),
	    array(
	        'name'      => esc_html__( 'Really Simple CAPTCHA', 'extretion' ),
	        'slug'      => 'really-simple-captcha',
	        'required'  => true,
	    ),
	    array(
	        'name'      => esc_html__( 'One Click Demo Import', 'extretion' ),
	        'slug'      => 'one-click-demo-import',
	        'required'  => true,
	    )
	);
    $config = array(
	    'id'           => 'extretion-tgmpa',
	    'capability'   => 'edit_theme_options',
	    'menu'         => 'extretion-required-plugins', // menu slug
	    'has_notices'  => true, // Show admin notices
	    'dismissable'  => false, // the notices are NOT dismissable
	    'dismiss_msg'  => '', // this message will be output at top of nag
	    'is_automatic' => true, // automatically activate plugins after installation
	    'message'      => '', // message to output right before the plugins table
	    'strings'      => array() // The array of message strings that TGM Plugin Activation uses
	);
 
    tgmpa( $plugins, $config );
 
}

/**
* Edit the comment form
*/
add_filter( 'comment_form_defaults', 'extretion_comment_form_defaults' );
add_filter( 'comment_form_default_fields', 'extretion_comment_form_default_fields' );
add_filter( 'cancel_comment_reply_link', 'extretion_cancel_comment_reply_link' , 10 , 3 );

function extretion_comment_form_defaults( $defaults ){

	$defaults['title_reply'] = '<span>' . esc_html__( 'Leave a Reply' , 'extretion' ) . '</span>';
	$defaults['comment_field'] = '<p class="comment-form-comment"><label for="comment">' . esc_html__( 'Comment', 'extretion' ) . '</label> <textarea id="comment" name="comment" cols="45" rows="8" maxlength="65525" aria-required="true" required="required" class="form-control"></textarea></p>';
	$defaults['submit_button'] = '<input name="%1$s" type="submit" id="%2$s" class="%3$s btn btn-primary" value="%4$s" />';
  	return $defaults;

}

function extretion_comment_form_default_fields( $fields ){

	$req      = get_option( 'require_name_email' );
	$commenter = wp_get_current_commenter();
	$aria_req = ( $req ? " aria-required='true'" : '' );

	$fields['author'] ='<p class="comment-form-author"><label for="author">' . esc_html__( 'Name', 'extretion' ) . '</label> ' . ( $req ? '<span class="text-danger">*</span>' : '' ) .
	'<input class="form-control" id="author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" size="30"' . $aria_req . ' /></p>';

	$fields['email']  = '<p class="comment-form-email"><label for="email">' . esc_html__( 'Email' , 'extretion' ) . ( $req ? ' <span class="text-danger">*</span>' : '' ) . '</label> ' . '<input class="form-control" id="email" name="email" ' . 'type="email"' . ' value="' . esc_attr(  $commenter['comment_author_email'] ) . '" size="30" maxlength="100" aria-describedby="email-notes"' . $aria_req  . ' /></p>';

	$fields['url'] = '<p class="comment-form-url"><label for="url">' . esc_html__( 'Website' , 'extretion' ) . '</label> ' . '<input class="form-control" id="url" name="url" ' . 'type="url"' . ' value="' . esc_attr( $commenter['comment_author_url'] ) . '" size="30" maxlength="200" /></p>';

	return $fields;

}

function extretion_cancel_comment_reply_link( $formatted_link, $link, $text ){

	$style = isset($_GET['replytocom']) ? '' : ' style="display:none;"';
	$formatted_link = '<a class="btn btn-warning" rel="nofollow" id="cancel-comment-reply-link" href="' . $link . '"' . $style . '>' . $text . '</a>';
	return $formatted_link;

}

/**
* Enqueue necessary Backend scripts
*/

add_action( 'admin_enqueue_scripts', 'extretion_wp_admin_style' );
function extretion_wp_admin_style(){

	if( !empty( $_GET['page'] ) && $_GET['page'] = 'extretion_email_settings' ){

		wp_enqueue_style( 'extretion_backend_email_style' , get_template_directory_uri().'/assets/css/customs-backend.css', false );

	}

	wp_enqueue_style( 'extretion_backend_style' , get_template_directory_uri().'/assets/css/admin_backend.css', false );

	wp_enqueue_script( 'extretion_backend_script', get_template_directory_uri() . '/assets/js/admin_backend.js', array(), '1.0.0', false );

}

/**
* Add Widgets
*/

add_action( 'widgets_init', 'extretion_widgets_init' );

function extretion_widgets_init() {

	register_sidebar( 

		array(
			'name'          => esc_html__( 'Main Sidebar', 'extretion' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'If no other sidebar assigned to the related category then this sidebar will be visible.', 'extretion' ),
			'before_widget' => '<div id="%1$s" class="sidebar-1 listmyhotel_widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title"><span>',
			'after_title'   => '</span></h3>',
		) 

	);

	register_sidebar( 

		array(
			'name'          => esc_html__( 'Blog Listing Sidebar', 'extretion' ),
			'id'            => 'blog_listing_sidebar',
			'description'   => esc_html__( 'This sidebar will be visible on the blog category page.', 'extretion' ),
			'before_widget' => '<div id="%1$s" class="blog_listing_sidebar section-title listmyhotel_widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title"><span>',
			'after_title'   => '</span></h3>',
		) 

	);

	register_sidebar( 

		array(
			'name'          => esc_html__( 'Blog Detail Sidebar', 'extretion' ),
			'id'            => 'blog_detail_sidebar',
			'description'   => esc_html__( 'This sidebar will be visible on the blog detail page.', 'extretion' ),
			'before_widget' => '<div id="%1$s" class="blog_detail_sidebar section-title listmyhotel_widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title"><span>',
			'after_title'   => '</span></h3>',
		) 

	);

	register_sidebar( 

		array(
			'name'          => esc_html__( 'Page Sidebar', 'extretion' ),
			'id'            => 'page_sidebar',
			'description'   => esc_html__( 'This sidebar will be visible on the pages.', 'extretion' ),
			'before_widget' => '<div id="%1$s" class="page_sidebar section-title listmyhotel_widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title"><span>',
			'after_title'   => '</span></h3>',
		) 

	);

	register_sidebar( 

		array(
			'name'          => esc_html__( 'Room Detail Sidebar', 'extretion' ),
			'id'            => 'room_detail_sidebar',
			'description'   => esc_html__( 'Note : This sidebar will be displayed only to the hotel owner if they are visiting their own room.', 'extretion' ),
			'before_widget' => '<div id="%1$s" class="page_sidebar section-title listmyhotel_widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title"><span>',
			'after_title'   => '</span></h3>',
		) 

	);

	register_sidebar( 

		array(
			'name'          => esc_html__( 'Footer 1', 'extretion' ),
			'id'            => 'footer_1',
			'description'   => esc_html__( 'This widget will be visible on the footer.', 'extretion' ),
			'before_widget' => '<div id="%1$s" class="footer_sidebar  %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4 class="footer-title ">',
			'after_title'   => '</h4>',
		) 

	);

	register_sidebar( 

		array(
			'name'          => esc_html__( 'Footer 2', 'extretion' ),
			'id'            => 'footer_2',
			'description'   => esc_html__( 'This widget will be visible on the footer.', 'extretion' ),
			'before_widget' => '<div id="%1$s" class="footer_sidebar  %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4 class="footer-title ">',
			'after_title'   => '</h4>',
		) 

	);

	register_sidebar( 

		array(
			'name'          => esc_html__( 'Footer 3', 'extretion' ),
			'id'            => 'footer_3',
			'description'   => esc_html__( 'This widget will be visible on the footer.', 'extretion' ),
			'before_widget' => '<div id="%1$s" class="footer_sidebar  %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4 class="footer-title ">',
			'after_title'   => '</h4>',
		) 

	);

	register_sidebar( 

		array(
			'name'          => esc_html__( 'Footer 4', 'extretion' ),
			'id'            => 'footer_4',
			'description'   => esc_html__( 'This widget will be visible on the footer.', 'extretion' ),
			'before_widget' => '<div id="%1$s" class="footer_sidebar  %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4 class="footer-title ">',
			'after_title'   => '</h4>',
		) 

	);

	register_sidebar( 

		array(
			'name'          => esc_html__( 'List My Room Sidebar', 'extretion' ),
			'id'            => 'list_my_room_sidebar',
			'description'   => esc_html__( 'This sidebar will be visible on the room registration page.', 'extretion' ),
			'before_widget' => '<div id="%1$s" class="listmyhotel_widget %2$s">',
			'after_widget'  => '</div><div class="mb-40"></div>',
			'before_title'  => '<div class="section-title-3"><h2>',
			'after_title'   => '</h2></div>',
		) 

	);

	register_sidebar( 

		array(
			'name'          => esc_html__( 'Room Category Sidebar', 'extretion' ),
			'id'            => 'room_cat_sidebar',
			'description'   => esc_html__( 'This sidebar will be visible on the room category page.', 'extretion' ),
			'before_widget' => '<div id="%1$s" class="%2$s listmyhotel_widget">',
			'after_widget'  => '</div><div class="mb-10"></div>',
			'before_title'  => '<h3 class="widget-title"><span>',
			'after_title'   => '</span></h3>',
		) 

	);

}

function extretion_blogDetailSidebar(){
	extretion_getSidebar( 'blog_detail_sidebar' );
}

function extretion_pageSidebar(){
	extretion_getSidebar( 'page_sidebar' );
}

function extretion_dashboard_sidebar(){
	extretion_profile_sidebar();
}

add_action( 'wp_ajax_get_current_user_details' , 'extretion_get_current_user_details' );
function extretion_get_current_user_details(){

	$content = '';

	if( $_POST['action'] == 'get_current_user_details' ){

		$user_id = get_current_user_id();

		ob_start(); ?>

		<div class="image">
			<?php echo get_avatar( $user_id ); ?>
		</div>
		
		<div class="content">
			<h4>
				<?php 
				$current_user_info = get_userdata( $user_id );
				$current_user_name = get_the_author_meta( 'first_name' , $user_id );
				echo ( $current_user_name ? $current_user_name : $current_user_info->user_login );
				?>	
			</h4>
			<p class="texting">
				<?php 
				$user_address =  get_the_author_meta( 'form_hotel_located_formatted_address' , $user_id );

				if( !empty( $user_address ) ){

					$user_address = explode( ',' , $user_address );
					echo esc_html( $user_address[0] );

				} ?>
			</p>
			
			<?php
			if( extretion_check_property_user( $user_id ) == true ){
				echo '<div class="label label-primary">'; esc_html_e( 'Property Owner' , 'extretion' ); echo '</div>';
			} 

			/**
			* Check if the user is traveller also
			*/

			$args = array(
				'post_type' => 'lmh_invoice',
				'post_status' => 'publish',
				'author' => $user_id,
				'posts_per_page' => 1,
				'meta_query' => array(
					array(
						'key'     => 'payment_status',
						'value'   => 'payment_successful',
						'compare' => '=',
					),
				),
			);

			$traveller_query = new WP_Query( $args ); 

			if( $traveller_query->have_posts() ){
				echo '<div class="label label-danger ml-5">' . esc_html__( 'Traveler', 'extretion' ) . '</div>';
			} ?>

		</div>

		<?php

		$content = ob_get_clean();

	}

	echo wp_json_encode( array( 'result' => $content ) );

	die;

}

function extretion_check_property_user( $user_id ){

	$args = array(
		'post_type' => 'room',
		'author' => $user_id,
		'posts_per_page' => 1,
	);

	$query = new WP_Query( $args );

	if( $query->have_posts() ):
		return true;
	else:
		return false;
	endif;

}

class LMH_Custom_Dashboard_Walker extends Walker_Nav_Menu {

	function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {

		$classes = empty( $item->classes ) ? array() : (array) $item->classes;
        $classes[] = 'menu-item-' . $item->ID;
        $class_names = join( ' ', apply_filters( 'extretion_nav_menu_css_class', array_filter( $classes ), $item, $args ) );

        if ( array_search( 'menu-item-has-children', $item->classes ) ) {

            $output .= sprintf( 
            	"<li class='%s'><a href='%s'> <span class='icon'><i class='fa %s'></i></span> %s</a>", 
            	( array_search( 'current-menu-item', $item->classes ) || array_search( 'current-page-parent', $item->classes ) ) ? 'active' : '', 
            	$item->url, 
            	( array_search( 'menu-item-has-children', $item->classes ) ? $class_names : '' ),
            	$item->title 
            );

        } else {

            $output .= sprintf( 
            	"<li %s><a href='%s'><span class='icon'><i class='fa %s'></i></span>%s</a>", 
            	( array_search( 'current-menu-item', $item->classes) ) ? ' class="active"' : '', 
            	$item->url, 
            	( array_search( 'menu-item-has-children', $item->classes ) ? '' : $class_names ),
            	$item->title 
            );

        }
    }

    function start_lvl( &$output, $depth = 0 , $args = array() ) {
        $indent = str_repeat( "\t", $depth );
        $output .= "\n$indent<ul>\n";
    }

}

function extretion_profile_sidebar(){ 

	$user_id = get_current_user_id(); 
	$user_info = get_userdata( $user_id );
	?>

	<aside class="sidebar-wrapper">
								
		<div class="dashboard-sidebar">
		
			<div class="dashboard-avatar">
			
				<div class="author_description_wrapper">

				</div>
				
				<ul class="meta clearfix">
					<li>
						<div>
							<?php esc_html_e( 'Member since:' , 'extretion' ); ?> 
							<span>
								<?php echo date( 'd M, Y' , strtotime( $user_info->user_registered ) ); ?>
							</span>
						</div>
					</li>
					<li>
						<div>
							<?php esc_html_e( 'Last login:' , 'extretion' ); ?> 
							<span>
								<?php echo extretion_get_last_login( $user_id ); ?>
							</span>
						</div>
					</li>
				</ul>
				
			</div>
			
			<div class="dashboard-menu-wrapper">
			
				<div class="navbar-vertical">
						
					<?php 

					wp_nav_menu(
						array(
							'items_wrap'=> '<ul class="navbar-vertical-menu dashboard-menu-list" id="responsive-menu-dashboard">%3$s</ul>', 
							'walker' => new LMH_Custom_Dashboard_Walker(), 
							'theme_location'=>'dashboard',
							'fallback_cb' => false
						)
					); ?>
				
				</div>
				
				<div class="relative">
					<div id="slicknav-mobile-dashboard"></div>
				</div>
				
			</div>
			
		</div>
		
	</aside>

	<?php
}

// Apply filter
add_filter( 'get_avatar' , 'extretion_custom_avatar' , 1 , 6 );

function extretion_custom_avatar( $avatar, $id_or_email, $size = null, $default = null, $alt = null , $args = null ) {
    $user = false;

    if ( is_numeric( $id_or_email ) ) {

        $id = (int) $id_or_email;
        $user = get_user_by( 'id' , $id );

    } elseif ( is_object( $id_or_email ) ) {

        if ( ! empty( $id_or_email->user_id ) ) {
            $id = (int) $id_or_email->user_id;
            $user = get_user_by( 'id' , $id );
        }

    } else {
        $user = get_user_by( 'email', $id_or_email );	
    }

    if ( $user && is_object( $user ) ) {

    	$profile_picture_id = get_user_meta( $user->ID , 'profile_picture' , true );

    	if( !empty( $profile_picture_id ) ){

	    	$image_src = wp_get_attachment_image_src( $profile_picture_id[0] , 'thumbnail' );

	    	if( $image_src ){
		        $avatar = "<img alt='{$alt}' src='{$image_src[0]}' class='avatar avatar-{$size} photo {$args['class']}' height='{$size}' width='{$size}' />";
		    }

		}

    }

    return $avatar;
}

function extretion_get_the_tags(){

	$posttags = get_the_tags();

	if ($posttags) {

		echo '<div class="tag-cloud-wrapper clearfix mb-40">
			<div class="tag-cloud-heading">' . esc_html__( 'Tags:' , 'extretion' ) . ' </div>
			<div class="tag-cloud tags clearfix">';

			foreach($posttags as $tag) {
			echo '<a href="' . get_tag_link( $tag->term_id ) . '">' . $tag->name . '</a>'; 
			}

			echo '</div>
		</div>';
	}

}

function extretion_blogDetailLayout(){

	$blog_listing_layout = get_option( 'options_blog_detail_layout' );

	if( $blog_listing_layout != 1 ){
		return ' left-sidebar';
	}
}

function extretion_fonts_url() {

    $fonts_url = '';
    $fonts     = array();
    $subsets   = '';

    /* translators: If there are characters in your language that are not supported by this font, translate this to 'off'. Do not translate into your own language. */
    if ( 'off' !== esc_html_x( 'on', 'PT Sans font: on or off', 'extretion' ) ) {
        $fonts[] = 'PT Sans:400,400italic,700,700italic';
    }

    /* translators: If there are characters in your language that are not supported by this font, translate this to 'off'. Do not translate into your own language. */
    if ( 'off' !== esc_html_x( 'on', 'Roboto font: on or off', 'extretion' ) ) {
        $fonts[] = 'Roboto:400,500,700,300,300italic,400italic,700italic';
    }

    /* translators: If there are characters in your language that are not supported by this font, translate this to 'off'. Do not translate into your own language. */
    if ( 'off' !== esc_html_x( 'on', 'Merriweather font: on or off', 'extretion' ) ) {
        $fonts[] = 'Merriweather:300italic,400italic';
    }

    if ( $fonts ) {
        $fonts_url = add_query_arg( array(
            'family' => urlencode( implode( '|', $fonts ) ),
            'subset' => urlencode( $subsets ),
        ), 'https://fonts.googleapis.com/css' );
    }

    return $fonts_url;
}

/**
* Enqueue necessary frontend scripts
*/

add_action( 'wp_enqueue_scripts', 'extretion_scripts' );

/**
* Enqueue scripts and styles.
*/

function extretion_scripts() {

	/**
	* Enqueue Styles
	*/

	/* CSS Plugins */

	wp_enqueue_style( 'extretion-style', get_stylesheet_uri() );
	wp_enqueue_style( 'extretion-normalize', get_template_directory_uri().'/assets/css/normalize.css', false , null );
	wp_enqueue_style( 'bootstrap' , get_template_directory_uri().'/assets/bootstrap/css/bootstrap.min.css', false , null );
	wp_enqueue_style( 'animate' , get_template_directory_uri().'/assets/css/animate.css', false, null );
	wp_enqueue_style( 'extretion_main' , get_template_directory_uri().'/assets/css/main.css', false, null );
	wp_enqueue_style( 'extretion_component' , get_template_directory_uri().'/assets/css/component.css', false, null );

	/* CSS Font Icons */

	wp_enqueue_style( 'open-iconic-bootstrap' , get_template_directory_uri().'/assets/icons/open-iconic/font/css/open-iconic-bootstrap.css', false, null );
	wp_enqueue_style( 'font-awesome' , get_template_directory_uri().'/assets/icons/font-awesome/css/font-awesome.min.css', false, null );
	wp_enqueue_style( 'pe-icon-7-stroke' , get_template_directory_uri().'/assets/icons/pe-icon-7-stroke/css/pe-icon-7-stroke.css', false, null );
	wp_enqueue_style( 'ionicons' , get_template_directory_uri().'/assets/icons/ionicons/css/ionicons.css', false, null );
	wp_enqueue_style( 'rivolicons' , get_template_directory_uri().'/assets/icons/rivolicons/style.css', false, null );
	wp_enqueue_style( 'flaticon-streamline-outline' , get_template_directory_uri().'/assets/icons/streamline-outline/flaticon-streamline-outline.css', false , null );
	wp_enqueue_style( 'around-the-world-icons' , get_template_directory_uri().'/assets/icons/around-the-world-icons/around-the-world-icons.css', false , null );
	wp_enqueue_style( 'extretion_et-line-font' , get_template_directory_uri().'/assets/icons/et-line-font/style.css', false , null );

	/* Google Fonts */

	wp_enqueue_style( 'extretion-fonts' , extretion_fonts_url() , array() , null );

	/* CSS Custom */
	wp_enqueue_style( 'extretion_main_style' , get_template_directory_uri().'/assets/css/style.css', false , rand() );
	wp_add_inline_style( 'extretion_main_style', extretion_add_theme_color() );

	/**
	* Enqueue Scripts
	*/

	/* HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries */
	/* if lt IE 9 */

	wp_enqueue_script( 'extretion_html5shiv', get_template_directory_uri() . '/assets/js/html5shiv.min.js' , array( 'jquery' ) , null );
	wp_script_add_data( 'extretion_html5shiv', 'conditional', 'lt IE 9' );

	wp_enqueue_script( 'extretion_respond' , get_template_directory_uri() . '/assets/js/respond.min.js' , array( 'jquery' ) , null );
	wp_script_add_data( 'extretion_respond', 'conditional', 'lt IE 9' );

	/* Bootstrap Js */
	wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/assets/bootstrap/js/bootstrap.min.js', array('jquery'), null , true );

	/* Plugins - serveral jquery plugins that use in this template */
	wp_enqueue_script( 'extretion_plugins', get_template_directory_uri() . '/assets/js/plugins.js', array('jquery'), null , false );

	/* Custom js codes for plugins */
	wp_register_script( 'extretion_custom_js', get_template_directory_uri() . '/assets/js/customs.js', array('jquery'), null , true );	

	// Localize the script with new data
	$translation_array = extretion_localizeScripts();
	wp_localize_script( 'extretion_custom_js', 'lmhAjax', $translation_array );

	// Enqueued script with localized data.
	wp_enqueue_script( 'extretion_custom_js' );

	/* Date Piacker */
	wp_enqueue_script( 'bootstrap-datepicker', get_template_directory_uri() . '/assets/js/bootstrap-datepicker.min.js', array('jquery'), null , true );
	wp_enqueue_script( 'extretion_customs-datepicker.min', get_template_directory_uri() . '/assets/js/customs-datepicker.js', array('jquery'), null , true );

	/* Jquery validation plugin */
	wp_enqueue_script( 'jquery-validation', get_template_directory_uri() . '/assets/js/jquery.validate.min.js', array('jquery'), null , true );

	// Google Map
	$google_map_key_default = 'AIzaSyBdVZzc9OkLOkR-t5dIt7mgnsg4vnrO1Pk';
	$db_google_api = get_option( 'options_lmh_google_map_api' , '' );
	$db_google_api = !empty( $db_google_api ) ? $db_google_api : $google_map_key_default;

	wp_enqueue_script( 'google-map', '//maps.google.com/maps/api/js?libraries=places&key=' . $db_google_api , array('jquery'), null , true );

	/* Map Icons Js */
	wp_enqueue_script( 'mapicon',get_template_directory_uri() . '/assets/js/mapicon.js', array('jquery'), null , true );

	/* Custom WordPress Custom Scripts */
	wp_enqueue_script( 'extretion_custom_front_js', get_template_directory_uri() . '/assets/js/custom-wordpress.js', array('jquery'), null , false );
	
	// Show success message on the modal
	wp_add_inline_script( 'extretion_custom_front_js', extretion_check_room_payment_status() );

	if( is_home() || is_front_page() || is_search() || is_page_template( 'page-templates/contact.php' ) || is_page_template( 'template-parts/dashboard-listyourroom.php' ) || is_singular( 'room' ) ){
		
		wp_enqueue_script( 'extretion_infobox_js', get_template_directory_uri() . '/assets/js/infobox.js', array('jquery'), null , true );

		if( !empty( $_GET['view'] ) && $_GET['view'] == 'map' ){
			wp_enqueue_script( 'extretion_custom_result_map', get_template_directory_uri() . '/assets/js/custom-result-map.js', array('jquery'), null , true );
		}

	}

	if( is_page_template( 'page-templates/booking-confirmation.php' ) ){
		wp_enqueue_script( 'extretion_stripe_js', 'https://js.stripe.com/v2/', array('jquery'), null , true );
	}

	// Add digit script
	if( is_page_template( 'page-templates/profile.php' ) ){
		wp_enqueue_script( 'extretion_digit_js', 'https://cdn.digits.com/1/sdk.js', array('jquery'), null , true );
	}

	if( is_singular( 'room' ) ){
		
		wp_enqueue_script( 'extretion_customs-detail-page_js', get_template_directory_uri() . '/assets/js/customs-detail-page.js', array('jquery'), null , true );
	}

	/**
	* Display on Contact template
	*/

	if( is_page_template( 'page-templates/contact.php' ) ){
		wp_enqueue_script( 'extretion_google_map_custom', get_template_directory_uri() . '/assets/js/customs-contact-map.js' , array('jquery'), null , true );
	}

	wp_enqueue_script( 'extretion_custom_filter', get_template_directory_uri() . '/assets/js/customs-filer.js' , array('jquery'), null , true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

}

function extretion_add_theme_color(){

	$primary_color = get_option( 'options_theme_colour' );
	$primary_color = !empty( $primary_color ) ? esc_html( $primary_color ) : '#005294';

	$secondary_color = get_option( 'options_secondary_theme_colour' );
	$secondary_color = !empty( $secondary_color ) ? esc_html( $secondary_color ) : '#D60D35';

	return $custom_css = "
			.slick-hero-slider-caption a:hover span{
				background: {$primary_color} !important;
    			border-color: {$primary_color} !important;
			}
			.label-primary{
				background-color : {$primary_color};
			}
			.dashboard-avatar .image{
				box-shadow: 0 0 5px 0 {$primary_color};
			}
			.edit_room_basic_details .heading.with-number > h3::after,.heading_style_1 > h4::after{
				background : {$primary_color};
			}

            .with-navbar-top-bottom .navbar-top{
                //background: {$primary_color} !important;
            }
            .colored-navbar-brand .navbar-default .navbar-brand::before{
            	//background: {$primary_color} !important;
            }
            .colored-navbar-brand .navbar-default .navbar-brand::after{
            	//background: {$primary_color} !important;
            }
            .colored-navbar-brand .navbar-default .navbar-brand{
            	//background: {$primary_color} !important;	
            }
            .with-navbar-top-bottom .navbar-top .navbar-mini > ul{
            	//border-left: 1px solid {$primary_color};	
            }
            .with-navbar-top-bottom .navbar-top .navbar-mini > ul > li{
            	//border-right: 1px solid {$primary_color};
            }
            .navbar-nav li ul{
            	border-color: {$primary_color} !important;
            }
            .btn-primary.btn-inverse {
			   // border-color: {$primary_color} !important;
			    //color: {$primary_color} !important;
			}
			.btn-primary.btn-inverse:hover{
				//background: {$primary_color};
			}
			.btn-primary {
			    background: {$primary_color};
			    border-color: {$primary_color};
			}
			.btn-primary:hover{
				background: {$primary_color};
			    border-color: {$primary_color};
			}
			.hotel-item-grid .content p.price .number{
				color: {$primary_color};
			}
			.text-primary {
			    color: {$primary_color} !important;
			}
			.bg-primary {
			    background: {$primary_color} !important;
			}
			.section-title-3 h2::after, .section-title-3 h3::after , h3.widget-title::after{
				background: {$primary_color};
			}
			.metro-box-wrapper > .heading.with-number .number{
				background: {$primary_color};	
			}
			.hotel-item-list .price .number{
				color: {$primary_color};	
			}
			.irs-bar{
				background: {$primary_color};	
			}
			.quick-search .btn{
				background: {$primary_color};	
			}
			ul.recent-post-sm li a:hover h3{
				color: {$primary_color};	
			}
			.font-icon-radio input[type='radio']:checked + label::before, .font-icon-checkbox input[type='checkbox']:checked + label::before{
				color: {$primary_color};
			}
			.btn-primary.focus, .btn-primary:focus {
			    background-color: {$primary_color};
			    border-color: {$primary_color};
			}
			.btn-primary.active.focus, .btn-primary.active:focus, .btn-primary.active:hover, .btn-primary.focus:active, .btn-primary:active:focus, .btn-primary:active:hover, .open > .dropdown-toggle.btn-primary.focus, .open > .dropdown-toggle.btn-primary:focus, .open > .dropdown-toggle.btn-primary:hover{
				background-color: {$primary_color};
			    border-color: {$primary_color};
			}
			.btn-primary.disabled, .btn-primary.disabled.active, .btn-primary.disabled.focus, .btn-primary.disabled:active, .btn-primary.disabled:focus, .btn-primary.disabled:hover, .btn-primary[disabled], .btn-primary.active[disabled], .btn-primary.focus[disabled], .btn-primary[disabled]:active, .btn-primary[disabled]:focus, .btn-primary[disabled]:hover, fieldset[disabled] .btn-primary, fieldset[disabled] .btn-primary.active, fieldset[disabled] .btn-primary.focus, fieldset[disabled] .btn-primary:active, fieldset[disabled] .btn-primary:focus, fieldset[disabled] .btn-primary:hover{
				 	background-color: {$primary_color};
    				border-color: {$primary_color};
			}
			.quick-search .btn:hover {
			    background: {$primary_color};
			}
			.tagcloud a:hover, .tag-cloud a:hover{
				background: {$primary_color};
			}
			.comment-item a.comment-reply{
				background: {$primary_color};	
			}
			ul.dashboard-menu-list li a:hover, ul.dashboard-menu-list > li:hover a{
				color: {$primary_color};
			}
			.dashboard-content .dashboard-heading h3::after{
				background: {$primary_color};
			}

			.widget_rss ul li .rsswidget{
				color : {$secondary_color};
			}
			.navbar-vertical ul.navbar-vertical-menu li ul::before{
				border-color: transparent {$secondary_color} transparent transparent;
			}
			.navbar-vertical ul.navbar-vertical-menu li ul {
				background: {$secondary_color};	
			}
			.blog-item-full .btn-read-more{
				border-bottom: 2px solid {$secondary_color};
			}
			.step-item.active .number .inner,.step-item.active .line{
				background: {$secondary_color};	
			}
			.navbar-nav > li.mega-menu:hover > a, .navbar-nav > li.mega-menu > a:hover, .navbar-nav > li.dropdown:hover > a, .navbar-nav > li.dropdown > a:hover, .navbar-nav > li.dropdown.active > a, .navbar-nav > li.dropdown.active > a:hover, .navbar-nav > li:hover > a, .navbar-nav > li.active > a{
				color : {$secondary_color} !important;
			}
			.featured-item-03 .icon{
				color : {$secondary_color};
			}
			.top-destination-item:hover{
				 border-bottom: 2px solid {$secondary_color};
			}
			.hotel-item-grid:hover{
				border-bottom: 2px solid {$secondary_color};
			}
			.slick-testimonial-wrapper .slick-center .image {
			    border: 1px solid {$secondary_color};
			}
			.recent-post:hover {
			    border-bottom: 2px solid {$secondary_color};
			}
			.label-danger{
				background-color : {$secondary_color};
			}
			a {
			    color: {$secondary_color};
			}
			.listmyhotel_widget a{
				color: {$secondary_color};	
			}
			.footer_1 a{
			    color: {$secondary_color} !important;
			}
			h4.footer-title::after{
				background: {$secondary_color} !important;	
			}
			.main-footer a:hover {
			    color: {$secondary_color};
			}
			ul#recentcomments li.recentcomments a,.widget_recent_entries ul > li a {
			    color: {$secondary_color};
			}
			.navbar-mini > ul > li > a:hover , .navbar-mini > ul > li > ul > li > a:hover{
			    color: {$secondary_color};
			}
			.navbar-mini .dropdown-menu > li > a:hover, .navbar-mini .dropdown-menu > li:hover > a, .navbar-mini .dropdown-menu > li > a:focus{
				color: {$secondary_color} !important;	
			}
			.featured-item-2 .icon{
				color: {$secondary_color};
			}
			.faq-accordion-wrapper .panel.accordion-item .panel-title a::after{
				background: {$secondary_color};
			}
			.faq-accordion-wrapper .accordion-heading .panel-title a:hover{
				color: {$secondary_color};
			}
			.btn-danger,.btn-danger:hover,.btn-danger:active,.btn-danger:focus{
				background: {$secondary_color};
    			border-color: {$secondary_color};
			}
			.featured-box a:hover{
				color: {$secondary_color};
			}
			.faq-category ul li.active a{
				color: {$secondary_color};	
			}
			#back-to-top a:hover {
			    background-color: {$secondary_color};
			    border-color: {$secondary_color};
			}
			.sort-wrapper > ul > li.active > a, .sort-wrapper > ul > li > a:hover{
				color: {$secondary_color};	
			}
			.search_view a, .search_view a:hover {
			    color: {$secondary_color} !important;
			}
			.result-paging-wrapper ul.paging li.active a, .result-paging-wrapper ul.paging li a:hover, .navigation_comment .current, .navigation_comment .current:hover,ul.paging_taxonomy li.active a{
				background: {$secondary_color};
			}
			.bg-warning{
				background: {$secondary_color} !important;
			}
			.hotel-item-list:hover {
			    border-bottom: 2px solid {$secondary_color};
			}
			.result-filter-wrapper h3 .icon{
				color: {$secondary_color};
				border: 1px solid {$secondary_color};
			}
			.result-filter-wrapper h3{
				border-bottom: 1px solid {$secondary_color};
			}
			.tripadvisor-module .texting{
				color: {$secondary_color};
			}
			.infobox-hotel-item:hover::after{
				border-top-color: {$secondary_color};
			}
			.result-status .back-to-list{
				background: {$secondary_color};
			}
			ul.multiple-sticky-nav > li a:hover {
			    color: {$secondary_color};
			}
			.round_circle{
				background: {$secondary_color};
			}
			ul.multiple-sticky-nav > li.active a{
				color:{$secondary_color};
			}
			.tab-style-01-wrapper ul.tab-nav li.active a{
				color:{$secondary_color};
				border-top: 2px solid {$secondary_color};
			}
			.tab-style-01-wrapper ul.tab-nav{
				border-bottom: 1px solid {$secondary_color};
			}
			.btn-danger.active.focus, .btn-danger.active:focus, .btn-danger.active:hover, .btn-danger.focus:active, .btn-danger:active:focus, .btn-danger:active:hover, .open > .dropdown-toggle.btn-danger.focus, .open > .dropdown-toggle.btn-danger:focus, .open > .dropdown-toggle.btn-danger:hover{
				background-color: {$secondary_color};
    			border-color: {$secondary_color};
			}
			.checkbox-block a{
				color:{$secondary_color};
			}
			.list-with-icon .text-danger{
				color:{$secondary_color} !important;	
			}";
}

function extretion_localizeScripts(){

	global $wp;
	global $post;
	$defaults = extretion_default_labels();
	$user_id = get_current_user_id();
	$password_strength = get_option( 'options_user_password_strength' );

	$translation_array = array(
		'contactMarker' => get_template_directory_uri() . '/images/map-marker.png',
		'contact_us_address' => is_object( $post ) ? get_post_meta( $post->ID, 'contact_address', true ) : '',
		'register_modal_rules' => extretion_registerModalRules(),
		'register_modal_message' => extretion_registerModalMessage(),
		'list_your_room_rules' => extretion_listYourRoomRules(),
		'list_your_room_message' => extretion_listYourRoomMessage(),
		'ajaxUrl' => admin_url( 'admin-ajax.php' ),
		'default_currency' => sanitize_text_field( get_option( 'options_base_currency' ) ),
		'commision_rate' => sanitize_text_field( get_option( 'options_commision_rate' ) ),
		'theme_path' => get_template_directory_uri(),
		'billingfield_rules' => extretion_billingfieldRules(),
		'check_logged_in_user' => get_current_user_id(),
		'max_upload_msg' => $defaults['other']['max_upload_msg'],
		'edit_profile_photo' => esc_html__( 'Browse & Upload Photo' , 'extretion' ),
		'edit_room_photos' => extretion_get_current_room_photos(),
		'room_id' => is_page_template( 'page-templates/room-edit.php' ) ? sanitize_text_field( $_GET['id'] ) : '',
		'guide_error_msg' => esc_html__( 'Upload Guide Photo' , 'extretion' ),
		'current_page_url' => $wp->request,
		'sticky_sidebar_room' => extretion_get_sticky_sidebar_room(),
		'no_of_photos_instagram' => extretion_no_of_photos_instagram(),
		'instagram_user_id' => extretion_instagram_user_id(),
		'instagram_access_token' => instagram_access_token(),
		'drag_n_drop_files_here' => esc_html__( 'Drag&Drop files here' , 'extretion' ),
		'text_or' => esc_html__( 'or' , 'extretion' ),
		'browse_files' => esc_html__( 'Browse Files' , 'extretion' ),
		'confirm_sort' => esc_html__( 'Confirm Sort' , 'extretion' ),
		'saving' => esc_html__( 'Saving ...' , 'extretion' ),
		'saved' => esc_html__( 'Saved' , 'extretion' ),
		'signing_in' => esc_html__( 'Signing in ...' , 'extretion' ),
		'sign_in' => esc_html__( 'Sign-in' , 'extretion' ),
		'submitting' => esc_html__( 'submitting ...' , 'extretion' ),
		'submit' => esc_html__( 'submit' , 'extretion' ),
		'working' => esc_html__( 'working ...' , 'extretion' ),
		'request_to_book' => esc_html__( 'Request to Book' , 'extretion' ),
		'redirecting' => esc_html__( 'working ...' , 'extretion' ),
		'processing' => esc_html__( 'Please wait while processing ....' , 'extretion' ),
		'check_in_cookie' => !empty( $_COOKIE['check_in_date'] ) ? date( 'm/d/Y' , strtotime( $_COOKIE['check_in_date'] ) ) : '',
		'check_out_cookie' => !empty( $_COOKIE['check_out_date'] ) ? date( 'm/d/Y' , strtotime( $_COOKIE['check_out_date'] ) ) : '',
		'paypal_disable_status' => get_option( 'options_booking_form' ),
		'send_message' => esc_html__( 'Send Message' , 'extretion' ),
		'post_id' => is_object( $post ) ? $post->ID : '',
		'password_strength' => $password_strength,
		'show_more' => esc_html__( 'Show more' , 'extretion' ),
		'show_less' => esc_html__( 'Show less' , 'extretion' ),
		'slider_autoplay_speed' => get_option( 'options_slider_autoplayspeed' , 4500 ),
		'slider_dots' => get_option( 'options_slider_dots' ),
		'slider_speed' => get_option( 'options_slider_slide_speed' , 500 ),
		'publishable_key' => extretion_get_publishable_key(),
	);

	$translation_array = apply_filters( 'extretion_localize_datas' , $translation_array );

	return $translation_array;

}

function instagram_access_token(){

	$instagram_access_token = get_option( 'options_instagram_access_token' );
	$instagram_access_token = empty( $instagram_access_token ) ? '' : esc_html( $instagram_access_token );
	return $instagram_access_token;

}

function extretion_instagram_user_id(){

	$instagram_user_id = get_option( 'options_user_id_instagram' );
	$instagram_user_id = empty( $instagram_user_id ) ? '' : esc_html( $instagram_user_id );
	return $instagram_user_id;

}

function extretion_no_of_photos_instagram(){

	$no_of_photos = get_option( 'options_no_of_photos_to_show_instagram' );
	$no_of_photos = ( ( empty( $no_of_photos ) || !ctype_digit( $no_of_photos ) ) ? 20 : esc_html( $no_of_photos ) );
	return $no_of_photos;

}

function extretion_get_sticky_sidebar_room(){

	$sticky = get_option( 'options_sticky_sidebar_room_detail' );

	if( empty( $sticky ) || $sticky == 1 ){
		return false;
	} else {
		return true;
	}

}

function extretion_get_image_details( $user_id = null , $key , $return = false , $meta = 'user' , $post_id = null ){

	$new_key = str_replace( array( '[' , ']' ), '', $key );
	$images_array = array();

	// Get profile picture
	if( $meta == 'user' ){
		$user_picture_id = get_user_meta( $user_id , $new_key , true );
	} else {
		$user_picture_id = get_post_meta( $post_id , $new_key , true );
	}

	//print_r(( $user_picture_id ));

	if( !empty( $user_picture_id ) && is_array( $user_picture_id ) ){

		foreach( $user_picture_id as $value  ){

			$avatar = wp_get_attachment_image_src( $value , 'medium' );

			if( !empty( $avatar ) && is_array( $avatar ) ){

				$data = array();
				$data['name'] = basename( $avatar[0] );
				$data['size'] = filesize( get_attached_file( $value ) );
				$data['type'] = get_post_mime_type( $value );
				$data['file'] = $avatar[0];
				$data['id'] = $value;
				//print_r(json_encode( $data , JSON_UNESCAPED_SLASHES )  ); die;
				$images_array[] = $data;

			}

		}

		//echo '<pre>'; print_r($images_array); echo '</pre>'; die;

		if( $return == false ){
			echo json_encode( $images_array );
		} else {
			return array_reverse( $images_array );
		}

	} else {

		if( $return == false ){
			echo json_encode( $images_array );
		} else {
			return $images_array;
		}

	}

}

function extretion_billingfieldRules(){

	global $wp_query;
	
	$post_id = get_query_var( 'post_id' );
	$secret = get_query_var( 'secret' );
	$data = null;
	$guests = array();

	$order_ids = get_post_meta( $post_id, 'order_ids', true );
	
	if( !empty($order_ids) ){

		foreach( $order_ids as $value ){

			if( $value['attributes']['secret_key'] == $secret ){
				$data = $value;
			}

		}

	}

	$args = array(
		'firstname' => array(
			'required' => true,
			'minlength' => 3
		),
		'lastname' => array(
			'required' => true,
			'minlength' => 3
		),
		'street_address' => array(
			'required' => true,
			'minlength' => 3
		),
		'postal_code' => array(
			'required' => true,
			'minlength' => 2
		),
		'city' => array(
			'required' => true,
			'minlength' => 2
		),
		'country' => array(
			'required' => true,
		),
		'phone' => array(
			'required' => true,
			'minlength' => 2
		),
	);

	$required_fields = get_option( 'options_guest_info_fields' );
	if( empty( $required_fields ) || $required_fields == 1 ){
		$required = true;
	} else {
		$required = false;
	}

	if( $data != null && $required_fields != 2 ){

		for ( $i=1; $i <= $data['attributes']['guests']; $i++) { 
			
			$args["guests_fname[". $i . "]"]['required'] = true;
			$args["guests_fname[". $i . "]"]['minlength'] = 2;

			$args["guests_lname[". $i . "]"]['required'] = true;
			$args["guests_lname[". $i . "]"]['minlength'] = 2;

		}

	}

	$args = apply_filters( 'extretion_billing_fields_rules' , $args );
	return $args;

}

add_filter( 'extretion_localize_datas' , 'extretion_profile_page' );
function extretion_profile_page( $data ){

	if( is_page_template( 'page-templates/profile.php' ) ){

		if( !empty( $_POST ) && is_user_logged_in() ){
			$data['new_avatar'] = true; 
		}

	}

	return $data;
}

add_filter( 'extretion_localize_datas' , 'extretion_booking_pages' );
function extretion_booking_pages( $data ){

	if( is_page_template( 'page-templates/booking-details.php' ) || is_page_template( 'page-templates/booking-request.php' ) || is_page_template( 'page-templates/booking-approval.php' ) || is_page_template( 'page-templates/booking-confirmation.php' ) ){

		$data['secret_key_booking'] = esc_html( get_query_var( 'secret', null ) );
		$data['booking_room_id'] = esc_html( get_query_var( 'post_id', null ) );

	}

	return $data;

}

add_filter( 'extretion_localize_datas' , 'extretion_room_edit_page' );
function extretion_room_edit_page( $data ){

	if( is_page_template( 'page-templates/room-edit.php' ) && !empty( $_GET['id'] ) && is_numeric( $_GET['id'] ) ){

		$post_id = $_GET['id'];
		$unavailable_dates = get_post_meta( $post_id , 'booking_unavailable_dates' , true );

		if( is_array( $unavailable_dates ) ){

			$data['unavailale_dates'] = $unavailable_dates;

		}

		$data['guide_page_location'] = extretion_get_google_default_location( $edit = true , false , 'form_place_located_location' , true );

	}

	return $data;

}

add_filter( 'extretion_localize_datas' , 'extretion_room_search_page' );
function extretion_room_search_page( $data ){

	if( is_search() ){

		$data['lat'] = !empty( $_GET['lat'] ) ? sanitize_text_field( $_GET['lat'] ) : '';
		$data['lng'] = !empty( $_GET['lng'] ) ? sanitize_text_field( $_GET['lng'] ) : '';
		$data['check_in'] = !empty( $_GET['arrival_date'] ) ? sanitize_text_field( $_GET['arrival_date'] ) : '';
		$data['check_out'] = !empty( $_GET['departure_date'] ) ? sanitize_text_field( $_GET['departure_date'] ) : '';
		$data['guests'] = !empty( $_GET['guests'] ) ? sanitize_text_field( $_GET['guests'] ) : 1;

		/* For price Filter */
		$data['currency'] =  extretion_get_default_currency_search();
		$data['min_price'] = extretion_get_min_price_search_filter();
		$data['max_price'] = extretion_get_max_price_search_filter();
		$data['view'] = !empty( $_GET['view'] ) ? sanitize_text_field( $_GET['view'] ) : '';
		$data['place_name'] = !empty( $_GET['place'] ) ? sanitize_text_field( $_GET['place'] ) : '';

	}

	return $data;

}

function extretion_get_prices_search_filter( $status ){

	$args = array(
		'post_type' => 'room',
		'post_status' => 'publish',
		'posts_per_page' => 1,
		'meta_query' => array(
			array(
				'key'     => 'lmh_search_price',
				'value'   => 0,
				'compare' => '>',
			),
		),
		'orderby' => 'meta_value_num',
		'order' => ($status == 'max' ? 'DESC' : 'ASC')
	);

	$price_query = new WP_Query( $args );

	if( $price_query->have_posts() ):

		while( $price_query->have_posts() ): $price_query->the_post();

			global $post;

			$price =  get_post_meta( $post->ID, 'lmh_search_price' , true );

			// For searching 
			if( $status == 'min' ){
				$price = $price - 300;
			} else {
				$price = $price + 300;	
			}			

			$exchange_price = extretion_exchange_currency( abs( $price ), 'NPR' , $currency_only = NULL , null , false );
			
			// Get only price ( Exclude currency )
			$price_per_night = preg_replace("/[^0-9\.]/", null, $exchange_price );
			
			return round( $price_per_night );

		endwhile;

	else:

		return 0;

	endif;

}

function extretion_get_max_price_search_filter(){

	return extretion_get_prices_search_filter( 'max' );

}

function extretion_get_min_price_search_filter(){

	return extretion_get_prices_search_filter( 'min' );
	
}

function extretion_get_default_currency_search(){

	$base_currency = !empty( $_COOKIE['currency'] ) ? sanitize_text_field( $_COOKIE['currency'] ) : sanitize_text_field( get_option( 'options_base_currency' ) );

	// Get Currency Symbol
	$currency_symbol = extretion_currency_symbol( $base_currency );

	return $currency_symbol;

}

add_filter( 'extretion_localize_datas' , 'extretion_detail_page_localize_data' );

function extretion_detail_page_localize_data( $data ){

	if( is_singular( 'room' ) ){

		global $wp_query;

		$post = $wp_query->post;
		$post_id = $post->ID;
		$data['hotel_latitude'] = get_post_meta( $post_id, 'form_place_located_lat', true );
		$data['hotel_longitude'] = get_post_meta( $post_id, 'form_place_located_lng', true );

		$min_booking = get_post_meta( $post_id, 'min_booking_duration', true );
		$min_booking = !empty( $min_booking ) ? $min_booking  : 1;

		$data['min_booking_duration'] = $min_booking;

		$data['booking_unavailable_dates'] = get_post_meta( $post_id , 'booking_unavailable_dates' , true );
		$data['post_id'] = $post_id;
		$data['calendar_updated_at'] = extretion_calendar_updated_at( $post_id );
		$data['guide_places'] = extretion_get_guide_places( $post_id );
		
	}

	if( is_page_template( 'page-templates/room-edit.php' ) ){

			$room_id = !empty( $_GET['id'] ) ? sanitize_text_field( $_GET['id'] ) : '';

			$data['guide_places'] = extretion_get_guide_places( $room_id );
	}

	return $data;

}

function extretion_get_guide_places( $post_id ){

	$user_id = get_current_user_id();
	$args = array(
		'post_type' => 'guide',
		'post_status' => 'publish',
		//'author' => $user_id,
		'posts_per_page' => -1,
		'meta_query' => array(
			array(
				'key'     => 'parent_post',
				'value'   => $post_id,
				'compare' => '=',
			),
		),
	);

	$query = new WP_Query( $args );
	$category = array();
	$count = 0;

	if( $query->have_posts() ):

		while( $query->have_posts() ): $query->the_post();

			global $post;

			$product_term = wp_get_object_terms( $post->ID,  'guide_cat' );
			$cat_name = $product_term[0]->slug;

			$guide_lat = get_post_meta( $post->ID , 'latitude' , true );
			$guide_lng = get_post_meta( $post->ID , 'longitude' , true );

			$title = explode( ',' , get_the_title( $post ) );

			$image_attributes = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ) , 'thumbnail' );

			$parent_post_id = get_post_meta( $post->ID , 'parent_post' , true );
			$hotel_lat = get_post_meta( $parent_post_id , 'form_place_located_lat' , true );
			$hotel_lng = get_post_meta( $parent_post_id , 'form_place_located_lng' , true );
			$guide_lat = get_post_meta( $post->ID , 'latitude' , true );
			$guide_lng = get_post_meta( $post->ID , 'longitude' , true );

			if( $image_attributes ){
				$image_url = $image_attributes[0];
			} else {
				$image_url = get_template_directory_uri() . '/images/no-image-square.jpg';
			}

			$category[$cat_name]['label'] = $product_term[0]->name;
			$category[$cat_name]['items'][] = "<div class='map-detail-info-window'>" . 
				"<div class='image'>" . 
					"<img src='" . $image_url . "' alt='image'>" . 
				"</div>".
				"<div class='content'>".
					"<h3>" . $title[0] . "</h3>".
					"<p class='infowindow_cat'>" . sprintf( esc_html__( 'Category : %s', 'extretion' ) , $product_term[0]->name ) . "</p>".
					"<p>" . extretion_distanceCalculator( $guide_lat , $guide_lng , $hotel_lat , $hotel_lng ,"M" ) . " metres far away</p>".
				"</div>".
			"</div>,$guide_lat,$guide_lng";

			$category[$cat_name]['icon'] = esc_html( get_option( 'guide_cat_' . $product_term[0]->term_id . '_icon' , 'map-icon-point-of-interest' ) );

			$category[$cat_name]['background_color'] = esc_html( get_option( 'guide_cat_' . $product_term[0]->term_id . '_background_color' , '#6331AE' ) );

		endwhile;

		wp_reset_postdata();

	endif;

	ksort($category);
	return $category;

	//echo '<pre>'; print_r($category); echo '</pre>';

	//die;

}

function extretion_distanceCalculator( $lat1, $lon1, $lat2, $lon2, $unit = null ) {

  	$theta = $lon1 - $lon2;
  	$dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
  	$dist = acos($dist);
  	$dist = rad2deg($dist);
  	$miles = $dist * 60 * 1.1515;
 	$unit = strtoupper($unit);

  	if ($unit == "K") { // Kilometers
      	return ($miles * 1.609344);
  	} else if ($unit == "N") { // Nautical Miles
      	return ($miles * 0.8684);
  	} elseif( $unit == "M" ){ // Meters
  		 return ceil($miles * 1609.344);
  	} else {
      	return $miles;
  	}
}



function extretion_calendar_updated_at( $post_id ){

	$calendar_updated_at = get_post_meta( $post_id, 'booking_dates_updated_at', true );
	return extretion_timeAgo( $calendar_updated_at );

}

function extretion_timeAgo($time_ago) {

	if( empty($time_ago) ){
		return '';
	}

    $time_ago = strtotime($time_ago);
    $cur_time   = time();
    $time_elapsed   = $cur_time - $time_ago;
    $seconds    = $time_elapsed ;
    $minutes    = round($time_elapsed / 60 );
    $hours      = round($time_elapsed / 3600);
    $days       = round($time_elapsed / 86400 );
    $weeks      = round($time_elapsed / 604800);
    $months     = round($time_elapsed / 2600640 );
    $years      = round($time_elapsed / 31207680 );
    // Seconds
    if($seconds <= 60){
        return esc_html__( "just now" , 'extretion' );
    }
    //Minutes
    else if( $minutes <= 60 ){
        if( $minutes == 1 ){
            return esc_html__( "one minute ago" , 'extretion' );
        }
        else{
            return sprintf( 
            	esc_html__( "%d minutes ago" , 'extretion' ) , $minutes
            );
        }
    }
    //Hours
    else if($hours <=24){
        if($hours==1){
            return esc_html__( "an hour ago" , 'extretion' );
        }else{
        	return sprintf( 
            	esc_html__( "%d hrs ago" , 'extretion' ) , $hours
            );
        }
    }
    //Days
    else if($days <= 7){
        if($days==1){
            return esc_html__( "yesterday" , 'extretion' );
        }else{
            return sprintf( 
            	esc_html__( "%d days ago" , 'extretion' ) , $days
            );
        }
    }
    //Weeks
    else if($weeks <= 4.3){
        if($weeks==1){
            return esc_html__( "a week ago" , 'extretion' );
        }else{
            return sprintf( 
            	esc_html__( "%d weeks ago" , 'extretion' ) , $weeks
            );
        }
    }
    //Months
    else if($months <=12){
        if($months==1){
            return esc_html__( "a month ago" , 'extretion' );
        }else{
            return sprintf( 
            	esc_html__( "%d months ago" , 'extretion' ) , $months
            );
        }
    }
    //Years
    else{
        if($years==1){
            return esc_html__( "one year ago" , 'extretion' );
        }else{
            return sprintf( 
            	esc_html__( "%d years ago" , 'extretion' ) , $years
            );
        }
    }
}

// Check Valid Date
function extretion_checkIsAValidDate($myDateString){
    return (bool)strtotime($myDateString);
}

add_action( 'wp_ajax_get_total_booking_price' , 'extretion_get_total_booking_price' );
add_action( 'wp_ajax_nopriv_get_total_booking_price' , 'extretion_get_total_booking_price' );
function extretion_get_total_booking_price(){

	if( empty( $_POST ) || $_POST['action'] != 'get_total_booking_price' ){
		die;
	}

	$data = array();
	$post_id = !empty( $_POST['post_id'] ) ? sanitize_text_field( $_POST['post_id'] ) : '';

	$check_in = !empty( $_POST['check_in'] ) ? sanitize_text_field( $_POST['check_in'] ) : '';
	$check_out = !empty( $_POST['check_out'] ) ? sanitize_text_field( $_POST['check_out'] ) : '';

	$guests = !empty( $_POST['guests'] ) ? sanitize_text_field( $_POST['guests'] ) : '';
	$guests_accomodate = get_post_meta( $post_id, 'guest_accomodate', true );

	$min_booking = get_post_meta( $post_id, 'min_booking_duration', true );

	// Get all dates bet start and between
	$user_dates_range = extretion_date_range( $check_in , $check_out );

	//print_r($user_dates_range );

	// Change date to seconds
	$check_in_str = strtotime( $check_in );
	$check_out_str = strtotime( $check_out );

	//print_r($user_dates_range);

	if( empty( $check_in ) || extretion_checkIsAValidDate($check_in) == false ){

		$data['result'] = 'error';
		$data['message'] = esc_html__( 'Please add check in date.' , 'extretion' );
		echo json_encode($data);
		die;

	} elseif( empty( $check_out ) || extretion_checkIsAValidDate($check_out) == false ){

		$data['result'] = 'error';
		$data['message'] = esc_html__( 'Please add check out date.' , 'extretion' );
		echo json_encode($data);
		die;

	} elseif( ( count( $user_dates_range ) - 1 ) < $min_booking ){

		// User min date should be greater or equal to the database min date
		$data['result'] = 'error';
		$data['message'] = sprintf(
			esc_attr__( 'Your booking should be minimum %d days.' , 'extretion' ),
			$min_booking
		);
		echo json_encode($data);
		die;


	} elseif( empty( $guests ) || !is_numeric( $guests ) || !ctype_digit( $guests ) || $guests > $guests_accomodate  ){

		$data['result'] = 'error';
		$data['message'] = esc_html__( 'Please select no of guests.' , 'extretion' );
		echo json_encode($data);
		die;

	} elseif( extretion_check_unavailable_dates( $user_dates_range , $post_id ) == false ){

		$data['result'] = 'error';
		$data['message'] = esc_html__( 'Please select only available dates.' , 'extretion' );
		echo json_encode($data);
		die;

	} elseif( $check_in_str > $check_out_str ){

		$data['result'] = 'error';
		$data['message'] = esc_html__( 'Check out date must be greater than check in date.' , 'extretion' );
		echo json_encode($data);
		die;

	} else {

		// Set Cookies
		extretion_set_cookie( $guests , $check_in , $check_out );

		$no_of_nights = count( $user_dates_range ) - 1;

		// User price per night
		$price_per_night = get_post_meta( $post_id , 'per_night_price' , true );

		// User Currency
		$user_currency = get_post_meta( $post_id, 'user_currency', true );

		$price_per_night = extretion_exchange_currency( $price_per_night, $user_currency , $currency_only = NULL );

		// Get Currency
		$extract_currency = preg_replace("/[0-9\s.]/", null, $price_per_night );

		// Get only price ( Exclude currency )
		$price_per_night = preg_replace("/[^0-9\.]/", null, $price_per_night );

		/**
		* Check extra person price
		* If "yes" add extra person price to "$price_per_night"
		*/
		$price_per_night = check_extra_person_price( $price_per_night , $post_id , $guests );

		// Add price * no of nights
		$price_calulating_nights = $price_per_night * $no_of_nights;

		$price_after_commission = $price_calulating_nights; //lmh_price_after_commission( $price_calulating_nights );
		
		if( $no_of_nights >= 7 && $no_of_nights < 30 ){

			/*
			** Give Discount for weekly bookings
			*/

			$price_after_discount = extretion_give_weekly_discount( $price_after_commission , $post_id );
			$discount_type = esc_html__( 'weekly price discount' , 'extretion' );

		} elseif( $no_of_nights >= 30 ){

			/*
			** Give Discount for monthly bookings
			*/

			$price_after_discount = extretion_give_monthly_discount( $price_after_commission , $post_id );
			$discount_type = esc_html__( 'monthly price discount' , 'extretion' );

		} else {

			/*
			** No discount
			*/

			$price_after_discount = array( 
				'price_after_discount' => $price_after_commission,
				'discount' => 0 
			);
			$discount_type = null;
		}

		// Add service fee
		$service_fee = get_post_meta( $post_id, 'cleaning_fee', true );
		$total_service_fee = $service_fee * $no_of_nights;
		$total_service_fee = extretion_exchange_currency( $total_service_fee, $user_currency , $currency_only = NULL );

		// Get only price ( Exclude currency )
		$total_service_fee = preg_replace("/[^0-9\.]/", null, $total_service_fee );	

		// Get Security Deposit
		$security_deposit = get_post_meta( $post_id, 'security_deposit', true );
		$security_deposit_after_conversion = extretion_exchange_currency( $security_deposit, $user_currency, $currency_only = null, null, false );	

		// Get only price ( Exclude currency )
		$security_deposit_after_conversion = preg_replace("/[^0-9\.]/", null, $security_deposit_after_conversion );	

		$security_deposit_filter = !empty( $security_deposit_after_conversion ) ? $security_deposit_after_conversion : 0;

		// Calculate total price
		$total_price = $price_after_discount['price_after_discount'] + $total_service_fee;

		$result = array();
		$result['price_per_night'] = round( $price_per_night );
		$result['no_of_nights'] = $no_of_nights;
		$result['price_calulating_nights'] = round( $price_calulating_nights );
		$result['price_after_commission'] = round( $price_after_commission );
		$result['discount_type'] = $discount_type;
		$result['price_after_discount'] = round( $price_after_discount['price_after_discount'] );
		$result['discounted_price'] = round( $price_after_discount['discount'] );
		$result['discount_percentage'] = !empty( $price_after_discount['discount_percentage'] ) ? round( $price_after_discount['discount_percentage'] ) : '';
		$result['total_service_fee'] = round( $total_service_fee );
		$result['total_price'] = round( $total_price );
		$result['currency'] = $extract_currency;
		$result['post_id'] = $post_id;
		$result['check_in'] = $check_in;
		$result['check_out'] = $check_out;
		$result['guests'] = $guests;
		$result['security_deposit'] = $security_deposit_filter;

		//print_r( $result );

		$data = array();
		$data['message'] = extretion_get_html_price_booking( $result );
		$data['result'] = $result;
		echo json_encode( $data );

	}

	//print_r( $_POST );
	die;

}

function check_extra_person_price( $price_per_night , $post_id , $guests ){

	$charge_extra_people = get_post_meta( $post_id, 'charge_extra_people', true );

	// If extra charge is not defined return the original price
	if( $charge_extra_people != 'yes' ){
		return $price_per_night;
	}

	// Create new price
	$new_price = $price_per_night * $guests;
	return $new_price;

}

function extretion_custom_breadcrumbs(){ 

	$defaults = extretion_default_labels(); ?>

	<div class="breadcrumb-wrapper">
					
		<div class="container">

			<div class="row">
			
				<div class="col-xs-12 col-sm-8">
					<ol class="breadcrumb">
						<?php 
						listmyhotel_custom_breadcrumbs(); ?>
					</ol>
				</div>
				
				<?php 
				$hotline = get_option( 'options_hot_line' );

				if( !empty( $hotline ) ){ ?>

					<div class="col-xs-12 col-sm-4 hidden-xs">
						<p class="hot-line"> 
							<i class="fa fa-phone"></i> 
							<?php 
							echo esc_html( $defaults['homepage']['hotline'] ) . ' ';
							echo '<span class="hot_line_inner">' . esc_html( $hotline ) . '</span>'; 
							?>
						</p>
					</div>

					<?php 

				} ?>
				
			</div>

		</div>

	</div>
	
	<?php
}

function extretion_send_booking_email(){ 

	/**
	* Insert Order ID to the post meta
	*/

	ob_start();
	extretion_save_booking_request_step_1();
	$order_details = json_decode( ob_get_clean() );
	$fragments = explode('/', $order_details->redirect_to);

	$secret_code = end( $fragments );
	$post_id = prev( $fragments );

	$order_id = extretion_get_order_id( $post_id , $secret_code );
	$price_details = extretion_get_html_price_booking($order_id);

	/**
	* Get Modal Form
	*/

	ob_start(); 

	//echo '<pre>'; print_r($order_id); echo '</pre>'; ?>

	<div class="modal fade modal-login modal-border-transparent" id="book_now_modal" tabindex="-1" role="dialog" aria-hidden="true" >
		<div class="modal-dialog">
			<div class="modal-content">
				
				<button type="button" class="btn btn-close close" data-dismiss="modal" aria-label="Close">
					<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
				</button>
				
				<div class="clear"></div>
				
				<!-- Begin # DIV Form -->
				<div id="modal-login-form-wrapper">
					
					<!-- Begin # Login Form -->
					<form id="book_email_form">
					
						<div class="modal-body pb-10">
					
							<h4 class="text-center mb-15"><?php esc_html_e( 'Booking Form' , 'extretion' ); ?></h4>

							<!-- Error Message Display -->
							<ul class="login_modal_error email_booking_error"></ul>

							<!-- Success Message -->
							<div class="alert alert-success email_booking_success" style="display:none;"></div>

							<h5 class="modal_booking_form"><?php esc_html_e( 'Billing Information', 'extretion' ); ?></h5>

							<div class="form-group mb-0"> 
								<input id="booking_first_name" class="form-control mb-5" placeholder="<?php esc_html_e( 'First Name *' , 'extretion' ); ?>" type="text" name="booking_first_name" autocomplete="off"> 
							</div>

							<div class="form-group mb-0"> 
								<input id="booking_last_name" class="form-control mb-5" placeholder="<?php esc_html_e( 'Last Name *' , 'extretion' ); ?>" type="text" name="booking_last_name" autocomplete="off"> 
							</div>

							<div class="form-group mb-0"> 
								<input id="booking_email" class="form-control mb-5" placeholder="<?php esc_html_e( 'Email *' , 'extretion' ); ?>" type="text" name="booking_email" autocomplete="off"> 
							</div>

							<div class="form-group mb-0"> 
								<input id="booking_address" class="form-control mb-5" placeholder="<?php esc_html_e( 'Address' , 'extretion' ); ?>" type="text" name="booking_address" autocomplete="off"> 
							</div>

							<div class="form-group mb-0"> 
								<input id="booking_phone" class="form-control mb-5" placeholder="<?php esc_html_e( 'Phone *' , 'extretion' ); ?>" type="text" name="booking_phone" autocomplete="off"> 
							</div>

							<div class="form-group mb-0"> 
								<textarea rows="5" id="booking_additional_note" autocomplete="off" class="form-control mb-5" placeholder="<?php esc_html_e( 'Additional Note' , 'extretion' ); ?>" name="booking_additional_note" style="height: 60px"></textarea>
							</div>

							<div class="form-group mb-0"> 
								<input id="booking_guests" class="form-control mb-5" value="<?php echo _n( ($order_id['guests']) . ' ' . esc_html__( 'guest', 'extretion' ), ($order_id['guests'] ) . ' ' . esc_html__( 'guests', 'extretion' ), $order_id['guests'], 'extretion' ); ?>" type="text" disabled> 
							</div>

							<input type="hidden" value="<?php echo $post_id; ?>" name="room_id">
							<input type="hidden" name="secret_code" value="<?php echo $secret_code; ?>">

							<h5 class="modal_booking_form"><?php esc_html_e( 'Price Information', 'extretion' ); ?></h5>

							<div class="modal_price_details mt-20">
								<?php echo $price_details; ?>
							</div>
						
						</div>
						
						<div class="modal-footer pt-20 pb-5">
						
							<div class="row gap-10">

								<div class="col-sm-12 mb-10">
									<a class="btn btn-primary btn-block book_by_email">
										<?php esc_html_e( 'Book by email and we will contact you back' , 'extretion' ); ?>	
									</a>
								</div>

							</div>
							
						</div>

					</form>	
								
				</div>
								
			</div>
		</div>
	</div>

	<?php

	$content = ob_get_clean();

	echo json_encode(
		array(
			'modal' => $content,
			'redirect_to' => ''
		)
	);
}

function extretion_save_booking_request_step_1(){

	$post_id = sanitize_text_field( $_POST['attributes']['post_id'] );

	$order_ids = get_post_meta( $post_id, 'order_ids' , true );

	$user_id = get_current_user_id();

	$data = array();
	$data['attributes'] = array_map( 'sanitize_text_field', $_POST['attributes'] );
	$secret = $data['attributes']['secret_key'] = wp_generate_password( $length = 30 , false, false );
	$data['attributes']['updated_at'] = date( 'Y-m-d H:i:s' );
	$data['attributes']['booking_request_by'] = $user_id;

	if( empty( $order_ids ) ){

		update_post_meta( $post_id , 'order_ids' , array( $data ) );

	} else {

		array_push( $order_ids , $data );
		update_post_meta( $post_id , 'order_ids' , $order_ids );

	}

	$redirect_to = get_permalink( get_option( 'options_select_booking_detail_page' ) );
	$redirect_to = $redirect_to ? ( $redirect_to . $post_id . '/' . $secret ) : '';

	$result = array();
	$result['redirect_to'] = $redirect_to;
	echo json_encode( $result );

}

add_action( 'wp_ajax_booking_step_1' , 'extretion_booking_step_1' );

// If Paypal is disabled and form is enable
if( get_option( 'options_booking_form' ) == true ){
	add_action( 'wp_ajax_nopriv_booking_step_1' , 'extretion_booking_step_1' );
}

function extretion_booking_step_1(){

	if( $_POST['action'] == 'booking_step_1' ){

		/**
		* If paypal is disabled then sent request by email
		* If $disable_paypal == true, sent booking email
		*/

		$paypal_disable = get_option( 'options_booking_form' );
		$paypal_disable = apply_filters( 'extretion_paypal_disable', $paypal_disable );

		if( $paypal_disable == true ){
			extretion_send_booking_email();
		} else {
			extretion_save_booking_request_step_1();
		}

	}

	die;

}

function extretion_get_my_trips_link(){

	$redirect_to = get_permalink( get_option( 'options_select_my_trips_page' ) );

	if( !empty( $redirect_to ) ){
		return $redirect_to;
	} else {
		return esc_url( site_url() );
	}

}

function extretion_get_reservation_link(){

	$redirect_to = get_permalink( get_option( 'options_select_reservation_page' ) );

	if( !empty( $redirect_to ) ){
		return $redirect_to;
	} else {
		return esc_url( site_url() );
	}

}

function extretion_get_edit_room_link(){

	$redirect_to = get_permalink( get_option( 'options_select_edit_room_page' ) );

	if( !empty( $redirect_to ) ){
		return $redirect_to;
	} else {
		return '#';
	}

}

function extretion_get_html_price_booking( $results ){

	$data = '';
	$currency_symbol = extretion_currency_symbol( $results['currency'] );

	$post = get_post( $results['post_id'] );
	
	$post_author = $post->post_author;
	$post_user = get_the_author_meta( 'user_login' , $post_author );

	ob_start(); ?>

	<!-- Price * nights -->
	<div class="price-subtotal price-subtotal-new mb-10 booking_html">
		<p class="pull-left">
			<?php 
			echo '<span class="currency_symbol">' . esc_attr( $currency_symbol )  . '</span> ';
			echo esc_attr( number_format( $results['price_per_night'] ) );
			echo ' x ';
			echo esc_attr( $results['no_of_nights'] ) . esc_attr__( ' nights' , 'extretion' );
			?>
		</p>
		<p class="pull-right">
			<?php echo '<span class="currency_symbol">' . esc_attr( $currency_symbol ) . '</span> ' . esc_attr( number_format( $results['price_after_commission'] ) ); ?>
		</p>
	</div>

	<?php

	if( $results['discounted_price'] > 0 ){ ?>

		<div class="price-subtotal price-subtotal-new mb-10 booking_html">
			<p class="pull-left">
				<?php 
				echo esc_attr( $results['discount_percentage'] );
				echo '% ';
				echo esc_attr( $results['discount_type'] );
				?>
				<span class="price-guarantee text-center hoover-help mb-0" data-toggle="tooltip" data-placement="top" title="<?php printf( esc_html__( '%s&#39;s place has weekly discounts for stays longer than 7 days.' , 'extretion' ) , $post_user ); ?>"><i class="fa  fa-question-circle text-success"></i></span>
			</p>
			<p class="pull-right discounted_price">
				<?php echo '- <span class="currency_symbol">'. esc_attr( $currency_symbol ) . '</span> '. esc_attr( number_format( $results['discounted_price'] ) ); ?>
			</p>
		</div>

		<?php
	}

	if( $results['total_service_fee'] > 0 ){ ?>

		<div class="price-subtotal price-subtotal-new mb-10 booking_html">
			<p class="pull-left">
				<?php 
				esc_html_e( 'Service Fee' , 'extretion' );
				?>
				<span class="price-guarantee text-center hoover-help mb-0" data-toggle="tooltip" data-placement="top" title="<?php esc_html_e( 'This help us run our platform and offer services like 24/7 support on your trip.' , 'extretion' );?>">
					<i class="fa fa-question-circle text-success"></i>
				</span>
			</p>
			<p class="pull-right">
				<?php echo '<span class="currency_symbol">' . esc_attr( $currency_symbol ) . '</span> '. esc_attr( number_format( $results['total_service_fee'] ) ); ?>
			</p>
		</div>

		<?php
	} ?>

	<div class="price-subtotal price-subtotal-new mb-10 booking_html grand_total">
		<p class="pull-left">
			<?php 
			esc_html_e( 'Total ' , 'extretion' );
			?>
		</p>
		<p class="pull-right">
			<?php echo '<span class="currency_symbol">' . esc_attr( $currency_symbol ) . '</span> '. esc_attr( number_format( $results['total_price'] ) ); ?>
		</p>
	</div>

	<?php

	if( !empty( $results['security_deposit'] ) && $results['security_deposit'] > 0 ){ ?>

		<div class="price-subtotal price-subtotal-new mb-10 booking_html">
			<p class="pull-left">
				<?php 
				esc_html_e( 'Security Deposit' , 'extretion' );
				?>
				<span class="price-guarantee text-center hoover-help mb-0" data-toggle="tooltip" data-placement="top" title="<?php esc_html_e( 'Security deposit is refundable.' , 'extretion' );?>">
					<i class="fa fa-question-circle text-success"></i>
				</span>
			</p>
			<p class="pull-right">
				<?php echo '<span class="currency_symbol">' . esc_attr( $currency_symbol ) . '</span> '. esc_attr( number_format( $results['security_deposit'] ) ); ?>
			</p>
		</div>

		<div class="price-subtotal price-subtotal-new mb-10 booking_html booking_message_abt_payment">
			<?php 
			printf( 
				esc_html__( 'Note : At booking you will have to pay security deposit + %d&#37; of the total price.' , 'extretion' ), 
				extretion_get_first_installment_percentage()
			);
			?>
		</div>

		<?php
	} else { ?>

		<div class="price-subtotal price-subtotal-new mb-10 booking_html booking_message_abt_payment">
			<?php 
			printf( 
				esc_html__( 'Note : At booking you will have to pay %d&#37; of the total price.' , 'extretion' ), 
				extretion_get_first_installment_percentage()
			);
			?>
		</div>

		<?php
	}

	$data .= ob_get_clean();
	return $data;

}

function extretion_price_after_commission( $price ){

	$base_currency = sanitize_text_field( get_option( 'options_base_currency' ) );
    $base_currency = $base_currency ? $base_currency : 'USD';

    // Add site commission
    $commission = sanitize_text_field( get_option( 'options_commision_rate' , 'option' ) );
    $commission = $commission ? $commission : 0;

    // Add commission to the price
    $new_price = $price + ( $commission/100 * $price );
    return $new_price; 

}

function extretion_give_weekly_discount( $price , $post_id ){

	$discount = get_post_meta( $post_id, 'weekly_discount' , true );
	$discount = $discount ? $discount : 0;

	$discounted_price = array();
	$discounted_price['price_after_discount'] = $price - ( $discount/100 * $price );
	$discounted_price['discount'] = $discount/100 * $price;
	$discounted_price['discount_percentage'] = $discount;
	return $discounted_price;

}

function extretion_give_monthly_discount( $price , $post_id ){

	$discount = get_post_meta( $post_id, 'monthly_discount' , true );
	$discount = $discount ? $discount : 0;

	$discounted_price = array();
	$discounted_price['price_after_discount'] = $price - ( $discount/100 * $price );
	$discounted_price['discount'] = $discount/100 * $price;
	$discounted_price['discount_percentage'] = $discount;
	return $discounted_price;

}

function extretion_check_unavailable_dates( $user_dates_range , $post_id ){

	$unavilable_dates_db = get_post_meta( $post_id, 'booking_unavailable_dates', true );

	if( !is_array( $unavilable_dates_db ) ){
		$unavilable_dates_db = array();
	}

	// echo 'Database Dates';
	// print_r($unavilable_dates_db);

	// echo 'User Dates';
	// print_r($user_dates_range);
	$count = 0;

	foreach( $user_dates_range as $dates ){

		if( in_array( $dates , $unavilable_dates_db ) ){

			$count = 1;

		}

	}

	if( $count == 1 ){
		return false;
	} else{
		return true;
	}

}

add_action( 'wp_ajax_change_currency' , 'extretion_change_currency' );
add_action( 'wp_ajax_nopriv_change_currency' , 'extretion_change_currency' );

function extretion_change_currency() {

	if( !empty( $_POST['change_currency'] ) ){

		$sanitize_currency = sanitize_text_field( $_POST['change_currency'] );

		foreach( extretion_currency_symbol() as $key => $value ){

			if( $key == $sanitize_currency ){

				setcookie( "currency" , $sanitize_currency , time() + 3600, '/');  /* expire in 1 hour */
			}

		}

	}

	die;

}

function extretion_currency_symbol( $currency = null ){

	$currency_symbols = array(
		'AED' => '&#1583;.&#1573;', // ?
		'AFN' => '&#65;&#102;',
		'ALL' => '&#76;&#101;&#107;',
		'AMD' => '&#1423;',
		'ANG' => '&#402;',
		'AOA' => '&#75;&#122;', // ?
		'ARS' => '&#36;',
		'AUD' => '&#36;',
		'AWG' => '&#402;',
		'AZN' => '&#1084;&#1072;&#1085;',
		'BAM' => '&#75;&#77;',
		'BBD' => '&#36;',
		'BDT' => '&#2547;', // ?
		'BGN' => '&#1083;&#1074;',
		'BHD' => '.&#1583;.&#1576;', // ?
		// 'BIF' => '&#70;&#66;&#117;', // ?
		'BMD' => '&#36;',
		'BND' => '&#36;',
		'BOB' => '&#36;&#98;',
		'BRL' => '&#82;&#36;',
		'BSD' => '&#36;',
		'BTN' => '&#78;&#117;&#46;', // ?
		'BWP' => '&#80;',
		//'BYR' => '&#112;&#46;',
		'BZD' => '&#66;&#90;&#36;',
		'CAD' => '&#36;',
		'CDF' => '&#70;&#67;',
		'CHF' => '&#67;&#72;&#70;',
		//'CLF' => 'CLF', // ?
		'CLP' => '&#36;',
		'CNY' => '&#165;',
		'COP' => '&#36;',
		'CRC' => '&#8353;',
		'CUP' => '&#8396;',
		'CVE' => '&#36;', // ?
		'CZK' => '&#75;&#269;',
		'DJF' => '&#70;&#100;&#106;', // ?
		'DKK' => '&#107;&#114;',
		'DOP' => '&#82;&#68;&#36;',
		'DZD' => '&#1583;&#1580;', // ?
		'EGP' => '&#163;',
		'ETB' => '&#66;&#114;',
		'EUR' => '&#8364;',
		'FJD' => '&#36;',
		'FKP' => '&#163;',
		'GBP' => '&#163;',
		'GEL' => '&#4314;', // ?
		'GHS' => '&#162;',
		'GIP' => '&#163;',
		'GMD' => '&#68;', // ?
		'GNF' => '&#70;&#71;', // ?
		'GTQ' => '&#81;',
		'GYD' => '&#36;',
		'HKD' => '&#36;',
		'HNL' => '&#76;',
		'HRK' => '&#107;&#110;',
		'HTG' => '&#71;', // ?
		'HUF' => '&#70;&#116;',
		//'IDR' => '&#82;&#112;',
		'ILS' => '&#8362;',
		'INR' => '&#8377;',
		//'IQD' => '&#1593;.&#1583;', // ?
		//'IRR' => '&#65020;',
		'ISK' => '&#107;&#114;',
		//'JEP' => '&#163;',
		'JMD' => '&#74;&#36;',
		'JOD' => '&#74;&#68;', // ?
		'JPY' => '&#165;',
		//'KES' => '&#75;&#83;&#104;', // ?
		'KGS' => '&#1083;&#1074;',
		'KHR' => '&#6107;',
		'KMF' => '&#67;&#70;', // ?
		'KPW' => '&#8361;',
		'KRW' => '&#8361;',
		'KWD' => '&#1583;.&#1603;', // ?
		'KYD' => '&#36;',
		'KZT' => '&#1083;&#1074;',
		'LAK' => '&#8365;',
		'LBP' => '&#163;',
		'LKR' => '&#8360;',
		'LRD' => '&#36;',
		'LSL' => '&#76;', // ?
		'LTL' => '&#76;&#116;',
		'LVL' => '&#76;&#115;',
		'LYD' => '&#1604;.&#1583;', // ?
		'MAD' => '&#1583;.&#1605;.', //?
		'MDL' => '&#76;',
		'MGA' => '&#65;&#114;', // ?
		'MKD' => '&#1076;&#1077;&#1085;',
		'MMK' => '&#75;',
		'MNT' => '&#8366;',
		'MOP' => '&#77;&#79;&#80;&#36;', // ?
		'MRO' => '&#85;&#77;', // ?
		'MUR' => '&#8360;', // ?
		'MVR' => '.&#1923;', // ?
		'MWK' => '&#77;&#75;',
		'MXN' => '&#36;',
		'MYR' => '&#82;&#77;',
		'MZN' => '&#77;&#84;',
		'NAD' => '&#36;',
		'NGN' => '&#8358;',
		'NIO' => '&#67;&#36;',
		'NOK' => '&#107;&#114;',
		'NPR' => '&#x20B9;',
		'NZD' => '&#36;',
		'OMR' => '&#65020;',
		'PAB' => '&#66;&#47;&#46;',
		'PEN' => '&#83;&#47;&#46;',
		'PGK' => '&#75;', // ?
		'PHP' => '&#8369;',
		'PKR' => '&#8360;',
		'PLN' => '&#122;&#322;',
		'PYG' => '&#71;&#115;',
		'QAR' => '&#65020;',
		'RON' => '&#108;&#101;&#105;',
		//'RSD' => '&#1044;&#1080;&#1085;&#46;',
		'RUB' => '&#1088;&#1091;&#1073;',
		'RWF' => '&#1585;.&#1587;',
		'SAR' => '&#65020;',
		'SBD' => '&#36;',
		'SCR' => '&#8360;',
		'SDG' => '&#163;', // ?
		'SEK' => '&#107;&#114;',
		'SGD' => '&#36;',
		'SHP' => '&#163;',
		'SLL' => '&#76;&#101;', // ?
		'SOS' => '&#83;',
		//'SRD' => '&#36;',
		//'STD' => '&#68;&#98;', // ?
		'SVC' => '&#36;',
		'SYP' => '&#163;',
		'SZL' => '&#76;', // ?
		//'THB' => '&#3647;',
		'TJS' => '&#84;&#74;&#83;', // ? TJS (guess)
		'TMT' => '&#109;',
		'TND' => '&#1583;.&#1578;',
		'TOP' => '&#84;&#36;',
		'TRY' => '&#8356;', // New Turkey Lira (old symbol used)
		'TTD' => '&#36;',
		'TWD' => '&#78;&#84;&#36;',
		//'TZS' => 'TZS',
		//'UAH' => '&#8372;',
		//'UGX' => '&#85;&#83;&#104;',
		'USD' => '&#36;',
		'UYU' => '&#36;&#85;',
		'UZS' => '&#1083;&#1074;',
		'VEF' => '&#66;&#115;',
		'VND' => '&#8363;',
		'VUV' => '&#86;&#84;',
		'WST' => '&#87;&#83;&#36;',
		//'XAF' => '&#70;&#67;&#70;&#65;',
		'XCD' => '&#36;',
		'XDR' => 'XDR',
		'XOF' => 'XOF',
		'XPF' => '&#70;',
		'YER' => '&#65020;',
		'ZAR' => '&#82;',
		'ZWL' => '&#90;&#36;',
	);

	$currency_symbols = apply_filters( 'extretion_currency_symbols' , $currency_symbols );
	
	if( $currency == null ){
		return $currency_symbols;
	}
	return $currency_symbols[$currency];	
	
}

function extretion_date_range( $first, $last, $step = '+1 day', $output_format = 'd-m-Y' ) {

    $dates = array();
    $current = strtotime($first);
    $last = strtotime($last);

    while( $current <= $last ) {

        $dates[] = date($output_format, $current);
        $current = strtotime($step, $current);
    }

    return $dates;
}

// All Prices will be changed to EUR currency
function extretion_exchange_currency( $db_price, $db_currency = NULL, $currency_only = NULL , $to_currency = null , $commission = true , $round = true ) {
    
    // If Changing currency is NULL set it to EUR
    if ($db_currency == NULL) {
        $from_Currency = 'EUR';
    }
    
    if( $to_currency == null ){	

    	// If cookie is set, get cookie value if not get the base_currency
		$base_currency = !empty( $_COOKIE['currency'] ) ? sanitize_text_field( $_COOKIE['currency'] ) : sanitize_text_field( get_option( 'options_base_currency' ) );
    	$base_currency = $base_currency ? $base_currency : 'USD';
    } else {
    	$base_currency = $to_currency;
    }

    if( $commission == true ){
    	// Add site commission
    	$commission = sanitize_text_field( get_option( 'options_commision_rate' ) );
    	$commission = $commission ? $commission : 0;

    	// Add commission to the price
    	$new_price = $db_price + ( $commission/100 * $db_price );
    } else {
    	$new_price = $db_price; 
    }    

    // If cookie is not set
    if (!isset($_COOKIE['currency'])) {

        $to_Currency = $base_currency;
        $from_Currency = urlencode($db_currency);

        return extretion_get_exchange_currency( $to_Currency , $from_Currency , $new_price , $currency_only , $db_currency , $round );

    } else {

        $from_Currency = urlencode($db_currency);
        $to_Currency = $base_currency;

        return extretion_get_exchange_currency( $to_Currency , $from_Currency , $new_price , $currency_only , $db_currency , $round );
	}
}

function extretion_search_currency_exchange( $db_price, $db_currency = NULL, $currency_only = NULL ){

    $to_Currency = 'NPR';

    $from_Currency = urlencode( $db_currency );

    $amount = urlencode( $db_price );

    $exchange_price = extretion_get_exchange_currency( $to_Currency , $from_Currency , $amount , null , null );

    $converted_amount = preg_replace("/[^0-9\.]/", null, $exchange_price );

    return round( $converted_amount );

}

function extretion_get_exchange_currency( $to_Currency , $from_Currency , $db_price , $currency_only , $db_currency , $round = true ){

	if( empty( $to_Currency ) || empty( $from_Currency ) ){
		return;
	}

    if ($to_Currency != $from_Currency) {

        $amount = urlencode($db_price);
        $to_Currency = urlencode($to_Currency);

		$get_currencies = get_option( 'get_currencies' , null );

		$converted_price = ( $get_currencies[$to_Currency] / $get_currencies[$from_Currency] ) * $amount;

        if($currency_only == TRUE){
            return $to_Currency;
        } else{

        	if( $round == false ){
        		return $converted_price . ' ' . $to_Currency;
        	}
            return round($converted_price) . ' ' . $to_Currency;
        }

    } else {

        if($currency_only == TRUE){
            return $db_currency;
        }else{

        	if( $round == false ){
        		return $db_price . ' ' . $db_currency;
        	}
            return round($db_price) . ' ' . $db_currency;
        }
    }

}

function extretion_registerModalRules(){

	$args = extretion_getRegisterArguments();
	
	return extretion_getValidationRules( $args , 'user_meta' );		

}

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function extretion_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'extretion_content_width', 640 );
}
add_action( 'after_setup_theme', 'extretion_content_width', 0 );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';

add_action( 'extretion_before_user_input_list_my_property' , 'extretion_before_checkbox_aminities' );
add_action( 'extretion_after_user_input_list_my_property' , 'extretion_after_checkbox_aminities' );
function extretion_before_checkbox_aminities( $value ){

	if( !empty( $value['for'] ) && $value['for'] == 'list_my_property' && $value['name'] == 'amenities' ){
		echo '<div class="pt-5">';
	}

}

function extretion_after_checkbox_aminities( $value ){

	if( !empty( $value['for'] ) && $value['for'] == 'list_my_property' && $value['name'] == 'amenities' ){
		echo '</div>';
	}

}

/*
** Add div wrapper before and after the inputs ( Register modal )
*/

add_action( 'extretion_before_user_label_user_register_modal' , 'extretion_before_regiter_user_get_field' );
add_action( 'extretion_after_user_input_user_register_modal' , 'extretion_after_regiter_user_get_field' );

function extretion_before_regiter_user_get_field( $value ){

	// Hide on edit profile page
	if( is_user_logged_in() ){
		return;
	}

	// Show on registration page
	if( !empty( $value['for'] ) && $value['for'] == 'user_register_modal' && $value['type'] == 'captcha' ){
		echo '<div class="form-group mb-0 mt-20">';
	} elseif( !empty( $value['for'] ) && $value['for'] == 'user_register_modal' ){
		echo '<div class="form-group mb-0">';
	}
}

function extretion_after_regiter_user_get_field( $value ){

	// Hide on edit profile page
	if( is_user_logged_in() ){
		return;
	}

	// Show on registration page
	if( !empty( $value['for'] ) && $value['for'] == 'user_register_modal' ){
		echo '</div>';
	}
}


add_action( 'before_get_field_list_my_property' , 'extretion_wpap_by_div_before_field' );
add_action( 'before_get_field_user_register_modal' , 'extretion_wpap_by_div_before_field' );
function extretion_wpap_by_div_before_field( $value ){

	// Show on edit page not on registration page
	if( !is_user_logged_in() ){
		return;
	}

	echo '<div class="col-sm-7 col-md-6">';
}

add_action( 'after_get_field_list_my_property' , 'extretion_wpap_by_div_after_field' );
add_action( 'after_get_field_user_register_modal' , 'extretion_wpap_by_div_after_field' );
function extretion_wpap_by_div_after_field( $value ){

	// Show on edit page not on registration page
	if( !is_user_logged_in() ){
		return;
	}

	echo '</div>';
}

add_action( 'extretion_before_user_label_list_my_property' , 'extretion_wpap_by_div_before_label' );
add_action( 'extretion_before_user_label_user_register_modal' , 'extretion_wpap_by_div_before_label' );
function extretion_wpap_by_div_before_label( $value ){

	// Show on edit page not on registration page
	if( !is_user_logged_in() ){
		return;
	}
	
	/**
	* This is to decrease the space
	*/
	$array = array( 'list_your_room_submit' , 'lyr_nonce' , 'secret_key' , 'edit_profile_user' );

	if( !empty( $value['name'] ) && !in_array( $value['name'] , $array ) && $value['type'] != 'info_box' ){
		echo '<div class="form-group row gap-15">';	
	} elseif( $value['type'] == 'info_box' ){
		echo '<div class="mb-20 ' . $value['class'] . '">';
	} else {
		echo '<div class="row">';	
	}
	
}

add_action( 'extretion_after_user_input_list_my_property' , 'extretion_wpap_by_div_after_input' );
add_action( 'extretion_after_user_input_user_register_modal' , 'extretion_wpap_by_div_after_input' );
function extretion_wpap_by_div_after_input( $value ){

	// Show on edit page not on registration page
	if( !is_user_logged_in() ){
		return;
	}

	echo '<div class="error_label"></div></div></div>';
}

add_action( 'extretion_before_user_input_list_my_property' , 'extretion_wpap_by_div_before_input' );
add_action( 'extretion_before_user_input_user_register_modal' , 'extretion_wpap_by_div_before_input' );
function extretion_wpap_by_div_before_input( $value ){

	// Show on edit page not on registration page
	if( !is_user_logged_in() ){
		return;
	}

	if( $value['type'] != 'info_box' ){
		echo '<div class="col-sm-6 col-md-6">';
	} else {
		echo '<div class="">';
	}
}

/**
* Send successfully reset password
*/

add_action( 'extretion_after_password_changed' , 'extretion_send_success_reset_pass_email' );
function extretion_send_success_reset_pass_email( $user_id ){

	$username = get_the_author_meta( 'user_login' , $user_id );
	$to = get_the_author_meta( 'user_email' , $user_id );

	$subject = get_option( 'options_after_resetting_password_subject' );
	$subject = !empty( $subject ) ? $subject : 'Reset password successful on [site_name]';
	$subject = str_replace( '[site_name]' , get_bloginfo( 'name' ) , $subject );

	$message = get_option( 'options_after_resetting_password' );
	$message = !empty( $message ) ? $message : '<p>Congratulations [username],</p><p>You have successfully reset your password on the [site_name]. Click on &#34;Log in&#34; link to sign in to your account using the new password.</p>';
	$message = str_replace( '[site_name]' , get_bloginfo( 'name' ) , $message );
	$message = str_replace( '[username]' , $username , $message );

	wp_mail( $to, $subject, nl2br( $message ) , extretion_mail_headers() );

}

add_filter( 'extretion_extra_sanitize_callback' , 'extretion_extra_sanitize_function' , 10 , 2 );
function extretion_extra_sanitize_function( $args , $arguments ){

	if( $arguments == 'extretion_listYourRoomArguments' ){

		$var = array(
			array(
				'callback' => 'extretion_callback_checkFloatValue_latitude',
				'sanitize_callback' => 'extretion_sanitize_callback_checkFloatValue',
				'input_name' => 'form_place_located_lat'
			),
			array(
				'callback' => 'extretion_callback_checkFloatValue_lng',
				'sanitize_callback' => 'extretion_sanitize_callback_checkFloatValue',
				'input_name' => 'form_place_located_lng'
			),
			array(
				//'callback' => 'callback_checkFormattedAddress',
				'sanitize_callback' => 'extretion_sanitize_callback_checkFormattedAddress',
				'input_name' => 'form_place_located_formatted_address'
			),
		);

		foreach( $var as $value ){
			array_push( $args , $value );	
		}

	} elseif( $arguments == 'extretion_getRegisterArguments' ){

		$var = array(
			array(
				'callback' => 'extretion_callback_checkFloatValue_latitude',
				'sanitize_callback' => 'extretion_sanitize_callback_checkFloatValue',
				'input_name' => 'form_hotel_located_lat'
			),
			array(
				'callback' => 'extretion_callback_checkFloatValue_lng',
				'sanitize_callback' => 'extretion_sanitize_callback_checkFloatValue',
				'input_name' => 'form_hotel_located_lng'
			),
			array(
				//'callback' => 'callback_checkFormattedAddress',
				'sanitize_callback' => 'extretion_sanitize_callback_checkFormattedAddress',
				'input_name' => 'form_hotel_located_formatted_address'
			),
		);

		foreach( $var as $value ){
			array_push( $args , $value );	
		}

	}

	return $args;

}

function extretion_callback_checkFloatValue_latitude( $value ){

	if( is_numeric( $value ) && floor( $value ) != $value ){
		return true;
	}

	return array(
		'result' => false,
		'message' => esc_html__( 'Latitude is empty. Please write the address properly and select one from the dropdown.' , 'extretion' )
	);

}

function extretion_callback_checkFloatValue_lng( $value ){

	if( is_numeric( $value ) && floor( $value ) != $value ){
		return true;
	}

	return array(
		'result' => false,
		'message' => esc_html__( 'Longitude is empty. Please write the address properly and select one from the dropdown.' , 'extretion' )
	);

}

function extretion_sanitize_callback_checkFormattedAddress( $value ){

	if( empty( $value ) ){
		return false;
	}

	return sanitize_text_field( $value );

}

function extretion_sanitize_callback_checkFloatValue( $value ){

	if( is_numeric( $value ) && floor( $value ) != $value ){
		return $value;
	}
	return false;

}

function extretion_check_room_secret_key( $data ){

	$secret_key = !empty( $data['secret_key'] ) ? sanitize_text_field( $data['secret_key'] ) : '';
	global $wpdb;

	$sql = $wpdb->prepare( "SELECT * FROM {$wpdb->postmeta} 
		WHERE `meta_key` = 'secret_key'
		AND `meta_value` = %s" , $secret_key );

	$results = $wpdb->get_results( $sql , ARRAY_A );

	if( !empty( $results ) ){
		return false;
	}
	return true;

}

function extretion_saveRoomTaxonomy( $data , $post_id ){

	$args = extretion_listYourRoomArguments();

	if( !empty( $args ) ){

		foreach( $args as $key => $value ){

			if( !empty( $value['taxonomy'] ) && $value['taxonomy'] == true ){

				$tax_name = str_replace( array( '[' , ']' ), '', $value['name'] );

				if( !empty( $data[$tax_name] ) ){
					
					if( is_array( $data[$tax_name] ) ){
						$taxonomy_value =  array_map('intval', $data[$tax_name] );
					} else {
						$taxonomy_value = (int) $data[$tax_name];
					}

					wp_set_object_terms( $post_id , $taxonomy_value , $value['taxonomy_name'] );

					unset( $data[$tax_name] );

				}				

			}			

		}

	}

	return $data;

}

function extretion_lineBreakTextarea( $text ){

	$html = true;

	if($text == ""){
		return "";
	}
  	$text = nl2br($text,false); // false gives <br>, true gives <br />

  	$textary = explode("<br>",$text);
  	foreach($textary as $key => $val){ 
  		$val = trim($val);
    	$val = stripslashes($val);
    	$val = htmlspecialchars($val);
    	$textary[$key] = $val;
  	}

  	if ($html){ 
  		return implode( "<br />" , $textary );
  	} //return implode("<br>",$textary);
  	else { 
  		return implode( "\r\n" , $textary );
  	}

}

add_action( 'extretion_after_sanitize_datas' , 'extretion_save_profile' , 10 , 2 );
function extretion_save_profile( $data , $arguments ){

	if( $arguments != 'extretion_getRegisterArguments' ){
		return;
	}

	// Email will be saved in the users table
	$email = $data['edit_email'];
	unset( $data['edit_email'] );
	$user_id = get_current_user_id();

	// If empty do not save into database
	if( empty( $data['profile_picture'] ) ){
		unset( $data['profile_picture'] );
	}

	// Change user email address
	extretion_change_user_email( $user_id , $email );

	// Save metas to the user meta
	extretion_save_data_to_database( $data , $arguments , $post_id = null , $user_id );

	//echo '<pre>'; print_r( $data ); echo '</pre>';

}

function extretion_change_user_email( $user_id , $email ){

	$args = array(
        'ID'         => $user_id,
        'user_email' => sanitize_email( $email )
    );            
    wp_update_user( $args );

}

add_filter( 'extretion_delete_old_attachment' , 'extretion_delete_old_attachment' , 10 , 2 );
function extretion_delete_old_attachment( $args , $arguments ){

	if( $arguments == 'extretion_getRegisterArguments' ){
		$args['profile_picture'] = 'user_meta';
	}
	//echo '<pre>'; print_r($args); echo '</pre>';
	return $args;

}

function extretion_old_attachments( $post_id, $user_id, $all_files, $key ){

	if( !empty( $all_files ) ){

		foreach( $all_files as $delete_key => $meta ){

			if( $delete_key == $key ){

				$meta_value = ( $meta == 'user_meta' ) ? get_user_meta( $user_id, $key, true ) : get_post_meta( $post_id, $key, true );

				if( !empty( $meta_value ) && is_array( $meta_value ) ){

					foreach( $meta_value as $attachment_id ){
						wp_delete_attachment( $attachment_id );
					}

				}

			}

		}

	}

}

/**
* Save metas to the database
*/

function extretion_save_data_to_database( $data , $arguments , $post_id = null , $user_id = null ){

	/**
	* $args will return all the names
	*/

	$ignoreSanitize = apply_filters( 'extretion_ignore_sanitize' , $args = array() , $arguments );
	$all_files = apply_filters( 'extretion_delete_old_attachment' , $args = array() , $arguments );

	foreach( $data as $key => $value ){

		if( !in_array( $key , $ignoreSanitize ) ){
			$meta_value = ( !is_array( $value ) ? sanitize_text_field( $value ) : $value );
		} else {
			$meta_value = $value;
		}	

		extretion_old_attachments( $post_id , $user_id, $all_files , $key );

		if( $post_id != null ){
			update_post_meta( $post_id, $key, $meta_value );	
		} else {
			update_user_meta( $user_id, $key, $meta_value );
		}
		
	}

}

function extretion_get_post_id_before_saving( $data , $user_id , $edit ){

	$paypal_email = get_user_meta( $user_id, 'paypal_email', true );
	$db_strip_details = get_user_meta( $user_id, 'stripe_details', true );

	/**
	* If PayPal or stripe is enabled, Publish the listings
	*/

	if( is_email( $paypal_email ) || !empty( $db_strip_details ) ){
		$paypal_status = true;		
	} else {
		$paypal_status = false;
	}

	$post_status = ( $paypal_status == true ? 'publish' : 'pending' );

	/**
	* Check paypal disable status
	*/

	$paypal_disable_status = get_option( 'options_booking_form' ); // If true then disabled
	if( $paypal_disable_status == true ){
		$post_status = 'publish';
	}

	if( $edit == true ){

		$post_id = ( !empty( $_GET['id'] ) && ctype_digit( $_GET['id'] ) ) ? $_GET['id'] : '';

		$my_post = array(
	      	'ID'           => $post_id,
	      	'post_title'   => sanitize_text_field( $data['room_title'] ),
	      	'post_content' => implode( "\n", array_map( 'sanitize_text_field', explode( "\n", $data['room_description'] ) ) ),
	      	'post_status'   => $post_status,
	  	);

		// Update the post into the database
	  	wp_update_post( $my_post );

	} else {

		$my_post = array(
		  	'post_title'    => sanitize_text_field( $data['room_title'] ),
		  	'post_content'  =>  implode( "\n", array_map( 'sanitize_text_field', explode( "\n", $data['room_description'] ) ) ),
		  	'post_status'   => $post_status,
		  	'post_author'   => $user_id,
		  	'post_type' => 'room'
		);

		$post_id = wp_insert_post( $my_post );

		// Add post views 
		update_post_meta( $post_id, 'lmh_post_views_count' , 0 );

	}

	return $post_id;

}

add_action( 'extretion_after_sanitize_datas' , 'extretion_create_new_room' , 10 , 3 );
function extretion_create_new_room( $data , $arguments , $edit ){

	if( $arguments != 'extretion_listYourRoomArguments' ){
		return;
	}

	$user_id = get_current_user_id();

	$post_id = extretion_get_post_id_before_saving( $data , $user_id , $edit );

	$data = extretion_saveRoomTaxonomy( $data , $post_id );
	extretion_saveDestinationTaxonomy( $data , $post_id );

	unset( $data['room_title'] );
	unset( $data['room_description'] );

	// Save post meta to the database
	extretion_save_data_to_database( $data , $arguments , $post_id );

	unset($_POST);

	$post_link = get_permalink( $post_id );

	do_action( 'extretion_after_room_creation' , $post_id );

	extretion_success_message_room( $edit , $post_link );

}

function extretion_success_message_room( $edit , $post_link ){

	if( $edit == true ){

		echo '<div class="success_message">' . esc_html__( 'Congratulation !!! You have successfully edited your room.' , 'extretion' ) . '</div>';

	} else {

		$user_id = get_current_user_id();
		$paypal_status = get_user_meta( $user_id , 'paypal_email' , true );
		$db_strip_details = get_user_meta( $user_id, 'stripe_details', true );

		/* 
		* Check paypal is enabled or not
		*/

		$disbale_paypal = get_option( 'options_booking_form' ); // If true paypal is disabled, if false paypal is enabled

		echo '<div class="alert alert-info mb-30">';
		echo '<div class="icon">
		<i class="fa fa-lightbulb-o font12"></i>
		</div>';
		echo '<div class="content"><h4 class="text-primary2"> ' . esc_html__( 'Notice', 'extretion' ) . ' </h4>';


		// If paypal is disabled
		if( $disbale_paypal == true ){

			extretion_successfully_published_item( $post_link );
		
		} 
		// If paypal id is entered by the user then show success message 
		elseif( (!empty( $paypal_status ) && is_email( $paypal_status )) || !empty( $db_strip_details ) ){

			extretion_successfully_published_item( $post_link );

		} 
		// If paypal id is not entered by the user then show the warning message
		else {

			esc_attr_e( 'Congratulation!!! You have successfully added your room but your room is in pending status. Add a valid PayPal email to receive payments from the traveler and your room will be published. Go to your profile section to add PayPal email.' , 'extretion' );

		}

		echo '</div></div>';

	}

}

function extretion_successfully_published_item( $post_link ){

	esc_attr_e( 'Congratulation!!! You have successfully added your room. ' , 'extretion' );
		
	printf( 
		wp_kses(
			__( '<a href="%s">Click Here</a> to see your room.', 'extretion' ),
			array( 
				'a' => array( 'href' => array() ) 
			) 
		), 
		esc_url( $post_link ) 
	);

}

if( !function_exists( 'extretion_saveDestinationTaxonomy' ) ){

	function extretion_saveDestinationTaxonomy( $data , $post_id ){

		if( empty( $data['form_place_located_country'] ) ){
			return;
		}

		// Add parent term
		$term_taxonomy_id = wp_set_object_terms( $post_id , sanitize_text_field( $data['form_place_located_country'] ) , 'destinations' );

		if( empty( $data['form_place_located_locality'] ) ){
			return;
		}

		// Add child term
		wp_insert_term(
		  	sanitize_text_field( $data['form_place_located_locality'] ), 
		  	'destinations',
		  	array(
		    	'parent'=> $term_taxonomy_id[0]
		  	)
		);

		$set_taxonomy = array( (int) $term_taxonomy_id[0] , sanitize_text_field( $data['form_place_located_locality'] ) );

		// Add post to child term
		wp_set_object_terms( $post_id , $set_taxonomy , 'destinations' );

	}

}

function extretion_destination_clause( $pieces, $taxonomies, $args ){

    // Everything checks out, lets remove parents
    $pieces['where'] .= ' AND tt.parent > 0';

    return $pieces;

}

function extretion_get_destination_link( $place_name ){

	$name = urlencode( sanitize_text_field( $place_name ) );
	$url = 'http://maps.google.com/maps/api/geocode/json?address=' . $name . '&sensor=false';
	$data = wp_remote_get( $url , array( 'sslverify' => false , 'timeout' => 30 ) );

	if( is_wp_error( $data ) ){
		return '#';
	}

	$response_a = json_decode($data['body']);

	$lat = $response_a->results[0]->geometry->location->lat;
	$lng = $response_a->results[0]->geometry->location->lng;
	$place_new = $response_a->results[0]->formatted_address;

	//echo '<pre>'; print_r( $response_a->results[0]->formatted_address ); echo '</pre>';
	return add_query_arg( array(
    	's' => $place_new,
    	'lat' => $lat,
    	'lng' => $lng,
	), esc_url( site_url() ) );

}

/**
* This function is to sort by price in the search page
*/
add_action( 'extretion_after_room_creation' , 'extretion_add_search_currency' );
function extretion_add_search_currency( $post_id ){

	$price = get_post_meta( $post_id , 'per_night_price' , true );

    $currency = get_post_meta( $post_id , 'user_currency' , true );

    $converted_price = extretion_search_currency_exchange( $price, $currency);

    update_post_meta( $post_id , 'lmh_search_price' , $converted_price);

}

add_action( 'extretion_ignore_keys_list_my_room' , 'extretion_ignore_keys_list_my_room' , 10 , 2 );
function extretion_ignore_keys_list_my_room( $args , $arguments ){
	
	if( $arguments == 'extretion_listYourRoomArguments' ){

		$args[] = 'list_my_room_name';
		$args[] = 'list_your_room_submit';
		$args[] = 'lyr_nonce';
		$args[] = 'accept_terms';
		$args[] = 'total_price_per_night';

	} elseif( $arguments == 'extretion_getRegisterArguments' ){

		$args[] = 'edit_profile_submit';
		$args[] = 'edit_profile_user';

	}

	return $args;
}

/**
* Allow only Numbers
*/

function extretion_validNumber( $value ){

	if( is_numeric( $value ) ){
		return $value;
	}
	return false;

}

function extretion_save_image_attachment( $files ){

	//echo '<pre>'; print_r( $files ); echo '</pre>';

	if( !empty( $files ) ){

		$image_ids = array();

		foreach( $files as $key => $values ){

			if( $key == 'tmp_name' ){

				foreach( $values as $num => $value ){

					$file = array();
					$file['name'] = $files['name'][$num];
					$file['type'] = $files['type'][$num];
					$file['tmp_name'] = $value;
					$file['error'] = $files['error'][$num];
					$file['size'] = $files['size'][$num];

					if( !empty( $file['name'] ) ){

						$image_ids[] = extretion_upload_image( $file );

					}

				}

			}

		}

		//echo '<pre>'; print_r( $image_ids ); echo '</pre>';
		return $image_ids;
	}

}

function extretion_upload_image( $file , $attached_to = 0 ){

	include_once ABSPATH . 'wp-admin/includes/media.php';
	include_once ABSPATH . 'wp-admin/includes/file.php';
	include_once ABSPATH . 'wp-admin/includes/image.php';

	//$files_temp = file_get_contents( $file["temp"] );
	$file_image = array(
        'name' => $file['name'],
        'type' => $file['type'],
        'tmp_name' => $file['tmp_name'],
        'error' => $file['error'],
        'size' => $file['size']
    );
	$upload_overrides = array( 'test_form' => false );
    $upload = wp_handle_upload( $file_image , $upload_overrides, time() );

    //resize image - start
    $image = wp_get_image_editor( $upload['file'] );
    if ( !is_wp_error($image) ) {
        $image->resize( 1024 , 800 , true);
        $image->save( $upload['file'] );
    }
    //resize image - end

    $attachment = array(
        'guid' => $upload['url'],
        'post_mime_type' => $upload['type'],
        'post_title' => preg_replace('/\.[^.]+$/', '', basename( $file_image['name'] )),
        'post_content' => '',
        'post_status' => 'inherit'
    );

    // Insert the attachment.
	$attach_id = wp_insert_attachment($attachment, $upload['file'], $attached_to );

	// Generate the metadata for the attachment, and update the database record.
    $attach_data = wp_generate_attachment_metadata($attach_id, $upload['file']);
    wp_update_attachment_metadata($attach_id, $attach_data);
    return $attach_id;

}

function extretion_get_room_gallery( $post_id , $tab = false ){

	$gallery = get_post_meta( $post_id, 'room_photos' , true );

	if( !empty( $gallery ) ){ ?>

			<div id="detail-content-sticky-nav-01" class="<?php echo ( $tab == false ? 'pt-30' : '' ); ?>">
					
				<div class="slick-gallery-slideshow">

					<div class="slider gallery-slideshow">

					 	<?php	
					 	foreach( $gallery as $image_id ){ 

					 		$image_attributes = wp_get_attachment_image_src( $image_id ); 

					 		if( $image_attributes ){ ?>

						 		<div>
									<div class="image">
										<?php echo wp_get_attachment_image( $image_id, 'extretion_room_gallery_image', false ); ?>
									</div>
								</div>

					 			<?php

					 		}
					 	} ?>

					</div>

					<?php 
					/**
					* If more than one image then only show the thumbnails
					*/
					if( count( $gallery ) > 1 ): ?>

						<div class="slider gallery-nav">

							<?php	
						 	foreach( $gallery as $image_id ){ 

						 		$image_attributes = wp_get_attachment_image_src( $image_id ); 

						 		if( $image_attributes ){ ?>

									<div>
										<div class="image">
											<?php echo wp_get_attachment_image( $image_id, 'extretion_room_gallery_image_thumb', false ); ?>
										</div>
									</div>

									<?php

								}

						 	} ?>

						</div>

						<?php 

					endif; ?>

				</div>

			</div>

		<?php

	}

}

function extretion_get_post_facilities( $post_id ){

	$facility = wp_get_post_terms( $post_id, 'facility' );
	$post_facility = array();

	if( !empty( $facility ) ){

		foreach( $facility as $term ){

			$post_facility[] = $term->term_id;

		}

	}

	return $post_facility;

}

function extretion_room_key_facts( $post_id ){

	$accomodates = get_post_meta( $post_id, 'guest_accomodate', true );
	$bathroom = get_post_meta( $post_id, 'room_bathroom', true );
	$bed_type = wp_get_post_terms( $post_id, 'bed_types' );
	$bedroom = get_post_meta( $post_id, 'no_of_bedroom', true );
	$beds = get_post_meta( $post_id, 'no_of_bed', true );
	$check_in_time = get_post_meta( $post_id, 'check_in_time', true );
	$check_out_time = get_post_meta( $post_id, 'check_out_time', true );
	$property_type = wp_get_post_terms( $post_id, 'type_of_place' );
	$space_offered = wp_get_post_terms( $post_id, 'space_offered' );
	$required_at_check_in = get_post_meta( $post_id, 'required_at_check_in', true );
	$children_check_in = get_post_meta( $post_id , 'children_check_in' , true );

	$args = array(
		array(
			'title' => esc_html__( 'The Space' , 'extretion' ),
			'outer_wrapper_start' => '<div class="row">',
			'outer_wrapper_end' => '</div>',
			'inner_wrapper_start' => '<div class="col-sm-6">',
			'inner_wrapper_end' => '</div>',
			'fields' => array(
				'accomodates' =>
					sprintf( 
						wp_kses(
							__( 'Accommodates : <strong>%d</strong>' , 'extretion' ),
							array(
								'strong' => array()
							)
						), 
						sanitize_text_field( $accomodates ) 
					),
				'bathrooms' =>
					sprintf( 
						wp_kses(
							__( 'Bathrooms : <strong>%d</strong>' , 'extretion' ),
							array(
								'strong' => array()
							)
						), 
						sanitize_text_field( $bathroom ) 
					),
				'beds' =>
					sprintf( 
						wp_kses(
							__( 'Beds : <strong>%d</strong>' , 'extretion' ),
							array(
								'strong' => array()
							)
						), 
						sanitize_text_field( $beds ) 
					),
				'bed_type' =>
					sprintf( 
						wp_kses(
							__( 'Bed Type : <strong>%s</strong>' , 'extretion' ),
							array(
								'strong' => array()
							)
						), 
						sanitize_text_field( $bed_type[0]->name ) 
					),
				'bedrooms' =>
					sprintf( 
						wp_kses(
							__( 'Bedrooms : <strong>%d</strong>' , 'extretion' ),
							array(
								'strong' => array()
							)
						), 
						sanitize_text_field( $bedroom ) 
					),
				'property_type' =>
					sprintf( 
						wp_kses(
							__( 'Type of Place : <strong>%s</strong>' , 'extretion' ),
							array(
								'strong' => array()
							)
						), 
						sanitize_text_field( $property_type[0]->name ) 
					),
				'space_offered' =>
					sprintf( 
						wp_kses(
							__( 'Space Offered : <strong>%s</strong>' , 'extretion' ),
							array(
								'strong' => array()
							)
						), 
						sanitize_text_field( $space_offered[0]->name ) 
					),					
			),
		),
		array(
			'title' => esc_html__( 'Arriving/leaving' , 'extretion' ),
			'outer_wrapper_start' => '<div>',
			'outer_wrapper_end' => '</div>',
			'inner_wrapper_start' => '<div>',
			'inner_wrapper_end' => '</div>',
			'fields' => array(
				'check_in_time' =>
				sprintf( esc_html__( '- Check-in time starts at %s' , 'extretion' ) , sanitize_text_field( $check_in_time ) ),
				'check_out_time' =>
				sprintf( esc_html__( '- Check-out time is %s' , 'extretion' ) , sanitize_text_field( $check_out_time ) ),
			)
		),
		array(
			'title' => esc_html__( 'Required at check in' , 'extretion' ),
			'outer_wrapper_start' => '<div>',
			'outer_wrapper_end' => '</div>',
			'inner_wrapper_start' => '<div>',
			'inner_wrapper_end' => '</div>',
			'fields' => array(
				'required_at' => extretion_required_at_check_in_add_dash( $required_at_check_in ),
			)
		),
		array(
			'title' => esc_html__( 'Children' , 'extretion' ),
			'outer_wrapper_start' => '<div>',
			'outer_wrapper_end' => '</div>',
			'inner_wrapper_start' => '<div>',
			'inner_wrapper_end' => '</div>',
			'fields' => array(
				'required_at' => extretion_children_check_in( $children_check_in ),
			)
		),
	);

	$args = apply_filters( 'extretion_room_key_facts' , $args , $post_id );

	return $args;

}

function extretion_children_check_in( $value ){

	return extretion_addLineBreak( $value );

}

function extretion_addLineBreak( $unfilteredText ){

	$content = null;
	if( !empty( $unfilteredText ) ){

		$text = preg_split('/<br[^>]*>/i', $unfilteredText);;
		
		foreach( $text as $value ){

			if( !empty( $value ) ){
				$content .= '- ' . $value . '<br>';
			}
		}

	}

	return $content;

}

function extretion_required_at_check_in_add_dash( $value ){

	return extretion_addLineBreak( $value );

}

function extretion_halfHourTimes() {
  	$h = 0;
	while ($h < 24) {
	    $key = date('h:i A', strtotime(date('Y-m-d') . ' + ' . $h . ' hours'));
	    $value = date('h : i A', strtotime(date('Y-m-d') . ' + ' . $h . ' hours'));
	    $formatter[$key] = $value;
	    $h++;
	}
	return $formatter;
}

/**
* Edit Profile
*/

function extretion_saveprofile(){

	if( !empty( $_POST['edit_profile_user'] ) && $_POST['edit_profile_user'] == 1 && is_user_logged_in() ){

		// Sanitize the language spoken array
		$post_language_spoken = !empty( $_POST['language_spoken'] ) ? array_map( 'sanitize_text_field' , $_POST['language_spoken'] ) : ''; 
		$post_language_spoken = empty( $post_language_spoken[0] ) ? '' : $post_language_spoken;

		// Unset it other wise it wil give an error
		unset( $_POST['language_spoken'] );

		// Sanitize the whole $_POST data
		$post_data = array_map( 'sanitize_text_field' , $_POST );

		// Add the sanitized language again to the post data
		$post_data['language_spoken'] = $post_language_spoken; 

		// Add the files to the post
		$post_data['lmh_files'] = !empty( $_FILES ) ? $_FILES : '';

		$validateResult = postValueCheck( $post_data , 'extretion_getRegisterArguments' );

		/**
		* If error, show the message and break the function
		*/

		if( $validateResult['check'] == true ){

			echo '<ul class="login_modal_error edit_profile_error">' . $validateResult['errors'] . '</ul>';
			$errorFields = rtrim( $validateResult['errorFields'] ,','); ?>

			<script>
				
				jQuery( document ).ready(function(){

					jQuery( "<?php echo esc_attr( $errorFields ); ?>" ).addClass( 'errorphp' );

				});

			</script>

			<?php

		} else {
			//echo '<pre>'; print_r( $post_data ); echo '</pre>';
			extretion_check_data_before_saving( $post_data , 'extretion_getRegisterArguments' , $edit = true );
			extretion_set_room_status_unpublish();
		}

		

	}

}

/**
* Insert new users
*/

function extretion_addNew(){

	if( !empty($_POST['register_hotel_user']) && $_POST['register_hotel_user'] == 1 && !is_user_logged_in()){

		$nonce = $_REQUEST['_register_user_nonce'];

		if ( wp_verify_nonce( $nonce, 'register_user_nonce' ) ) {

			$ignore_keys = array( 
				'register_password', 
				'register_password_confirm', 
				'_register_user_nonce',
				'user_input_captcha',
				'captcha_prefix'
			);
			
			/**
			* Filter $_POST values before saving into the database
			*/

			$filteredValues = extretion_filterPostValues( $_POST , $ignore_keys );

			/*
			** Check user password
			*/

			$checkPass = extretion_checkUserPassword( $_POST );

			if( $checkPass['result'] != true ){
				//$filteredValues = array();
				$filteredValues['errors'] = '<li>' . $checkPass['message'] . '</li>' . $filteredValues['errors']; 
				$filteredValues['error_fields'] .= '[name=register_password],[name=register_password_confirm],';
				$filteredValues['check'] = true;
			}

			/**
			* If error(s) found show the register form
			*/

			if(  $filteredValues['check'] == true ): ?>

				<script>

					jQuery(document).ready(function(){
						"use strict";
						var errorMsg = "<?php echo wp_kses( $filteredValues['errors'] , array( 'li' => array() ) ); ?>";
						var errorFields = "<?php echo rtrim( $filteredValues['error_fields'] ,',' ); ?>";

						jQuery( '#loginModal' ).modal('show');
						jQuery( '#login-form,#lost-form' ).hide();
						jQuery( '#register-form' ).show();
						jQuery( '.registration_modal_error' ).html( errorMsg );
						jQuery(  errorFields ).addClass( 'errorphp' );

					});

				</script>

				<?php
			else:
				extretion_saveRegisteredUserDate( $_POST ); ?>

				<script>
					
					jQuery( document ).ready( function(){

						jQuery('#userRegistrationMsg').modal( 'show' );
						jQuery('.register_form_modal input').not(':input[name=register_hotel_user], :input[name=_register_user_nonce]').val('');
						
					});

				</script>

				<?php
			endif;

		} 			

	}

}

function extretion_verify_user_email(){

	if( empty( $_GET['verification_code'] ) || empty( $_GET['user_id'] ) ){
		return;
	}

	$code = sanitize_text_field( $_GET['verification_code'] );
	$user_id = sanitize_text_field( $_GET['user_id'] );

	$check_verify =  get_user_meta( $user_id, 'verification' , true );
	$verify_code_db =  get_user_meta( $user_id, 'verification_key' , true );

	if( $check_verify != false || $verify_code_db != $code ){
		return;
	}

	update_user_meta( $user_id, 'verification' , true );
	delete_user_meta( $user_id, 'verification_key' ); ?>

	<script>
		/**
		* Show successful verification modal
		*/
		jQuery(document).ready(function(){
			jQuery('#userVerifiedMsg').modal('show');
		});
	</script>
	<?php

}

function extretion_resetPasswordForm(){

	if( empty( $_GET['reset_pass_key'] ) || empty( $_GET['user_id'] ) || is_user_logged_in()){
		return;
	}

	$reset_key_browser = sanitize_text_field( $_GET['reset_pass_key'] );
	$user_id = sanitize_text_field( $_GET['user_id'] );

	$db_reset_key = get_user_meta( $user_id, 'reset_verification_key' , true );

	if( $db_reset_key != $reset_key_browser ){
		return;
	} ?>

	<script>
		jQuery(document).ready(function(){
			"use strict";
			jQuery('#userResetForm').modal('show');
		});
	</script>

	<?php

}

function extretion_getRegisterArguments(){

	$user_id = get_current_user_id();
	$digitStatus = get_option( 'digits_status' );

	$captcha_status = get_option( 'options_registration_captcha' );
	$password_strength = get_option( 'options_user_password_strength' );

	$db_strip_details = get_user_meta( $user_id, 'stripe_details', true );

	$stripe_connect_url = 'https://connect.stripe.com/oauth/authorize?response_type=code&client_id=' . extretion_get_client_id() . '&scope=read_write';

	$profileLink = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	$mobileVerification = add_query_arg( 'action', 'add_mobile_number', $profileLink );

	if( empty( $db_strip_details ) ){
		$stripe_btn = '<a href="' . $stripe_connect_url . '"><img src="' . get_template_directory_uri() . '/images/connect_stripe.png' . '" /></a>';	
	} else {
		$stripe_btn = '<a href="' . parse_url( $_SERVER["REQUEST_URI"], PHP_URL_PATH ) . '?status=remove_stripe' . '"><img src="' . get_template_directory_uri() . '/images/disconnect-stripe.png' . '" /></a>';
	}
	
	$args = array(
		array(
			'label' => esc_html__( 'Profile Picture' , 'extretion' ),
			'label_class' => 'col-sm-4 col-md-3 control-label',
			'id' => 'profile_picture',
			'required' => true,
			'class' => 'filer_input_profile_picture',
			'name' => 'profile_picture[]',
			'type' => 'file',
			'for' => 'user_register_modal',
			'validation' => array(
				'required' => true,
			),
			'visible' => 'logged_in',
			'callback' => 'extretion_check_profile_picture',
			'sanitize_callback' => 'extretion_save_image_attachment',
			'limit' => 1, // no of files
			'max_size' => 1, // In MB
			'extensions' => array( 'png','jpg','jpeg','gif','bmp' ), // allowed extensions
			'input_label' => esc_html__( 'Click Here To Upload' , 'extretion' )
		),
		array(
			'type' => 'text',
			'label' => esc_html__( 'First Name' , 'extretion' ),
			'label_class' => 'col-sm-4 col-md-3 control-label',
			'name' => 'first_name',
			'required' => true,
			'placeholder' => esc_html__( 'First Name' , 'extretion' ),
			'class' => 'form-control mb-5',
			'for' => 'user_register_modal',
			'visible' => 'logged_in',
			'validation' => array(
				'required' => true,
				'minlength' => 3
			),
			'callback' => 'extretion_requiredPostValue',
			'callback_error_message' => esc_html__( 'Please enter your first name.' , 'extretion' ),
		),
		array(
			'type' => 'text',
			'label_class' => 'col-sm-4 col-md-3 control-label',
			'name' => 'last_name',
			'required' => true,
			'placeholder' => esc_html__( 'Last Name' , 'extretion' ),
			'label' => esc_html__( 'Last Name' , 'extretion' ),
			'class' => 'form-control mb-5',
			'for' => 'user_register_modal',
			'visible' => 'logged_in',
			'validation' => array(
				'required' => true,
				'minlength' => 3
			),
			'callback' => 'extretion_requiredPostValue',
			'callback_error_message' => esc_html__( 'Please enter your last name.' , 'extretion' ),
		),
		array(
			'placeholder' => esc_html__( 'Username' , 'extretion' ),
			'label_class' => 'hide_label',
			'id' => 'username',
			'class' => 'form-control mb-5',
			'name' => 'username',
			'type' => 'text',
			'validation' => array(
				'required' => true,
				'minlength' => 3
			),
			'validation_msg' => array(
				'required' => esc_html__( "Please enter a username" , 'extretion' ),
				'minlength' => esc_html__( "Your username must consist of at least 3 characters" , 'extretion' )
			),
			'for' => 'user_register_modal',
			'callback' => 'extretion_check_db_user',
			'visible' => 'not_logged_in' // logged_in
		),
		array(
			'placeholder' => esc_html__( 'Email' , 'extretion' ),
			'label' => esc_html__( 'Email' , 'extretion' ),
			'label_class' => 'hide_label col-sm-4 col-md-3 control-label',
			'id' => 'email',
			'required' => true,
			'class' => 'form-control mb-5',
			'name' => 'email',
			'type' => 'email',
			'validation' => array(
				'required' => true,
				'laxEmail' => true
			),
			'validation_msg' => array(
				'required' => esc_html__( "Please enter an email" , 'extretion' ),
				'laxEmail' => esc_html__( "Please enter a valid email address" , 'extretion' )
			),
			'for' => 'user_register_modal',
			'callback' => 'extretion_check_db_email',
			'visible' => 'not_logged_in' // logged_in
		),
		array(
			'label' => esc_html__( 'Email' , 'extretion' ),
			'label_class' => 'hide_label col-sm-4 col-md-3 control-label',
			'id' => 'email',
			'required' => true,
			'class' => 'form-control mb-5',
			'name' => 'edit_email',
			'type' => 'email',
			'for' => 'user_register_modal',
			'visible' => 'logged_in',
			'validation' => array(
				'required' => true,
				'laxEmail' => true
			),
			'callback' => 'extretion_check_user_email',
			'value' => get_the_author_meta( 'user_email' , $user_id )
		),
		array(
			'label' => esc_html__( 'Paypal Email' , 'extretion' ),
			'label_class' => 'hide_label col-sm-4 col-md-3 control-label',
			'id' => 'paypal_email',
			'class' => 'form-control mb-5',
			'name' => 'paypal_email',
			'type' => 'text',
			'for' => 'user_register_modal',
			'visible' => 'logged_in',
			'validation' => array(
				'laxEmail' => true
			),
			'callback' => 'extretion_check_paypal_email',
			'help_text' => esc_html__( 'The email associated with your PayPal account. If this is empty then you cannot receive the payments through PayPal.' , 'extretion' ),
		),
		array(
			'type' => 'custom_message',
			'label_class' => 'hide_label col-sm-4 col-md-3 control-label',
			'label' => esc_html__( '&#32;' , 'extretion' ),
			'for' => 'user_register_modal',
			'name' => 'stripe_button',
			'content' => '<div class="stripe_connect_btn">' . $stripe_btn . '</div>'
		),
		array(
			'placeholder' => esc_html__( 'Password' , 'extretion' ),
			'label_class' => 'hide_label',
			'id' => 'register_password',
			'class' => 'form-control mb-5',
			'name' => 'register_password',
			'type' => 'password',
			'validation' => array(
				'required' => true,
				'atleastNum' => ( $password_strength == 2 ? true : false ),
				'atleastlowercase' => ( $password_strength == 2 ? true : false ),
				'atleastuppercase' => ( $password_strength == 2 ? true : false ),
				'minlength' => 5,
				'specialcharacter' => ( $password_strength == 2 ? true : false )
			),
			'validation_msg' => array(
				'required' => esc_html__( "Please provide a password" , 'extretion' ),
				'minlength' => esc_html__( "Your password must be at least 5 characters long" , 'extretion' ),
			),
			'for' => 'user_register_modal',
			'visible' => 'not_logged_in' // logged_in
		),
		array(
			'placeholder' => esc_html__( 'Confirm Password' , 'extretion' ),
			'label_class' => 'hide_label',
			'id' => 'register_password_confirm',
			'class' => 'form-control mb-5',
			'name' => 'register_password_confirm',
			'type' => 'password',
			'validation' => array(
				'required' => true,
				'minlength' => 5,
				'equalTo' => "#register_password"
			),
			'validation_msg' => array(
				'required' => esc_html__( "Please provide a password" , 'extretion' ),
				'minlength' => esc_html__( "Your password must be at least 5 characters long" , 'extretion' ),
				'equalTo' => esc_html__( "Please enter the same password as above" , 'extretion' )
			),
			'for' => 'user_register_modal',
			'visible' => 'not_logged_in' // logged_in
		),
		array(
			'type' => ( class_exists( 'ReallySimpleCaptcha' ) && $captcha_status == 1 ) ? 'captcha' : '',
			'for' => 'user_register_modal',
			'name' => 'user_input_captcha',
			'label_class' => 'captcha_registration_label',
			'validation' => array(
				'required' => true,
			),
			'validation_msg' => array(
				'required' => esc_html__( "Please type above letters" , 'extretion' ),
			),
			'visible' => 'not_logged_in' // logged_in
		),
		array(
			'type' => 'text',
			'label_class' => 'col-sm-4 col-md-3 control-label',
			'name' => 'mobile_no',
			'placeholder' => esc_html__( 'Mobile Number' , 'extretion' ),
			'label' => esc_html__( 'Mobile Number' , 'extretion' ),
			'class' => 'form-control mb-5 ' . (( $digitStatus == 'enable' ) ? 'disabledWrapper' : ''),
			'callback' => 'extretion_check_register_mobile',
			'for' => 'user_register_modal',
			'visible' => 'logged_in',
			'disabled' => ( $digitStatus == 'enable' ) ? true : false,
			'help_text' => ( $digitStatus == 'enable' ) ? sprintf( __( '%s to verify your mobile no.' , 'extretion' ) , '<a href="' . $mobileVerification . '">' . esc_html__( 'Click Here' , 'extretion' ) . '</a>' ) : '',

		),
		array(
			'type' => 'text',
			'label_class' => 'col-sm-4 col-md-3 control-label',
			'name' => 'website',
			'placeholder' => esc_html__( 'Website' , 'extretion' ),
			'label' => esc_html__( 'Website' , 'extretion' ),
			'class' => 'form-control mb-5',
			'callback' => 'extretion_check_website',
			'for' => 'user_register_modal',
			'visible' => 'logged_in',
			'validation' => array(
				'url' => true
			),
		),
		array(
			'label' => esc_html__( 'Languages Spoken' , 'extretion' ),
			'label_class' => 'col-sm-4 col-md-3 control-label',
			'id' => 'language_spoken',
			'required' => true,
			'class' => 'selectpicker mb-5',  
			'live_search' => true, // only for multiselect
			'data_size' => 5, // only for multiselect
			'name' => 'language_spoken[]',
			'type' => 'multiselect',
			'value' => extretion_language_options(),
			'validation' => array(
				'required' => true,
			),
			'for' => 'user_register_modal',
			'visible' => 'logged_in',
			'callback' => 'extretion_requiredPostValue',
			'callback_error_message' => esc_html__( 'Please select your spoken languages.' , 'extretion' ),
		),
		array(
			'label' => esc_html__( 'Where&#39;s your place?' , 'extretion' ),
			'label_class' => 'col-sm-4 col-md-3 control-label',
			'id' => 'hotel_located',
			'required' => true,
			'class' => 'form-control mb-0 googleClass',
			'name' => 'hotel_located',
			'type' => 'google_map',
			'validation' => array(
				'required' => true,
			),
			'validation_msg' => array(
				'required' => esc_html__( "Please select your place" , 'extretion' ),
			),
			'for' => 'user_register_modal',
			'help_text' => esc_html__( 'You can move the marker to your place.' , 'extretion' ),
			'callback' => 'extretion_requiredPostValue',
			'callback_error_message' => esc_html__( 'Please add your place on the google map' , 'extretion' ),
			'visible' => 'logged_in'
		),
		array(
			'type' => 'hidden',
			'label_class' => 'hide_label',
			'name' => 'register_hotel_user',
			'value' => '1',
			'for' => 'user_register_modal',
			'visible' => 'not_logged_in',
		),
		array(
			'type' => 'hidden',
			'label_class' => 'hide_label',
			'name' => '_register_user_nonce',
			'value' => wp_create_nonce( 'register_user_nonce' ),
			'for' => 'user_register_modal',
			'visible' => 'not_logged_in',
		),
		// Check "edit_profile_user" value before saving
		array(
			'type' => 'hidden',
			'label_class' => 'hide_label',
			'name' => 'edit_profile_user',
			'value' => '1',
			'for' => 'user_register_modal',
			'visible' => 'logged_in',
			'static_value' => true
		),
		array(
			'label' => esc_html__( '' , 'extretion' ),
			'label_class' => 'col-sm-4 col-md-3 control-label hidden-xs',
			'id' => 'edit_profile_submit',
			'class' => 'btn btn-danger',
			'name' => 'edit_profile_submit',
			'type' => 'button',
			'value' => esc_html__( 'Save Profile' , 'extretion' ),
			'for' => 'user_register_modal',
			'visible' => 'logged_in'
		)
	);
	
	foreach ( $args as $key => $value) {

		if( !empty( $value['id'] ) && $value['id'] == 'paypal_email' ){

			/**
			* Disable PayPal 
			*/

			if( get_option( 'options_paypal_status' ) == 1 ){
				unset( $args[$key] );
			}

		}

		if( !empty( $value['name'] ) && $value['name'] == 'stripe_button' ){

			/**
			* Disable Stripe 
			*/

			if( get_option( 'options_stripe_status' ) == 1 ){
				unset( $args[$key] );
			}

		}

	}

	$args = apply_filters( 'extretion_user_register_modal' , $args );

	return $args;

}

function extretion_check_paypal_email( $value ){

	if( empty( $value ) ){
		return true;
	}

	if( !is_email( $value ) ){
		return array( 
			'result' => false,
			'message' => esc_html__( 'Not a valid email address.' , 'extretion' )
		);
	}

	return true;

}

function extretion_language_options(){

	$lang = extretion_language_spoken();
	$language_array =  array();

	foreach( $lang as $value ){
		$language_array[$value] = $value;
	}
	return $language_array;

}

function extretion_get_all_languages(){

	$lang = array('Afar','Afrikaans','Akan','Albanian','Amharic','Arabic','Aragonese','Armenian','Assamese','Avaric','Avestan','Aymara','Azerbaijani','Bambara','Bashkir','Basque','Belarusian','Bengali','Bihari','Bislama','Bosnian','Breton','Bulgarian','Burmese','Catalan','Chamorro','Chechen','Chinese','Church Slavic','Chuvash','Cornish','Corsican','Cree','Croatian','Czech','Danish','Divehi','Dutch','Dzongkha','English','Esperanto','Estonian','Ewe','Faroese','Fijian','Finnish','French','Fulah','Galician','Ganda','Georgian','German','Greek','Guarani','Gujarati','Haitian','Hausa','Hebrew','Herero','Hindi','Hiri Motu','Hungarian','Icelandic','Ido','Igbo','Indonesian','Interlingua','Interlingue','Inuktitut','Inupiaq','Irish','Italian','Japanese','Javanese','Kalaallisut','Kannada','Kanuri','Kashmiri','Kazakh','Khmer','Kikuyu','Kinyarwanda','Komi','Kongo','Korean','Kuanyama','Kurdish','Kyrgyz','Lao','Latin','Latvian','Limburgish','Lingala','Lithuanian','Luba-Katanga','Luxembourgish','Macedonian','Malagasy','Malay','Malayalam','Maltese','Manx','Maori','Marathi','Marshallese','Moldavian','Mongolian','Nauru','Navajo','Ndonga','Nepali','North Ndebele','Northern Sami','Norwegian','','Norwegian Nynorsk','Nyanja','Occitan','Ojibwa','Oriya','Oromo','Ossetic','Pali','Pashto','Persian','Polish','Portuguese','Punjabi','Quechua','Romanian','Romansh','Rundi','Russian','Samoan','Sango','Sanskrit','Sardinian','Scottish Gaelic','Serbian','Serbo-Croatian','Shona','Sichuan Yi','Sindhi','Sinhala','Slovak','Slovenian','Somali','South Ndebele','Southern Sotho','Spanish','Sundanese','Swahili','Swati','Swedish','Tagalog','Tahitian','Tajik','Tamil','Tatar','Telugu','Thai','Tibetan','Tigrinya','Tongan','Tsonga','Tswana','Turkish','Turkmen','Twi','Ukrainian','Urdu','Uyghur','Uzbek','Venda','Vietnamese','Volapuk','Walloon','Welsh','Western Frisian','Wolof','Xhosa','Yiddish','Yoruba','Zhuang','Zulu');

	return $lang;

}

//add_action( 'init' , 'lmh_language_spoken' );
function extretion_language_spoken() {
    return extretion_get_all_languages();
}

function extretion_getValidationRules( $args , $for ){

	$rules = array();
	
	$user_id = get_current_user_id();

	foreach( $args as $value ){	

		$status = false;

		if( !empty( $value['type'] ) && $value['type'] == 'file' ){

			$key_name = str_replace( array( '[' , ']' ), '', $value['name'] );

			// If file exists do not validate the file field
			if( $for == 'user_meta' ){
				$image_id = get_user_meta( $user_id , $key_name , true );
			} else {
				$image_id = get_post_meta( $user_id , $key_name , true );				
			}
		 	
			$image_details = !empty( $image_id ) ? wp_get_attachment_image_src( $image_id[0] , 'thumbnail' ) : '';

		 	if( !empty( $image_details ) ){
		 		$status = true;
		 	}

		}		

		if( !empty( $value['validation'] ) && $status == false ){

			//echo '<pre>'; print_r($value); echo '</pre>';

			$name = $value['name'];	
			
			$rules[$name] = $value['validation'];

		}

	}
	//echo '<pre>'; print_r($rules); echo '</pre>';
	return $rules;

}

function extretion_registerModalMessage(){

	$args = extretion_getRegisterArguments();
	return extretion_getValidationMessage( $args );

}

function extretion_getValidationMessage( $args ){

	$msg = array();

	foreach( $args as $value ){

		if( !empty( $value['validation_msg'] ) ){

			$name = $value['name'];
			$msg[$name] = $value['validation_msg'];

		}

	}

	//echo '<pre>'; print_r($msg); echo '</pre>';
	return $msg;

}

function extretion_listYourRoomRules(){

	$args = extretion_listYourPropertyFields();

	$data = array();
	foreach( $args as $value ){
		foreach( $value['fields'] as $fields ){
			$data[] = $fields;
		}
	}			

	return extretion_getValidationRules( $data , 'post_meta' );

}

function extretion_get_guide_categories(){

	$tax = extretion_getAllTermsArray( 'guide_cat' );
	if( !empty( $tax ) && is_array( $tax ) ){

		echo '<option value="">' . esc_html__( 'Select Category' , 'extretion' ) . '</option>';

		foreach( $tax as $key => $value ){

			echo '<option value="' . $key . '">' . $value . '</option>';

		}

	}

}

function extretion_getAllTermsArray( $taxonomy ){
	$terms = get_terms( array(
	    'taxonomy' => $taxonomy,
	    'hide_empty' => false,
	) );

	if( empty( $terms ) || is_wp_error( $terms )){ 
		return false;
	}

	$data = array();
	foreach( $terms as $value ){
		$data[$value->term_id] = $value->name;
	}

	return $data;
}

function extretion_getUsermeta( $meta ){

	if( is_user_logged_in() ){
		$user_id = get_current_user_id();
		return get_the_author_meta( $meta , $user_id );
	} else {
		return null;
	}

}

function extretion_checkDisableListMyRoom(){

	if( is_user_logged_in() ){
		return true;
	} else {
		return false;
	}

}

function extretion_listYourRoomMessage(){

	$args = extretion_listYourPropertyFields();
	$data = array();
	foreach( $args as $value ){
		foreach( $value['fields'] as $fields ){
			$data[] = $fields;
		}
	}
	return extretion_getValidationMessage( $data );

}

function extretion_getFaqCategoryPost( $cat_id , $id , $layout ){ 

	$style = ( $layout == 2 ? 'style-2' : '' );

	$args = array(
		'post_type' => 'faqs',
		'post_status' => 'publish',
		'posts_per_page' => -1,
		'tax_query' => array(
			array(
				'taxonomy' => 'faq_cat',
				'field'    => 'id',
				'terms'    => $cat_id,
			),
		),
	); 

	$query = new WP_Query( $args );

	if( $query->have_posts() ):

		echo '<div class="accordion-wrapper faq-accordion-wrapper ' . $style . '" id="faqAccordion' . $id . '" role="tablist" aria-multiselectable="true">';

		while( $query->have_posts() ): $query->the_post();

			global $post; 

			$rand = wp_generate_password( 16, false , false ); ?>

			<div class="panel accordion-item">
				<div class="accordion-heading" role="tab" id="faqAccordionOneHeader<?php echo esc_html( $rand );?>">
					<h4 class="panel-title">
						<a class="collapsed" data-toggle="collapse" data-parent="#faqAccordionOne" href="#faqAccordion<?php echo esc_html( $rand ); ?>" aria-expanded="true" aria-controls="faqAccordion<?php echo esc_html( $rand ); ?>"><?php the_title(); ?></a>
					</h4>
				</div>

				<div id="faqAccordion<?php echo esc_html( $rand ); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="faqAccordionOneHeader<?php echo esc_html( $rand ); ?>">
					<div class="panel-body">
						<div class="accordion-inner">							
							<?php the_content(); ?>
						</div>
					</div>
				</div>
			</div>

			<?php

		endwhile;

		wp_reset_postdata();

		echo '</div>';

	endif; 

}

function extretion_guestAccomodate(){

	$data = array();

	for( $i = 1; $i <= apply_filters( 'extretion_accomodate_guest', 10 ); $i++) { 
		$data[$i] = $i;
	}

	return $data;

}

/**
* List Your Property Elements
*/

function extretion_listYourPropertyFields(){

	$max_photos_upload_detail_page = get_option( 'options_max_photos_upload_detail_page' );
	$max_photos_upload_detail_page = is_numeric( $max_photos_upload_detail_page ) ? $max_photos_upload_detail_page : 10;

	$args = array(
		array(
			'main_title' => esc_html__( 'Tell us about your place' , 'extretion' ),
			'number' => 1,
			'fields' => array(
				array(
					'label' => esc_html__( 'Type of place' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'type_of_place',
					'required' => true,
					'class' => 'selectpicker mb-5',
					'name' => 'type_of_place',
					'type' => 'select',
					'live_search' => true,
					'data_size' => 5, // only for multiselect
					'value' => extretion_getAllTermsArray( 'type_of_place' ),
					'taxonomy' => true,
					'taxonomy_name' => 'type_of_place',
					'validation' => array(
						'required' => true,
					),
					'validation_msg' => array(
						'required' => esc_html__( "Please select one place" , 'extretion' ),
					),
					'for' => 'list_my_property',
					'callback' => 'extretion_requiredPostValue',
					'callback_error_message' => esc_html__( 'Please select type of place' , 'extretion' ),
					'sanitize_callback' => 'extretion_validNumber' // Allow only numbers
				),
				array(
					'label' => esc_html__( 'Space Offered' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'space_offered',
					'required' => true,
					'class' => 'selectpicker mb-5',
					'name' => 'space_offered',
					'type' => 'select',
					'value' => extretion_getAllTermsArray( 'space_offered' ),
					'taxonomy_name' => 'space_offered',
					'taxonomy' => true,
					'validation' => array(
						'required' => true,
					),
					'validation_msg' => array(
						'required' => esc_html__( "Please select one place" , 'extretion' ),
					),
					'for' => 'list_my_property',
					'help_text' => esc_html__( 'How much of this place are you renting out?' , 'extretion' ),
					'callback' => 'extretion_requiredPostValue',
					'callback_error_message' => esc_html__( 'Please select space offered' , 'extretion' ),
					'sanitize_callback' => 'extretion_validNumber' // Allow only numbers
				),
				array(
					'label' => esc_html__( 'Accommodates' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'guest_accomodate',
					'required' => true,
					'class' => 'selectpicker mb-5',
					'data_size' => 5,
					'name' => 'guest_accomodate',
					'type' => 'select',
					'value' => extretion_guestAccomodate(),
					'validation' => array(
						'required' => true,
					),
					'validation_msg' => array(
						'required' => esc_html__( "Please select one place" , 'extretion' ),
					),
					'for' => 'list_my_property',
					'help_text' => esc_html__( 'How many guests can your place accommodate?' , 'extretion' ),
					'callback' => 'extretion_requiredPostValue',
					'callback_error_message' => esc_html__( 'Please select accommodates' , 'extretion' ),
					'sanitize_callback' => 'extretion_validNumber' // Allow only numbers
				),
				array(
					'label' => esc_html__( 'Where&#39;s your place?' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'place_located',
					'required' => true,
					'class' => 'form-control mb-0 googleClass',
					'name' => 'place_located',
					'type' => 'google_map',
					'validation' => array(
						'required' => true,
					),
					'validation_msg' => array(
						'required' => esc_html__( "Please select one place" , 'extretion' ),
					),
					'for' => 'list_my_property',
					'help_text' => esc_html__( 'You can move the marker to your place.' , 'extretion' ),
					'callback' => 'extretion_requiredPostValue',
					'callback_error_message' => esc_html__( 'Please add your place on the google map' , 'extretion' ) 
				),
				array(
					'label' => esc_html__( 'Check In Time' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'check_in_time',
					'required' => true,
					'data_size' => 5,
					'class' => 'selectpicker mb-5',
					'name' => 'check_in_time',
					'type' => 'select',
					'value' => extretion_halfHourTimes(),
					'validation' => array(
						'required' => true,
					),
					'validation_msg' => array(
						'required' => esc_html__( "Please select check in time." , 'extretion' ),
					),
					'for' => 'list_my_property',
					'callback' => 'extretion_requiredPostValue',
					'callback_error_message' => esc_html__( 'Please select check in time.' , 'extretion' ),
					//'sanitize_callback' => 'extretion_validNumber' // Allow only numbers
				),
				array(
					'label' => esc_html__( 'Check Out Time' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'check_out_time',
					'required' => true,
					'class' => 'selectpicker mb-5',
					'data_size' => 5,
					'name' => 'check_out_time',
					'type' => 'select',
					'value' => extretion_halfHourTimes(),
					'validation' => array(
						'required' => true,
					),
					'validation_msg' => array(
						'required' => esc_html__( "Please select check out time." , 'extretion' ),
					),
					'for' => 'list_my_property',
					'callback' => 'extretion_requiredPostValue',
					'callback_error_message' => esc_html__( 'Please select check out time.' , 'extretion' ),
					//'sanitize_callback' => 'extretion_validNumber' // Allow only numbers
				),
			),							
		),
		array(
			'main_title' => esc_html__( 'Your Room Details' , 'extretion' ),
			'number' => 2,
			'fields' => array(
				array(
					'label' => esc_html__( 'Title' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'room_title',
					'required' => true,
					'class' => 'form-control mb-0',
					'name' => 'room_title',
					'type' => 'text',
					'for' => 'list_my_property',
					'validation' => array(
						'required' => true,
					),
					'callback' => 'extretion_requiredPostValue',
					'callback_error_message' => esc_html__( 'Please add a title.' , 'extretion' ) 
				),					
				array(
					'label' => esc_html__( 'Photos' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'room_photos',
					'required' => true,
					'class' => 'filer_input',
					'name' => 'room_photos[]',
					'type' => 'file',
					'for' => 'list_my_property',
					'validation' => array(
						'required' => true,
					),
					'callback' => 'extretion_checkImagesFiles',
					'sanitize_callback' => 'extretion_save_image_attachment',
					'limit' => $max_photos_upload_detail_page, // no of files
					'max_size' => 10, // In MB
					'extensions' => array( 'png','jpg','jpeg','gif','bmp' ), // allowed extensions
					'input_label' => esc_html__( 'Upload Room Photos' , 'extretion' ),
					'ignore_pages_template' => array( 'page-templates/room-edit.php' )
				),
				array(
					'label' => esc_html__( 'Description' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'room_description',
					'required' => true,
					'class' => 'form-control mb-5',
					'name' => 'room_description',
					'type' => 'textarea',
					'for' => 'list_my_property',
					'rows' => 8,
					'validation' => array(
						'required' => true,
						'minlength' => 50,
					),
					'callback' => 'extretion_requiredPostValue',
					'callback_error_message' => esc_html__( 'Please add a description.' , 'extretion' )
				),
				array(
					'label' => esc_html__( 'Number of Bathroom' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'room_bathroom',
					'required' => true,
					'class' => 'selectpicker mb-5',
					'data_size' => 5,
					'name' => 'room_bathroom',
					'type' => 'select',
					'value' => array( 1 => 1 , 2 => 2 , 3 => 3 , 4 => 4 , 5 => 5 ),
					'validation' => array(
						'required' => true,
					),
					'validation_msg' => array(
						'required' => esc_html__( "Please select number of bathrooms." , 'extretion' ),
					),
					'for' => 'list_my_property',
					'callback' => 'extretion_requiredPostValue',
					'callback_error_message' => esc_html__( 'Please select number of bathrooms.' , 'extretion' ),
					'sanitize_callback' => 'extretion_validNumber' // Allow only numbers
				),
				array(
					'label' => esc_html__( 'Bed Type' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'bed_type',
					'required' => true,
					'class' => 'selectpicker mb-5',
					'data_size' => 5,
					'live_search' => true,
					'name' => 'bed_type',
					'type' => 'select',
					'value' => extretion_getAllTermsArray( 'bed_types' ),
					'taxonomy_name' => 'bed_types',
					'taxonomy' => true,
					'validation' => array(
						'required' => true,
					),
					'validation_msg' => array(
						'required' => esc_html__( "Please select a bed type." , 'extretion' ),
					),
					'for' => 'list_my_property',
					'callback' => 'extretion_requiredPostValue',
					'callback_error_message' => esc_html__( 'Please select a bed type.' , 'extretion' ),
					//'sanitize_callback' => 'extretion_validNumber' // Allow only numbers
				),
				array(
					'label' => esc_html__( 'Number of Bedrooms' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'no_of_bedroom',
					'required' => true,
					'class' => 'selectpicker mb-5',
					'data_size' => 5,
					'name' => 'no_of_bedroom',
					'type' => 'select',
					'value' => array( 1 => 1 , 2 => 2 , 3 => 3 , 4 => 4 , 5 => 5 , 6 => 6 , 7 => 7  ),
					'validation' => array(
						'required' => true,
					),
					'validation_msg' => array(
						'required' => esc_html__( "Please select no of bedrooms." , 'extretion' ),
					),
					'for' => 'list_my_property',
					'callback' => 'extretion_requiredPostValue',
					'callback_error_message' => esc_html__( 'Please select no of bedrooms.' , 'extretion' ),
					'sanitize_callback' => 'extretion_validNumber' // Allow only numbers
				),
				array(
					'label' => esc_html__( 'Number of Beds' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'no_of_bed',
					'required' => true,
					'class' => 'selectpicker mb-5',
					'data_size' => 5,
					'name' => 'no_of_bed',
					'type' => 'select',
					'value' => array( 1 => 1 , 2 => 2 , 3 => 3 , 4 => 4 , 5 => 5 , 6 => 6 , 7 => 7  ),
					'validation' => array(
						'required' => true,
					),
					'validation_msg' => array(
						'required' => esc_html__( "Please select no of beds." , 'extretion' ),
					),
					'for' => 'list_my_property',
					'callback' => 'extretion_requiredPostValue',
					'callback_error_message' => esc_html__( 'Please select no of beds.' , 'extretion' ),
					'sanitize_callback' => 'extretion_validNumber' // Allow only numbers
				),
				array(
					'label' => esc_html__( 'Amenities' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'amenities',
					'col' => 2,
					'required' => true,
					'class' => '',
					'name' => 'amenities[]',
					'type' => 'checkbox',
					'value' => extretion_getAllTermsArray( 'facility' ),
					'taxonomy_name' => 'facility',
					'taxonomy' => true,
					'for' => 'list_my_property',
					'validation' => array(
						'required' => true,
					),
					'callback' => 'extretion_requiredPostValue',
					'callback_error_message' => esc_html__( 'Please select some amenities.' , 'extretion' )
				),
			),
		),
		array(
			'main_title' => esc_html__( 'Pricing' , 'extretion' ),
			'number' => 3,
			'fields' => array(
				array(
					'type' => 'info_box',
					'label' => esc_html__( 'Pricing tips' , 'extretion' ),
					'label_class' => 'hide_label',
					'icon' => 'fa-lightbulb-o',
					'class' => 'pricing_tips',
					'name' => 'pricing_tips',
					'for' => 'list_my_property',
					'content' => sprintf( 
						wp_kses( 
							__( '<li>Choose a price which is attractive and easy for guests to compare.</li><li>After you enter the amount, we automatically show you how much your payout will be, adding the %1$d&#37; commission.</li>' , 'extretion' ),
							array( 
								'li' => array() 
							) 
						),
						get_option( 'options_commision_rate' ) ? get_option( 'options_commision_rate' , 'option' ) : 0 
					)
				),
				array(
					'label' => esc_html__( 'Your Currency' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'user_currency',
					'required' => true,
					'class' => 'selectpicker mb-5',
					'data_size' => 5,
					'live_search' => true,
					'name' => 'user_currency',
					'type' => 'select',
					'value' => extretion_worldCurrency(),
					'validation' => array(
						'required' => true,
					),
					'validation_msg' => array(
						'required' => esc_html__( "Please select your currency." , 'extretion' ),
					),
					'for' => 'list_my_property',
					'callback' => 'extretion_requiredPostValue',
					'callback_error_message' => esc_html__( 'Please select your currency.' , 'extretion' ),
					//'sanitize_callback' => 'extretion_validNumber' // Allow only numbers
				),
				array(
					'label' => esc_html__( 'Price per night' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'per_night_price',
					'required' => true,
					'class' => 'form-control mb-0',
					'name' => 'per_night_price',
					'type' => 'text',
					'for' => 'list_my_property',
					'before_input' => '<span class="lmh_before_input user_price_change"></span>',
					'validation' => array(
						'required' => true,
						'digits' => true,
						'min' => 1
					),
					'callback' => 'extretion_checkNumber',
				),
				array(
					'label' => sprintf( esc_html__( 'Total price after adding %d&#37; commision rate' , 'extretion' ) , sanitize_text_field( get_option( 'options_commision_rate' ) ) ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'total_price_per_night',
					'class' => 'form-control mb-0',
					'name' => 'total_price_per_night',
					'before_input' => '<span class="lmh_before_input user_price_change"></span>',
					'type' => 'text',
					'for' => 'list_my_property',
					//'help_text' => esc_html__( 'Price in USD' , 'extretion' ),
					'disabled' => true
				),
				array(
					'label' => esc_html__( 'Weekly Discount' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'weekly_discount',
					'class' => 'selectpicker mb-5',
					'data_size' => 5,
					'name' => 'weekly_discount',
					'type' => 'select',
					'value' => extretion_room_discount( $limit = 50 ),
					'for' => 'list_my_property',
					'sanitize_callback' => 'extretion_validNumber' // Allow only numbers
				),
				array(
					'label' => esc_html__( 'Monthly Discount' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'monthly_discount',
					'class' => 'selectpicker mb-5',
					'data_size' => 5,
					'name' => 'monthly_discount',
					'type' => 'select',
					'value' => extretion_room_discount( $limit = 50 ),
					'for' => 'list_my_property',
					'sanitize_callback' => 'extretion_validNumber' // Allow only numbers
				),
				array(
					'label' => esc_html__( 'Security deposit fee' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'security_deposit',
					'class' => 'form-control mb-0',
					'required' => true,
					'name' => 'security_deposit',
					'type' => 'text',
					'for' => 'list_my_property',
					'before_input' => '<span class="lmh_before_input user_price_change"></span>',
					'validation' => array(
						'required' => true,
						'digits' => true,
						'min' => 0
					),
					'callback' => 'extretion_checkServiceFee',
					'help_text' => esc_html__( 'Enter 0 for no security deposit' , 'extretion' ),
				),
				array(
					'label' => esc_html__( 'Service fee' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'cleaning_fee',
					'class' => 'form-control mb-0',
					'required' => true,
					'name' => 'cleaning_fee',
					'type' => 'text',
					'for' => 'list_my_property',
					'before_input' => '<span class="lmh_before_input user_price_change"></span>',
					'help_text' => esc_html__( 'Service fee for 1 night ( Enter 0 for no service fee )' , 'extretion' ),
					'validation' => array(
						'required' => true,
						'digits' => true,
						'min' => 0
					),
					'callback' => 'extretion_checkServiceFee',
				),
				array(
					'label' => esc_html__( 'Cancellation Policy' , 'extretion' ),
					'required' => true,
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'cancellation_policy',
					'class' => 'selectpicker mb-5',
					'name' => 'cancellation_policy',
					'type' => 'select',
					'for' => 'list_my_property',
					'value' => extretion_cancellation_policy(),
					'callback' => 'extretion_requiredPostValue',
					'callback_error_message' => esc_html__( 'Please select your cancellation policy.' , 'extretion' )
				),
				array(
					'label' => esc_html__( 'Min. Booking Duration' , 'extretion' ),
					'required' => true,
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'min_booking_duration',
					'class' => 'selectpicker mb-5',
					'data_size' => 5,
					'name' => 'min_booking_duration',
					'type' => 'select',
					'for' => 'list_my_property',
					'value' => extretion_min_booking_duration(),
					'callback' => 'extretion_requiredPostValue',
					'callback_error_message' => esc_html__( 'Please select your minimum booking duration.' , 'extretion' )
				),
				array(
					'label' => esc_html__( 'Charge Extra People?' , 'extretion' ),
					'required' => true,
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'charge_extra_people',
					'class' => 'selectpicker mb-5',
					'name' => 'charge_extra_people',
					'type' => 'select',
					'for' => 'list_my_property',
					'value' => array( 'yes' => 'Yes' , 'no' => 'No' ),
					'callback' => 'extretion_requiredPostValue',
					'callback_error_message' => esc_html__( 'Charge extra people? field is required' , 'extretion' ),
					'help_text' => __( 'If more than one guest, extra charge will be taken.<br>eg. If price per night is $10 & guest is 2 then price per night will be $20 ($10*2)' , 'extretion' ),
				)			
			),
		),
		array(
			'main_title' => esc_html__( 'Others' , 'extretion' ),
			'number' => 4,
			'fields' => array(
				array(
					'label' => esc_html__( 'Required at check in' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'required_at_check_in',
					'class' => 'form-control mb-5',
					'name' => 'required_at_check_in',
					'type' => 'textarea',
					'for' => 'list_my_property',
					'rows' => 8,
					'help_text' => esc_html__( 'For multiple messages write in a new line' , 'extretion' ),
					'sanitize_callback' => 'extretion_lineBreakTextarea'
				),
				array(
					'label' => esc_html__( 'Children' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'children_check_in',
					'class' => 'form-control mb-5',
					'name' => 'children_check_in',
					'type' => 'textarea',
					'for' => 'list_my_property',
					'rows' => 8,
					'help_text' => esc_html__( 'For multiple messages write in a new line' , 'extretion' ),
					'sanitize_callback' => 'extretion_lineBreakTextarea'
				),
				array(
					'label' => esc_html__( 'Pet Policy' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'pet_policy',
					'class' => 'form-control mb-5',
					'name' => 'pet_policy',
					'type' => 'textarea',
					'for' => 'list_my_property',
					'rows' => 8,
					'help_text' => esc_html__( 'For multiple messages write in a new line' , 'extretion' ),
					'sanitize_callback' => 'extretion_lineBreakTextarea'
				),
				array(
					'label' => esc_html__( 'Cancellation Policy' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'cancellation_policy_room',
					'class' => 'form-control mb-5',
					'name' => 'cancellation_policy_room',
					'type' => 'textarea',
					'for' => 'list_my_property',
					'rows' => 8,
					'help_text' => esc_html__( 'For multiple messages write in a new line' , 'extretion' ),
					'sanitize_callback' => 'extretion_lineBreakTextarea'
				),
				array(
					'label' => esc_html__( 'Payment Policy' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'id' => 'payment_policy_room',
					'class' => 'form-control mb-5',
					'name' => 'payment_policy_room',
					'type' => 'textarea',
					'for' => 'list_my_property',
					'rows' => 8,
					'help_text' => esc_html__( 'For multiple messages write in a new line' , 'extretion' ),
					'sanitize_callback' => 'extretion_lineBreakTextarea'
				),
			),
		),
		array(
			'main_title' => esc_html__( 'Your Details' , 'extretion' ),
			'number' => 5,
			'fields' => array(
				array(
					'label' => esc_html__( 'Username' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'type' => 'text',
					'name' => 'username',
					'value' => extretion_getUsermeta( 'user_login' ),
					'class' => 'form-control mb-0',
					'disabled' => extretion_checkDisableListMyRoom(),
					'required' => true,
					'for' => 'list_my_property',
					'validation' => array(
						'required' => true,
						'minlength' => 3
					),
					'ignore_pages_template' => array( 'page-templates/room-edit.php' )
				),
				array(
					'label' => esc_html__( 'Email' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'type' => 'text',
					'name' => 'email',
					'value' => extretion_getUsermeta( 'user_email' ),
					'class' => 'form-control mb-0',
					'disabled' => extretion_checkDisableListMyRoom(),
					'required' => true,
					'for' => 'list_my_property',
					'validation' => array(
						'required' => true,
						'laxEmail' => true
					),
					'ignore_pages_template' => array( 'page-templates/room-edit.php' )
				),
				array(
					'label' => esc_html__( 'Password' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'type' => 'password',
					'name' => 'lmh_password',
					'id' => 'lmh_password',
					'value' => '',
					'class' => 'form-control mb-0',
					'required' => true,
					'for' => 'list_my_property',
					'display' => 'guest',
					'validation' => array(
						'required' => true,
						'atleastNum' => true,
						'atleastlowercase' => true,
						'atleastuppercase' => true,
						'minlength' => 5,
						'specialcharacter' => true
					),
					'ignore_pages_template' => array( 'page-templates/room-edit.php' )
				),
				array(
					'label' => esc_html__( 'Confirm Password' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label',
					'type' => 'password',
					'name' => 'lmh_confirm_password',
					'value' => '',
					'class' => 'form-control mb-0',
					'required' => true,
					'for' => 'list_my_property',
					'display' => 'guest', // logged_in
					'validation' => array(
						'required' => true,
						'minlength' => 5,
						'equalTo' => "#lmh_password"
					),
					'ignore_pages_template' => array( 'page-templates/room-edit.php' )
				),
				array(
					'label' => esc_html__( '' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label hidden-xs',
					'id' => 'accept_terms',
					'col' => 1,
					'class' => '',
					'name' => 'accept_terms[]',
					'type' => 'checkbox',
					'value' => array( '1' => 
						sprintf( 
							wp_kses(
								__( 'Yes, I have read and accept the <a target="blank" class="underline" href="%1$s">Terms and conditions</a>' , 'extretion' ),
								array(
									'a' => array( 
										'href' => array(),
										'class' => array(),
										'target' => array(),
									)
								)
							),
							esc_url( get_permalink( get_option( 'options_terms_and_condition_page' ) ) )
						) 
					),
					'for' => 'list_my_property',
					'validation' => array(
						'required' => true,
					),
					'ignore_pages_template' => array( 'page-templates/room-edit.php' )
				),
				array(
					'name' => 'list_your_room_submit',
					'type' => 'hidden',
					'value' => true,
					'for' => 'list_my_property',
					'label_class' => 'hide_label'
				),
				array(
					'name' => 'lyr_nonce',
					'type' => 'hidden',
					'value' => wp_create_nonce( 'list_your_room_nonce' ),
					'for' => 'list_my_property',
					'label_class' => 'hide_label'
				),
				array(
					'name' => 'secret_key',
					'type' => 'hidden',
					'value' => wp_generate_password( $length = 32 , false, false ),
					'for' => 'list_my_property',
					'label_class' => 'hide_label'
				),
				array(
					'label' => esc_html__( '' , 'extretion' ),
					'label_class' => 'col-sm-4 col-md-3 control-label hidden-xs',
					'id' => 'list_my_room_id',
					'class' => 'btn btn-danger',
					'name' => 'list_my_room_name',
					'type' => 'button',
					'value' => esc_html__( 'Submit' , 'extretion' ),
					'for' => 'list_my_property',
				)
			),
		),
	);
	
	$args = apply_filters( 'extretion_list_your_property_fields' , $args );

	return $args;

}

function extretion_min_booking_duration(){

	return array(
		'1' => '1 Night Minimum',
		'2' => '2 Night Minimum',
		'3' => '3 Night Minimum',
		'4' => '4 Night Minimum',
		'5' => '5 Night Minimum',
		'6' => '6 Night Minimum',
		'7' => 'Weekly Rental Only',
		'14' => '2 Weeks Minimum',
		'21' => '3 Weeks Minimum',
		'30' => 'Monthly Rental Only',
	);

}

function extretion_cancellation_policy(){

	return array(
		'flexible' => esc_html__( 'Flexible' , 'extretion' ),
		'moderate' => esc_html__( 'Moderate' , 'extretion' ),
		'strict' => esc_html__( 'Strict' , 'extretion' ),
	);


}

function extretion_room_discount( $limit = 50 ){

	$discount = array();
	for ( $i=0; $i <= $limit; $i++ ) { 
		$discount[$i] = $i . '%';
	}
	return $discount;

}

function extretion_worldCurrency(){

	return array (
        'ALL' => 'Albania Lek ( ALL )',
		'AFN' => 'Afghanistan Afghani ( AFN )',
		'ARS' => 'Argentina Peso ( ARS )',
		'AWG' => 'Aruba Guilder ( AWG )',
		'AUD' => 'Australia Dollar ( AUD )',
		'BSD' => 'Bahamas Dollar ( BSD )',
		'AZN' => 'Azerbaijan New Manat ( AZN )',
		'BBD' => 'Barbados Dollar ( BBD )',
		'BDT' => 'Bangladeshi taka ( BDT )',
		'BYR' => 'Belarus Ruble ( BYR )',
		'BZD' => 'Belize Dollar ( BZD )',
		'BMD' => 'Bermuda Dollar ( BMD )',
		'BOB' => 'Bolivia Boliviano ( BOB )',
		'BAM' => 'Bosnia and Herzegovina Convertible Marka ( BAM )',
		'BWP' => 'Botswana Pula ( BWP )',
		'BGN' => 'Bulgaria Lev ( BGN )',
		'BRL' => 'Brazil Real ( BRL )',
		'BND' => 'Brunei Darussalam Dollar ( BND )',
		'KHR' => 'Cambodia Riel ( KHR )',
		'CAD' => 'Canada Dollar ( CAD )',
		'KYD' => 'Cayman Islands Dollar ( KYD )',
		'CLP' => 'Chile Peso ( CLP )',
		'CNY' => 'China Yuan Renminbi ( CNY )',
		'COP' => 'Colombia Peso ( COP )',
		'CRC' => 'Costa Rica Colon ( CRC )',
		'HRK' => 'Croatia Kuna ( HRK )',
		'CUP' => 'Cuba Peso ( CUP )',
		'CZK' => 'Czech Republic Koruna ( CZK )',
		'DKK' => 'Denmark Krone ( DKK )',
		'DOP' => 'Dominican Republic Peso ( DOP )',
		'XCD' => 'East Caribbean Dollar ( XCD )',
		'EGP' => 'Egypt Pound ( EGP )',
		'SVC' => 'El Salvador Colon ( SVC )',
		'EUR' => 'Euro Member Countries ( EUR )',
		'FKP' => 'Falkland Islands (Malvinas) Pound ( FKP )',
		'FJD' => 'Fiji Dollar ( FJD )',
		'GIP' => 'Gibraltar Pound ( GIP )',
		'GTQ' => 'Guatemala Quetzal ( GTQ )',
		'GYD' => 'Guyana Dollar ( GYD )',
		'GNF' => 'Guinean Franc ( GNF )',
		'HNL' => 'Honduras Lempira ( HNL )',
		'HKD' => 'Hong Kong Dollar ( HKD )',
		'HUF' => 'Hungary Forint ( HUF )',
		'ISK' => 'Iceland Krona ( ISK )',
		'INR' => 'India Rupee ( INR )',
		'IDR' => 'Indonesia Rupiah ( IDR )',
		'IRR' => 'Iran Rial ( IRR )',
		'ILS' => 'Israel Shekel ( ILS )',
		'JMD' => 'Jamaica Dollar ( JMD )',
		'JPY' => 'Japan Yen ( JPY )',
		'KZT' => 'Kazakhstan Tenge ( KZT )',
		'KPW' => 'Korea (North) Won ( KPW )',
		'KRW' => 'Korea (South) Won ( KRW )',
		'KGS' => 'Kyrgyzstan Som ( KGS )',
		'LAK' => 'Laos Kip ( LAK )',
		'LVL' => 'Latvia Lat ( LVL )',
		'LBP' => 'Lebanon Pound ( LBP )',
		'LRD' => 'Liberia Dollar ( LRD )',
		'LTL' => 'Lithuania Litas ( LTL )',
		'MKD' => 'Macedonia Denar ( MKD )',
		'MYR' => 'Malaysia Ringgit ( MYR )',
		'MUR' => 'Mauritius Rupee ( MUR )',
		'MXN' => 'Mexico Peso ( MXN )',
		'MNT' => 'Mongolia Tughrik ( MNT )',
		'MZN' => 'Mozambique Metical ( MZN )',
		'NAD' => 'Namibia Dollar ( NAD )',
		'NPR' => 'Nepal Rupee ( NPR )',
		'ANG' => 'Netherlands Antilles Guilder ( ANG )',
		'NZD' => 'New Zealand Dollar ( NZD )',
		'NIO' => 'Nicaragua Cordoba ( NIO )',
		'NGN' => 'Nigeria Naira ( NGN )',
		'NOK' => 'Norway Krone ( NOK )',
		'OMR' => 'Oman Rial ( OMR )',
		'PKR' => 'Pakistan Rupee ( PKR )',
		'PAB' => 'Panama Balboa ( PAB )',
		'PYG' => 'Paraguay Guarani ( PYG )',
		'PEN' => 'Peru Nuevo Sol ( PEN )',
		'PHP' => 'Philippines Peso ( PHP )',
		'PLN' => 'Poland Zloty ( PLN )',
		'QAR' => 'Qatar Riyal ( QAR )',
		'RON' => 'Romania New Leu ( RON )',
		'RUB' => 'Russia Ruble ( RUB )',
		'SHP' => 'Saint Helena Pound ( SHP )',
		'SAR' => 'Saudi Arabia Riyal ( SAR )',
		'RSD' => 'Serbia Dinar ( RSD )',
		'SCR' => 'Seychelles Rupee ( SCR )',
		'SGD' => 'Singapore Dollar ( SGD )',
		'SBD' => 'Solomon Islands Dollar ( SBD )',
		'SOS' => 'Somalia Shilling ( SOS )',
		'ZAR' => 'South Africa Rand ( ZAR )',
		'LKR' => 'Sri Lanka Rupee ( LKR )',
		'SEK' => 'Sweden Krona ( SEK )',
		'CHF' => 'Switzerland Franc ( CHF )',
		//'SRD' => 'Suriname Dollar ( SRD )',
		'SYP' => 'Syria Pound ( SYP )',
		'TWD' => 'Taiwan New Dollar ( TWD )',
		//'THB' => 'Thailand Baht ( THB )',
		'TTD' => 'Trinidad and Tobago Dollar ( TTD )',
		'TRY' => 'Turkey Lira ( TRY )',
		//'UAH' => 'Ukraine Hryvna ( UAH )',
		'GBP' => 'United Kingdom Pound ( GBP )',
		'UGX' => 'Uganda Shilling ( UGX )',
		'USD' => 'United States Dollar ( USD )',
		'UYU' => 'Uruguay Peso ( UYU )',
		'UZS' => 'Uzbekistan Som ( UZS )',
		// 'VEF' => 'Venezuela Bolivar ( VEF )',
		'VND' => 'Viet Nam Dong ( VND )',
		'XOF' => 'West African CFA franc ( XOF )',
		'YER' => 'Yemen Rial ( YER )',
    );

}

function extretion_getHTMLFields( $args , $edit = false , $user_meta = false , $post_meta = false ){

	if( empty( $args ) ){
		return false;
	}

	foreach( $args as $value ){

		do_action( 'extretion_before_get_field' , $value );

		if( !empty( $value['type'] ) ){
			
			switch ( $value['type'] ) {

				case 'text':
					extretion_getField( 'text' , $value , $edit , $user_meta , $post_meta );
					break;

				case 'email':
					extretion_getField( 'email' , $value , $edit , $user_meta , $post_meta );	
					break;

				case 'password':
					extretion_getField( 'password' , $value );
					break;

				case 'hidden':
					extretion_getField( 'hidden' , $value , $edit , $user_meta , $post_meta );
					break;

				case 'file':
					extretion_getField( 'file' , $value , $edit , $user_meta , $post_meta );
					break;

				case 'google_map':
					extretion_getField( 'google_map' , $value , $edit , $user_meta , $post_meta );
					break;

				case 'select':
					extretion_getField( 'select' , $value , $edit , $user_meta , $post_meta );
					break;

				case 'textarea':
					extretion_getField( 'textarea' , $value , $edit , $user_meta , $post_meta );
					break;

				case 'checkbox':
					extretion_getField( 'checkbox' , $value , $edit , $user_meta , $post_meta );
					break;

				case 'button':
					extretion_getField( 'submit' , $value );
					break;

				case 'info_box':
					extretion_getField( 'info_box' , $value );
					break;

				case 'multiselect':
					extretion_getField( 'multiselect' , $value , $edit , $user_meta , $post_meta );
					break;

				case 'captcha':
					extretion_getField( 'captcha' , $value );
					break;

				case 'custom_message':
					extretion_getField( 'custom_message' , $value );
					break;
				
				default:
					# code...
					break;
			}

		}

		do_action( 'extretion_after_get_field' , $value );

	}

}

function extretion_checkUserPrevilage( $value ){

	if( empty( $value['display'] ) ){
		return true;
	} elseif( !empty( $value['display'] ) && $value['display'] == 'guest' && !is_user_logged_in() ){
		return true;
	} elseif( !empty( $value['display'] ) && $value['display'] == 'logged_in' && is_user_logged_in() ){
		return true;
	} else {
		return false;
	}

}

function extretion_getLabel( $value ){ ?>

	<label class="<?php echo ( !empty( $value['label_class'] ) ? $value['label_class'] : '' ); ?>">
		<?php 
		// Name of the Field
		echo ( !empty( $value['label'] ) ? $value['label'] : '' ); 

		if( !empty( $value['required'] ) && $value['required'] == true ){ ?> 
			<span class="text-danger">*</span>
			<?php
		} ?>

	</label>

	<?php
}

function extretion_getHelpText( $value ){

	$allowed_html = array(
	    'br' => array(),
	    'a' => array(
	    	'href' => array()
	    )
	);

	if( !empty( $value['help_text'] ) ){
		echo '<label class="control-label mb-10"><span class="mt-5 mb-0 line14 font-italic text-muted">';
		echo wp_kses( $value['help_text'] , $allowed_html );
		echo '</span></label>';
	}

}

function check_user_status( $value ){

	if( empty( $value['visible'] ) ){
		return true;
	} elseif( $value['visible'] == 'not_logged_in' && !is_user_logged_in()){
  		return true;
	} elseif( $value['visible'] == 'logged_in' && is_user_logged_in()){
  		return true;
	}
	return false;

}

function extretion_getDefaultFieldValue( $value , $type = null , $user_meta , $post_meta ){

	// IF post value exists
	$name = $value['name'];
	$user_id = get_current_user_id();

	//echo '<pre>'; print_r( $value ); echo '</pre>';

	if( !empty( $value['static_value'] ) && $value['static_value'] == true ){

		// $value['static_value'] will be same. It will not change/static value
		echo ( !empty( $value['value'] ) ? $value['value'] : '' );

	} elseif( $user_meta != false && empty( $value['value'] ) ){

		if( $name == 'edit_email' ){
			echo get_the_author_meta( 'user_email' , $user_id );
		} else{
			echo esc_html( get_user_meta( $user_id, $name , true ) );
		}

	} elseif( $post_meta == true && empty( $value['value'] ) ){

		$post_id = !empty( $_GET['id'] ) ? sanitize_text_field( $_GET['id'] ) : '';

		$strip_break = array( 
			'required_at_check_in', 
			'children_check_in', 
			'pet_policy',
			'cancellation_policy_room',
			'payment_policy_room'
		);

		if( $name == 'room_title' ){
			echo get_the_title( $post_id );
		} elseif( $name == 'room_description' ){
			$post = get_post( $post_id );
			echo esc_html( $post->post_content );
		} elseif( in_array( $name , $strip_break ) ){
			// Convert <br> to /n
			echo br2nl( get_post_meta( $post_id, $name , true ) );
		} else {
			echo esc_html( get_post_meta( $post_id, $name , true ) );
		}		

	} elseif( !empty( $_POST[$name] ) && $type != 'password' ){			

		echo sanitize_text_field( stripslashes( $_POST[$name] ) );

	} else {

		echo ( !empty( $value['value'] ) ? $value['value'] : '' );

	}

}

function br2nl( $input ) {
    return preg_replace('/<br\s?\/?>/ius', "\n", str_replace("\n","",str_replace("\r","", htmlspecialchars_decode($input))));
}

function extretion_getDefaultField( $value , $type , $edit = false , $user_meta = false , $post_meta = false ){

	$allowed_html = array(
	   "span" => array(
	   		"class" => array(),
	   		"id" => array()
	   	),
	   "div" => array(
	        "class" => array(),
	        "id" => array()
	    ),
	);

	if( !empty( $value['before_input'] ) ){
		echo wp_kses( 
			$value['before_input'], 
			$allowed_html 
		);
	}

	echo '<input';
	echo ' autocomplete="off"';
	echo ' type="' . $type . '"';

	if( !empty( $value['placeholder'] ) ){
		echo ' placeholder="' . $value['placeholder'] . '"';
	}

	if( !empty( $value['id'] ) ){
		echo ' id="' . $value['id'] . '"';
	}
	
	echo ' class="' . (!empty( $value['class'] ) ? $value['class'] : '') . '"';
	echo ' name="' . (!empty( $value['name'] ) ? $value['name'] : '') . '"';
	echo ( !empty( $value['disabled'] ) ? ' disabled="disabled"' : '' );
	echo ' value="';
	
	extretion_getDefaultFieldValue( $value, $type, $user_meta, $post_meta );

	echo '"';
	echo '>';

	extretion_getHelpText( $value );

	// Call the filer scripts
	extretion_addFilerScripts( $type , $edit , $value );

}

function extretion_addFilerScripts( $type , $edit , $value ){

	if( $type == 'file' /*&& $edit == true*/ ){ ?>

		<script>
			
		jQuery(".<?php echo esc_html( $value['class'] ); ?>").filer({
				limit: <?php echo ( !empty( $value['limit'] ) ? esc_js( $value['limit'] ) : 1 ); ?>,
				maxSize: <?php echo ( !empty( $value['max_size'] ) ? esc_js( $value['max_size'] ) : 1 ); ?>,
				extensions: <?php echo ( !empty( $value['extensions'] ) ? json_encode( $value['extensions'] ) : null ); ?>,
				changeInput: '<div class="jFiler-custom-wrapper"><a class="jFiler-btn-form">' + "<?php echo esc_html( $value['input_label'] ); ?>" + '</a></div>',
				showThumbs: true,
				templates: {
						box: '<ul class="jFiler-items-list jFiler-items-grid lmh_files_upload"></ul>',
						item: '<li class="jFiler-item">\
							<div class="jFiler-item-container">\
								<div class="jFiler-item-inner">\
									<div class="jFiler-item-thumb">\
										<div class="jFiler-item-status"></div>\
										<div class="jFiler-item-info">\
											<span class="jFiler-item-title"><b title="{{fi-name}}">{{fi-name | limitTo: 15}}</b></span>\
											<span class="jFiler-item-others">{{fi-size2}}</span>\
										</div>\
										{{fi-image}}\
									</div>\
									<div class="jFiler-item-assets jFiler-row">\
										<ul class="list-inline pull-left">\
											<li>{{fi-progressBar}}</li>\
										</ul>\
										<ul class="list-inline pull-right">\
											<li><a class="icon-jfi-trash jFiler-item-trash-action"></a></li>\
										</ul>\
									</div>\
								</div>\
							</div>\
						</li>',
						itemAppend: '<li class="jFiler-item">\
								<div class="jFiler-item-container">\
									<div class="jFiler-item-inner">\
										<div class="jFiler-item-thumb">\
											<div class="jFiler-item-status"></div>\
											<div class="jFiler-item-info">\
													<span class="jFiler-item-title"><b title="{{fi-name}}">{{fi-name | limitTo: 15}}</b></span>\
													<span class="jFiler-item-others">{{fi-size2}}</span>\
											</div>\
											{{fi-image}}\
										</div>\
										<div class="jFiler-item-assets jFiler-row">\
										</div>\
									</div>\
								</div>\
						</li>',
						progressBar: '<div class="bar"></div>',
						itemAppendToEnd: false,
						removeConfirmation: true,
						_selectors: {
								list: '.jFiler-items-list',
								item: '.jFiler-item',
								progressBar: '.bar',
								remove: '.jFiler-item-trash-action'
						}
				},
				files: <?php extretion_get_image_details( get_current_user_id() , $value['name'] ); ?>
			});

		</script>

		<?php
	}

}

function extretion_getField( $type , $value , $edit = false , $user_meta = false , $post_meta = false ){

	// Ignore page templates
	if(  !empty( $value['ignore_pages_template'] ) && is_page_template( $value['ignore_pages_template'] ) ){
		return;
	}

	// Show fields for logged in or non logged in
	if( check_user_status( $value ) == false ){
		return;
	}

	$result = extretion_checkUserPrevilage( $value );

	if( $result == false ){
		return;
	}

	do_action( 'extretion_before_user_label_' . $value['for'] , $value );
	extretion_getLabel($value);
	do_action( 'extretion_after_user_label_' . $value['for'] , $value );

	do_action( 'extretion_before_user_input_' . $value['for'] , $value );

	switch ( $type ) {

		case 'text':
		case 'email':
		case 'password':
		case 'hidden':
		case 'file':
		case 'submit':
			extretion_getDefaultField( $value , $type , $edit , $user_meta , $post_meta );
			break;

		case 'google_map':
			extretion_getGoogleMapField( $value , $edit , $user_meta , $post_meta );
			break;

		case 'select':
		case 'multiselect':
			extretion_getSelectField( $value , $edit , $user_meta , $post_meta );
			break;

		case 'textarea':
			extretion_getTextareaField( $value , $edit , $user_meta , $post_meta );
			break;

		case 'checkbox':
			extretion_getCheckboxField( $value , $edit , $user_meta , $post_meta );
			break;

		case 'info_box':
			extretion_getInfoBox( $value );
			break;

		case 'captcha':
			extretion_get_captcha( $value );
			break;

		case 'custom_message':
			extretion_get_custom_message( $value );
			break;

		default:
			# code...
			break;

	}
	
	do_action( 'extretion_after_user_input_' . $value['for'] , $value );

}

function extretion_get_custom_message( $value ){
	if( is_user_logged_in() ){
		echo $value['content'];
	}
}

/**
* If $edit == true then it is edit page
*/

function extretion_getRegisterModalFields( $edit = false , $user_meta = false , $post_meta = false ){

	$args = extretion_getRegisterArguments();

	//echo '<pre>'; print_r($args); echo '</pre>';

	extretion_getHTMLFields( $args , $edit , $user_meta , $post_meta );

}

function extretion_verificationMsg(){

	if( get_option( 'options_user_verification_success_message' ) ){
		echo get_option( 'options_user_verification_success_message' );
	} else {
		esc_html_e( 'Verification Process Completed' , 'extretion' );
	}

}

function extretion_successRegistrationMsg(){

	if( get_option( 'options_successfully_registration_message' ) ){
		echo esc_html( get_option( 'options_successfully_registration_message' ) );
	} else {
		esc_html_e( 'You have successfully registered on this site. Please check your email for verification message.' , 'extretion' );
	}

}

function extretion_loggoutRedirectTo(){

	global $wp;

	$redirect = get_permalink( get_option( 'options_after_loggout_completed' ) );

	$redirect = !empty( $redirect ) ? $redirect : esc_url( site_url( add_query_arg( array() , $wp->request )) );

	return $redirect;

}

// Breadcrumbs
function listmyhotel_custom_breadcrumbs() {
       
    // Settings
    $separator          = '/';
    $breadcrums_id      = 'breadcrumbs';
    $breadcrums_class   = 'breadcrumbs';
    $home_title         = esc_html__( 'Home' , 'extretion' );;
      
    // If you have any custom post types with custom taxonomies, put the taxonomy name below (e.g. product_cat)
    $custom_taxonomy    = 'destinations';
       
    // Get the query & post information
    global $post,$wp_query;
       
    // Do not display on the homepage
    if ( !is_front_page() ) {
           
        // Home page
        echo '<li class="item-home extretion-home"><a class="bread-link bread-home" href="' . esc_url( site_url() ) . '" title="' . $home_title . '">' . $home_title . '</a></li>';
        
        if ( is_single() ) {
              
            // Get post category info
            $category = get_the_category();

            if(!empty($category)) {
              
                // Get last category post is in
                $last_category =array_pop((array_slice($category, -1)));
                  
                // Get parent any categories and create array
                $get_cat_parents = rtrim(get_category_parents($last_category->term_id, true, ','),',');
                $cat_parents = explode(',',$get_cat_parents);
                  
                // Loop through parent categories and store in variable $cat_display
                $cat_display = '';
                foreach($cat_parents as $parents) {
                    $cat_display .= '<li class="item-cat">'.$parents.'</li>';
                    //$cat_display .= '<li class="separator"> ' . $separator . ' </li>';
                }
             
            }
              
            // If it's a custom post type within a custom taxonomy
            $taxonomy_exists = taxonomy_exists($custom_taxonomy);
            if(empty($last_category) && !empty($custom_taxonomy) && $taxonomy_exists) {
                   
                $taxonomy_terms = get_the_terms( $post->ID, $custom_taxonomy );

                if( !empty( $taxonomy_terms ) && is_array( $taxonomy_terms ) ){

                	$cat_id         = $taxonomy_terms[0]->term_id;
	                $cat_nicename   = $taxonomy_terms[0]->slug;
	                $cat_link       = get_term_link($taxonomy_terms[0]->term_id, $custom_taxonomy);
	                $cat_name       = $taxonomy_terms[0]->name;

                }
                
            }
              
            // Check if the post is in a category
            if(!empty($last_category)) {

                $allowed_html = array(
                	'li' => array(
                		'class' => array()
                	),
                	'a' => array(
                		'href' => array()
                	)
                );

                echo wp_kses( $cat_display , $allowed_html );
                echo '<li class="item-current item-' . $post->ID . '"><span class="bread-current active bread-' . $post->ID . '" title="' . get_the_title() . '">' . get_the_title() . '</span></li>';
                  
            // Else if post is in a custom taxonomy
            } else if(!empty($cat_id)) {
                  
                echo '<li class="item-cat item-cat-' . $cat_id . ' item-cat-' . $cat_nicename . '"><a class="bread-cat bread-cat-' . $cat_id . ' bread-cat-' . $cat_nicename . '" href="' . $cat_link . '" title="' . $cat_name . '">' . $cat_name . '</a></li>';
                //echo '<li class="separator"> ' . $separator . ' </li>';
                echo '<li class="item-current item-' . $post->ID . '"><span class="active bread-current bread-' . $post->ID . '" title="' . get_the_title() . '">' . get_the_title() . '</span></li>';
              
            } else {
                  
                echo '<li class="item-current item-' . $post->ID . '"><span class="active bread-current bread-' . $post->ID . '" title="' . get_the_title() . '">' . get_the_title() . '</span></li>';
                  
            }
              
        } elseif ( is_category() ) {
               
            // Category page
            echo '<li class="item-current item-cat"><span class="active bread-current bread-cat">' . single_cat_title('', false) . ' Category</span></li>';
               
        } elseif ( is_page() ) {
               
            // Standard page
            if( $post->post_parent ){
                   
                // If child page, get parents 
                $anc = get_post_ancestors( $post->ID );
                $parents = '';
                   
                // Get parents in the right order
                $anc = array_reverse($anc);
                   
                // Parent page loop
                foreach ( $anc as $ancestor ) {
                    $parents .= '<li class="item-parent item-parent-' . $ancestor . '"><a class="bread-parent bread-parent-' . $ancestor . '" href="' . get_permalink($ancestor) . '" title="' . get_the_title($ancestor) . '">' . get_the_title($ancestor) . '</a></li>';
                    //$parents .= '<li class="separator separator-' . $ancestor . '"> ' . $separator . ' </li>';
                }
                   
                // Display parent pages

                echo wp_kses( 
                	$parents, 
                	array(
                		'li' => array(
                			'class' => array()
                		),
                		'a' => array(
                			'class' => array(),
                			'href' => array(),
                			'title' => array()
                		),
                	)
                );
                   
                // Current page
                echo '<li class="item-current item-' . $post->ID . '"><span class="active" title="' . get_the_title() . '"> ' . get_the_title() . '</span></li>';
                   
            } else {
                   
                // Just display current page if not parents
                echo '<li class="item-current item-' . $post->ID . '"><span class="active bread-current bread-' . $post->ID . '"> ' . get_the_title() . '</span></li>';
                   
            }
               
        } elseif ( is_tag() ) {
               
            // Tag page
               
            // Get tag information
            $term_id        = get_query_var('tag_id');
            $taxonomy       = 'post_tag';
            $args           = 'include=' . $term_id;
            $terms          = get_terms( $taxonomy, $args );
            $get_term_id    = $terms[0]->term_id;
            $get_term_slug  = $terms[0]->slug;
            $get_term_name  = $terms[0]->name;
               
            // Display the tag name
            echo '<li class="item-current item-tag-' . $get_term_id . ' item-tag-' . $get_term_slug . '"><span class="active bread-current bread-tag-' . $get_term_id . ' bread-tag-' . $get_term_slug . '">' . $get_term_name . '</span></li>';
           
        } elseif ( is_day() ) {
               
            // Day archive
               
            // Year link
            echo '<li class="item-year item-year-' . get_the_time('Y') . '"><a class="bread-year bread-year-' . get_the_time('Y') . '" href="' . get_year_link( get_the_time('Y') ) . '" title="' . get_the_time('Y') . '">' . get_the_time('Y') . ' Archives</a></li>';
            //echo '<li class="separator separator-' . get_the_time('Y') . '"> ' . $separator . ' </li>';
               
            // Month link
            echo '<li class="item-month item-month-' . get_the_time('m') . '"><a class="bread-month bread-month-' . get_the_time('m') . '" href="' . get_month_link( get_the_time('Y'), get_the_time('m') ) . '" title="' . get_the_time('M') . '">' . get_the_time('M') . ' Archives</a></li>';
           // echo '<li class="separator separator-' . get_the_time('m') . '"> ' . $separator . ' </li>';
               
            // Day display
            echo '<li class="item-current item-' . get_the_time('j') . '"><span class="active bread-current bread-' . get_the_time('j') . '"> ' . get_the_time('jS') . ' ' . get_the_time('M') . ' Archives</span></li>';
               
        } elseif ( is_month() ) {
               
            // Month Archive
               
            // Year link
            echo '<li class="item-year item-year-' . get_the_time('Y') . '"><a class="bread-year bread-year-' . get_the_time('Y') . '" href="' . get_year_link( get_the_time('Y') ) . '" title="' . get_the_time('Y') . '">' . get_the_time('Y') . ' Archives</a></li>';
            //echo '<li class="separator separator-' . get_the_time('Y') . '"> ' . $separator . ' </li>';
               
            // Month display
            echo '<li class="item-month item-month-' . get_the_time('m') . '"><span class="active bread-month bread-month-' . get_the_time('m') . '" title="' . get_the_time('M') . '">' . get_the_time('M') . ' Archives</span></li>';
               
        } elseif ( is_year() ) {
               
            // Display year archive
            echo '<li class="item-current item-current-' . get_the_time('Y') . '"><span class="active bread-current bread-current-' . get_the_time('Y') . '" title="' . get_the_time('Y') . '">' . get_the_time('Y') . ' Archives</span></li>';
               
        } elseif ( is_author() ) {
               
            // Auhor archive
               
            // Get the author information
            global $author;
            $userdata = get_userdata( $author );

            // Display author name
            echo '<li class="item-current item-current-' . $userdata->user_nicename . '"><span class="active bread-current bread-current-' . $userdata->user_nicename . '" title="' . $userdata->display_name . '">' . 'Author: ' . $userdata->display_name . '</span></li>';
           
        } elseif ( is_search() ) {
           
           $search_title = explode( ',' , get_search_query() );
            // Search results page
            echo '<li class="item-current item-current-' . get_search_query() . '"><span class="active bread-current bread-current-' . get_search_query() . '" title="Search results for: ' . get_search_query() . '">' . esc_html__( 'Search results for:' , 'extretion' ) . ' ' . $search_title[0] . '</span></li>';
           
        } elseif ( is_404() ) {
               
            // 404 page
            echo '<li>' . 'Error 404' . '</li>';
        } elseif( is_tax() ){

        	$term = get_term_by("slug", get_query_var("term"), get_query_var("taxonomy") );

	        $tmpTerm = $term;
	        $tmpCrumbs = array();
	        while ($tmpTerm->parent > 0){
	            $tmpTerm = get_term($tmpTerm->parent, get_query_var("taxonomy"));
	            $crumb = '<li><a href="' . get_term_link($tmpTerm, get_query_var('taxonomy')) . '">' . $tmpTerm->name . '</a></li>';
	            array_push($tmpCrumbs, $crumb);
	        }
	        echo implode('', array_reverse($tmpCrumbs));
	        echo '<li class="item-current item-cat"><span class="active bread-current bread-cat">' . $term->name . '</span></li>';

        }
                  
    }
       
}

function extretion_blogListingSidebar(){ 
	extretion_getSidebar( 'blog_listing_sidebar' );
}

function extretion_roomDetailSidebar(){ 
	extretion_getSidebar( 'room_detail_sidebar' );
}

function extretion_getSidebar( $sidebar ){

	if ( is_active_sidebar( $sidebar ) ) { ?>
					
		<aside id="secondary" class="widget-area" role="">

			<div class="mb-10"></div>

				<?php dynamic_sidebar( $sidebar ); ?>

			<div class="mb-30"></div>

		</aside>

		<?php
	} else {
		get_sidebar(); 
	}

}

function extretion_blogListingLayout(){

	$blog_listing_layout = get_option( 'options_blog_listing_layout' );

	if( $blog_listing_layout != 1 ){
		return ' left-sidebar';
	}
}

function extretion_blogListingPublishedDate(){

	$blog_listing_published_date = get_option( 'options_blog_listing_published_date' );

	$blog_listing_published_date = $blog_listing_published_date == 1 ? true : false;

	return $blog_listing_published_date;

}

function extretion_blogListingFeaturedImage(){

	$blog_listing_featured_image = get_option( 'options_blog_listing_featured_image' );

	$blog_listing_featured_image = $blog_listing_featured_image == 1 ? true : false;

	return $blog_listing_featured_image;

}

function extretion_blogListingAuthor(){

	$blog_listing_author = get_option( 'options_blog_listing_author' );

	$blog_listing_author = $blog_listing_author == 1 ? true : false;

	return $blog_listing_author;

}

function extretion_blogListingCategory(){

	$blog_listing_category = get_option( 'options_blog_listing_category' );

	$blog_listing_category = $blog_listing_category == 1 ? true : false;

	return $blog_listing_category;

}

function extretion_blogListingPagination(){

	$blog_listing_pagination = get_option( 'options_blog_listing_pagination' );

	$blog_listing_pagination = $blog_listing_pagination == 1 ? 'default' : 'numbered';

	// Change max_num_pages on the taxonomy pages
	if( is_tax() ){
		global $wp_query;
		$no_of_rooms_category_page = get_option( 'options_no_of_rooms_category_page' );
		$wp_query->max_num_pages = ceil( $wp_query->found_posts / $no_of_rooms_category_page );
	}

	if( $blog_listing_pagination == 'default' ){
		echo '<div class="result-paging-wrapper">';
		the_posts_navigation(
			array(
		        'screen_reader_text' => ' '
		    )
		);
		echo '</div><div class="clear"></div>';
	} else {
		listMyHotelPagination();
	}

}

function extretion_getCategories( $post_id , $taxonomy , $args = array("fields" => "all") ){

	$data = wp_get_post_terms( $post_id, $taxonomy, $args );
	//echo '<pre>'; print_r( $data ); echo '</pre>';

	if( !empty( $data ) ){

		echo '<i class="fa fa-folder"></i> ';
		$lastElementKey = count($data);
		$i = 0;

		foreach( $data as $key => $value ){
			echo '<a href="' . get_term_link( $value ) . '"> ' . $value->name . '</a>';
			
			if( ++$i != $lastElementKey ){
				echo ', ';
			}
		}

	}

}

function extretion_string_limit_words($text, $limit) {

  	if (str_word_count($text, 0) > $limit) {
      $words = str_word_count($text, 2);
      $pos = array_keys($words);
      $text = substr($text, 0, $pos[$limit]) . '...';
  }
  return $text;

}

add_filter( 'extretion_check_post_data' , 'extretion_addNameToPost' , 10 , 2 );
function extretion_addNameToPost( $post , $arguments ){

	if( empty( $post['amenities'] ) && $arguments == 'extretion_listYourRoomArguments' ){
		$post['amenities'] = null;	
	}
	//echo '<pre>'; print_r($post); echo '</pre>';
	//print_r($arguments);
	return $post;		

}

function extretion_blogListingExcerpt(){

	$blog_listing_excerpt = get_option( 'options_blog_listing_excerpt' );

	$blog_listing_excerpt = !empty( $blog_listing_excerpt ) ? $blog_listing_excerpt : 100;

	return $blog_listing_excerpt;

}

function listMyHotelPagination( $pages = '', $range = 1 ) {  
    $showitems = ($range * 2)+1;  

    global $paged;
    if(empty($paged)){
     	$paged = 1;
    }

    if($pages == '') {
        
    	$no_of_rooms_category_page = get_option( 'options_no_of_rooms_category_page' );

        global $wp_query;
        $pages = (!empty( $no_of_rooms_category_page ) && !is_archive() ) ? ceil( $wp_query->found_posts / $no_of_rooms_category_page ) : $wp_query->max_num_pages;
        if(!$pages){
            $pages = 1;
        }
    }  
    //echo '<pre>'; print_r($wp_query);
    if(1 != $pages) {

        echo "<div class='result-paging-wrapper text-center'><ul class='paging_taxonomy'>";
        
        if($paged > 2 && $paged > $range+1 && $showitems < $pages){ 
         	echo "<li><a href='".get_pagenum_link(1)."'>&laquo;</a></li>";
        }

        if($paged > 1 && $showitems < $pages){ 
         	echo "<li><a href='".get_pagenum_link($paged - 1)."'>&lsaquo;</a></li>";
        }

        for ($i=1; $i <= $pages; $i++) {

            if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems )){
                echo ($paged == $i)? "<li class='active'><a href=''>".$i."</a></li>":"<li><a href='".get_pagenum_link($i)."' class='inactive' >".$i."</a></li>";
            }

        }

        if ($paged < $pages && $showitems < $pages){
         	echo "<li><a href='".get_pagenum_link($paged + 1)."'>&rsaquo;</a><li>";
        }  
        
        if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages){
         	echo "<li><a href='".get_pagenum_link($pages)."'>&raquo;</a></li>";
        }
        
        echo "</ul></div>\n";
    
    }

}

function extretion_listYourProperty( $edit = false , $user_meta = false , $post_meta = false ){

	$args = extretion_listYourPropertyFields();

	foreach( $args as $value ){ 

		//echo '<pre>'; print_r( $value ); echo '</pre>'; ?>

		<div class="metro-box-wrapper">
				
			<div class="heading with-number">
				<div class="number"><?php echo esc_attr( $value['number'] ); ?></div>
				<h3><?php echo esc_attr( $value['main_title'] ); ?></h3>
			</div>

			<div class="content">
			
				<div class="form-horizontal">
				
					<?php 
					if( !empty( $value['fields'] ) ):

						foreach( $value['fields'] as $fields ): 
							extretion_getHTMLFields( array( $fields ) , $edit , $user_meta , $post_meta );				
						endforeach;

					endif; 

					?>
				
				</div>
			
			</div>
		
		</div>

		<?php
	}

}

function extretion_saveListYourProperty( $edit = false ){

	$nonce = !empty( $_POST['lyr_nonce'] ) ? sanitize_text_field( $_POST['lyr_nonce'] ) : '';
	if( empty($_POST) || !wp_verify_nonce( $nonce, 'list_your_room_nonce' ) ){
		return;
	}

	$status = extretion_check_room_secret_key( $_POST );

	if( $status == false ){
		unset($_POST);
		return;
	}

	$_POST['lmh_files'] = !empty( $_FILES ) ? $_FILES : '';

	//echo '<pre>'; print_r($_POST); echo '</pre>';

	$validateResult = postValueCheck( $_POST , 'extretion_listYourRoomArguments' );

	//echo '<pre>'; print_r($validateResult);

	/**
	* If error, show the message and break the function
	*/

	if( $validateResult['check'] == true ){

		echo '<ul class="login_modal_error">' . $validateResult['errors'] . '</ul>';
		$errorFields = rtrim( $validateResult['errorFields'] ,','); ?>

		<script>
			
			jQuery( document ).ready(function(){

				jQuery( "<?php echo esc_attr( $errorFields ); ?>" ).addClass( 'errorphp' );

			});

		</script>

		<?php

	} else {

		//echo '<pre>'; print_r($_POST); echo '</pre>';

		extretion_check_data_before_saving( $_POST,'extretion_listYourRoomArguments' , $edit );

	}		

}

function extretion_getSelectField( $value , $edit , $user_meta , $post_meta ){

	//echo '<pre>'; print_r($value); echo '</pre>';

	$selected = !empty( $_POST[$value['name']] ) ? $_POST[$value['name']] : '';
	$multiple = $value['type'] == 'multiselect' ? 'multiple' : '';
	$live_search = ( !empty( $value['live_search'] ) && $value['live_search'] == true ) ? ' data-live-search="true" ' : '';
	$data_size = ( !empty( $value['data_size'] ) && is_numeric( $value['data_size'] ) ) ? ' data-size=" ' . $value['data_size'] . '" ' : '';

	echo '<select autocomplete="off" data-width="100%" ' . $data_size . $live_search . $multiple . ' name="' . (!empty( $value['name'] ) ? $value['name'] : '') . '"';
	echo ' class="' . (!empty( $value['class'] ) ? $value['class'] : '') . '"';
	echo ' id="' . (!empty( $value['id'] ) ? $value['id'] : '') . '"'; 
	echo '>';

	if( !empty( $value['value'] ) ){
		foreach( $value['value'] as $key => $option ){
			echo '<option ';
			selected( $selected, $key );
			echo ' value="' . sanitize_text_field( $key ) . '">' . sanitize_text_field( $option ) . '</option>';
		}	
	}
	echo '</select>';

	extretion_getHelpText( $value );
	extretion_polpulate_select_value( $value , $edit , $user_meta , $post_meta );

}

function extretion_polpulate_select_value( $value , $edit , $user_meta , $post_meta ){

	/**
	* If not edit page break the function
	*/

	if( $edit != true ){
		return;
	}

	$user_id = get_current_user_id();
	$key = str_replace( array( '[' , ']' ), '', $value['name'] );
	$id = $value['id'];
	$data = null;
	$post_id = !empty( $_GET['id'] ) ? sanitize_text_field( $_GET['id'] ) : '';

	//echo '<pre>'; print_r( $value );

	if( $user_meta != false ){ // get user meta

		$data = get_user_meta( $user_id, $key, true );

	} elseif( !empty( $value['taxonomy'] ) && $value['taxonomy'] == true ){ // if taxonomy

		$tax = wp_get_object_terms( $post_id, sanitize_text_field( $value['taxonomy_name'] ));
		$data = extretion_get_post_tax( $tax );

	} else { // get post meta

		$data = get_post_meta( $post_id, $key, true );

	} 

	if( !empty( $data ) /*&& is_array( $data )*/ ){ ?>

		<script>
				
			jQuery(document).ready(function(){

				jQuery("#<?php echo sanitize_text_field( $id ); ?>").selectpicker();
				jQuery("#<?php echo sanitize_text_field( $id ); ?>").selectpicker( 'val', <?php extretion_selectpicker_value( $data ); ?> );
				jQuery("#<?php echo sanitize_text_field( $id ); ?>").selectpicker("refresh");

			});

		</script>

		<?php

	}

}

function extretion_selectpicker_value( $data ){

	if( is_array( $data ) ){
		echo '["' . implode( '","' , $data ) . '"]';
	} else {
		echo json_encode( $data );
	}

}

function extretion_get_post_tax( $taxonomies ){

	$data = array();

	if( !empty( $taxonomies ) && is_array( $taxonomies ) ){

		foreach( $taxonomies as $tax ){

			$data[] = $tax->term_id;

		}

	}

	return $data;

}

function extretion_getGoogleMapDefaultvalue( $nameField , $edit , $user_meta , $post_meta ){

	if( $user_meta != false && $edit == true ){

		$user_id = get_current_user_id();
		echo esc_html( get_user_meta( $user_id, $nameField , true ) );

	} elseif( $post_meta == true && $edit == true ){

		$post_id = !empty( $_GET['id'] ) ? sanitize_text_field( $_GET['id'] ) : '';
		echo esc_html( get_post_meta( $post_id, $nameField , true ) );

	} else {

		echo ( !empty( $_POST[$nameField] ) ? sanitize_text_field( stripslashes( $_POST[$nameField] ) ) : ''  );

	}

}

function extretion_get_google_default_location( $edit , $user_meta , $location , $post_meta ){

	$user_id = get_current_user_id();

	if( $edit == true && $user_meta != false ){

		$user_location = get_user_meta( $user_id , $location , true );

		$defaultLocation = $user_location ? explode( ',' , $user_location ) : '';
		
	} elseif( $edit == true && $post_meta == true ){

		$post_id = !empty( $_GET['id'] ) ? sanitize_text_field( $_GET['id'] ) : '';

		$user_location = get_post_meta( $post_id , $location , true );

		$defaultLocation = $user_location ? explode( ',' , $user_location ) : '';

	} else{
		$defaultLocation = !empty( $_POST[$location] ) ? explode( ',' , $_POST[$location] ) : false;
	}

	return $defaultLocation;

}

function extretion_getGoogleMapField( $value , $edit , $user_meta , $post_meta ){ 

	$nameField = $value['name'];
	$google_input_id = $value['id'];

	echo '<input';
	echo ' autocomplete="off"';
	echo ' type="text"';
	echo ' placeholder="' . ( !empty( $value['placeholder'] ) ? $value['label'] : '') . '"';
	echo ' id="' . (!empty( $value['id'] ) ? $value['id'] : '') . '"';
	echo ' class="' . (!empty( $value['class'] ) ? $value['class'] : '') . '"';
	echo ' name="' . (!empty( $nameField ) ? $nameField : '') . '"';
	echo ' value="';
	extretion_getGoogleMapDefaultvalue( $nameField , $edit , $user_meta , $post_meta );
	echo '"';
	echo '>';

	extretion_getHelpText( $value );

	$google_id = $nameField . '_googleMap';
	$populateForm = 'form_' . $nameField;

	extretion_googlePopulateForm( $populateForm , $edit , $user_meta , $post_meta );

	$location = $populateForm . '_location';

	$defaultLocation = extretion_get_google_default_location( $edit , $user_meta , $location , $post_meta );
	
	$icon =  get_template_directory_uri() . '/images/map-marker.png';

	$args = array(
		'map' => '#'.$google_id,
		'location' => $defaultLocation,
		'details' => '.'.$populateForm,
		'detailsAttribute'=> "data-" . $populateForm,
		'types' => array( 'geocode' , 'establishment' ),
		'markerOptions' => array( 
			'draggable' => true,
			'icon' => $icon
		),
		
	);

	$mapOptions = apply_filters( $nameField . '_google_map' , $args );

	echo '<div class="responsive_google_map" id="' . $google_id . '" style="width:500px;height:250px;"></div>'; ?>
	
	<script>
		
		jQuery( document ).ready( function(){

			"use_strict";
			jQuery("#<?php echo esc_js( $value['id'] ); ?>").geocomplete(
			  	<?php echo wp_json_encode($mapOptions); ?>
			);

		});

		jQuery("#<?php echo esc_js( $value['id'] ); ?>").bind("geocode:dragged", function(event, latLng){

			"use_strict";
		  	var <?php echo esc_js( $value['id'] ) . '_map'; ?> = jQuery("#<?php echo esc_js( $value['id'] ); ?>").geocomplete("map");
		  	<?php echo esc_js( $value['id'] ) . '_map'; ?>.panTo(latLng);
		  	var geocoder = new google.maps.Geocoder();

		  	geocoder.geocode({'latLng': latLng }, function(results, status) {

		    	if (status == google.maps.GeocoderStatus.OK) {

		      		if (results[0]) {

		      			var fields = [ 'name' , 'point_of_interest' , 'lat' , 'lng' , 'location' , 'location_type' , 'formatted_address' , 'bounds' , 'viewport' , 'route' , 'street_number' , 'postal_code' , 'locality' , 'sublocality' , 'country' , 'country_short' , 'administrative_area_level_1' , 'place_id' , 'id' , 'reference' , 'url' , 'website'];
		      			var id = "<?php echo esc_js( $populateForm ); ?>";
		      			var selector;

		      			jQuery( fields ).each( function( i ){

		      				selector = id + '_' + fields[i];

		      				switch ( fields[i] ) {

		      					case 'lat':
		      						jQuery('[name="' + selector + '"]').val(latLng.lat());
		      						break;

		      					case 'lng':
		      						jQuery('[name="' + selector + '"]').val(latLng.lng());
		      						break;

		      					case 'location':
		      						jQuery('[name="' + selector + '"]').val(latLng.lat() + ',' + latLng.lng());
		      						break;

		      					case 'formatted_address':
		      						jQuery('[name="' + selector + '"]').val( results[0].formatted_address );
		      						jQuery("#<?php echo esc_js( $google_input_id ); ?>").val( results[0].formatted_address );
		      						break;

		      					case 'administrative_area_level_1':
		      						jQuery('[name="' + selector + '"]').val( findplaces( 'administrative_area_level_1' , results[0].address_components ) );
		      						break;

		      					case 'country_short':
		      						jQuery('[name="' + selector + '"]').val( findplaces( 'country_short' , results[0].address_components ) );
		      						break;

		      					case 'country':
		      						jQuery('[name="' + selector + '"]').val( findplaces( 'country_long' , results[0].address_components ) );
		      						break;

		      					case 'sublocality':
		      						jQuery('[name="' + selector + '"]').val( findplaces( 'sublocality' , results[0].address_components ) );
		      						break;

		      					case 'locality':
		      						jQuery('[name="' + selector + '"]').val( findplaces( 'locality' , results[0].address_components ) );
		      						break;

		      					case 'postal_code':
		      						jQuery('[name="' + selector + '"]').val( findplaces( 'postal_code' , results[0].address_components ) );
		      						break;

		      					default:
		      						jQuery('[name="' + selector + '"]').val('');
		      						break;
		      				}

		      			});

		      		}

		    	}

		  	});

		});

	</script>
	<?php

}

function extretion_googlePopulateFormValues( $nameField , $edit , $user_meta , $post_meta ){

	if( $user_meta != false && $edit == true ){

		$user_id = get_current_user_id();
		return esc_html( get_user_meta( $user_id, $nameField , true ) );

	} elseif( $post_meta == true && $edit == true ){

		$post_id = !empty( $_GET['id'] ) ? sanitize_text_field( $_GET['id'] ) : '';
		return esc_html( get_post_meta( $post_id, $nameField , true ) );

	} else {

		return ( !empty( $_POST[$nameField] ) ? $_POST[$nameField] : '' );

	}

}

function extretion_googlePopulateForm( $class , $edit , $user_meta , $post_meta ){ 

	$class = esc_attr( $class );

	$fields = array( 'name' , 'point_of_interest' , 'lat' , 'lng' , 'location' , 'location_type' , 'formatted_address' , 'bounds' , 'viewport' , 'route' , 'street_number' , 'postal_code' , 'locality' , 'sublocality' , 'country' , 'country_short' , 'administrative_area_level_1' , 'place_id' , 'id' , 'reference' , 'url' , 'website' )?>

	<div class="<?php echo esc_attr( $class ); ?>">

		<?php 
		foreach( $fields as $value ){  

			$name = $class . '_' . $value;
			$defaultValue = extretion_googlePopulateFormValues( $name , $edit , $user_meta , $post_meta ); ?>

			<input 
			autocomplete="off" 
			type="hidden" 
			data-<?php echo esc_attr( $class ); ?>="<?php echo esc_html( $value ); ?>" 
			name="<?php echo esc_html( $name ); ?>" 
			value="<?php echo sanitize_text_field( $defaultValue ); ?>" />

			<?php 
		} ?>
	
	</div>

	<?php
}

function extretion_getInfoBox( $value ){ ?>
										
	<div class="alert alert-info mt-20" role="alert">
		<div class="icon">
			<i class="fa <?php echo ( !empty( $value['icon'] ) ? $value['icon'] : '' ); ?> font12"></i>
		</div>
		<div class="content">
			<h4 class="text-primary2"> <?php echo ( !empty( $value['label'] ) ? $value['label'] : '' ); ?> </h4>
			<ul>
				<?php echo ( !empty( $value['content'] ) ? $value['content'] : '' ); ?>
			</ul>
		</div>
	</div>

	<?php
}

function extretion_get_captcha( $value ){

	/**
	* If Really Simple Captcha is installed and activated
	*/
	
	$captcha_status = get_option( 'options_registration_captcha' );

	if( class_exists( 'ReallySimpleCaptcha' ) && $captcha_status == 1 ){

		$captcha_instance = new ReallySimpleCaptcha();
		$captcha_instance->bg = array( 255, 255, 255 );
		$captcha_instance->img_size = array( 250 , 40 );
		$captcha_instance->char_length = 7;
		$captcha_instance->font_size = 25;
		$captcha_instance->font_char_width = 35;
		$captcha_instance->base = array( 6, 30 );

		$word = $captcha_instance->generate_random_word();
		$prefix = mt_rand();
		$filename = $captcha_instance->generate_image( $prefix, $word );

		$image = plugins_url() . '/really-simple-captcha/tmp/' . $filename;

		echo '<div class="captcha_wrapper"><img id="' . $prefix . '" class="extretion_registration_captcha" src="' . $image . '" /></div>';
		echo '<input name="user_input_captcha" type="text" class="form-control mb-5 mt-5" placeholder="' . esc_html__( 'Type above letters' , 'extretion' ) . '">';
		echo '<input type="hidden" name="captcha_prefix" value="' . $prefix . '">';

	}

}

function extretion_getTextareaField( $value , $edit , $user_meta , $post_meta ){

	echo '<textarea name="' . (!empty( $value['name'] ) ? $value['name'] : '') . '"';
	echo ' class="' . (!empty( $value['class'] ) ? $value['class'] : '') . '"';
	echo ' id="' . (!empty( $value['id'] ) ? $value['id'] : '') . '"'; 
	echo ' rows="' . (!empty( $value['rows'] ) ? $value['rows'] : '5' ) . '"'; 
	echo '>';
	//echo (!empty( $_POST[$value['name']] ) ? sanitize_text_field( stripslashes( $_POST[$value['name']] ) ) : '' );

	extretion_getDefaultFieldValue( $value, $type = null , $user_meta, $post_meta );

	echo '</textarea>';

	extretion_getHelpText( $value );

}

function extretion_getCheckboxField( $value , $edit , $user_meta , $post_meta ){ 

	if( !empty($value['col']) && $value['col'] == 3 ){
		$divide = 4;
	} elseif( !empty($value['col']) && $value['col'] == 2 ){
		$divide = 6;
	} else {
		$divide = 12;
	} 

	$sanitizeName = str_replace( array( '[' , ']' ), '', $value['name'] ); ?>

	<div class="row gap-15 pl-5">

		<?php 
		if( !empty( $value['value'] ) ){
			foreach( $value['value'] as $key => $option ){ ?>
				
				<div class="col-sm-<?php echo (int) $divide; ?>">

					<div class="checkbox-block font-icon-checkbox">

						<input 
						autocomplete="off" 
						id="amenities-checkbox-<?php echo esc_html( $key ); ?>" 
						name="<?php echo esc_html( $value['name'] ); ?>" 
						type="checkbox" 
						class="checkbox <?php echo esc_html( $value['class'] ); ?>" 
						value="<?php echo sanitize_text_field( $key ); ?>" <?php extretion_customSelected( $sanitizeName , $key , $edit , $user_meta , $post_meta , $value ); ?>/>

						<label class="checkbox_label label-<?php echo esc_html( $key ); ?>" for="amenities-checkbox-<?php echo esc_html( $key ); ?>"><?php printf( '%s' , $option ); ?></label>

					</div>

				</div>

				<?php
			}	
		}
		?>

	</div>

	<?php

	extretion_getHelpText( $value );
}

function extretion_customSelected( $name, $selected , $edit , $user_meta , $post_meta, $value ){

	$post_id = ( !empty( $_GET['id'] ) && ctype_digit( $_GET['id'] ) ) ? $_GET['id'] : '';

	$array = !empty( $_POST[$name] ) ? $_POST[$name] : array(); 


	if( !empty( $array ) && in_array( $selected , $array) ){ // Inserting for the first time

		echo 'checked="checked"';

	} elseif( $post_meta == true && $edit == true ){ // if is post edit

		if( !empty( $value['taxonomy'] ) && $value['taxonomy'] == true ){ // if is taxonomy

			$tax = wp_get_object_terms( $post_id, sanitize_text_field( $value['taxonomy_name'] ));
			extretion_check_selected_value( $tax , $selected );

		} else {

			$amenities = get_post_meta( $post_id , $name , true );

		}

	}

}

function extretion_check_selected_value( $tax , $selected ){

	if( !empty( $tax ) && is_array( $tax ) ){

		foreach( $tax as $value ){

			if( $selected == $value->term_id ){

				echo 'checked="checked"';

			}

		}

	}

}

function extretion_get404Search(){ 

	$search_field = get_option( 'options_404_search_field' );

	if( $search_field != 2 ){ ?>

		<p class="text-grey"><?php esc_html_e( 'You Search For What You Are Looking For' , 'extretion' ); ?></p>

		<div class="row">
			
			<div class="col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4">
				<form class="row gap-0">
					<div class="col-xs-9 col-sm-9">
						<input class="form-control" placeholder="<?php esc_html_e( 'Search' , 'extretion' ); ?>" />
					</div>
					<div class="col-xs-3 col-sm-3">
						<button class="btn btn-danger btn-block btn-search"><i class="fa fa-search"></i></button>
					</div>
				</form>
			</div>
			
		</div>
	
		<div class="mb-25"></div>

		<?php

	}

}

function extretion_helpfulLinks(){

	$helpful_links = get_option( 'options_404_helpful_links' );

	if( !empty( $helpful_links ) ){

		echo '<p class="lead">' . esc_html__( 'Here are some helpful links' , 'extretion' ) . '</p>';

		echo '<div class="row">
		
			<div class="col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4">
			
				<div class="row gap-10">';

		foreach( $helpful_links as $value ){ 

			$post_help = get_post( $value );

			?>

			<div class="col-xss-12 col-xs-4 col-sm-6 col-md-4">
				<div class="error-menu clearfix">
					<i class="fa fa-arrow-right"></i> <a href="<?php echo get_permalink( $post_help->ID );?>">
						<?php echo get_the_title( $post_help->ID );?>
					</a>
				</div>
			</div>

			<?php
		}

		echo '</div></div></div>';

	}

}

function extretion_checkValidUrl( $url ){

    $reg_exp = "@^(http\:\/\/|https\:\/\/)?([a-z0-9][a-z0-9\-]*\.)+[a-z0-9][a-z0-9\-]*$@i";
    if(preg_match($reg_exp, $url) == TRUE){
    	return true;
    }
    else{
    	return false;
    }
}

function extretion_getCallback( $name , $name_key , $callback_key, $function ){

	$args = $function();

	foreach( $args as $key => $value ){

		$sanitize_name = str_replace( array( '[' , ']' ), '', $args[$key][$name_key] );

		if( $sanitize_name == $name && !empty( $args[$key][$callback_key] ) ){

			//echo '<pre>'; print_r($sanitize_name);echo '</pre>';
			//echo '<pre>'; print_r($args[$key][$callback_key]);echo '</pre>';

			return $args[$key][$callback_key];

		}

	}

	return false;

}

function extretion_set404Page(){
	global $wp_query;
	$wp_query->is_404 = true;
	$wp_query->is_single = false;
	$wp_query->is_page = false;

	include( get_query_template( '404' ) );
	exit();
}

function extretion_checkPostDatas( $post , $errors , $check , $errorFields , $arguments ){

	$extraSanitizeCallback = apply_filters( 'extretion_extra_sanitize_callback' , $args = array() , $arguments );

	foreach( $post as $key => $value ){

		$callback = extretion_getCallback( $key , 'name' , 'callback' , $arguments );
		//echo  $callback . '<br>' . $key . '<br>';
		/**
		* Validation user data
		*/

		if( $callback != false && $callback == 'extretion_requiredPostValue' ){

			//echo  $key . '<br>';
			$validateResult = extretion_requiredPostValue( $value , extretion_correspondingKeyArray( $key , $arguments ) );
			//print_r( $validateResult );
			if( $validateResult['result'] === false ){

				$errors.= '<li>' . $validateResult['message'] . '</li>';
				$check = true;
				$errorFields .= "[name=" . $key . "],";

			}

		} elseif( $callback != false ){
			$validateResult = $callback( $value );

			if( $validateResult['result'] === false ){

				$errors.= '<li>' . $validateResult['message'] . '</li>';
				$check = true;
				$errorFields .= "[name=" . $key . "],";

			}

		} else {

			$validateResult = extretion_checkExtraCallbackData( $extraSanitizeCallback , $key , $value );

			if( $validateResult['result'] === false ){

				$errors.= '<li>' . $validateResult['message'] . '</li>';
				$check = true;
				$errorFields .= "[name=" . $key . "],";

			}

		}

		//echo '<pre>'; print_r($validateResult); echo '</pre>';

	}

	return array(
		'errors' => $errors,
		'check' => $check,
		'errorFields' => $errorFields
	);

}

function extretion_checkExtraCallbackData( $extraSanitizeCallback , $name , $unfilteredValue ){

	if( !empty( $extraSanitizeCallback ) ){

		foreach( $extraSanitizeCallback as $value ){

			if( $value['input_name'] == $name && !empty( $value['callback'] ) ){

				$extraCallback = $value['callback'];
				$result = $extraCallback( $unfilteredValue );
				return $result;

			}

		}

	}

}

function extretion_validate_image( $files ){

	$allowImages = array( 'image/jpg' , 'image/jpeg' , 'image/gif' , 'image/png' , 'image/bmp' );

	foreach( $files as $key => $value ){

		if( $key == 'type' ){

			foreach( $value as $filetype ){
				//echo '<pre>'; print_r($filetype); echo '</pre>';
	
		 		if( !in_array( $filetype , $allowImages ) ){

		 			return array(
						'result' => false,
						'message' => esc_html__( "Please upload only image files." , 'extretion' )
					);

		 		}

		 	}

		}

	}

	return true;

}

function extretion_check_profile_picture( $files ){

	$user_id = get_current_user_id();
	$avatar_id = get_user_meta( $user_id, 'profile_picture' , true );
	$result = true;
	$avatar_details = null;

	if( !empty( $avatar_id ) && is_array( $avatar_id ) ){
		$avatar_details = wp_get_attachment_image_src( $avatar_id[0] , 'thumbnail' );
	}
	
	if( empty( $avatar_details ) || !empty( $files['name'][0] ) ){

		//echo '<pre>'; print_r($files); echo '</pre>';
		$result = extretion_validate_image( $files );

	}

	return $result;

}

function extretion_checkImagesFiles( $files ){

	$result = extretion_validate_image( $files );

	if( $result != true ){
		return $result;
	}

	// Check limit photos
	$no_of_photos = count($files['name']);

	//$max_photos = get_field( 'max_photos_upload_detail_page' , 'option' );
	//$max_photos = is_numeric( $max_photos ) ? $max_photos : 10;

	if( $no_of_photos > 10 ){

		return array(
			'result' => false,
			'message' => sprintf( _n( "You can only upload %d image" , "You can only upload %d images" , $max_photos, 'extretion' ) , $max_photos )
		);

	}

	return true;

}

function extretion_checkFilesDatas( $post , $errors , $check , $errorFields , $arguments ){

	foreach( $post as $key => $value ){

		$callback = extretion_getCallback( $key , 'name' , 'callback' , $arguments );
		//echo  $callback . '<br>';
		/**
		* Validation user FILES
		*/

		if( $callback != false ){

			$validateResult = $callback( $value );

			if( $validateResult['result'] === false ){

				$errors.= '<li>' . $validateResult['message'] . '</li>';
				$check = true;
				$errorFields .= "[name=" . $key . "],";

			}
		}

		//echo '<pre>'; print_r($validateResult); echo '</pre>';

	}

	return array(
		'errors' => $errors,
		'check' => $check,
		'errorFields' => $errorFields
	);

}

function postValueCheck( $post , $arguments ){

	$post = apply_filters( 'extretion_check_post_data' , $post , $arguments );

	$errors = '';
	$check = false;
	$errorFields = '';
	$resultsFiles = array();

	/**
	* Check only $_FILES ( Ignore $_POST )
	*/

	if( !empty( $post['lmh_files'] ) ){ 
		$resultsFiles = extretion_checkFilesDatas( $post['lmh_files'] , $errors , $check , $errorFields , $arguments ); 
	} else {
		$resultsFiles['errors'] = $errors;
		$resultsFiles['check'] = $check;
		$resultsFiles['errorFields'] = $errorFields;
	}

	/**
	* Check only $_POST ( Ignore Files if any )
	*/

	if( !empty( $post['lmh_files'] ) ){ 
		unset( $post['lmh_files'] );
	}

	$results = extretion_checkPostDatas( $post , $resultsFiles['errors'] , $resultsFiles['check'] , $resultsFiles['errorFields'] , $arguments );

	return array(
		'errors' => $results['errors'],
		'check' => $results['check'],
		'errorFields' => $results['errorFields']
	);

}

function extretion_sanitizeFilesDatas( $post , $extraSanitizeCallback , $validKeys , $arguments ){

	foreach( $post as $key => $value ){

		// For Post Data ( Except Files )
		$callback = extretion_getCallback( $key , 'name' , 'sanitize_callback' , $arguments );
		$sanitizeData = null;
		

		/**
		* If no callback function define do not validate
		*/

		if( $callback != false ){

			/**
			* Sanitize data to save in the database
			*/

			$sanitizeData = $callback( $value );

		} else {

			$sanitizeData = extretion_checkExtraCallback( $extraSanitizeCallback , $key , $value );

		}

		// If sanitize data available take that if not take the $_POST data
		$filterValue = ( $sanitizeData === null ? $value : $sanitizeData );

		// Ignore keys to save 
		$ignoreKeys = apply_filters( 'extretion_ignore_keys_list_my_room' , $args = array() , $arguments );

		if( !in_array( $key , $ignoreKeys ) ){
			$validKeys[$key] =  $filterValue;
		}

		//echo '<pre>'; print_r( $key ); echo ' - '; print_r( $filterValue ); echo '</pre>';

	}

	return $validKeys;

}

function extretion_check_data_before_saving( $post , $arguments , $edit ){

	if( empty( $post ) ){
		return;
	}

	$extraSanitizeCallback = apply_filters( 'extretion_extra_sanitize_callback' , $args = array() , $arguments );
	$validKeys = array();

	if( !empty( $post['lmh_files'] ) ){

		// Check files
		$validKeys = extretion_sanitizeFilesDatas( $post['lmh_files'] , $extraSanitizeCallback , $validKeys , $arguments );
		
		// Unset after the work has been done
		unset($post['lmh_files']);
	}

	// Check Post data
	$validKeys = extretion_sanitizeFilesDatas( $post , $extraSanitizeCallback , $validKeys , $arguments );

	//echo '<pre>'; print_r($validKeys); echo '</pre>';

	do_action( 'extretion_after_sanitize_datas' , $validKeys , $arguments , $edit );

}

function extretion_checkExtraCallback( $extraSanitizeCallback , $name , $unfilterValue ){

	if( !empty( $extraSanitizeCallback ) ){

		foreach( $extraSanitizeCallback as $value ){

			if( $value['input_name'] == $name && !empty( $value['sanitize_callback'] ) ){

				$extraCallback = $value['sanitize_callback'];
				$sanitizeData = $extraCallback( $unfilterValue );
				return $sanitizeData;

			}

		}

	}

}

function extretion_correspondingKeyArray( $field_name , $arguments ){

	$args = $arguments();
	//echo '<pre>'; print_r($args); echo '</pre>';
	foreach( $args as $key => $value ){

		$sanitizes_value = str_replace( array( ']' , '[' ) , '', $value['name'] );

		if( $sanitizes_value == $field_name ){

			//echo '<pre>'; print_r($args[$key]); echo '</pre>';
			return $args[$key];
			//echo '<br>';

		}

	}

	return false;

}

function extretion_requiredPostValue( $value , $data ){

	//echo '<pre>'; print_r($value); echo '</pre>';

	if( is_array( $value ) ){

		$sanitizes_value = $value;

		if ( empty($sanitizes_value) ) {
		    return array( 
				'result' => false,
				'message' => $data['callback_error_message']
			);
		}

	} else {
		$sanitizes_value = sanitize_text_field( $value );

		if ( empty($sanitizes_value) ) {
		    return array( 
				'result' => false,
				'message' => $data['callback_error_message']
			);
		}
	}

	return true;

}

function extretion_checkServiceFee( $value ){

	if( !is_numeric( $value ) ){
		return array( 
			'result' => false,
			'message' => esc_html__( 'Please enter your service fee.' , 'extretion' )
		);
	}

	return true;

}

function extretion_checkNumber( $value ){

	if( empty( $value ) ){
		return array( 
			'result' => false,
			'message' => esc_html__( 'Price field is mandatory.' , 'extretion' )
		);
	} elseif( !is_numeric( $value ) ){
		return array( 
			'result' => false,
			'message' => esc_html__( 'Please enter a valid price.' , 'extretion' )
		);
	}

	return true;

}

add_action( 'wp_ajax_nopriv_reset_password' , 'extretion_reset_password' );
function extretion_reset_password(){

	$include_keys = array( 'action' , 'pass' , 'confirm_pass' , 'reset_key' , 'user_id' , 'nonce' );

	$defaultResult = array(); 
	$defaultResult['result'] = false;
	$defaultResult['result'] = esc_html__( 'Something is wrong, please try again.' , 'extretion' );

	if( empty( $_POST ) || !is_array( $_POST ) ){
		echo json_encode( $defaultResult );
		die;
	}

	foreach( $_POST as $key => $value ){

		if( !in_array( $key , $include_keys ) ){
			echo json_encode( $defaultResult );
			die;
		}

	}

	$user_id = sanitize_text_field( $_POST['user_id'] );
	$pass = sanitize_text_field( $_POST['pass'] );
	$confirm_pass = sanitize_text_field( $_POST['confirm_pass'] );
	$reset_key = sanitize_text_field( $_POST['reset_key'] );
	$nonce = sanitize_text_field( $_POST['nonce'] );

	// Check database reset key
	$db_reset_key =  get_user_meta( $user_id, 'reset_verification_key' , true );

	// Check Nonce and password
	if( !wp_verify_nonce( $nonce, 'reset_pass_nonce' ) || $db_reset_key != $reset_key ){
		echo json_encode( $defaultResult );
		die;
	}

	$data = array();
	$data['register_password'] = $pass;
	$data['register_password_confirm'] = $confirm_pass;

	$result = extretion_checkUserPassword( $data );

	if( $result['result'] != true ){
		echo json_encode($result);
	} else {

		wp_set_password( $pass, $user_id );

		delete_user_meta( $user_id, 'reset_verification_key' );

		do_action( 'extretion_after_password_changed' , $user_id );

		echo json_encode( 
			array( 
				'result' => 'success' , 
				'message' => esc_html__( 'Your password has been reset successfully. Please sign in to continue.' , 'extretion' )
			) 
		);
	}

	die;

}

add_action( 'wp_ajax_nopriv_forgot_password' , 'extretion_forgot_password' );
function extretion_forgot_password(){

	if( empty( $_POST['action'] ) || $_POST['action'] != 'forgot_password' ){
		return;
	}

	$data = array();
	$email = sanitize_text_field( $_POST['email'] );

	if( email_exists( $email ) ){

		$user = get_user_by( 'email', $email );
		$user_id = $user->ID;
		$to = $email;

		$reset_key = wp_generate_password( 20, false, false );
		update_user_meta( $user_id , 'reset_verification_key' , $reset_key );

		
		$reset_link = '<a href="' . esc_url( site_url() ) . '/?reset_pass_key=' . $reset_key . '&user_id=' . $user_id . '">' . esc_html__( 'Click Here' , 'extretion' ) . '</a>';

		$message_db = get_option( 'options_forgot_your_password_message' );

		if( empty( $message_db ) ){

			$message_db = '<p>Someone requested that the password be reset for the following account:</p><p>[site_url] ( [site_name] )</p><p>Username : [username]</p><p>If this was a mistake, just ignore this email and nothing will happen.</p><p>To reset your password, visit the following address: [reset_link]</p>';

		}

		$message = str_replace( '[username]' , $user->user_login , $message_db );
		$message = str_replace( '[site_url]' , esc_url( site_url() ) , $message );
		$message = str_replace( '[site_name]' , get_bloginfo( 'name' ) , $message );
		$message = str_replace( '[reset_link]' , $reset_link , $message );

		$subject = get_option( 'options_forgot_your_password_subject' );
		$subject = !empty( $subject ) ? $subject : esc_html__( 'Reset Password' , 'extretion' );

		wp_mail( $to , $subject , nl2br( $message ) , extretion_mail_headers() );

		$data['result'] = 'success';
		$data['message'] = esc_html__( "Success !!! We have sent you an email. Please check your inbox/spam folder." , 'extretion' );

	} else {

		$data['result'] = 'error';
		$data['message'] = esc_html__( "Email doesn't exists." , 'extretion' );

	}

	echo json_encode( $data );

	die;

}

add_action( 'wp_ajax_nopriv_lmh_login_user' , 'extretion_login_user' );
function extretion_login_user(){

	if( empty( $_POST['login_nonce'] ) && $_POST['action'] != 'lmh_login_user' && !wp_verify_nonce( $_POST['login_nonce'] , 'login_user_nonce' )  ){
		return;
	}
	//echo '<pre>'; print_r( $_POST ); echo '</pre>';
	$data = array();
	$data['username'] = sanitize_text_field( $_POST['username'] );
	$data['register_password'] = sanitize_text_field( $_POST['pass'] );
	$data['remember'] = !empty( $_POST['remember'] ) ? sanitize_text_field( $_POST['remember'] ) : '';

	$rediret_url = sanitize_text_field( $_POST['current_url'] );
	extretion_automaticLoginUser( $data , $rediret_url );

}

function extretion_automaticLoginUser( $data , $rediret_url ){

	$user_data = array();
	$returnData = array();

	$login_name_email = $data['username'];
	
	$user_data['user_password'] = $data['register_password'];
	$user_data['remember'] = ( $data['remember'] == 1 ? true : false );  

	// Search database for the user
	$args = array(
		'search'         => $login_name_email,
		'search_columns' => array( 'user_login', 'user_email' )
	);

	$user_query = new WP_User_Query( $args );

	if( empty( $user_query->results ) ){

		$returnData['result'] = 'error';
		$returnData['message'] = esc_html__( "Username / Email doesn't exists." , 'extretion' );
		echo json_encode($returnData);
		die; 

	} else {

		if ( !wp_check_password( $data['register_password'] , $user_query->results[0]->data->user_pass, $user_query->results[0]->data->ID ) ){

			$returnData['result'] = 'error';
			$returnData['message'] = esc_html__( "Password doesn't match." , 'extretion' );
			echo json_encode($returnData);
			die;

		}			 

	}

	$user_data['user_login'] = $user_query->results[0]->data->user_login;
	$user = wp_signon( $user_data, false );

	if ( !is_wp_error($user) ) {			
		wp_set_current_user( $user->ID, $user_data['user_login'] );
		wp_set_auth_cookie( $user->ID );
		do_action('set_current_user');
	}
	$returnData['result'] = 'success';
	global $wp;

	/**
	* Check if the request came form room detail page, if yes then redirect to the room detail page
	*/
	
	$url_break = explode( '/' , $rediret_url );
	$redirect = get_permalink( get_option( 'options_after_login_completed' ) );
	$redirect = ( !empty( $redirect ) && $url_break[0] != 'room' ) ? $redirect : esc_url( site_url( add_query_arg( array() , $rediret_url ) ) );

	$returnData['redirect'] = $redirect;
	echo json_encode($returnData);
	die;

}

function extretion_mail_headers(){
	$headers = "MIME-Version: 1.0\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headers .= "X-Mailer: PHP's mail() Function\r\n";
    //$headers .= "From: {get_bloginfo( 'name' )} <{get_option( 'admin_email' )}>" . "\r\n";
    return $headers;
}

function extretion_check_captcha( $post ){

	$captcha_status = get_option( 'options_registration_captcha' );

	if( class_exists( 'ReallySimpleCaptcha' ) && $captcha_status == 1 ){

		$prefix = $post['captcha_prefix'];
		$the_answer_from_respondent = $post['user_input_captcha'];

		$captcha_instance = new ReallySimpleCaptcha();
		$correct = $captcha_instance->check( $prefix, $the_answer_from_respondent );

		return $correct;

	}

	return true;

}

function extretion_filterPostValues( $post , $ignore_keys ){

	$errors = '';
	$errorFields = '';
	$check = false;

	// validate the user input and captcha
	$captcha_status = extretion_check_captcha( $post );

	if( $captcha_status != true ){

		$errors.= '<li>' . esc_html__( 'Verification code is incorrect.' , 'extretion' ) . '</li>';
		$check = true;
		$errorFields .= "[name=user_input_captcha],";

	}

	foreach( $post as $key => $value ):

		if( !in_array( $key , $ignore_keys ) ):

			$callback = extretion_getCallback( $key , 'name' , 'callback' , 'extretion_getRegisterArguments' );

			/**
			* If no callback function define do not validate
			*/

			if( $callback != false ){

				/**
				* Validation user data
				*/

				$validateResult = $callback( $value );

				if( $validateResult['result'] === false ){

					$errors.= '<li>' . $validateResult['message'] . '</li>';
					$check = true;
					$errorFields .= "[name=" . $key . "],";

				}

			}						

		endif;

	endforeach;	

	return array(
		'errors' => $errors,
		'error_fields' => $errorFields,
		'check' => $check
	);

}

add_action( 'wp_ajax_lmh_change_password' , 'extretion_change_password' );
function extretion_change_password(){

	$sanitize_data = array_map( 'sanitize_text_field' , $_POST );

	if( empty( $sanitize_data['old_password'] ) || empty( $sanitize_data['new_password'] ) || empty( $sanitize_data['confirm_password'] ) ){

		echo wp_json_encode(
			array(
				'result' => 'error',
				'message' => '<li>' . esc_html__( 'All fields are required.' , 'extretion' ) . '</li>'
			)
		);

		die;
	}

	if( $sanitize_data['old_password'] == $sanitize_data['new_password'] ){

		echo wp_json_encode(
			array(
				'result' => 'error',
				'message' => '<li>' . esc_html__( 'Old and new password cannot be the same.' , 'extretion' ) . '</li>'
			)
		);

		die;
	}

	$user_id = get_current_user_id();

	$userdata = get_userdata( $user_id );


	// If old password doesn't match
	if ( !wp_check_password( $sanitize_data['old_password'], $userdata->data->user_pass, $user_id ) ){

		echo wp_json_encode(
			array(
				'result' => 'error',
				'message' => '<li>' . esc_html__( "Old password doesn't match." , 'extretion' ) . '</li>'
			)
		);

		die;
	}

	$pass_data = array();
	$pass_data['register_password'] = $sanitize_data['new_password'];
	$pass_data['register_password_confirm'] = $sanitize_data['confirm_password'];

	$checkpass = extretion_checkUserPassword( $pass_data );

	// Check new password
	if( $checkpass['result'] == false ){

		echo wp_json_encode(
			array(
				'result' => 'error',
				'message' => '<li>' . $checkpass['message'] . '</li>'
			)
		);
		die;

	}

	wp_set_password( $sanitize_data['new_password'] , $user_id );

	do_action( 'extretion_after_password_changed' , $user_id );

	echo wp_json_encode(
		array(
			'result' => 'success',
		)
	);

	die;

}

function extretion_checkUserPassword( $data ){

	// Weak pass or strong pass
	$pass_strength = get_option( 'options_user_password_strength' );

	$pass1 = sanitize_text_field( $data['register_password'] );
	$pass2 = sanitize_text_field( $data['register_password_confirm'] );

	$length_pass_1 = strlen($pass1);
	$length_pass_2 = strlen($pass2);

	$r1='/[A-Z]/';  //Uppercase
   	$r2='/[a-z]/';  //lowercase
   	$r3='/[!@#$%^&*()\-_=+{};:,<.>]/';  // whatever you mean by 'special char'
   	$r4='/[0-9]/';  //numbers

	if( empty( $length_pass_1 ) || empty( $length_pass_2 ) ){

		return array(
			'result' => false,
			'message' => esc_html__( "Password field is required." , 'extretion' )
		);

	} elseif( $length_pass_1 < 5 || $length_pass_2 < 5 ){

		return array(
			'result' => false,
			'message' => esc_html__( "Minimum length of password is 5." , 'extretion' )
		);

	} elseif( $pass1 != $pass2 ){

		return array(
			'result' => false,
			'message' => esc_html__( "Both passwords should be same." , 'extretion' )
		);

	} elseif( $pass1 == $pass2 && preg_match_all( $r1 , $pass1 , $o ) < 1 && $pass_strength == 2 ){

		return array(
			'result' => false,
			'message' => esc_html__( "Your password should contain atleast 1 uppercase character." , 'extretion' )
		);

	} elseif( $pass1 == $pass2 && preg_match_all( $r2 , $pass1 , $o )<1 && $pass_strength == 2 ){

		return array(
			'result' => false,
			'message' => esc_html__( "Your password should contain atleast 1 lowercase character." , 'extretion' )
		);

	} elseif( $pass1 == $pass2 && preg_match_all( $r3 , $pass1 , $o )<1 && $pass_strength == 2 ){

		return array(
			'result' => false,
			'message' => esc_html__( "Your password should contain atleast 1 special character ( !@#$%^&*()\-_=+{};:,<.> )." , 'extretion' )
		);

	} elseif( $pass1 == $pass2 && preg_match_all( $r4 , $pass1 , $o )<1 && $pass_strength == 2 ){

		return array(
			'result' => false,
			'message' => esc_html__( "Your password should contain atleast 1 number." , 'extretion' )
		);

	} else {

		return array( 'result' => true );

	}		

}

function extretion_insertUser( $data ){

	$userdata = array(
        'user_login'  =>  sanitize_text_field( $data['username'] ),
        'user_pass'   =>  sanitize_text_field( $data['register_password'] ),
        'user_email' => sanitize_text_field( $data['email'] ),
        'role' => 'subscriber'
    );
    
    $user_id = wp_insert_user( $userdata );
    return $user_id;

}

function extretion_upload_default_user_picture( $user_id ){

	require_once(ABSPATH . "wp-admin" . '/includes/image.php');
    require_once(ABSPATH . "wp-admin" . '/includes/file.php');
    require_once(ABSPATH . "wp-admin" . '/includes/media.php');

	// URL to the WordPress logo
	$url =  get_template_directory_uri() . '/images/default_avatar.png';
	$timeout_seconds = 5;
	$id = '';

	// download file to temp dir
	$temp_file = download_url( $url, $timeout_seconds );

	if (!is_wp_error( $temp_file )) {

		// array based on $_FILE as seen in PHP file uploads
		$file = array(
			'name' => basename($url), // ex: wp-header-logo.png
			'type' => 'image/png',
			'tmp_name' => $temp_file,
			'error' => 0,
			'size' => filesize($temp_file),
		);

		$id = media_handle_sideload( $file , 0 , null );

	} else {
		@unlink( $temp_file );
	}

	return $id;

}

function extretion_saveRegisteredUserDate( $data ){	

	if( !empty( $data ) ){

		// Insert new user
		$user_id = extretion_insertUser( $data );

		$user_image_id = extretion_upload_default_user_picture( $user_id );
		update_user_meta( $user_id, 'profile_picture', array( $user_image_id ) );

		if( $user_id ){

			foreach( $data as $key => $value ){

				$callback = extretion_getCallback( $key , 'name' , 'sanitize_callback' , 'extretion_getRegisterArguments' );
				$sanitizeData = null;

				/**
				* If no callback function define do not validate
				*/

				if( $callback != false ){

					/**
					* Sanitize data to save in the database
					*/

					$sanitizeData = $callback( $value );

				}

				// If sanitize data available take that if not take the $_POST data
				$filterValue = ( $sanitizeData == null ? $value : $sanitizeData );

				$ignore_keys = array( 
					'username', 
					'email',
					'register_password', 
					'register_password_confirm',
					'user_input_captcha',
					'captcha_prefix'
				);

				if( !in_array( $key , $ignore_keys ) ){
					update_user_meta( $user_id, sanitize_text_field( $key ) , $filterValue );	
				}				

			}

			// For verification
			update_user_meta( $user_id, 'verification' , false );
			update_user_meta( $user_id, 'verification_key' , wp_generate_password( 20 , false , false ) );

			do_action( 'extretion_after_registration_complete' , $user_id );

			//lmh_automaticLoginUser( $data );

		}
		
	}

}

function extretion_sanitize_register_phone( $value ){

	return ltrim( $value , '9' );

}

function extretion_check_db_user( $value ){

	$len = strlen($value);
	if( empty( $value ) ){

		return array( 
			'result' => false,
			'message' => esc_html__( 'Username cannot be empty' , 'extretion' )
		);

	} elseif( username_exists( $value ) ){

		return array( 
			'result' => false,
			'message' => esc_html__( 'Username already exists' , 'extretion' )
		);

	} elseif( !validate_username( $value ) ){

		return array( 
			'result' => false,
			'message' => esc_html__( 'Invalid username.' , 'extretion' )
		);

	} elseif( $len < 3 ){

		return array( 
			'result' => false,
			'message' => esc_html__( 'Username is too short, minimum 3 characters.' , 'extretion' )
		);

	}

	return true;

}

function extretion_check_user_email( $email ){

	$pattern = '/^(?!(?:(?:\\x22?\\x5C[\\x00-\\x7E]\\x22?)|(?:\\x22?[^\\x5C\\x22]\\x22?)){255,})(?!(?:(?:\\x22?\\x5C[\\x00-\\x7E]\\x22?)|(?:\\x22?[^\\x5C\\x22]\\x22?)){65,}@)(?:(?:[\\x21\\x23-\\x27\\x2A\\x2B\\x2D\\x2F-\\x39\\x3D\\x3F\\x5E-\\x7E]+)|(?:\\x22(?:[\\x01-\\x08\\x0B\\x0C\\x0E-\\x1F\\x21\\x23-\\x5B\\x5D-\\x7F]|(?:\\x5C[\\x00-\\x7F]))*\\x22))(?:\\.(?:(?:[\\x21\\x23-\\x27\\x2A\\x2B\\x2D\\x2F-\\x39\\x3D\\x3F\\x5E-\\x7E]+)|(?:\\x22(?:[\\x01-\\x08\\x0B\\x0C\\x0E-\\x1F\\x21\\x23-\\x5B\\x5D-\\x7F]|(?:\\x5C[\\x00-\\x7F]))*\\x22)))*@(?:(?:(?!.*[^.]{64,})(?:(?:(?:xn--)?[a-z0-9]+(?:-+[a-z0-9]+)*\\.){1,126}){1,}(?:(?:[a-z][a-z0-9]*)|(?:(?:xn--)[a-z0-9]+))(?:-+[a-z0-9]+)*)|(?:\\[(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){7})|(?:(?!(?:.*[a-f0-9][:\\]]){7,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?)))|(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){5}:)|(?:(?!(?:.*[a-f0-9]:){5,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3}:)?)))?(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))(?:\\.(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))){3}))\\]))$/iD';

	if( empty( $email ) ){
		return array( 
			'result' => false,
			'message' => esc_html__( 'Email address cannot be empty.' , 'extretion' )
		);
	} elseif( preg_match( $pattern, $email ) !== 1 ){
		return array( 
			'result' => false,
			'message' => esc_html__( 'Not a valid email address.' , 'extretion' )
		);
	}

	$user_id = get_current_user_id();
	$user_email = get_the_author_meta( 'user_email' , $user_id );

	// Database email and new email should not be same
	if( $user_email != $email ){

		if ( email_exists( $email ) ){

			return array( 
				'result' => false,
				'message' => esc_html__( 'Email address already exists.' , 'extretion' )
			);

		}

	}

	return true;

}

function extretion_check_db_email( $email ){

	$pattern = '/^(?!(?:(?:\\x22?\\x5C[\\x00-\\x7E]\\x22?)|(?:\\x22?[^\\x5C\\x22]\\x22?)){255,})(?!(?:(?:\\x22?\\x5C[\\x00-\\x7E]\\x22?)|(?:\\x22?[^\\x5C\\x22]\\x22?)){65,}@)(?:(?:[\\x21\\x23-\\x27\\x2A\\x2B\\x2D\\x2F-\\x39\\x3D\\x3F\\x5E-\\x7E]+)|(?:\\x22(?:[\\x01-\\x08\\x0B\\x0C\\x0E-\\x1F\\x21\\x23-\\x5B\\x5D-\\x7F]|(?:\\x5C[\\x00-\\x7F]))*\\x22))(?:\\.(?:(?:[\\x21\\x23-\\x27\\x2A\\x2B\\x2D\\x2F-\\x39\\x3D\\x3F\\x5E-\\x7E]+)|(?:\\x22(?:[\\x01-\\x08\\x0B\\x0C\\x0E-\\x1F\\x21\\x23-\\x5B\\x5D-\\x7F]|(?:\\x5C[\\x00-\\x7F]))*\\x22)))*@(?:(?:(?!.*[^.]{64,})(?:(?:(?:xn--)?[a-z0-9]+(?:-+[a-z0-9]+)*\\.){1,126}){1,}(?:(?:[a-z][a-z0-9]*)|(?:(?:xn--)[a-z0-9]+))(?:-+[a-z0-9]+)*)|(?:\\[(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){7})|(?:(?!(?:.*[a-f0-9][:\\]]){7,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?)))|(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){5}:)|(?:(?!(?:.*[a-f0-9]:){5,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3}:)?)))?(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))(?:\\.(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))){3}))\\]))$/iD';


	if( empty( $email ) ){
		return array( 
			'result' => false,
			'message' => esc_html__( 'Email address cannot be empty.' , 'extretion' )
		);
	} elseif( preg_match( $pattern, $email ) !== 1 ){
		return array( 
			'result' => false,
			'message' => esc_html__( 'Not a valid email address.' , 'extretion' )
		);
	} elseif( email_exists( $email ) ){
		return array( 
			'result' => false,
			'message' => esc_html__( 'Email address already exists.' , 'extretion' )
		);
	}

	return true;

}

function extretion_check_website( $value ){

	if( empty( $value ) ){
		return true;
	}

	if ( extretion_checkValidUrl( $value ) === false ) {
	    return array( 
			'result' => false,
			'message' => esc_html__( 'Please enter valid URL' , 'extretion' )
		);
	}

	return true;

}

function extretion_check_register_mobile( $value ){

	// empty() bcoz phone no is not required
	if( empty( $value ) || is_numeric( $value ) ){
		return array( 'result' => true );
	} else {
		return array( 
			'result' => false,
			'message' => esc_html__( 'Please enter only numbers in mobile field' , 'extretion' )
		);
	}

}

function extretion_check_register_phone( $value ){

	// empty() bcoz phone no is not required
	if( empty( $value ) || is_numeric( $value ) ){
		return array( 'result' => true );
	} else {
		return array( 
			'result' => false,
			'message' => esc_html__( 'Please enter only numbers in phone field' , 'extretion' )
		);
	}

}

function extretion_listYourRoomArguments(){

	$args = extretion_listYourPropertyFields();

	$data = array();
	foreach( $args as $value ){
		foreach( $value['fields'] as $fields ){
			$data[] = $fields;
		}
	}

	return $data;

}

add_filter( 'extretion_ignore_sanitize' , 'extretion_ignore_sanitize' , 10 , 2 );
function extretion_ignore_sanitize( $args , $arguments ){

	if( $arguments == 'extretion_listYourRoomArguments' ){
		$args = array( 
			'required_at_check_in', 
			'children_check_in', 
			'pet_policy', 
			'cancellation_policy_room',
			'payment_policy_room'
		);
	}

	return $args;

}

add_action( 'comment_form_logged_in_after', 'extretion_add_rating_fields_room_detail' );
add_action( 'comment_form_after_fields', 'extretion_add_rating_fields_room_detail' );

function extretion_add_rating_fields_room_detail( $default ) { 

	if( !is_singular('room') ){
		return;
	}?>

	<div class="row">

	    <div class="comment-form-rating-cleanliness">

	    	<div class="label_holder col-sm-3">
		        <label for="cleanliness" class="">
		        	<?php esc_html_e( 'Cleanliness' , 'extretion' ); ?>
		        </label>
		        <span class="text-danger">*</span>
		    </div>
	        <div class="rating rating-cleanliness col-sm-3"></div>
	    </div>

	</div>

	<div class="row">
	    
	    <div class="comment-form-rating-service">
	    	<div class="label_holder col-sm-3">
	        	<label for="service"><?php esc_html_e( 'Service' , 'extretion' ); ?></label>
	       	 	<span class="text-danger">*</span>
	       	</div>
	        <div class="rating rating-service col-sm-3"></div>
	    </div>

	</div>

	<div class="row">

	    <div class="comment-form-rating-comfort">
	    	<div class="label_holder col-sm-3">
	        	<label for="comfort"><?php esc_html_e( 'Comfort' , 'extretion' ); ?></label>
	        	<span class="text-danger">*</span>
	        </div>
	        <div class="rating rating-comfort col-sm-3"></div>
	    </div>

	</div>

	<div class="row">

	    <div class="comment-form-rating-condition">
	    	<div class="label_holder col-sm-3">
	        	<label for="condition"><?php esc_html_e( 'Condition' , 'extretion' ); ?></label>
	        	<span class="text-danger">*</span>
	        </div>
	        <div class="rating rating-condition col-sm-3"></div>
	    </div>

	</div>

	<div class="row">

	    <div class="comment-form-rating-neighbourhood">
	    	<div class="label_holder col-sm-3">
	        	<label for="neighbourhood"><?php esc_html_e( 'Neighbourhood' , 'extretion' ); ?></label>
	        	<span class="text-danger">*</span>
	        </div>
	        <div class="rating rating-neighbourhood col-sm-3"></div>
	    </div>

	</div>

	<div class="row">

	    <div class="comment-form-recommend">
	    	<div class="label_holder col-sm-3">
	        	<label for="neighbourhood"><?php esc_html_e( 'Recommend to others ?' , 'extretion' ); ?></label>
	        </div>
	        <div class="col-sm-3">

	        	<div class="checkbox-block font-icon-checkbox">
					<input id="recommend-checkbox" autocomplete="off" name="recommend" type="checkbox" class="checkbox" value="yes"/>
					<label for="recommend-checkbox" class="checkbox_label label-recommend"><?php esc_html_e( 'Yes' , 'extretion' ); ?></label>
				</div>

	        </div>
	    </div>

	</div>

	<div class="mb-10"></div>

	<div class="row">

	    <div class="comment-form-title col-sm-12">
	        	<label for="neighbourhood"><?php esc_html_e( 'Title' , 'extretion' ); ?></label>
	        	<span class="text-danger">*</span>
	        <input type="text" value="" name="comment_title" class="form-control">
	    </div>

	</div>

    <?php
}

add_action( 'comment_post', 'extretion_save_comment_room_meta_data' );
function extretion_save_comment_room_meta_data( $comment_id ) {

	//print_r($_POST); die;
    add_comment_meta( $comment_id, 'comment_title', sanitize_text_field( $_POST[ 'comment_title' ] ) );
    add_comment_meta( $comment_id, 'room_cleanliness', sanitize_text_field( $_POST[ 'room_cleanliness' ] ) );
    add_comment_meta( $comment_id, 'room_service', sanitize_text_field( $_POST[ 'room_service' ] ) );
    add_comment_meta( $comment_id, 'room_comfort', sanitize_text_field( $_POST[ 'room_comfort' ] ) );
    add_comment_meta( $comment_id, 'room_condition', sanitize_text_field( $_POST[ 'room_condition' ] ) );
    add_comment_meta( $comment_id, 'neighbourhood', sanitize_text_field( $_POST[ 'room_neighbourhood' ] ) );

    if( !empty( $_POST[ 'recommend' ] ) && $_POST[ 'recommend' ] == 'yes' ){
    	$recommend = 'yes';
    } else {
    	$recommend = 'no';
    }

    add_comment_meta( $comment_id, 'recommend', sanitize_text_field( $recommend ) );
}

add_filter( 'preprocess_comment', 'extretion_verify_comment_meta_data' );

function extretion_verify_comment_meta_data( $commentdata ) {

	if( !is_singular('room') ){
		return $commentdata;
	}

	$comment_title = sanitize_text_field( $_POST['comment_title'] );
	$room_cleanliness = sanitize_text_field( $_POST['room_cleanliness'] );
	$room_service = sanitize_text_field( $_POST['room_service'] );
	$room_comfort = sanitize_text_field( $_POST['room_comfort'] );
	$room_condition = sanitize_text_field( $_POST['room_condition'] );
	$neighbourhood = sanitize_text_field( $_POST['room_neighbourhood'] );

    if ( empty( $comment_title ) || empty( $room_cleanliness ) || empty( $room_service ) || empty( $room_comfort ) || empty( $room_condition ) || empty( $neighbourhood ) ){

        wp_die( esc_html__( 'Error: Please fill all the required fields.' , 'extretion' ) , '' , array( 'back_link' => true ) );

    }

    return $commentdata;
}

function extretion_get_individual_avg_rating( $comment_id ){

	$room_cleanliness = get_comment_meta( $comment_id, 'room_cleanliness', true );
	$room_service = get_comment_meta( $comment_id, 'room_service', true );
	$room_comfort = get_comment_meta( $comment_id, 'room_comfort', true );
	$room_condition = get_comment_meta( $comment_id, 'room_condition', true );
	$neighbourhood = get_comment_meta( $comment_id, 'neighbourhood', true );

	$total = $room_cleanliness + $room_service + $room_comfort + $room_condition + $neighbourhood;

	$avg = ( $total/5 );

	return number_format( $avg , 0 );
}

function extretion_get_individual_rating_words( $rating ){

	switch ( $rating ) {
		case '1':
			return esc_html__( 'Bad' , 'extretion' );
			break;

		case '2':
			return esc_html__( 'Poor' , 'extretion' );
			break;

		case '3':
			return esc_html__( 'Regular' , 'extretion' );
			break;

		case '4':
			return esc_html__( 'Good' , 'extretion' );
			break;

		case '5':
			return esc_html__( 'Excellent' , 'extretion' );
			break;
		
		default:
			//return esc_html__( 'Not Rated Yet' , 'extretion' );
			return '&nbsp;';
			break;
	}

}

function extretion_get_all_avg_rating( $post_id ){

	$results = get_comments(
		array(
			'post_id' => $post_id,
			'status' => 'approve',
		)
	);

	if( !empty( $results ) ){

		$total_avg_rating = array();

		foreach( $results as $value ){

			$comment_id = $value->comment_ID;

			$room_cleanliness = get_comment_meta( $comment_id, 'room_cleanliness', true );
			$room_service = get_comment_meta( $comment_id, 'room_service', true );
			$room_comfort = get_comment_meta( $comment_id, 'room_comfort', true );
			$room_condition = get_comment_meta( $comment_id, 'room_condition', true );
			$neighbourhood = get_comment_meta( $comment_id, 'neighbourhood', true );

			$total_avg_rating[] = $room_cleanliness + $room_service + $room_comfort + $room_condition + $neighbourhood;

		}

		//echo '<pre>'; print_r($total_avg_rating); echo '</pre>';

		$total_rating = '';
		foreach( $total_avg_rating as $value ){

			$total_rating += $value;

		}

		$avg_total = ( $total_rating/count($total_avg_rating) ) / 5;

		return $avg_total;

	}

	return 0;

}

function extretion_show_score_breakdown( $post_id ){

	$results = get_comments(
		array(
			'post_id' => $post_id,
			'status' => 'approve',
		)
	);

	if( !empty( $results ) ){

		foreach( $results as $value ){

			$comment_id = $value->comment_ID;

			$room_cleanliness = get_comment_meta( $comment_id, 'room_cleanliness', true );
			$room_service = get_comment_meta( $comment_id, 'room_service', true );
			$room_comfort = get_comment_meta( $comment_id, 'room_comfort', true );
			$room_condition = get_comment_meta( $comment_id, 'room_condition', true );
			$neighbourhood = get_comment_meta( $comment_id, 'neighbourhood', true );

			$total = ( $room_cleanliness + $room_service + $room_comfort + $room_condition + $neighbourhood ) / 5;

			$total_avg_rating[] = number_format( $total , 0 );

		}

		$array_count_values = array_count_values( $total_avg_rating );
		$total_keys = count( $total_avg_rating );

		for( $i = 5; $i >= 1 ; $i-- ){ ?>

			<li>
				<span class="absolute number font700 full">
					<?php echo number_format( $i , 1 ); ?>
				</span>
				<div class="progress progress-primary">
					<div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo extretion_progressbar_length( $array_count_values , $i , $total_keys ); ?>%;"></div>
				</div>
				<span class="absolute people-count">(<?php echo extretion_no_of_comments_rating( $array_count_values , $i ); ?>)</span>
			</li>			

			<?php
		}

		//echo '<pre>'; print_r( $total_avg_rating ); echo '</pre>';
		//echo '<pre>'; print_r( array_count_values( $total_avg_rating ) ); echo '</pre>';

	}

}

function extretion_no_of_comments_rating( $array_count_values , $number ){

	return ( !empty( $array_count_values[$number] ) ? $array_count_values[$number] : 0 );

}

function extretion_progressbar_length( $array_count_values , $number , $total_keys ){

	return ( !empty( $array_count_values[$number] ) ? ( $array_count_values[$number]/$total_keys ) * 100 : 0 );

}

function extretion_title_star_width( $rating , $post_id = '' , $class = null ){

	//$rating = number_format( $rating );

	echo '<span class=" ' . $class . ' rating_wrapper aggregrate_rating' . $post_id . '"></span>';
	echo '<script>
	jQuery( document ).ready( function(){

		jQuery.fn.raty.defaults.path = lmhAjax.theme_path + "/images/raty";
		jQuery(".aggregrate_rating' . $post_id . '").raty({
			readOnly : true, 
			space: false,
			score : ' . number_format( $rating , 1 ) . '
		});		

	});
	</script>';


}

function extretion_count_published_comments( $post_id ){

	$results = get_comments(
		array(
			'post_id' => $post_id,
			'status' => 'approve',
		)
	);

	return count( $results );

}

function extretion_get_recommend_percentage( $post_id ){

	$results = get_comments(
		array(
			'post_id' => $post_id,
			'status' => 'approve',
		)
	);

	if( !empty( $results ) ){

		$total_recommend = array();

		foreach( $results as $value ){

			$comment_id = $value->comment_ID;

			$total_recommend[] = get_comment_meta( $comment_id, 'recommend', true );

		}

		$count = 0;
		foreach( $total_recommend as $value ){

			if( $value == 'yes' ){
				$count++;
			}

		}

		$recommend_percentage = ($count/count( $total_recommend )) * 100;

		return $recommend_percentage;

		//echo '<pre>'; print_r($recommend_percentage); echo '</pre>';

	}

}

//add_action( 'init' , 'get_averating_for_meta_value' );
function extretion_get_averating_for_meta_value( $post_id ){

	$meta_values = array( 'room_cleanliness' , 'room_service' , 'room_comfort' , 'room_condition' , 'neighbourhood' );
	
	global $wpdb;

	foreach( $meta_values as $value ){

		$query = $wpdb->prepare(
			"SELECT mt1.meta_key,mt1.meta_value 
				FROM {$wpdb->commentmeta} as mt1,{$wpdb->comments} as mt2,{$wpdb->commentmeta} as mt3
				WHERE mt1.comment_id = mt2.comment_ID
				AND mt3.comment_id = mt2.comment_ID
				AND mt2.comment_post_ID = %d
				AND mt2.comment_approved = %d
				AND mt3.meta_key = %s
				AND mt1.meta_key = %s",
			$post_id,
			1,
			$value,
			$value
		);
		

		$results = $wpdb->get_results( $query , ARRAY_A );

		$aggregrate = 0;

		if( !empty( $results ) ){

			foreach( $results as $meta_value ){

				$aggregrate += $meta_value['meta_value'];			

			}

		}

		switch ( $value ) {
			case 'room_cleanliness':
				$label = esc_html__( 'Cleanliness', 'extretion' );
				break;

			case 'room_service':
				$label = esc_html__( 'Service' , 'extretion' );
				break;

			case 'room_comfort':
				$label = esc_html__( 'Comfort' , 'extretion' );
				break;

			case 'room_condition':
				$label =  esc_html__( 'Condition' , 'extretion' );
				break;
			
			default:
				$label = esc_html__( 'Neighbourhood' , 'extretion' );
				break;
		}

		if( $aggregrate == 0 ){
			echo '<li>' . $label . '<span class="pull-right">0</span></li>';
		} else {
			echo '<li>' . $label . '<span class="pull-right">' . number_format( ( $aggregrate )/count( $results ) , 1 ) . '</span></li>';
		}

	}

}

function extretion_check_room_accomodates( $post_id ){

	$accomodates = get_post_meta( $post_id, 'guest_accomodate', true );

	$accomodates = !empty( $accomodates ) ? sanitize_text_field( $accomodates ) : 1;

	for( $i = 1 ; $i <= $accomodates ; $i++ ){

		echo '<option value="' . $i . '">' . $i . '</option>';

	}

}

// add_action( 'init' , 'set_available_unavaliable_dates' );

// function set_available_unavaliable_dates(){

// 	$meta_value = array(
// 		'21-07-2016',
// 		'22-07-2016',
// 		'23-07-2016',
// 		'27-07-2016',
// 		'28-07-2016',
// 	);

// 	update_post_meta( 661 , 'booking_unavailable_dates' , $meta_value );
// }

add_action( 'init', 'extretion_rewrite_rules' );
function extretion_rewrite_rules(){

	$book_now_redirect = get_permalink( get_option( 'options_select_booking_detail_page' ) ); 
	$rewrite_url = str_replace( site_url() . '/' , '' , $book_now_redirect );

	if( !empty( $book_now_redirect ) ){

		add_rewrite_rule(

	        $rewrite_url . '([0-9]+)/([^/]*)/?',

	        'index.php?pagename=' . rtrim( $rewrite_url , "/") . '&post_id=$matches[1]&secret=$matches[2]',

	        'top'

	    );

	}

	$step_2_redirect = get_permalink( get_option( 'options_select_booking_confirmation_page' ) );
	$rewrite_url_2 = str_replace( site_url() . '/' , '' , $step_2_redirect );
	
	if( !empty( $step_2_redirect ) ){

		add_rewrite_rule(

	        $rewrite_url_2 . '([0-9]+)/([^/]*)/?',

	        'index.php?pagename=' . rtrim( $rewrite_url_2 , "/") . '&post_id=$matches[1]&secret=$matches[2]',

	        'top'

	    );

	}

	$step_3_redirect = get_permalink( get_option( 'options_select_booking_approval_page' ) );
	$rewrite_url_3 = str_replace( site_url() . '/' , '' , $step_3_redirect );

	if( !empty( $step_3_redirect ) ){

		add_rewrite_rule(

	        $rewrite_url_3 . '([0-9]+)/?',

	        'index.php?pagename=' . rtrim( $rewrite_url_3 , "/") . '&post_id=$matches[1]',

	        'top'

	    );

	}

	$step_4_redirect = get_permalink( get_option( 'options_select_booking_confirmation_n_payment' ) );
	$rewrite_url_4 = str_replace( site_url() . '/' , '' , $step_4_redirect );

	if( !empty( $step_4_redirect ) ){

		add_rewrite_rule(

	        $rewrite_url_4 . '([0-9]+)/?',

	        'index.php?pagename=' . rtrim( $rewrite_url_4 , "/") . '&post_id=$matches[1]',

	        'top'

	    );

	}

}

add_filter( 'query_vars', 'extretion_query_vars' );
function extretion_query_vars( $query_vars )
{
    $query_vars[] = 'post_id';
    $query_vars[] = 'secret';
    return $query_vars;
}

function extretion_get_order_id( $post_id , $secret ){

	$order_ids = get_post_meta( $post_id, 'order_ids' , true );

	if( !empty( $order_ids ) ){

		foreach( $order_ids as $value ){

			//echo '<pre>'; print_r($value); echo '</pre>';

			if( $value['attributes']['post_id'] == $post_id && $value['attributes']['secret_key'] == $secret ){

				return $value['attributes'];

			}

		}

	}

}

function extretion_check_secret_key_order( $post_id , $secret ){

	$order_ids = get_post_meta( $post_id, 'order_ids' , true );

	if( !empty( $order_ids ) ){

		foreach( $order_ids as $value ){

			if( $value['attributes']['post_id'] == $post_id && $value['attributes']['secret_key'] == $secret && extretion_check_order_time( $value['attributes']['updated_at'] ) == true ){

				return true;

			}

		}

	}

	return false;

}

function extretion_check_order_time( $db_time ){

	$start = strtotime( date( 'H:i' , strtotime($db_time) ) );

	$end = strtotime( date('H:i', $start) ) + 60*60;

	$now = strtotime( date( 'H:i' ) );

	if( $now >= $start && $now <= $end ){
		return true;
	}
	return false;

}

function extretion_default_labels(){

	/** 
	* Booking Page Step 2 
	*/

	$args['book_now_rules_step_2'] = get_option( 'options_terms_and_conditions_message' );
		
	$args['secure_your_price'] = esc_html__( 'Prices may go up&#44; so secure your reservation today.' , 'extretion' );
	$args['congratulations_msg'] = esc_html__( 'Congratulations&#44; you&#39;ve got the best price at just ' , 'extretion' );
	$args['guest_info_last_name'] = esc_html__( 'Last Name' , 'extretion' );
	$args['guest_info_first_name'] = esc_html__( 'First Name' , 'extretion' );
	$args['guest_label'] = esc_html__( 'Guest' , 'extretion' );
	$args['guest_info_label'] = esc_html__( 'Guests Information' , 'extretion' );
	$args['billing_info_phone'] = esc_html__( 'Phone' , 'extretion' );
	$args['billing_info_country'] = esc_html__( 'Country' , 'extretion' );
	$args['billing_info_city'] = esc_html__( 'City' , 'extretion' );
	$args['billing_info_postal_code'] = esc_html__( 'Postal Code' , 'extretion' );
	$args['billing_info_street_address'] = esc_html__( 'Street Address' , 'extretion' );
	$args['billing_info_email_address'] = esc_html__( 'Email Address' , 'extretion' );
	$args['billing_info_last_name'] = esc_html__( 'Last Name' , 'extretion' );
	$args['billing_info_first_name'] = esc_html__( 'First Name' , 'extretion' );
	$args['billing_info_label'] = esc_html__( 'Billing Information' , 'extretion' );
	$args['billing_info_fill_all_fields'] = esc_html__( 'Fill in your details below to complete the booking. The host will then have 24 hours to accept your booking request. Once your booking is accepted, we will send you a confirmation email with the host&#39;s contact details and the exact address of the property.' , 'extretion' );
	$args['billing_info_great_choice'] = esc_html__( 'Great choice! You&#39;re just 1 minute away from booking.' , 'extretion' );
	$args['billing_info_price_title'] = esc_html__( 'Price' , 'extretion' );
	$args['billing_info_check_out'] = esc_html__( 'Check-out:' , 'extretion' );
	$args['billing_info_check_in'] = esc_html__( 'Check-in:' , 'extretion' );
	$args['billing_info_your_dates'] = esc_html__( 'Your Dates' , 'extretion' );
	$args['billing_info_required_fields'] = 'Fields marked with asterisk ( <span class="text-danger">*</span> ) are required';
	$args['billing_info_book_now_btn'] = esc_html__( 'Book Now' , 'extretion' );

	/** 
	* Booking Page Step 3 
	*/

	$args['confirmation_fname'] = esc_html__( 'First Name:' , 'extretion' );
	$args['confirmation_lname'] = esc_html__( 'Last Name:' , 'extretion' );
	$args['confirmation_email'] = esc_html__( 'Email:' , 'extretion' );
	$args['confirmation_street'] = esc_html__( 'Street Address:' , 'extretion' );
	$args['confirmation_postal'] = esc_html__( 'Postal Code:' , 'extretion' );
	$args['confirmation_city'] = esc_html__( 'City:' , 'extretion' );
	$args['confirmation_country'] = esc_html__( 'Country:' , 'extretion' );
	$args['confirmation_phone'] = esc_html__( 'Phone:' , 'extretion' );
	$args['confirmation_price_lable'] = esc_html__( 'Guest &#38; Price Informations' , 'extretion' );
	$args['confirmation_no_of_nights'] = esc_html__( 'night(s)' , 'extretion' );
	$args['confirmation_total'] = esc_html__( 'Total' , 'extretion' );

	/** 
	* Search Page
	*/

	$args['search_page']['search_again'] = esc_html__( 'Search Again' , 'extretion' );
	$args['search_page']['where_to_go'] = esc_html__( 'Where do you want to go?' , 'extretion' );
	$args['search_page']['type_a_place'] = esc_html__( 'Type a place' , 'extretion' );
	$args['search_page']['check_in'] = esc_html__( 'Check-in' , 'extretion' );
	$args['search_page']['check_out'] = esc_html__( 'Check-out' , 'extretion' );
	$args['search_page']['rooms'] = esc_html__( 'Guest' , 'extretion' );
	$args['search_page']['search'] = esc_html__( 'Search' , 'extretion' );
	$args['search_page']['start_from'] = esc_html__( 'start from' , 'extretion' );
	$args['search_page']['per_night'] = esc_html__( 'per night' , 'extretion' );
	$args['search_page']['per_week'] = esc_html__( 'per week' , 'extretion' );
	$args['search_page']['per_month'] = esc_html__( 'per month' , 'extretion' );
	$args['search_page']['details'] = esc_html__( 'Details' , 'extretion' );
	$args['search_page']['filter'] = esc_html__( 'Filter' , 'extretion' );
	$args['search_page']['room_type'] = esc_html__( 'Room Type' , 'extretion' );
	$args['search_page']['show_all'] = esc_html__( 'Show All' , 'extretion' );
	$args['search_page']['price'] = esc_html__( 'Price' , 'extretion' );
	$args['search_page']['size'] = esc_html__( 'Size' , 'extretion' );
	$args['search_page']['bedrooms'] = esc_html__( 'Bedrooms' , 'extretion' );
	$args['search_page']['bathrooms'] = esc_html__( 'Bathrooms' , 'extretion' );
	$args['search_page']['beds'] = esc_html__( 'Beds' , 'extretion' );
	$args['search_page']['facilities'] = esc_html__( 'Facilities' , 'extretion' );
	$args['search_page']['type_of_place'] = esc_html__( 'Type of Place' , 'extretion' );
	$args['search_page']['show_on_map'] = esc_html__( 'Show on map' , 'extretion' );
	$args['search_page']['sort_by'] = esc_html__( 'Sort by:' , 'extretion' );
	$args['search_page']['distance'] = esc_html__( 'Distance' , 'extretion' );
	$args['search_page']['name'] = esc_html__( 'Name' , 'extretion' );
	$args['search_page']['per_night_grid'] = esc_html__( '&#47; night' , 'extretion' );
	$args['search_page']['per_week_grid'] = esc_html__( '&#47; week' , 'extretion' );
	$args['search_page']['per_month_grid'] = esc_html__( '&#47; month' , 'extretion' );

	/** 
	* HomePage
	*/

	$args['homepage']['destination-search-homepage'] = esc_html__( 'Country or City' , 'extretion' );
	$args['homepage']['check_in'] = esc_html__( 'Check-in' , 'extretion' );
	$args['homepage']['check_out'] = esc_html__( 'Check-out' , 'extretion' );
	$args['homepage']['guests'] = esc_html__( 'Guests' , 'extretion' );
	$args['homepage']['sign_up'] = esc_html__( 'Sign-up' , 'extretion' );
	$args['homepage']['become_host'] = esc_html__( 'Become a host' , 'extretion' );
	$args['homepage']['currency'] = esc_html__( 'Currency' , 'extretion' );
	$args['homepage']['hotline'] = esc_html__( 'Hot Line:' , 'extretion' );

	/** 
	* Others
	*/

	$max_photos_upload_detail_page = get_option( 'options_max_photos_upload_detail_page' );
	$max_photos_upload_detail_page = is_numeric( $max_photos_upload_detail_page ) ? $max_photos_upload_detail_page : 10;

	$args['other']['max_upload_msg'] = sprintf( esc_html__( 'Browse Files (up to %d photos)' , 'extretion' ) , $max_photos_upload_detail_page );

	$args = apply_filters( 'extretion_lmh_default_labels' , $args );
	return $args;

}

function extretion_check_guest_fields( $datapost ){

	$guest_info = get_option( 'options_guest_information' ); 
	$required_fields = get_option( 'options_guest_info_fields' );

	if( $guest_info != 1 ){
		return;
	}

	if( ( empty( $required_fields ) || $required_fields == 1 ) && $guest_info != 1 ){
		
		if( empty( $datapost['guest_fname'] ) || empty( $datapost['guest_lname'] ) ){

			echo json_encode(
				array(
					'result' => 'error',
				)
			);
			die;

		}

	}

}

add_action( 'wp_ajax_save_billing_info' , 'extretion_save_billing_info' );
function extretion_save_billing_info(){

	parse_str( $_POST['datas'], $datapost ); 

	$ignore_keys = apply_filters( 'extretion_billing_info_ignore_keys' , $ignore_keys = array() );
	$sanitizePost = array();
	$count = false;

	// Get options from the backend( Options page ) and compare it
	extretion_check_guest_fields( $datapost );

	foreach( $datapost as $key => $value ){

		$name = $key;
		$name_value = $value;

		// if ignore key is set then do not validate
		if( !in_array( $name , $ignore_keys ) ){

			if( empty( $name_value ) ){

				$count = true;

			}

		}

		if ( strpos(  $name , 'guests_fname' ) !== false) {
		    $sanitizePost['guest_fname'] = array_map( 'sanitize_text_field' , $name_value );
		} elseif( strpos(  $name , 'guests_lname' ) !== false ){
			$sanitizePost['guest_lname'] = array_map( 'sanitize_text_field' , $name_value );
		} else {
			$sanitizePost[$name] = sanitize_text_field( $name_value );
		}

	}

	if( $count == true ){
		echo json_encode(
			array(
				'result' => 'error',
			)
		);
		die;
	}
	
	extretion_booking_by_paypal( $sanitizePost );

	die;

}

function extretion_booking_by_paypal( $sanitizePost ){

	$post_id = sanitize_text_field( $sanitizePost['post_id'] );
	$secret = sanitize_text_field( $sanitizePost['secret'] );

	// Get Order Ids
	$order_ids = get_post_meta( $post_id, 'order_ids', true );

	unset( $sanitizePost['post_id'] );
	unset( $sanitizePost['secret'] );

	if( !empty( $order_ids ) ){

		foreach( $order_ids as $key => $value ){

			if( $value['attributes']['secret_key'] == $secret ){

				$order_ids[$key]['attributes']['step_2_attributes'] = $sanitizePost;

			}

		}

	}

	update_post_meta( $post_id, 'order_ids', $order_ids );

	$redirect_to = get_permalink( get_option( 'options_select_booking_confirmation_page' ) );
	$redirect_to = $redirect_to ? ( $redirect_to . $post_id . '/' . $secret ) : '';

	echo json_encode( array( 'result' => 'success' , 'redirect_to' => $redirect_to ) );

}

function extretion_check_page_template_breadcrum( $page_template ){

	if( is_page_template( $page_template ) ){
		return true;
	}

	return false;

}

function extretion_get_search_values( $ajax_data = null ){

	//echo '<pre>'; print_r($ajax_data); echo '</pre>';
	//print_r($ajax_data);
	$data = array();
	$data['booking_days'] = null;

	if( empty( $ajax_data ) ){

		$lat = !empty( $_GET['lat'] ) ? sanitize_text_field( $_GET['lat'] ) : '';
		$lng = !empty( $_GET['lng'] ) ? sanitize_text_field( $_GET['lng'] ) : '';
		$guests = !empty( $_GET['guests'] ) ? sanitize_text_field( $_GET['guests'] ) : '';
		$check_in = !empty( $_GET['arrival_date'] ) ? sanitize_text_field( $_GET['arrival_date'] ) : '';
		$check_out = !empty( $_GET['departure_date'] ) ? sanitize_text_field( $_GET['departure_date'] ) : '';
		$data['distance'] = '';
		$data['name'] = '';
		$data['price'] = '';
		//echo lmh_get_min_price_search_filter();
		$data['min_price'] = extretion_get_exchange_min_price( extretion_get_min_price_search_filter() );
		$data['max_price'] = extretion_get_exchange_max_price( extretion_get_max_price_search_filter() );
		$data['facility'] = '';
		$data['type_of_place'] = '';
		$data['room_type'] = '';
		$data['bedrooms'] = '';
		$data['bathrooms'] = '';
		$data['beds'] = '';
		$data['view'] = !empty( $_GET['view'] ) ? sanitize_text_field( $_GET['view'] ) : 'grid';

	} else {

		$no_rooms_to_display = get_option( 'options_number_of_rooms_to_display' );
		$no_rooms_to_display = !empty( $no_rooms_to_display ) ? sanitize_text_field( $no_rooms_to_display ) : 10;

		$lat = !empty( $ajax_data['lat'] ) ? sanitize_text_field( $ajax_data['lat'] ) : '';
		$lng = !empty( $ajax_data['lng'] ) ? sanitize_text_field( $ajax_data['lng'] ) : '';
		$guests = !empty( $ajax_data['guests'] ) ? sanitize_text_field( $ajax_data['guests'] ) : '';
		$check_in = !empty( $ajax_data['arrival_date'] ) ? sanitize_text_field( $ajax_data['arrival_date'] ) : '';
		$check_out = !empty( $ajax_data['departure_date'] ) ? sanitize_text_field( $ajax_data['departure_date'] ) : '';
		$data['offset'] = ( $ajax_data['page_no'] - 1 ) * $no_rooms_to_display;
		$data['distance'] = !empty( $ajax_data['distance'] ) ? sanitize_text_field( $ajax_data['distance'] ) : '';
		$data['name'] = !empty( $ajax_data['name'] ) ? sanitize_text_field( $ajax_data['name'] ) : '';
		$data['price'] = !empty( $ajax_data['price'] ) ? sanitize_text_field( $ajax_data['price'] ) : '';
		$data['facility'] = !empty( $ajax_data['facility'] ) ? $ajax_data['facility'] : '';
		$data['type_of_place'] = !empty( $ajax_data['type_of_place'] ) ? sanitize_text_field( $ajax_data['type_of_place'] ) : '';
		$data['room_type'] = !empty( $ajax_data['room_type'] ) ? sanitize_text_field( $ajax_data['room_type'] ) : '';
		$data['bedrooms'] = !empty( $ajax_data['bedrooms'] ) ? sanitize_text_field( $ajax_data['bedrooms'] ) : '';
		$data['bathrooms'] = !empty( $ajax_data['bathrooms'] ) ? sanitize_text_field( $ajax_data['bathrooms'] ) : '';
		$data['beds'] = !empty( $ajax_data['beds'] ) ? sanitize_text_field( $ajax_data['beds'] ) : '';
		$data['view'] = !empty( $ajax_data['view'] ) ? sanitize_text_field( $ajax_data['view'] ) : 'grid';

		/**
		* Min Currency
		*/

		if( !empty( $ajax_data['min_price'] ) ){

			$data['min_price'] = extretion_get_exchange_min_price( $ajax_data['min_price'] );

		} else {
			$data['min_price'] = null;
		}

		/**
		* Max Currency
		*/

		if( !empty( $ajax_data['max_price'] ) ){

			$data['max_price'] = extretion_get_exchange_max_price( $ajax_data['max_price'] );

		} else {
			$data['max_price'] = null;
		}

	}

	$data['lat'] = !empty( $lat ) ? $lat : apply_filters( 'extretion_default_latitude_search' , 27.6644011 );
	$data['lng'] = !empty( $lng ) ? $lng : apply_filters( 'extretion_default_longitude_search' , 85.31879140000001 );

	$search_radius = get_option( 'options_search_radius' );
	$data['radius'] = ( is_numeric( $search_radius ) ? $search_radius : 10 );

	$data['guests'] = !empty( $guests ) ? $guests : apply_filters( 'extretion_default_guest_search' , 1 );

	/* Check Dates */
	$data['booking_days'] = extretion_get_min_booking_dates( $check_in , $check_out );

	//print_r($data);
	return $data;

}

function extretion_get_min_booking_dates( $check_in , $check_out ){

	$check_in = !empty( $check_in ) ? sanitize_text_field( $check_in ) : '';
	$check_out = !empty( $check_out ) ? sanitize_text_field( $check_out ) : '';

	if( extretion_checkIsAValidDate($check_in) != false && extretion_checkIsAValidDate($check_out) != false ){

		// Get all dates bet start and between
		$user_dates_range = extretion_date_range( $check_in , $check_out );

		// Change date to seconds
		$check_in_str = strtotime( $check_in );
		$check_out_str = strtotime( $check_out );

		if( $check_in_str < $check_out_str ){

			return extretion_min_booking_dates( count( $user_dates_range ) - 1 );

		}

	}

	return '';

}

function extretion_get_exchange_max_price( $price ){

	$from_currency = !empty( $_COOKIE['currency'] ) ? sanitize_text_field( $_COOKIE['currency'] ) : sanitize_text_field( get_option( 'options_base_currency' ) );

	$exchange_price = extretion_exchange_currency( $price , $from_currency , $currency_only = NULL , 'NPR' , $commission = false );
	$max_price_per_night = preg_replace("/[^0-9\.]/", null, $exchange_price );

	$max_price = !empty( $max_price_per_night ) ? sanitize_text_field( $max_price_per_night ) : '';
	return $max_price;

}

function extretion_get_exchange_min_price( $price ){

	$from_currency = !empty( $_COOKIE['currency'] ) ? sanitize_text_field( $_COOKIE['currency'] ) : sanitize_text_field( get_option( 'options_base_currency' ) );

	$exchange_price = extretion_exchange_currency( $price , $from_currency , $currency_only = NULL , 'NPR' , $commission = false );
	$min_price_per_night = preg_replace("/[^0-9\.]/", null, $exchange_price );

	$min_price = !empty( $min_price_per_night ) ? sanitize_text_field( $min_price_per_night ) : '';
	return $min_price;

}

function extretion_min_booking_dates( $days ){

	if( $days > 0 && $days <= 7 ){
		return $days;
	} elseif( $days > 7 && $days <= 14 ){
		return 14;
	} elseif( $days > 14 && $days <= 21 ){
		return 21;
	} else{
		return 30;
	}

}

function extretion_count_total_rooms_search( $data = null ){	

	$results = extretion_get_search_values( $data );
	
	$no_of_rooms = extretion_google_search_code( $results['lat'] , $results['lng'] , $results['booking_days'] , $results['radius'] , $results['guests'] , null , $results['distance'] , $results['name'] , $results['price'] , $results['min_price'] , $results['max_price'] , $results['facility'] , $results['type_of_place'] , $results['room_type'] , $results['bedrooms'] , $results['bathrooms'] , $results['beds'] );
	return count($no_of_rooms);

}

function extretion_pagination_html( $pageno = null , $count_posts = null  ){

	//$count_posts = lmh_count_total_rooms_search( $data );	
	
	$no_rooms_to_display = get_option( 'options_number_of_rooms_to_display' );
	$no_rooms_to_display = !empty( $no_rooms_to_display ) ? sanitize_text_field( $no_rooms_to_display ) : 9;

	if( $count_posts != 0 ){

		$page_no = ( !empty( $pageno ) ? sanitize_text_field( $pageno ) : 1 );
		$pagination = '';
	  	$page = ceil( $count_posts / $no_rooms_to_display);
	  	$range = 2;
	  	$range_increase = $range + 1;
	  	$showitems = ($range * 2)+1;
	  	$pagination .= '<li class="remove_background"><a>' . 'Page ' . $page_no . ' of ' . $page . '</a></li>';
	  
	  	if($page_no > 2 && ($page_no > $range_increase) && ($showitems < $page)){
	    	$pagination .= '<li><a href="javascript:void(0)" data-page_no="1">&laquo; First</a></li>';
	  	}

	  	if($page_no > 1 && $showitems < $page){
	    	$pagination .= '<li><a href="javascript:void(0)" data-page_no="' . ($page_no - 1) . '">&lsaquo; Previous</a></li>';
	  	}

	  	for($i = 1; $i <= $page; $i++){ 
	    	if (1 != $page &&( !($i >= $page_no+$range+1 || $i <= $page_no-$range-1) || $page <= $showitems )){
	       		if($page_no == $i){
	          		$active = 'active';
	        	} else{
	          		$active ='';
	        	}
	        	$pagination .= '<li class="' . $active . '"><a class="" href="javascript:void(0)" data-page_no="' . $i . '">' . $i . '</a></li>';
	    	}
		}

	    if ($page_no < $page && $showitems < $page){
	        $pagination .= '<li><a href="javascript:void(0)" data-page_no="' . ($page_no + 1) . '">Next &rsaquo;</a></li>';
	    }

	    if ($page_no < $page-1 &&  $page_no+$range-1 < $page && $showitems < $page){
	        $pagination .= '<li><a href="javascript:void(0)" data-page_no="' . $page . '">Last &raquo;</a></li>';
	    }

	    printf( '%s' , $pagination );

	}	

}

function extretion_get_first_image_room( $post_id ){

	$room_photos = get_post_meta( $post_id , 'room_photos' , true );
	$image = '';

	if( !empty( $room_photos ) ){

		$image_attributes = wp_get_attachment_image_src( $room_photos[0] , 'extretion_search_page_image' );

		if( $image_attributes ){
			$image = $image_attributes[0];
		} else {
			$image = get_template_directory_uri() . '/images/no-image.jpg';
		}

	}

	return $image;

}

function extretion_get_accomodation_coulmn(){

	$accommodation_columns = get_option( 'options_accommodation_columns' ); 
	$accommodation_columns = !empty( $accommodation_columns ) ? esc_html( $accommodation_columns ) : 4; 

	switch ( $accommodation_columns ) {

		case 3:
			return 'col-md-4';
			break;
		
		default:
			return 'col-md-3';
			break;

	}

}

function extretion_get_room_list( $rooms , $view = 'grid' ){

	$defaults = extretion_default_labels();
	$count = 0;

	foreach( $rooms as $key => $room ):

		$post_id = $room['postid']; 
		$post = get_post( $post_id );

		$image = extretion_get_first_image_room( $post_id );

		if( empty( $view ) || $view == 'grid' ){

			if( $count == 0 ){
				echo '<div class="top-hotel-grid-wrapper"><div class="row gap-20 min-height-alt">';
			}

			extretion_get_grid_view_search( $image, $post, $defaults, null, true );

			if( ( count( $rooms ) -1 ) == $key ){
				echo '</div></div>';
			}

		} elseif( $view == 'map' ){

		} else {
			
			if( $count == 0 ){
				echo '<div class="hotel-item-list-wrapper mb-40">';
			}

			extretion_get_list_view_search( $image , $post , $defaults );

			if( ( count( $rooms ) -1 ) == $key ){
				echo '</div>';
			}
		}

		$count++;

	endforeach;

}

function extretion_check_search_sort_view(){

	if( empty( $_GET['view'] ) ){
		return true;
	}

	if( $_GET['view'] == 'map' ){
		return false;
	}

	return true;

}

function get_discount_tag_grid( $post_id , $search_page ){ 

	/**
	* Get checked in and out cookies
	*/

	// If page is other than search page
	if( $search_page == false ){
		$checked_in = !empty( $_COOKIE['check_in_date'] ) ? $_COOKIE['check_in_date'] : '';
		$checked_out = !empty( $_COOKIE['check_out_date'] ) ? $_COOKIE['check_out_date'] : '';
	} 
	// On ajax use the POST variables
	elseif( !empty( $_POST['arrival_date'] ) && !empty( $_POST['departure_date'] ) ){
		$checked_in = !empty( $_POST['arrival_date'] ) ? sanitize_text_field( $_POST['arrival_date'] ) : '';
		$checked_out = !empty( $_POST['departure_date'] ) ? sanitize_text_field( $_POST['departure_date'] ) : '';
	} 
	// Use GET variable only once
	else {
		$checked_in = !empty( $_GET['arrival_date'] ) ? sanitize_text_field( $_GET['arrival_date'] ) : '';
		$checked_out = !empty( $_GET['departure_date'] ) ? sanitize_text_field( $_GET['departure_date'] ) : '';
	}

	$days = get_days_difference( $checked_in , $checked_out );

	// Discounts in percentage
	$weekly_discount = get_post_meta( $post_id , 'weekly_discount' , true ); 
	$monthly_discount = get_post_meta( $post_id , 'monthly_discount' , true ); 

	// Weekly discount tag
	if( $days > 6 && $days < 30 && $weekly_discount > 0 ){ ?>

		<div class="bg-primary hotel-tag">
			<i class="fa fa-tag"></i> 
			<?php 
			printf( 
				esc_html__( '%d&#37; weekly price discount', 'extretion' ),
    			$weekly_discount
    		);
			?>
		</div>

		<?php
	} elseif( $days >= 30 && $monthly_discount > 0 ) { ?>

		<div class="bg-danger hotel-tag">
			<i class="fa fa-tag"></i> 
			<?php 
			printf( 
				esc_html__( '%d&#37; monthly price discount', 'extretion' ),
    			$monthly_discount
    		);
			?>
		</div>

		<?php
	}

}

function extretion_get_grid_view_search( $image , $post , $defaults , $column = null, $search_page = false ){ 

	$column = ( $column == null ? 'col-md-4' : $column ); ?>

	<div class="col-xss-12 col-xs-12 col-sm-6 col-mdd-6 <?php echo esc_html( $column ); ?>" data-match-height="result-grid">
		<div class="hotel-item-grid">

			<?php 
			get_discount_tag_grid( $post->ID , $search_page );
			?>			

			<a href="<?php echo get_permalink( $post->ID ); ?>">
				<div class="image">
					<img src="<?php echo esc_url( $image ); ?>" alt="<?php esc_html_e( 'Top Destinations' , 'extretion' ); ?>">
				</div>
				<div class="heading">

					<?php 
					/* Start Rating */
					$get_all_avg_rating = extretion_get_all_avg_rating( $post->ID );		
					extretion_title_star_width( $get_all_avg_rating , $post->ID );
					/* End Rating */
					?>

					<h4><?php echo get_the_title( $post->ID ); ?></h4>
					<p>
						<?php 
						$fulladdress = get_post_meta( $post->ID, 'form_place_located_formatted_address', true ); 
						$address = explode( ',' , $fulladdress );

						if( !empty( $address ) ){
							echo '<i class="fa fa-map-marker text-primary"></i> ';
							echo sanitize_text_field( $address[0] ); 
							}
						?>
					</p>
				</div>
				<div class="content">
					<div class="row gap-5">
						<div class="col-xs-12 col-sm-12">
							<p class="price text-center">
								<span class="block mb-5">
									<?php echo esc_html( $defaults['search_page']['start_from'] ); ?>
									
								</span>
								<span class="number">
									
									<?php 
									$count_days = get_days_week_month_price( $post->ID, $search_page );
									?>

								</span> 
								<?php 
								// Month
								if( $count_days >= 30 ){
									echo esc_html( $defaults['search_page']['per_month_grid'] ); 
								} 
								// Weekly
								elseif( $count_days > 6 && $count_days < 30 ){
									echo esc_html( $defaults['search_page']['per_week_grid'] ); 
								} else {
									echo esc_html( $defaults['search_page']['per_night_grid'] ); 
								}								
								?>
							</p>
						</div>
					</div>
				</div>
			</a>
		</div>
	</div>

	<?php
}

function get_days_week_month_price( $post_id, $search_page ){

	/**
	* Get checked in and out cookies
	*/

	// If page is other than search page
	if( $search_page == false ){
		$checked_in = !empty( $_COOKIE['check_in_date'] ) ? $_COOKIE['check_in_date'] : '';
		$checked_out = !empty( $_COOKIE['check_out_date'] ) ? $_COOKIE['check_out_date'] : '';
	} 
	// On ajax use the POST variables
	elseif( !empty( $_POST['arrival_date'] ) && !empty( $_POST['departure_date'] ) ){
		$checked_in = !empty( $_POST['arrival_date'] ) ? sanitize_text_field( $_POST['arrival_date'] ) : '';
		$checked_out = !empty( $_POST['departure_date'] ) ? sanitize_text_field( $_POST['departure_date'] ) : '';
	} 
	// Use GET variable only once
	else {
		$checked_in = !empty( $_GET['arrival_date'] ) ? sanitize_text_field( $_GET['arrival_date'] ) : '';
		$checked_out = !empty( $_GET['departure_date'] ) ? sanitize_text_field( $_GET['departure_date'] ) : '';
	}

	$days = get_days_difference( $checked_in , $checked_out );

	$user_per_night = get_post_meta( $post_id , 'per_night_price' , true );

	// User Currency
	$user_currency = get_post_meta( $post_id , 'user_currency', true );

	$exchange_price = extretion_exchange_currency( $user_per_night, $user_currency , $currency_only = NULL );

	// Get Currency
	$extract_currency = preg_replace("/[0-9\s.]/", null, $exchange_price );

	// Get only price ( Exclude currency )
	$price_per_night = preg_replace("/[^0-9\.]/", null, $exchange_price );

	// Get Currency Symbol
	$currency_symbol = extretion_currency_symbol( $extract_currency );

	// Month
	if( $days >= 30 ){
		$monthly_price = $price_per_night * 30;
		echo esc_html( $currency_symbol ) . '' . esc_html( number_format( $monthly_price, 0, '.', ',') );
	} 
	// Weekly
	elseif( $days > 6 && $days < 30 ){
		$weekly_price = $price_per_night * 7;
		echo esc_html( $currency_symbol ) . '' . esc_html( $weekly_price );
	} else {
		echo esc_html( $currency_symbol ) . '' . esc_html( $price_per_night );
	}

	return $days;

}

function extretion_get_list_view_search( $image , $post , $defaults ){ ?>

	<div class="hotel-item-list">

		<div class="image" style="background-image:url( <?php echo esc_url( $image ); ?> );"></div>

		<?php 
		// Add a discount tag for weekly or monthly discount
		get_discount_tag_grid( $post->ID , true ); 
		?>

		<div class="content">
			<div class="heading">
				<h4><?php echo get_the_title( $post->ID ); ?></h4>
				<p>
					<?php
					
					/* Start Rating */
					$get_all_avg_rating = extretion_get_all_avg_rating( $post->ID );		
					extretion_title_star_width( $get_all_avg_rating , $post->ID );
					/* End Rating */

					$fulladdress = get_post_meta( $post->ID, 'form_place_located_formatted_address', true ); 
					$address = explode( ',' , $fulladdress );

					if( !empty( $address ) ){
						echo '<i class="fa fa-map-marker text-primary"></i> ';
						echo sanitize_text_field( $address[0] ); 
					} ?>

				</p>
			</div>
			<div class="short-info">
				<?php 
				if( has_excerpt( $post->ID ) ){
					the_excerpt();
				} else {			
					echo '<p>' . extretion_string_limit_words( wp_strip_all_tags( $post->post_content ) , apply_filters( 'extretion_room_listing_content_limit' , 35 ) ) . '</p>';
				}
				?>
			</div>
		</div>
		
		<?php 
		$term_list = wp_get_post_terms($post->ID, 'facility', array("fields" => "all"));
		//echo '<pre>'; print_r($term_list); echo '</pre>';
		$facilities = count($term_list);

		if( !empty( $facilities ) ):

			echo '<div class="absolute-bottom"><p class="text-primary">';

			if( $facilities == 1  ){
				echo '<i class="fa fa-check-circle"></i> ' . $term_list[0]->name;
			} else {
				echo '<i class="fa fa-check-circle"></i> ' . $term_list[0]->name;
				echo '<span class="mh-10">|</span> ';
				echo '<i class="fa fa-check-circle"></i> ' . $term_list[1]->name;
			}

			echo '</p></div>';

		endif;
		?>
		
		<div class="absolute-right">
			<div class="price-wrapper">
				<p class="price">
					<span class="block">
						<?php echo esc_html( $defaults['search_page']['start_from'] ); ?>	
					</span>
					<span class="number">
						<?php
						$count_days = get_days_week_month_price( $post->ID , true );
						?>
					</span> 
					<span class="block">

						<?php 
						// Month
						if( $count_days >= 30 ){
							echo esc_html( $defaults['search_page']['per_month'] ); 
						} 
						// Weekly
						elseif( $count_days > 6 && $count_days < 30 ){
							echo esc_html( $defaults['search_page']['per_week'] ); 
						} else {
							echo esc_html( $defaults['search_page']['per_night'] ); 
						}								
						?>
						
					</span>
				</p>
				<a href="<?php echo get_permalink( $post->ID ); ?>" class="btn btn-danger btn-sm"><?php echo esc_html( $defaults['search_page']['details'] ); ?></a>
			</div>
		</div>
	</div>

	<?php
}

function extretion_my_listings_list_view( $image , $post , $defaults ){ ?>

	<div class="hotel-item-list">
		<div class="image" style="background-image:url( <?php echo esc_url( $image ); ?> );"></div>
		<div class="content">
			<div class="heading">
				<h4><?php echo get_the_title( $post->ID ); ?></h4>
				<p>
					<?php
					
					/* Start Rating */
					$get_all_avg_rating = extretion_get_all_avg_rating( $post->ID );		
					extretion_title_star_width( $get_all_avg_rating , $post->ID );
					/* End Rating */

					$fulladdress = get_post_meta( $post->ID, 'form_place_located_formatted_address', true ); 
					$address = explode( ',' , $fulladdress );

					if( !empty( $address ) ){
						echo '<i class="fa fa-map-marker text-primary"></i> ';
						echo sanitize_text_field( $address[0] ); 
					} ?>

				</p>
			</div>
			<div class="short-info">
				<?php 
				if( has_excerpt( $post->ID ) ){
					the_excerpt();
				} else {			
					echo '<p>' . extretion_string_limit_words( wp_strip_all_tags( $post->post_content ) , apply_filters( 'extretion_room_listing_content_limit' , 35 ) ) . '</p>';
				}
				?>
			</div>
		</div> 

		<div class="absolute-bottom my_listings_edit_options">

			<a href="<?php echo esc_url( extretion_get_edit_room_link() . '?id=' . $post->ID . '&page=basic' ); ?>" class="label label-primary">
				<?php esc_html_e( 'Edit Basic Info', 'extretion' ); ?>
			</a>
			<a href="<?php echo esc_url( extretion_get_edit_room_link() . '?id=' . $post->ID . '&page=photos' ); ?>" class="label label-primary">
				<?php esc_html_e( 'Edit Photos', 'extretion' ); ?>
			</a>
			<a href="<?php echo esc_url( extretion_get_edit_room_link() . '?id=' . $post->ID . '&page=calendar' ); ?>" class="label label-primary">
				<?php esc_html_e( 'Edit Calendar', 'extretion' ); ?>
			</a>
			<a href="<?php echo esc_url( extretion_get_edit_room_link() . '?id=' . $post->ID . '&page=guide' ); ?>" class="label label-primary">
				<?php esc_html_e( 'Edit Guides', 'extretion' ); ?>
			</a>
			<a href="javascript:void(0)" delete_id="<?php echo (int) $post->ID; ?>" class="label guide_delete">
				<?php esc_html_e( 'Delete', 'extretion' ); ?>
			</a>
			
		</div>
		
		<div class="absolute-right">
			<div class="price-wrapper">
				<p class="price">
					<span class="block">
						<?php echo esc_html( $defaults['search_page']['start_from'] ); ?>	
					</span>
					<span class="number">
					<?php 
					$user_per_night = get_post_meta( $post->ID , 'per_night_price' , true );

					// User Currency
					$user_currency = get_post_meta( $post->ID , 'user_currency', true );

					$exchange_price = extretion_exchange_currency( $user_per_night, $user_currency , $currency_only = NULL );

					// Get Currency
					$extract_currency = preg_replace("/[0-9\s.]/", null, $exchange_price );

					// Get only price ( Exclude currency )
					$price_per_night = preg_replace("/[^0-9\.]/", null, $exchange_price );

					// Get Currency Symbol
					$currency_symbol = extretion_currency_symbol( $extract_currency );

					echo esc_html( $currency_symbol ) . '' . esc_html( $price_per_night );

					?>
					</span> 
					<span class="block"><?php echo esc_html( $defaults['search_page']['per_night'] ); ?></span>
				</p>
				<a href="<?php echo get_permalink( $post->ID ); ?>" class="btn btn-danger btn-sm"><?php esc_html_e( 'Preview', 'extretion' ); ?></a>
			</div>
		</div>
	</div>

	<?php
}

function extretion_get_searched_rooms(){

	$results = extretion_get_search_values();
	$no_of_rooms = extretion_google_search_code( $results['lat'] , $results['lng'] , $results['booking_days'] , $results['radius'] , $results['guests'] , $offset = 0 , $results['distance'] , $results['name'] , $results['price'] , $results['min_price'] , $results['max_price'] , $results['facility'] , $results['type_of_place'] , $results['room_type'] , $results['bedrooms'] , $results['bathrooms'] , $results['beds'] );

	if( !empty( $no_of_rooms ) ){

		extretion_get_room_list( $no_of_rooms , $results['view'] );

	} 

}

add_action( 'wp_ajax_nopriv_get_room_list_pagination' , 'extretion_get_ajax_search_results' );
add_action( 'wp_ajax_get_room_list_pagination' , 'extretion_get_ajax_search_results' );

function extretion_get_ajax_search_results(){

	$content = '';
	$pagination_content = '';

	$room_facitlity = !empty( $_POST['facility'] ) ? $_POST['facility'] : '';

	if( !empty( $room_facitlity ) && is_array( $room_facitlity ) ){
		$room_facitlity = array_map( 'sanitize_text_field' , $room_facitlity );	
	}

	unset( $_POST['facility'] );

	// Sanitize all data at once
	$data = array_map( 'sanitize_text_field' , $_POST );
	$data['facility'] = $room_facitlity;

	// Get search values
	$search_values = extretion_get_search_values( $data );
	$count_posts = extretion_count_total_rooms_search( $data );

	// Get query results
	$query_result = extretion_google_search_code( $search_values['lat'] , $search_values['lng'] , $search_values['booking_days'] , $search_values['radius'] , $search_values['guests'] , $search_values['offset'] , $search_values['distance'] , $search_values['name'] , $search_values['price'] , $search_values['min_price'] , $search_values['max_price'] , $search_values['facility'] , $search_values['type_of_place'] , $search_values['room_type'] , $search_values['bedrooms'] , $search_values['bathrooms'] , $search_values['beds'] );

	ob_start();

	if( !empty( $query_result ) ){

		extretion_get_room_list( $query_result , $search_values['view'] );

	} 

	$content .= ob_get_clean();

	ob_start();
	extretion_pagination_html( $data['page_no'] , $count_posts );
	$pagination_content .= ob_get_clean();

	echo json_encode( 
		array(
			'content' => $content, 
			'pagination' => $pagination_content,
			'found_posts' => $count_posts
		)
	);

	die;

}

//add_action( 'init' , 'lmh_add_currency' );
function extretion_add_currency(){

	$args = array(
		'post_type' => 'room',
		'post_status' => 'any',
		'posts_per_page' => -1
	);

	$query = new WP_Query( $args );

	if( $query->have_posts() ){

		while( $query->have_posts() ){
			$query->the_post();

			global $post;

			// $commision_rate = get_field( 'commision_rate' , 'option' );

			// $search_price = get_post_meta( $post->ID , 'lmh_search_price' , true );

			// $new_price = ( $search_price * ( $commision_rate/100 ) ) + $search_price;

			// update_post_meta( $post->ID , 'lmh_search_price' , round( $new_price ) );

			update_post_meta( $post->ID , 'lmh_post_views_count' , 0 );

		}

	}
	die;

}

add_action( 'wp_ajax_map_room_search' ,'extretion_map_room_search' );
add_action( 'wp_ajax_nopriv_map_room_search' ,'extretion_map_room_search' );
function extretion_map_room_search(){

	$data = array_map( 'sanitize_text_field' , $_POST );
	$data_facility = array_map( 'sanitize_text_field' , $_POST['facility'] );

	$min_booking = extretion_get_min_booking_dates( $data['arrival_date'] , $data['departure_date'] );

	// Declare the query arguments  
	$args = array(  
	    'post_type' => 'room',
	    'post_status' => 'publish',
	    'posts_per_page' => -1,
	    'tax_query' => array(
	    	'relation' => 'AND',
	    ),
	    'meta_query' => array(
	    	'relation' => 'AND',
	    )
	);

	/**
	* Check Min & Max price
	*/

	$min_price = extretion_get_exchange_min_price( $data['min_price'] );
	$max_price = extretion_get_exchange_max_price( $data['max_price'] );

	if( !empty( $min_booking ) && is_numeric( $min_booking ) ){

		array_push( $args['meta_query'] , 
			array(
				'key' => 'lmh_search_price',
				'value'    => array( $min_price , $max_price ),
				'compare'    => 'BETWEEN',
				'type' => 'NUMERIC'
			)
		);

	}

	/**
	* For min booking duration
	*/

	if( !empty( $min_booking ) && is_numeric( $min_booking ) ){

		array_push( $args['meta_query'] , 
			array(
				'key' => 'min_booking_duration',
				'value'    => $min_booking,
				'compare'    => '<=',
				'type' => 'NUMERIC'
			)
		);

	} else {

		array_push( $args['meta_query'] , 
			array(
				'key' => 'min_booking_duration',
				'value'    => 1,
				'compare'    => '<=',
				'type' => 'NUMERIC'
			)
		);

	}

	/**
	* For No of Bedrooms
	*/

	if( !empty( $data['guests'] ) && is_numeric( $data['guests'] ) ){

		array_push( $args['meta_query'] , 
			array(
				'key' => 'guest_accomodate',
				'value'    => $data['guests'],
				'compare'    => '>=',
				'type' => 'NUMERIC'
			)
		);

	}

	/**
	* For No of Bedrooms
	*/

	if( !empty( $data['bedrooms'] ) && is_numeric( $data['bedrooms'] ) ){

		array_push( $args['meta_query'] , 
			array(
				'key' => 'no_of_bedroom',
				'value'    => $data['bedrooms'],
				'compare'    => '>=',
				'type' => 'NUMERIC'
			)
		);

	}

	/**
	* For No of Beds
	*/

	if( !empty( $data['beds'] ) && is_numeric( $data['beds'] ) ){

		array_push( $args['meta_query'] , 
			array(
				'key' => 'no_of_bed',
				'value'    => $data['beds'],
				'compare'    => '>=',
				'type' => 'NUMERIC'
			)
		);

	}

	/**
	* For No of Bathrooms
	*/

	if( !empty( $data['bathrooms'] ) && is_numeric( $data['bathrooms'] ) ){

		array_push( $args['meta_query'] , 
			array(
				'key' => 'room_bathroom',
				'value'    => $data['bathrooms'],
				'compare'    => '>=',
				'type' => 'NUMERIC'
			)
		);

	}

	/**
	* For Room Type
	*/

	if( !empty( $data['room_type'] ) && is_numeric( $data['room_type'] ) ){

		array_push( $args['tax_query'] , 
			array(
				'taxonomy' => 'space_offered',
				'field'    => 'term_id',
				'terms'    => $data['room_type'],
			)
		);

	}

	/**
	* For Facility
	*/
	
	if( !empty( $data_facility ) && is_array( $data_facility ) ){

		array_push( $args['tax_query'] , 
			array(
				'taxonomy' => 'facility',
				'field'    => 'term_id',
				'terms'    => $data_facility,
				'operator' => 'AND',
			)
		);

	}

	/**
	* For Type of place
	*/
	
	if( !empty( $data['type_of_place'] ) && is_numeric( $data['type_of_place'] ) ){

		array_push( $args['tax_query'] , 
			array(
				'taxonomy' => 'type_of_place',
				'field'    => 'term_id',
				'terms'    => $data['type_of_place'],
			)
		);

	}

	//print_r($args);

	$content = 'extretion_location_posts_where';

	add_filter( 'posts_join' , 'extretion_custom_posts_join');
	add_filter( 'posts_where', function( $content ) use ( $data ) {
	        return extretion_location_posts_where( $content, $data );
	    }, 12
	);
	
	// Execute the query  
	$query = new WP_Query( $args );
	$attributes = array();
	$count=0;

	if( $query->have_posts() ):

		while ( $query->have_posts() ): $query->the_post();

			global $post;

			$get_all_avg_rating = extretion_get_all_avg_rating( $post->ID );

			$attributes[$count]['location_latitude'] = get_post_meta( $post->ID , 'form_place_located_lat' , true );
			$attributes[$count]['location_longitude'] = get_post_meta( $post->ID , 'form_place_located_lng' , true );
			$attributes[$count]['image_url'] = extretion_get_first_image_room( $post->ID );
			$attributes[$count]['name_point'] = get_the_title( $post->ID );
			$attributes[$count]['location_point'] = get_post_meta( $post->ID , 'form_place_located_formatted_address' , true );
			$attributes[$count]['star_point'] = extretion_get_individual_rating_stars( $get_all_avg_rating );
			$attributes[$count]['tripadvisor_rating_point'] = extretion_get_individual_rating_words( number_format( $get_all_avg_rating ) );
			$attributes[$count]['review_count_point'] = extretion_count_published_comments( $post->ID );
			$attributes[$count]['url_point'] = get_permalink( $post->ID );
			$attributes[$count]['review_text'] = esc_html__( 'reviews' , 'extretion' );
			$attributes[$count]['price'] = sprintf( '<span class="block">%1$s</span><span class="number">%2$s</span> %3$s' , 
				esc_html__( 'start from' , 'extretion' ),
				extretion_get_currency_n_price( $post->ID ),
				esc_html__( '/ night' , 'extretion' )
			);

			$count++;
			
		endwhile;

	endif;		 
	 
	//print_r( $query );

	// Remove the filter just to be sure its  
	// not used again by non-related queries  
	remove_filter( 'posts_join' , 'extretion_custom_posts_join');
	remove_filter( 'posts_where' , 'extretion_location_posts_where' );

	echo json_encode( 
		array( 
			'content' => $attributes, 
			'result' => 'success',
			'message' => sprintf( esc_html__( 'We found %1$s hosts with availability.', 'extretion' ),
    			'<span class="found_hotels text-primary font700">' . count( $attributes ) . '</span>'
    			)
		) 
	);

	die;

}

function extretion_get_individual_rating_stars( $rate ){

	if( $rate > 0 && $rate <= 0.5 ){
		return '<div class="star-rate rated-05 mb-10"></div>';
	} elseif( $rate > 0.5 && $rate <= 1 ){
		return '<div class="star-rate rated-10 mb-10"></div>';
	} elseif( $rate > 1 && $rate <= 1.5 ){
		return '<div class="star-rate rated-15 mb-10"></div>';
	} elseif( $rate > 1.5 && $rate <= 2 ){
		return '<div class="star-rate rated-20 mb-10"></div>';
	} elseif( $rate > 2 && $rate <= 2.5 ){
		return '<div class="star-rate rated-25 mb-10"></div>';
	} elseif( $rate > 2.5 && $rate <= 3 ){
		return '<div class="star-rate rated-30 mb-10"></div>';
	} elseif( $rate > 3 && $rate <= 3.5 ){
		return '<div class="star-rate rated-35 mb-10"></div>';
	} elseif( $rate > 3.5 && $rate <= 4 ){
		return '<div class="star-rate rated-40 mb-10"></div>';
	} elseif( $rate > 4 && $rate <= 4.5 ){
		return '<div class="star-rate rated-45 mb-10"></div>';
	} elseif( $rate > 4.5 && $rate <= 5 ){
		return '<div class="star-rate rated-50 mb-10"></div>';
	}
	return '';

}

function extretion_get_currency_n_price( $post_id ){

	$user_per_night = get_post_meta( $post_id , 'per_night_price' , true );

	// User Currency
	$user_currency = get_post_meta( $post_id , 'user_currency', true );

	$exchange_price = extretion_exchange_currency( $user_per_night, $user_currency , $currency_only = NULL );

	// Get Currency
	$extract_currency = preg_replace("/[0-9\s.]/", null, $exchange_price );

	// Get only price ( Exclude currency )
	$price_per_night = preg_replace("/[^0-9\.]/", null, $exchange_price );

	// Get Currency Symbol
	$currency_symbol = extretion_currency_symbol( $extract_currency );

	return ( $currency_symbol . '' . $price_per_night);

}

function extretion_custom_posts_join( $join ){

	global $wpdb;
 	$join .= ", $wpdb->postmeta AS pm1 , $wpdb->postmeta AS pm2 ";
 	return $join;

}

function extretion_location_posts_where( $where , $data ) {  
    global $wpdb;  

    //print_r($data);

    // Specify the co-ordinates that will form  
    // the centre of our search  
    $sw_lat = $data['sw_lat'];  
    $ne_lat = $data['ne_lat']; 
    $sw_lng = $data['sw_lng']; 
    $ne_lng = $data['ne_lng'];  
          
    // Append our radius calculation to the WHERE  
    $where .= $wpdb->prepare(
    	" AND pm1.meta_key = 'form_place_located_lat' 
	    	AND pm1.meta_value BETWEEN %f
	    	AND %f
	    	AND pm2.meta_key = 'form_place_located_lng' 
	    	AND pm2.meta_value BETWEEN %f
	    	AND %f
	    	AND $wpdb->posts.ID = pm1.post_id
	    	AND $wpdb->posts.ID = pm2.post_id ",
	    $sw_lat,
	    $ne_lat,
	    $sw_lng,
	    $ne_lng
    );  
      
    // Return the updated WHERE part of the query  
    return $where;  
}

function extretion_google_search_code( $lat , $lng , $booking_days , $radius , $guests , $offset = null , $distance_ordering = null , $name_ordering = null , $price_ordering = null , $min_price = null , $max_price = null , $facility = null , $type_of_place = null , $room_type = null , $bedrooms = null , $bathrooms = null , $beds = null ){

	global $wpdb;

	$search_filters = get_option( 'options_search_filters' );
	$search_filters = empty( $search_filters ) ? array() : $search_filters;

	/**
	* Check No of Beds
	*/

	if( !in_array( 'beds' , $search_filters ) || empty( $beds ) || !is_numeric( $beds ) ){
		$bed_table = '';
		$bed_condition = '';
		$bed_check_post = '';
	} else {
		$bed_table = $wpdb->postmeta . ' AS mt9,';
		$bed_condition = "AND mt9.meta_key = 'no_of_bed' AND mt9.meta_value >= " . $beds;
		$bed_check_post = 'AND mt9.post_id = mt2.post_id';
	}

	/**
	* Check No of Bathrooms
	*/

	if( !in_array( 'bathrooms' , $search_filters ) || empty( $bathrooms ) || !is_numeric( $bathrooms ) ){
		$bathrooms_table = '';
		$bathrooms_condition = '';
		$bathrooms_check_post = '';
	} else {
		$bathrooms_table = $wpdb->postmeta . ' AS mt8,';
		$bathrooms_condition = "AND mt8.meta_key = 'room_bathroom' AND mt8.meta_value >= " . $bathrooms;
		$bathrooms_check_post = 'AND mt8.post_id = mt2.post_id';
	}

	/**
	* Check No of Bedrooms
	*/

	if( !in_array( 'bedrooms' , $search_filters ) || empty( $bedrooms ) || !is_numeric( $bedrooms ) ){
		$bedrooms_table = '';
		$bedrooms_condition = '';
		$bedrooms_check_post = '';
	} else {
		$bedrooms_table = $wpdb->postmeta . ' AS mt7,';
		$bedrooms_condition = "AND mt7.meta_key = 'no_of_bedroom' AND mt7.meta_value >= " . $bedrooms;
		$bedrooms_check_post = 'AND mt7.post_id = mt2.post_id';
	}

	/**
	* Check "Room type" Taxonomy
	*/

	$term_room_type = '';
	$term_room_type_id = '';

	if( !empty( $room_type ) && is_numeric( $room_type ) ){

		$term_room_type = 'INNER JOIN ' . $wpdb->term_relationships . ' AS tt_room ON ( t.ID = tt_room.object_id) ';
		$term_room_type_id = ' AND ( tt_room.term_taxonomy_id IN (' . $room_type . ') ) ';

	}

	/**
	* Check "Type of place" Taxonomy
	*/
	
	$term_type_of_place = '';
	$term_type_of_place_ids = '';

	if( !empty( $type_of_place ) && is_numeric( $type_of_place ) ){
		$term_type_of_place = 'INNER JOIN ' . $wpdb->term_relationships . ' AS tt_place ON ( t.ID = tt_place.object_id) ';
		$term_type_of_place_ids = ' AND ( tt_place.term_taxonomy_id IN (' . $type_of_place . ') ) ';;
	}

	/**
	* Check "Facility" Taxonomy
	*/

	$term_facility = '';
	$term_facility_ids = '';

	if( !empty( $facility ) ){

		foreach( $facility as $key => $value ){

			$tt = 'tt' . $key;
			$term_facility .=' INNER JOIN ' . $wpdb->term_relationships . ' AS ' . $tt . ' ON ( t.ID = ' . $tt . '.object_id) ';
			$term_facility_ids .= $tt . '.term_taxonomy_id IN (' . $value . ')';

			if( $key < ( count( $facility ) - 1 ) ){
				$term_facility_ids .= ' AND ';
			}

		}

		$term_facility_ids = 'AND ( ' . $term_facility_ids .' ) ';

	}

	/**	
	* For Min and Max range  
	*/

	if( !empty($min_price) || !empty($max_price) ){

		$min_price = is_numeric($min_price) ? $min_price : 0;
		$max_price = is_numeric($max_price) ? $max_price : 0;

		$price_query = "AND mt6.meta_key = 'lmh_search_price' AND mt6.meta_value BETWEEN " . (int) $min_price . ' AND ' . (int) $max_price;
	} else {
		$price_query = "";
	}

	/** 
	* For Order By and Order 
	*/

	if( $name_ordering != null ){
		$ordering = ( $name_ordering == 'DESC' ? 'DESC' : 'ASC' );
		$order_by = 'title';
	} elseif( $price_ordering != null ){
		$ordering = ( $price_ordering == 'DESC' ? 'DESC' : 'ASC' );
		$order_by = 'price+0';
	} else {
		$ordering = ( $distance_ordering == 'DESC' ? 'DESC' : 'ASC' );
		$order_by = 'distance';
	}

	$booking_days = ( $booking_days == 0 ? 1 : $booking_days );
	
	/** 
	* For Limit and Offset 
	*/

	$no_rooms_to_display = get_option( 'options_number_of_rooms_to_display' );
	$no_rooms_to_display = !empty( $no_rooms_to_display ) ? sanitize_text_field( $no_rooms_to_display ) : 10;
	$limit = ( $offset === null ? '' : ( 'LIMIT ' . $no_rooms_to_display . ' OFFSET ' . $offset ) );

	$sql = $wpdb->prepare(

		"SELECT DISTINCT t.ID , mt2.post_id AS postid , mt5.post_title AS title, ( 6371 * acos( cos( radians(%f) ) * cos( radians(

            (SELECT DISTINCT b1.meta_value FROM $wpdb->postmeta AS b1

                WHERE b1.meta_key = 'form_place_located_lat' 

                AND b1.post_id = postid)

        ) ) * cos( radians( 

        (SELECT DISTINCT b2.meta_value FROM $wpdb->postmeta AS b2

            WHERE b2.meta_key = 'form_place_located_lng' 

            AND b2.post_id = postid)

        ) - radians(%f) ) + sin( radians(%f) ) * sin( radians( 

        (SELECT DISTINCT b3.meta_value FROM $wpdb->postmeta AS b3

            WHERE b3.meta_key = 'form_place_located_lat' 

            AND b3.post_id = postid)

        ) ) ) ) AS distance,

        ( SELECT DISTINCT b4.meta_value FROM $wpdb->postmeta as b4
        	WHERE b4.meta_key = 'lmh_search_price'
        	AND b4.post_id = postid ) AS price

		FROM $wpdb->postmeta AS mt2, 
		$wpdb->postmeta AS mt1, 
		$wpdb->postmeta AS mt3, 
		$wpdb->postmeta AS mt4, 
		$wpdb->posts AS mt5, 
		$wpdb->postmeta AS mt6, 
		{$bedrooms_table}
		{$bathrooms_table} 
		{$bed_table} 
		$wpdb->posts AS t

		{$term_facility}

		{$term_type_of_place}

		{$term_room_type}

        WHERE mt2.meta_key = 'guest_accomodate'

        AND mt2.meta_value >= %d

        {$bedrooms_condition}

        {$bathrooms_condition}

        {$bed_condition}

        {$term_facility_ids}

        {$term_type_of_place_ids}

        {$term_room_type_id}

        AND mt1.meta_key = 'form_place_located_lng'

        AND mt3.meta_key = 'form_place_located_lat'

        AND mt4.meta_key = 'min_booking_duration'

        AND mt4.meta_value <= %d

        {$price_query}

        AND mt3.post_id = mt2.post_id

        AND mt1.post_id = mt2.post_id

        AND mt4.post_id = mt2.post_id

        AND mt6.post_id = mt2.post_id

        {$bedrooms_check_post}

        {$bathrooms_check_post}

        {$bed_check_post}

        AND mt5.ID = mt2.post_id

        AND mt5.post_status = 'publish'

		AND t.ID = mt2.post_id

        HAVING distance < %d

        ORDER BY {$order_by} {$ordering}

        {$limit}",

        $lat,
        $lng,
        $lat,
        $guests,
        $booking_days,
        $radius

	);

	$query = $wpdb->get_results( $sql ,ARRAY_A );

	//echo '<pre>'; print_r($wpdb); echo '</pre>'; die;

	return $query;

	die;

}

add_action( 'init' , 'extretion_initialize_after_theme_setup' );

function extretion_initialize_after_theme_setup(){

	// Add new currency exchange to the database
	extretion_add_currency_to_database();

	// Add cookie for check in and out dates
	extretion_get_arg_cookie();

}

/**
* Delete booking after 48 hrs if payment not done
*/

add_action( 'init' , 'extretion_schedule_booking_no_payment_48hrs' );
add_action( 'extretion_delete_booking_no_payment_48hrs_action' , 'extretion_delete_booking_no_payment_48hrs' );

function extretion_schedule_booking_no_payment_48hrs(){

	//wp_clear_scheduled_hook( 'extretion_delete_booking_no_payment_48hrs_action' );
	//echo '<pre>'; print_r( _get_cron_array() ); echo '</pre>'; die;

   	//check if event scheduled before
  	if( !wp_next_scheduled( 'extretion_delete_booking_no_payment_48hrs_action' ) ){

  		//shedule event to run daily
   		wp_schedule_event( time(), 'daily', 'extretion_delete_booking_no_payment_48hrs_action' );	

  	}

}

//add_action( 'init' , 'extretion_delete_booking_no_payment_48hrs' );
function extretion_delete_booking_no_payment_48hrs(){

	$args = array(
		'post_type' => 'lmh_invoice',
		'post_status' => 'publish',
		'posts_per_page' => -1,
		'meta_query' => array(
			array(
				'key'     => 'payment_status',
				'value'   => 'booking_request_accepted',
				'compare' => '=',
			),
			array(
				'key'     => 'updated_at',
				'value'   => date( 'Y-m-d' ),
				'compare' => '<',
				'type' => 'DATE'
			),
		),
	);

	$query = new WP_Query( $args );

	if( $query->have_posts() ):

		while( $query->have_posts() ): $query->the_post();

			global $post;
			$date_diff =  get_days_difference( get_post_meta( $post->ID, 'updated_at', true ) , date( 'Y-m-d H:i:s' ) );

			// If greater than 48 hrs delete the booking
			if( $date_diff > 2 ){

				// Start Subject
				
				$subject = get_option( 'options_booking_delete_after_48hrs_no_payment_subject' );
				if( empty( $subject ) ){
					$subject = 'Booking request [invoice_name] at [site_name] has been removed';
				}
				$subject = str_replace( '[invoice_name]' , get_the_title( $post->ID ) , $subject );
				$subject = str_replace( '[site_name]' , get_bloginfo( 'name' ) , $subject ); 

				// End Subject

				// Start Message

				$message = get_option( 'options_booking_delete_after_48hrs_no_payment_message' );
				if( empty( $message ) ){
					$message = '<p>Hello!</p><p>The booking fee of [invoice_name] at [site_name] has not been paid by the traveler within 48hrs so we are deleting the booking request.</p>';
				}
				$message = str_replace( '[invoice_name]' , get_the_title( $post->ID ) , $message );
				$message = str_replace( '[site_name]' , get_bloginfo( 'name' ) , $message ); 

				// End Message

				$traveller_id = $post->post_author;
				$hotel_id = get_post_meta( $post->ID , 'hotel_owner', true );
				$senders = array( extretion_get_user_email( $traveller_id ) , extretion_get_user_email( $hotel_id ) );

				foreach ( $senders as $value) {
					$to = $value;
					wp_mail( $to, $subject, nl2br( $message ), extretion_mail_headers() );
				}

				$room_id = get_post_meta( $post->ID , 'related_room_id' , true );
				$check_in = get_post_meta( $post->ID , 'check_in_date' , true );
				$check_out = get_post_meta( $post->ID , 'check_out_date' , true );

				// add booking dates for the room
				extretion_set_booking_available_dates( $room_id , $check_in , $check_out );
				wp_delete_post( $post->ID );

				do_action( 'extretion_delete_booking_after_no_payment_48hrs', $room_id, $traveller_id, $hotel_id );
			}

		endwhile;

	endif;

}

/**
* Reminder about approved booking request 24h after owner approval if payment not done.
*/

add_action( 'init' , 'extretion_schedule_reminder_approval_booking_after_24hrs' );
add_action( 'extretion_reminder_approval_booking_after_24hrs_action' , 'extretion_reminder_approval_booking_after_24hrs' );

function extretion_schedule_reminder_approval_booking_after_24hrs(){

	//wp_clear_scheduled_hook( 'extretion_reminder_approval_booking_after_24hrs_action' );
	//echo '<pre>'; print_r( _get_cron_array() ); echo '</pre>'; die;

   	//check if event scheduled before
  	if( !wp_next_scheduled( 'extretion_reminder_approval_booking_after_24hrs_action' ) ){

  		//shedule event to run daily
   		wp_schedule_event( time(), 'daily', 'extretion_reminder_approval_booking_after_24hrs_action' );	

  	}
   	
}

function extretion_reminder_approval_booking_after_24hrs(){

	$args = array(
		'post_type' => 'lmh_invoice',
		'post_status' => 'publish',
		'posts_per_page' => -1,
		'meta_query' => array(
			'relation' => 'AND',
			array(
				'key'     => 'payment_status',
				'value'   => 'booking_request_accepted',
				'compare' => '=',
			),
			array(
				'key'     => 'updated_at',
				'value'   => date( 'Y-m-d' ),
				'compare' => '<',
				'type' => 'DATE'
			),
			array(
				'key'     => 'booking_request_accepted_reminder_mail',
				'value'   => 1,
				'compare' => '!=',
				'type' => 'NUMERIC'
			),
		),
	);

	$query = new WP_Query( $args );

	if( $query->have_posts() ):

		while( $query->have_posts() ): $query->the_post();

			global $post;
			$hotel_id = get_post_meta( $post->ID , 'hotel_owner' , true );
			extretion_after_booking_request_accept( $hotel_id , $post->post_author , $post->ID );
			update_post_meta( $post->ID , 'booking_request_accepted_reminder_mail', true );

		endwhile;

	endif;

}

/**
* Delete not approved booking requests after 14 days
* If a booking request has passed 14 days, without approval, we delete it. Send email.
*/

add_action( 'init' , 'extretion_schedule_delete_pending_booking_after_14_days' );
add_action( 'extretion_delete_pending_booking_after_14_days_action' , 'extretion_delete_pending_booking_after_14_days' );

function extretion_schedule_delete_pending_booking_after_14_days(){

	//wp_clear_scheduled_hook( 'extretion_delete_pending_booking_after_14_days_action' );
	//echo '<pre>'; print_r( _get_cron_array() ); echo '</pre>'; die;

   	//check if event scheduled before
  	if( !wp_next_scheduled( 'extretion_delete_pending_booking_after_14_days_action' ) ){

  		//shedule event to run daily
   		wp_schedule_event( time(), 'daily', 'extretion_delete_pending_booking_after_14_days_action' );	

  	}
   	
}

//add_action( 'init','extretion_delete_pending_booking_after_14_days' );
function extretion_delete_pending_booking_after_14_days(){

	$args = array(
		'post_type' => 'lmh_invoice',
		'post_status' => 'publish',
		'posts_per_page' => -1,
		'meta_query' => array(
			array(
				'key'     => 'payment_status',
				'value'   => 'pending_approval',
				'compare' => '=',
			),
		),
	);

	$query = new WP_Query( $args );

	if( $query->have_posts() ):

		while( $query->have_posts() ): $query->the_post();

			global $post;
			$date_diff =  get_days_difference( $post->post_date , date( 'Y-m-d H:i:s' ) );

			// If no answer for 14 days delete the booking request
			if( $date_diff > 14 ){

				//echo 'Date Diff for : ' . get_the_title( $post->ID ) . ' is ' . $date_diff . '<br>';

				$subject = get_option( 'options_booking_delete_after_14_days_subject' );
				if( empty( $subject ) ){
					$subject = 'Booking request [invoice_name] at [site_name] has been removed';
				}

				$subject = str_replace( '[invoice_name]' , get_the_title( $post->ID ) , $subject );
				$subject = str_replace( '[site_name]' , get_bloginfo( 'name' ) , $subject ); 

				$message = get_option( 'options_booking_delete_after_14_days_message' );
				if( empty( $message ) ){
					$message = '<p>Hello!</p><p>We are sorry, the booking request [invoice_name] at [site_name] has not been answered by the owner for last 14 days and now has been removed.</p><p>You are more than welcome to search other exciting rentals that can meet your needs, search at [site_url].</p>';
				}

				$message = str_replace( '[invoice_name]' , get_the_title( $post->ID ) , $message ); 
				$message = str_replace( '[site_name]' , get_bloginfo( 'name' ) , $message ); 
				$message = str_replace( '[site_url]' , site_url() , $message ); 

				$to = extretion_get_user_email( $post->post_author );

				$traveller_id = $post->post_author;
				$host_id = get_post_meta( $post->ID , 'hotel_owner', true );

				$room_id = get_post_meta( $post->ID , 'related_room_id' , true );	

				wp_mail( $to, $subject, nl2br( $message ), extretion_mail_headers() );

				wp_delete_post( $post->ID );						

				do_action( 'extretion_after_delete_invoices_after_14_days' , $room_id , $traveller_id , $host_id );

				die;

			}

		endwhile;

	endif;

}

function get_days_difference( $start, $end ) {

    $datediff = (strtotime($end) - strtotime($start));

    return ceil($datediff / (60 * 60 * 24));

}

/**
* Reminder after 48h
* If the initial booking request is not answered, a first reminder is sent to owner. If the
* booking request has been declined or approved, this reminder shall not be sent.
*/

add_action( 'init' , 'extretion_schedule_reminder_after_48_hrs' );
add_action( 'extretion_reminder_after_48_hrs_action' , 'extretion_reminder_after_48_hrs' );

function extretion_schedule_reminder_after_48_hrs(){

	//wp_clear_scheduled_hook( 'extretion_reminder_after_48_hrs_action' );
	//echo '<pre>'; print_r( _get_cron_array() ); echo '</pre>'; die;

   	//check if event scheduled before
  	if( !wp_next_scheduled( 'extretion_reminder_after_48_hrs_action' ) ){

  		//shedule event to run daily
   		wp_schedule_event( time(), 'daily', 'extretion_reminder_after_48_hrs_action' );	

  	}
   	
}

function extretion_reminder_after_48_hrs(){

	$args = array(
		'post_type' => 'lmh_invoice',
		'post_status' => 'publish',
		'posts_per_page' => -1,
		'date_query'    => array(
        	'column'  => 'post_date',
	        'after'   => '- 2 days'
	    ),
		'meta_query' => array(
			array(
				'key'     => 'payment_status',
				'value'   => 'pending_approval',
				'compare' => '=',
			),
		),
	);

	$query = new WP_Query( $args );

	if( $query->have_posts() ):

		while( $query->have_posts() ): $query->the_post();

			global $post;
			extretion_send_mail_to_hotel_owner( $post->ID );

		endwhile;

	endif;

}

/*
* Delete not approved booking requests that has crossed Check-in-date
* If a booking request has passed Check-in-date, without approval, we delete it. Send email to 
* traveller and hotel owner and free the dates on the calendar for others to book.
*
* Runs once a day
*/

add_action( 'init' , 'extretion_schedule_delete_invoice_after_check_in' );
add_action( 'extretion_schedule_delete_invoice_after_check_in_action' , 'extretion_delete_invoices_after_check_in_date' );
  
function extretion_schedule_delete_invoice_after_check_in(){

	//wp_clear_scheduled_hook( 'extretion_schedule_delete_invoice_after_check_in_action' );
	//echo '<pre>'; print_r( _get_cron_array() ); echo '</pre>'; die;

   	//check if event scheduled before
  	if( !wp_next_scheduled('extretion_schedule_delete_invoice_after_check_in_action') ){

  		//shedule event to run daily
   		wp_schedule_event( time(), 'daily', 'extretion_schedule_delete_invoice_after_check_in_action' );	

  	}
   	
}

//add_action( 'init' , 'extretion_delete_invoices_after_check_in_date' );
function extretion_delete_invoices_after_check_in_date(){

	$args = array(
		'post_type' => 'lmh_invoice',
		'post_status' => 'publish',
		'posts_per_page' => -1,
		'meta_query' => array(
			'relation' => 'AND',
			array(
				'key'     => 'payment_status',
				'value'   => 'pending_approval',
				'compare' => '=',
			),
			array(
				'key'     => 'check_in_date',
				'value'   => date( 'd-m-Y' ),
				'compare' => '<=',
			),
		),
	);

	$delete_query = new WP_Query( $args );

	if( $delete_query->have_posts() ):

		while( $delete_query->have_posts() ): $delete_query->the_post();

			global $post;

			/**
			* Start subject
			*/

			$subject = get_option( 'options_booking_delete_check_in_subject' );
			if( empty( $subject ) ){
				$subject = 'Booking request [invoice_name] at [site_name] has been removed';
			}
			$subject = str_replace( '[invoice_name]' , get_the_title( $post->ID ) , $subject ); 
			$subject = str_replace( '[site_name]' , get_bloginfo( 'name' ) , $subject ); 
			
			/**
			* End subject
			*/

			/**
			* Start message
			*/

			$message = get_option( 'options_booking_delete_check_in_message' );
			if( empty( $message ) ){
				$message = '<p>Hello!</p><p>We are sorry, the booking request [invoice_name] at [site_name] has not been answered by the owner and it has exceeded the Check In Date so the booking request has been removed.</p><p>You are more than welcome to search other exciting rentals that can meet your needs, search at [site_url].</p>';
			}

			$message = str_replace( '[invoice_name]' , get_the_title( $post->ID ) , $message ); 
			$message = str_replace( '[site_name]' , get_bloginfo( 'name' ) , $message ); 
			$message = str_replace( '[site_url]' , site_url() , $message ); 

			/**
			* End message
			*/

			$traveller_id = $post->post_author;
			$hotel_id = get_post_meta( $post->ID , 'hotel_owner', true );
			$senders = array( extretion_get_user_email( $traveller_id ) , extretion_get_user_email( $hotel_id ) );

			foreach ( $senders as $value) {
				$to = $value;
				wp_mail( $to, $subject, nl2br( $message ), extretion_mail_headers() );
			}

			$room_id = get_post_meta( $post->ID , 'related_room_id' , true );			

			// add booking dates for the room
			wp_delete_post( $post->ID );

			do_action( 'extretion_after_delete_invoices_check_in_date' , $room_id , $traveller_id , $hotel_id );

		endwhile;

	endif;

}

function extretion_set_booking_available_dates( $room_id , $check_in , $check_out ){

	$booking_unavailable_dates = get_post_meta( $room_id, 'booking_unavailable_dates', true );

	$available_dates = extretion_date_range( $check_in , $check_out );

	if( empty( $booking_unavailable_dates ) || !is_array( $booking_unavailable_dates ) ){
		return;
	}

	/**
	* Unset unavailable dates for others to book
	*/

	foreach ( $booking_unavailable_dates as $key => $value ) {
		
		if( in_array( $value , $available_dates ) ){

			unset( $booking_unavailable_dates[$key] );

		}

	}

	$new_unavailable_dates = array_values( $booking_unavailable_dates );

	update_post_meta( $room_id, 'booking_unavailable_dates', $new_unavailable_dates );

}

function extretion_show_users_details_after_payment( $payment_status , $hotel_id , $traveller_id ){

	if( $payment_status != 'payment_successful' ): 
		return;
	endif; ?>

	<div class="row">
		
		<div class="col-sm-12 col-md-6 mb-30 payment_users_details" data-match-height="confirm">
			
			<div class="metro-box-wrapper equal-height1">
				
				<div class="heading">
					<h3><?php esc_html_e( 'Traveler Details' , 'extretion' ); ?></h3>
				</div>

				<div class="content">

					<ul class="payment_traveller_details row">
						
						<li class="col-md-4 pm_user_image">
							
							<?php echo get_avatar( $traveller_id , $size = 150 ); ?>

						</li>

						<li class="col-md-8">
							<i class="fa fa-user"></i>
							<span class="pm_name">
								<?php 
								echo extretion_get_user_name( $traveller_id );
								?>
							</span>
						</li>
						<li class="col-md-8">
							<i class="fa fa-envelope"></i>
							<span class="pm_email">
								<?php echo extretion_get_user_email( $traveller_id ); ?>
							</span>
						</li>
						<li class="col-md-8">
							<i class="fa fa-map-marker"></i>
							<span class="pm_address">
								<?php echo esc_html( get_user_meta( $traveller_id, 'form_hotel_located_formatted_address', true ) ); ?>
							</span>
						</li>
						<li class="col-md-8">
							<i class="fa fa-mobile"></i>
							<span class="pm_mobile">
								<?php echo esc_html( get_user_meta( $traveller_id, 'mobile_no', true ) ); ?>
							</span>
						</li>

						<li class="col-md-8">
							<i class="fa fa-phone-square "></i>
							<span class="pm_mobile">
								<?php echo esc_html( get_user_meta( $traveller_id, 'phone_no', true ) ); ?>
							</span>
						</li>

					</ul>

				</div>

			</div>

		</div>

		<div class="col-sm-12 col-md-6 mb-30 payment_users_details" data-match-height="confirm">
			
			<div class="metro-box-wrapper equal-height1">
				
				<div class="heading">
					<h3><?php esc_html_e( 'Property Owner Details' , 'extretion' ); ?></h3>
				</div>

				<div class="content">

					<ul class="payment_traveller_details row">
						
						<li class="col-md-4 pm_user_image">
							
							<?php echo get_avatar( $hotel_id , $size = 150 ); ?>

						</li>

						<li class="col-md-8">
							<i class="fa fa-user"></i>
							<span class="pm_name">
								<?php 
								echo extretion_get_user_name( $hotel_id );
								?>
							</span>
						</li>
						<li class="col-md-8">
							<i class="fa fa-envelope"></i>
							<span class="pm_email">
								<?php echo extretion_get_user_email( $hotel_id ); ?>
							</span>
						</li>
						<li class="col-md-8">
							<i class="fa fa-map-marker"></i>
							<span class="pm_address">
								<?php echo esc_html( get_user_meta( $hotel_id, 'form_hotel_located_formatted_address', true ) ); ?>
							</span>
						</li>
						<li class="col-md-8">
							<i class="fa fa-mobile"></i>
							<span class="pm_mobile">
								<?php echo esc_html( get_user_meta( $hotel_id, 'mobile_no', true ) ); ?>
							</span>
						</li>

						<li class="col-md-8">
							<i class="fa fa-phone-square "></i>
							<span class="pm_mobile">
								<?php echo esc_html( get_user_meta( $hotel_id, 'phone_no', true ) ); ?>
							</span>
						</li>

					</ul>

				</div>

			</div>

		</div>

	</div>

	<?php
}

function extretion_get_user_email( $user_id ){

	$user_data = get_userdata( $user_id );
	return $user_data->user_email;

}

function extretion_get_user_name( $user_id ){

	$firstname = get_user_meta( $user_id, 'first_name', true );
	$lastname = get_user_meta( $user_id, 'last_name', true );
	$user_data = get_userdata( $user_id );

	if( empty( $firstname ) ){
		return $user_data->user_login; // Return user login
	} else {
		return ( esc_html( $firstname ) . ' ' . esc_html( $lastname ) ); // return first and last name
	}

}

function extretion_check_room_payment_status(){

	$invoice_id = get_query_var( 'post_id' );
	$secret_key = !empty( $_GET['paysecret'] ) ? sanitize_text_field( $_GET['paysecret'] ) : '';
	$user_id = get_current_user_id();
	$invoice_details = get_post( $invoice_id );

	if( empty( $invoice_id ) || !ctype_digit( $invoice_id ) || empty( $secret_key ) ){
		return;
	}

	$payment_successful_key = get_post_meta( $invoice_id, 'payment_successful_key', true );

	// Check payment success key on the database
	if( $payment_successful_key != $secret_key || $invoice_details->post_author != $user_id || $invoice_details->post_type != 'lmh_invoice' ){
		return;
	}

	update_post_meta( $invoice_id, 'payment_status' , 'payment_successful' );
	delete_post_meta( $invoice_id, 'payment_successful_key' );

	do_action( 'extretion_after_payment_successful' , $invoice_id );

	// Show success message on the modal
	return 'jQuery(document).ready( function(){ jQuery("#confirm_payment_for_room").modal("show") });';

}

add_action( 'extretion_after_payment_successful' , 'extretion_send_mail_to_users_after_payment' );

function extretion_send_mail_to_users_after_payment( $invoice_id ){

	$invoice_object = get_post( $invoice_id );

	if( !is_object( $invoice_object ) ){
		return;
	}

	$hotel_id = get_post_meta( $invoice_id, 'hotel_owner', true );
	$traveller_id = $invoice_object->post_author;
	$invoice_details = get_post_meta( $invoice_id, 'invoice_details', true );
	$room_id = $invoice_details['post_id'];
	$room_location = get_post_meta( $room_id, 'form_place_located_formatted_address' , true );

	$subject = get_option( 'options_booking_confirmed_subject' );
	if( empty( $subject ) ){
		$subject = 'Confirmed booking of [invoice_name] at [site_name].';
	}

	$subject = str_replace( '[site_name]' , get_bloginfo( 'name' ) , $subject );
	$subject = str_replace( '[invoice_name]' , get_the_title( $invoice_id ) , $subject ); 

	$message = get_option( 'options_booking_confirmed_message' );
	if( empty($message) ){
		$message = '<p>Hello!</p><p>Confirmed booking of [invoice_name] at [site_name].</p><p>Room : [invoice_name]<br /> Location : [location]<br /> Check-in : [check_in]<br /> Check-out : [check_out]</p><p>Please find your booking details and travel information in your Confirmation and Payment section at [site_name].</p><p>We recommend you to contact each other to plan the details at check-in and discuss any other needs.</p><p>Thank you for booking with [site_name]!</p>';
	}

	$message = str_replace( '[invoice_name]' , get_the_title( $invoice_id ) , $message ); 
	$message = str_replace( '[site_name]' , get_bloginfo( 'name' ) , $message ); 
	$message = str_replace( '[check_in]' , date( 'd M, Y' , strtotime( $invoice_details['check_in'] ) ) , $message ); 
	$message = str_replace( '[check_out]' , date( 'd M, Y' , strtotime( $invoice_details['check_out'] ) ) , $message ); 
	$message = str_replace( '[location]' , $room_location , $message ); 

	$to = array( extretion_get_user_email( $hotel_id ) , extretion_get_user_email( $traveller_id ) );

	wp_mail( $to, $subject, nl2br( $message ), extretion_mail_headers() );

}

function extretion_get_arg_cookie(){

	if( empty( $_GET['s'] ) ){
		return;
	}

	$check_in = !empty( $_GET['arrival_date'] ) ? sanitize_text_field( $_GET['arrival_date'] ) : '';

	// Check valid date 
	$check_in = ( extretion_checkIsAValidDate($check_in) != false ? $check_in : '' );

	$check_out = !empty( $_GET['departure_date'] ) ? sanitize_text_field( $_GET['departure_date'] ) : '';

	// Check valid date 
	$check_out = ( extretion_checkIsAValidDate($check_out) != false ? $check_out : '' );

	// Get no of guests
	if( !empty( $_GET['guests'] ) && is_numeric( $_GET['guests'] ) ){
		$guests = sanitize_text_field( $_GET['guests'] ); 
	} else {
		$guests = 1;
	}

	extretion_set_cookie( $guests , $check_in , $check_out );

}

function extretion_set_cookie( $guests , $check_in , $check_out ){

	setcookie( "room_guest" , $guests , time() + 3600 , '/' ); /* expire in 1 hour */

	if( !empty( $check_in ) && !empty( $check_out ) ){

		setcookie( "check_in_date" , date( 'd-m-Y' , strtotime( $check_in ) ) , time() + 3600 , '/' );  /* expire in 1 hour */
    	setcookie( "check_out_date" , date( 'd-m-Y' , strtotime( $check_out ) ) , time() + 3600 , '/' );  /* expire in 1 hour */

	}	

}

function extretion_track_post_views( $post_id ){

	if ( !is_single() ) return;

    if ( empty ( $post_id ) ) {
        global $post;
        $post_id = $post->ID;    
    }
    extretion_set_post_views($post_id);

}

function extretion_set_post_views($postID) {
    $count_key = 'lmh_post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '1');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}

function extretion_check_query(){

	$args = array(
		'post_type' => 'room',
		'tax_query' => array(
			'RELATION' => 'AND',
			array(
				'taxonomy'         => 'facility',
				'field'            => 'id',
				'terms'            => array( '63' ),
				'operator'         => 'IN'
			),
			array(
				'taxonomy'         => 'facility',
				'field'            => 'id',
				'terms'            => array('31' ),
				'operator'         => 'IN'
			),
			array(
				'taxonomy'         => 'facility',
				'field'            => 'id',
				'terms'            => array('33' ),
				'operator'         => 'IN'
			),
		),
	);
	
	$query = new WP_Query( $args );
	//echo '<pre>'; print_r( $query ); echo '</pre>';
	die;

}

add_action( 'init' , 'extretion_get_live_currency' );
add_action( 'extretion_get_live_currency_action' , 'extretion_update_room_search_currency' );
  
function extretion_get_live_currency(){

	//wp_clear_scheduled_hook( 'extretion_get_live_currency_action' );
   	//check if event scheduled before
  	if(!wp_next_scheduled('extretion_get_live_currency_action')){
  		//shedule event to run after every hour
   		wp_schedule_event( time(), 'twicedaily', 'extretion_get_live_currency_action');	
  	}
   	
}

function extretion_update_room_search_currency(){

	global $wpdb;

	$sql = $wpdb->prepare(
		"SELECT * FROM {$wpdb->postmeta}
			WHERE `meta_key` = %s",
		'per_night_price'
	);

	$results = $wpdb->get_results( $sql , ARRAY_A );

	if( empty( $results ) ){
		return;
	}

	foreach( $results as $value ){

		$user_currency = get_post_meta( $value['post_id'] , 'user_currency', true );

		$exchange_price = extretion_exchange_currency( $value['meta_value'], $user_currency , $currency_only = NULL , 'NPR' , true  );
		
		// Get only price ( Exclude currency )
		$price_per_night = preg_replace("/[^0-9\.]/", null, $exchange_price );

		update_post_meta( $value['post_id'] , 'lmh_search_price' , $price_per_night );

	}

}

function extretion_add_currency_to_database(){

	$currencies = get_option( 'get_currencies' , null );
	$currencies_saved_time = get_option( 'currencies_saved_time' , null );

	if( empty( $currencies_saved_time ) ){
		extretion_get_new_currency();
	} else {

		$new_currency_interval = get_option( 'options_refresh_currency_after' );
		$new_currency_interval = ( empty( $new_currency_interval ) ? 300 : $new_currency_interval );

		if( ( ( strtotime($currencies_saved_time) + $new_currency_interval) < strtotime(date('Y-m-d H:i:s')) ) ) {
			
			extretion_get_new_currency();

		}
	}
}

function extretion_get_new_currency(){

	$data = array();
	$url = 'http://finance.yahoo.com/webservice/v1/symbols/allcurrencies/quote?format=json';
	$contents = json_decode( wp_remote_fopen($url) , true);
	
	if( empty( $contents['list']['resources'] ) ){
		return;
	}

	foreach( $contents['list']['resources'] as $key => $value ){

		if( empty( $value['resource']['fields']['name'] ) ){
			return;
		}

		$name = explode( '/' , $value['resource']['fields']['name'] );

		if( count( $name ) == 2 ){
			$key_name = str_replace( ' ', '' , $name[1] );
			$data[$key_name] = $value['resource']['fields']['price'];
		}
		
	}

	ksort( $data );
	$data['USD'] = 1; // 1 Dollar
	update_option( 'get_currencies' , $data );
	update_option( 'currencies_saved_time' , date('Y-m-d H:i:s') );

}

function extretion_search_filter_no_of_bedrooms(){

	$args = apply_filters( 'extretion_search_filter_no_of_bedrooms' , 7 );

	for ( $i = 1; $i <= $args; $i++ ) { 

		if( $i == 1 ){
			echo '<option value="' . $i . '">' . $i . ' ' . esc_html__( 'Bedroom' , 'extretion' ) . '</option>';
		} else {
			echo '<option value="' . $i . '">' . $i . ' ' . esc_html__( 'Bedrooms' , 'extretion' ) . '</option>';
		}
		
	}

}

function extretion_search_filter_no_of_bathrooms(){

	$args = apply_filters( 'extretion_search_filter_no_of_bathrooms' , 5 );

	for ( $i = 1; $i <= $args; $i++ ) { 

		if( $i == 1 ){
			echo '<option value="' . $i . '">' . $i . ' ' . esc_html__( 'Bathroom' , 'extretion' ) . '</option>';
		} else {
			echo '<option value="' . $i . '">' . $i . ' ' . esc_html__( 'Bathrooms' , 'extretion' ) . '</option>';
		}
		
	}

}

function extretion_search_filter_no_of_beds(){

	$args = apply_filters( 'extretion_search_filter_no_of_beds' , 7 );

	for ( $i = 1; $i <= $args; $i++ ) { 

		if( $i == 1 ){
			echo '<option value="' . $i . '">' . $i . ' ' . esc_html__( 'Bed' , 'extretion' ) . '</option>';
		} else {
			echo '<option value="' . $i . '">' . $i . ' ' . esc_html__( 'Beds' , 'extretion' ) . '</option>';
		}
		
	}

}

function extretion_get_banner_image(){

	$banner_image = get_option( 'options_banner_homepage' );

	if( !empty( $banner_image ) ){

		$id = extretion_get_image_id( $banner_image );
		$img_attr = wp_get_attachment_image_src( $id , 'extretion_banner-homepage' );

		if( $img_attr ){
			return esc_url( $img_attr[0] );
		}

	} else {
		return get_template_directory_uri() . '/images/hero-header/03.jpg';
	}

}

function extretion_get_banner_title(){

	$banner_title = get_option( 'options_banner_title' );

	if( !empty( $banner_title ) ){
		return esc_html( $banner_title );
	} else {
		return esc_html__( 'Find a place to stay' , 'extretion' );
	}

}

function extretion_get_banner_subtitle(){

	$subtitle_homepage = get_option( 'options_subtitle_homepage' );

	if( !empty( $subtitle_homepage ) ){
		return esc_html( $subtitle_homepage );
	} else {
		return esc_html__( 'Book homes from local hosts in 191+ countries and experience a place like you live there.' , 'extretion' );
	}

}

function extretion_get_the_destination_cat_home( $value ){

	$image_id = get_option( 'destinations_' . $value->term_id . '_image_destination' );  

	$image_attr = wp_get_attachment_image_src( $image_id , 'extretion_search_page_image' ); 

	if( $image_attr ){
		$image = $image_attr[0];
	} else {
		$image = get_template_directory_uri() . '/images/no-image.jpg' ;
	} ?>

	<div class="col-xss-12 col-xs-6 col-sm-4 col-md-3">
		<div class="top-destination-item">
			<a href="<?php echo get_term_link( $value ); ?>">

				<div class="image">
					<img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_html( $value->name ); ?>">
				</div>
				<div class="content">
					<div class="row gap-10">
					
						<div class="col-xs-7 place">
							<h4>
								<?php echo get_term( $value->parent , 'destinations' )->name; ?>
							</h4>
							<p><?php echo esc_html( $value->name ); ?></p>
						</div>
						
						<div class="col-xs-5 price right-circle-icon">
							
							<p>
								<?php 
								printf( esc_html__( '%d hosts', 'extretion' ) , $value->count ); 
								?>									
							</p>
							<p class="icon"><i class="ri ri-chevron-right-circle"></i></p>

						</div>
						
					</div>
				</div>
			</a>
		</div>
	</div>

	<?php
}

function extretion_checkLoggedInUser(){

	if( !is_user_logged_in() ){
		extretion_set404Page();
	}

}

function extretion_check_user_room(){

	if( !is_page_template( 'page-templates/room-edit.php' ) ){
		return;
	}

	// If empty / not logged in show 404 page
	if( empty( $_GET['id'] ) || empty( $_GET['page'] ) || !is_user_logged_in() ){

		extretion_set404Page();

	}

	$post_id = sanitize_text_field( $_GET['id'] );
	$post = get_post( $post_id );
	$user_id = get_current_user_id();

	//echo '<pre>'; print_r( $post ); echo '</pre>';

	// If not post found show 404 page
	if( empty( $post ) || !is_object( $post ) ){
		extretion_set404Page();
	}

	// If room is not of the user show 44 page
	if( $post->post_author != $user_id ){
		extretion_set404Page();
	}

	return $post;

}

function extretion_get_other_user_posts( $exclude_id ,$pagename ){

	$args = array(
		'post_type' => 'room',
		'posts_per_page' => -1,
		'author' => get_current_user_id(),
		'post__not_in' => array($exclude_id),
		'order' => 'ASC',
		'orderby' => 'name'
	);

	$query = new WP_Query( $args );

	if( $query->have_posts() ):
		echo '<li class="divider"></li>';
		while( $query->have_posts() ): $query->the_post();
			global $post;
			echo '<li><a href="' . site_url() . '/' . $pagename . '?id=' . $post->ID . '&page=basic' . '">' . get_the_title( $post ) . '</a></li>';
		endwhile;
	endif;

}

function extretion_get_current_room_photos(){

	$user_id = get_current_user_id();
	$room_details = extretion_check_user_room();
	//print_r($room_details);die;
	if( is_object( $room_details ) ){
		return extretion_get_image_details( $user_id = null , 'room_photos' , $return = true ,  $meta = 'post' , $room_details->ID );
	}

	return array();

}

add_action( 'wp_ajax_add_more_photos_room' , 'extretion_add_more_photos_room' );
function extretion_add_more_photos_room(){

	//print_r($_FILES); die;

	$post_data = array_map( 'sanitize_text_field' , $_POST );
	$user_id = get_current_user_id();

	if( empty( $post_data ) && $post_data['action'] != 'add_more_photos_room' && empty( $_FILES ) ){
		die;
	}

	$post = get_post( $post_data['post_id'] );

	if( $post->post_author != $user_id ){
		die;
	}

	// Allow only image files
	$allowImages = array( 'image/jpg' , 'image/jpeg' , 'image/gif' , 'image/png' , 'image/bmp' );

	if( in_array( $_FILES['tmp_name']['type'][0] , $allowImages ) ){

		$file = array();
		$file['name'] = $_FILES['tmp_name']['name'][0];
		$file['type'] = $_FILES['tmp_name']['type'][0];
		$file['tmp_name'] = $_FILES['tmp_name']['tmp_name'][0];
		$file['error'] = $_FILES['tmp_name']['error'][0];
		$file['size'] = $_FILES['tmp_name']['size'][0];

		$image_id = extretion_upload_image( $file , $post->ID );

		$room_photos =  get_post_meta( $post->ID , 'room_photos' , true );

		array_push( $room_photos , $image_id );

		update_post_meta( $post->ID , 'room_photos' , $room_photos );

	}

	die;

}

add_action( 'wp_ajax_delete_room_photos' , 'extretion_delete_room_photos' );
function extretion_delete_room_photos(){

	/**
	* If empty data break the loop
	*/

	$post_data = array_map( 'sanitize_text_field' , $_POST );
	if( empty( $post_data ) || !is_numeric( $post_data['image_id'] ) || !is_numeric( $post_data['post_id'] ) ){
		die;
	}

	/**
	* If no photos break the loop
	*/

	$room_photos = get_post_meta( $post_data['post_id'] , 'room_photos' , true );
	if( empty( $room_photos ) || !is_array( $room_photos ) ){
		die;
	}

	if( count( $room_photos ) == 1 ){
		echo wp_json_encode( 
			array( 
				'status' => 'error' , 
				'message' => esc_html__( 'Error deleting file : atleast one image should be kept in the gallery. Please refresh the page to reload the content.' , 'extretion' )
			) 
		);
		die;
	}

	/**
	* If not user room break the loop
	*/

	$user_id = get_current_user_id();
	$post = get_post( $post_data['post_id'] );

	if( $post->post_author != $user_id ){
		die;
	}

	// Delete image
	if( in_array( $post_data['image_id'] , $room_photos ) ){
		wp_delete_attachment( $post_data['image_id'] );
	}

	// Remove image id from the database
	foreach( $room_photos as $key => $value ){

		if( $value == $post_data['image_id'] || wp_attachment_is_image( $value ) == false ){

			unset( $room_photos[$key] );

		}

	}

	update_post_meta( $post->ID , 'room_photos' , array_values( $room_photos ) );

	echo wp_json_encode( array( 'result' => 'success' ) );

	die;

}

add_action( 'wp_ajax_sort_room_photos_order' , 'extretion_sort_room_photos_order' );
function extretion_sort_room_photos_order(){

	$user_id = get_current_user_id();

	if( empty( $_POST['post_id'] ) ){
		die;
	}

	$post = get_post( $_POST['post_id'] );

	if( empty( $post ) || !is_object( $post ) || $user_id != $post->post_author ){
		die;
	}

	$image_data = array_map( 'sanitize_text_field' , $_POST['images'] );

	if( !empty( $image_data ) && is_array( $image_data ) ){

		$new_sort = array();

		foreach( $image_data as $value ){

			$new_sort[] = extretion_get_attachment_id_from_url( $value );

		}

		update_post_meta( $post->ID , 'room_photos' , $new_sort );

	}

	die;

}

function extretion_get_attachment_id_from_url( $attachment_url = '' ) {
 
	global $wpdb;
	$attachment_id = false;
 
	// If there is no url, return.
	if ( '' == $attachment_url )
		return;
 
	// Get the upload directory paths
	$upload_dir_paths = wp_upload_dir();
 
	// Make sure the upload path base directory exists in the attachment URL, to verify that we're working with a media library image
	if ( false !== strpos( $attachment_url, $upload_dir_paths['baseurl'] ) ) {
 
		// If this is the URL of an auto-generated thumbnail, get the URL of the original image
		$attachment_url = preg_replace( '/-\d+x\d+(?=\.(jpg|jpeg|png|gif)$)/i', '', $attachment_url );
 
		// Remove the upload path base directory from the attachment URL
		$attachment_url = str_replace( $upload_dir_paths['baseurl'] . '/', '', $attachment_url );
 
		// Finally, run a custom database query to get the attachment ID from the modified attachment URL
		$attachment_id = $wpdb->get_var( 
			$wpdb->prepare( "SELECT wposts.ID FROM $wpdb->posts wposts, $wpdb->postmeta wpostmeta 
				WHERE wposts.ID = wpostmeta.post_id 
				AND wpostmeta.meta_key = '_wp_attached_file' 
				AND wpostmeta.meta_value = '%s' 
				AND wposts.post_type = 'attachment'", $attachment_url 
			) 
		);

		$image_attributes = wp_get_attachment_image_src( $attachment_id );

		if( $image_attributes ){
			return $attachment_id;
		} else {
			return null;
		}
 
	}
 
	return $attachment_id;
}

add_action( 'wp_ajax_change_room_calendar_dates' , 'extretion_change_room_calendar_dates' );
function extretion_change_room_calendar_dates(){

	$user_id = get_current_user_id();
	$post_data = array_map( 'sanitize_text_field' , $_POST );

	if( empty( $post_data['start_date'] ) || empty( $post_data['end_date'] ) || empty( $post_data['post_id'] ) || !isset( $post_data['date_status'] ) ){
		die;
	}

	$post = get_post( $post_data['post_id'] );

	if( $post->post_author != $user_id ){
		die;
	}

	$unavailable_dates = get_post_meta( $post->ID , 'booking_unavailable_dates' , true );
	$unavailable_dates = empty( $unavailable_dates ) ? array() : $unavailable_dates;

	if( extretion_checkIsAValidDate( $post_data['start_date'] ) == true && extretion_checkIsAValidDate( $post_data['end_date'] ) == true ){
		
		$startdate = check_start_end_date( $post_data['start_date'] , $post_data['end_date'] , 'start' );
		$enddate = check_start_end_date( $post_data['start_date'] , $post_data['end_date'] , 'end' );

		// Get all dates bet start and between
		$dates_range = extretion_date_range( $startdate , $enddate );

		if( empty( $dates_range ) || !is_array( $dates_range ) ){
			die;
		}
		
		if( $post_data['date_status'] == 1 ){ // Avalilable dates

			$new_booking_dates = booking_available_dates( $dates_range , $unavailable_dates );

		} else { // Not Avalilable dates

			$new_booking_dates = booking_unavailable_dates( $dates_range , $unavailable_dates );

		}

		update_post_meta( $post->ID , 'booking_unavailable_dates' , $new_booking_dates );
		update_post_meta( $post->ID , 'booking_dates_updated_at' , date( 'd-m-Y H:i:s' ) );

	}

	die;

}

function booking_unavailable_dates( $dates_range , $unavailable_dates = array() ){

	foreach( $dates_range as $key => $date ){

		if( !in_array( $date , $unavailable_dates ) ){

			array_push( $unavailable_dates , $date );

		}

	}

	return array_values($unavailable_dates);

}

function booking_available_dates( $dates_range , $unavailable_dates = array() ){

	foreach( $unavailable_dates as $key => $unavailable_date ){

		if( in_array( $unavailable_date , $dates_range ) ){

			unset( $unavailable_dates[$key] );

		}

	}

	return array_values($unavailable_dates);

}

function check_start_end_date( $start , $end , $return = null ){

	$starDate = strtotime($start);
	$endDate = strtotime($end);

	if( $starDate < $endDate ){

		$normal_start = $start;
		$normal_end = $end;

	} else {

		$normal_start = $end;
		$normal_end = $start;

	}

	if( $return == 'start' ){
		return $normal_start;
	} else {
		return $normal_end;
	}

}

function extretion_check_guide_errors( $post_data , $error_msg , $error_status , $image_upload = true ){

	$allowImages = array( 'image/jpg' , 'image/jpeg' , 'image/gif' , 'image/png' , 'image/bmp' );

	if( !is_numeric( $post_data['lat'] ) || !is_numeric( $post_data['lng'] ) ){

		$error_status = true;
		$error_msg .= '<li>' . esc_html__( 'Enter the place name and select from the dropdown or drag the marker to the place.' , 'extretion' ) . '</li>';

	}

	if( empty( $post_data['name'] ) ){

		$error_status = true;
		$error_msg .= '<li>' . esc_html__( 'Enter the place name.' , 'extretion' ) . '</li>';

	}

	if( !ctype_digit( $post_data['category'] ) ){

		$error_status = true;
		$error_msg .= '<li>' . esc_html__( 'Select a category.' , 'extretion' ) . '</li>';

	}

	if( empty( $_FILES['image']['tmp_name'] ) && $image_upload == true ){

		$error_status = true;
		$error_msg .= '<li>' . esc_html__( 'Select a photo for that place.' , 'extretion' ) . '</li>';

	} elseif( !in_array( $_FILES['image']['type'] , $allowImages ) && $image_upload == true ){

		$error_status = true;
		$error_msg .= '<li>' . esc_html__( 'Upload only image file.' , 'extretion' ) . '</li>';		

	}

	if( $error_status == true ){

		echo wp_json_encode( array(
			'result' => 'error',
			'message' => $error_msg
		) );
		die;

	}

}

function extretion_save_guide_post_type( $post_data, $user_id ){

	// Create post object
	$my_post = array(
	  'post_title'    => $post_data['name'],
	  'post_content'  => $post_data['description'],
	  'post_status'   => 'publish',
	  'post_author'   => $user_id,
	  'post_type' => 'guide'
	);
	 
	// Insert the post into the database
	$post_id = wp_insert_post( $my_post );

	wp_set_object_terms( $post_id, (int) $post_data['category'] , 'guide_cat' );

	update_post_meta( $post_id, 'latitude' , $post_data['lat'] );
	update_post_meta( $post_id, 'longitude' , $post_data['lng'] );
	update_post_meta( $post_id, 'parent_post' , $post_data['for_post_id'] );

	$image_id = extretion_upload_image( $_FILES['image'] , $post_id );

	set_post_thumbnail( $post_id , $image_id );

}

add_action( 'wp_ajax_save_guide_details' , 'extretion_save_guide_details' );
function extretion_save_guide_details(){

	$post_data = array_map( 'sanitize_text_field' , $_POST );

	$error_msg = '';
	$error_status = false;
	$user_id = get_current_user_id();

	extretion_check_guide_errors( $post_data , $error_msg , $error_status );
	extretion_save_guide_post_type( $post_data, $user_id );

	echo wp_json_encode( array( 'result' => 'success' ) );
	die;

}

function extretion_whats_around( $object ){

	$args = array(
		'post_type' => 'guide',
		'post_status' => 'publish',
		'author' => $object->post_author,
		'posts_per_page' => -1,
		'meta_query' => array(
			array(
				'key'     => 'parent_post',
				'value'   => $object->ID,
				'compare' => '=',
			),
		),
	);

	$query = new WP_Query( $args );

	if( $query->have_posts() ): ?>

		<div class=" row gap-20 clearfix">
							
			<div class="col-xs-12 col-sm-12">

				<h5 class="font400 text-uppercase mb-15 font16">
					<?php esc_html_e( 'What&#39;s around' , 'extretion' ); ?>	
				</h5>

				<ul class="list-with-icon whats_around">

					<?php
					while( $query->have_posts() ): $query->the_post(); 

						global $post; ?>

						<li class="">
							<i class="fa fa-map-marker text-primary"></i>
							<?php 
							$title = explode( ',' , get_the_title() ); 
							echo esc_html( $title[0] ); 
							printf( 
								esc_html__( ' ( %d meters far away )' , 'extretion' ) , extretion_get_distance_room( $post ) 
							); ?>
						</li>

					<?php
					endwhile;
					?>

				</ul>
			</div>
		</div>
		
	<?php

	endif;

	wp_reset_postdata();

}

function extretion_get_distance_room( $post ){

	$parent_post_id = get_post_meta( $post->ID , 'parent_post' , true );
	$hotel_lat = get_post_meta( $parent_post_id , 'form_place_located_lat' , true );
	$hotel_lng = get_post_meta( $parent_post_id , 'form_place_located_lng' , true );
	$guide_lat = get_post_meta( $post->ID , 'latitude' , true );
	$guide_lng = get_post_meta( $post->ID , 'longitude' , true );

	return extretion_distanceCalculator( $guide_lat , $guide_lng , $hotel_lat , $hotel_lng ,"M" );

}

function extretion_get_fav_icon(){

	$fav_icon = get_option( 'options_fav_icon' );

	if( !empty( $fav_icon ) && is_numeric( $fav_icon ) ){

		$image_attributes = wp_get_attachment_image_src( $fav_icon , 'thumbnail' );

		if( $image_attributes ){

			return $image_attributes[0];

		}

	}

	return get_template_directory_uri() . '/images/ico/favicon.png';

}

function extretion_countries_list(){

	$country_array = array(
		"AF" => "Afghanistan",
		"AL" => "Albania",
		"DZ" => "Algeria",
		"AS" => "American Samoa",
		"AD" => "Andorra",
		"AO" => "Angola",
		"AI" => "Anguilla",
		"AQ" => "Antarctica",
		"AG" => "Antigua and Barbuda",
		"AR" => "Argentina",
		"AM" => "Armenia",
		"AW" => "Aruba",
		"AU" => "Australia",
		"AT" => "Austria",
		"AZ" => "Azerbaijan",
		"BS" => "Bahamas",
		"BH" => "Bahrain",
		"BD" => "Bangladesh",
		"BB" => "Barbados",
		"BY" => "Belarus",
		"BE" => "Belgium",
		"BZ" => "Belize",
		"BJ" => "Benin",
		"BM" => "Bermuda",
		"BT" => "Bhutan",
		"BO" => "Bolivia",
		"BA" => "Bosnia and Herzegovina",
		"BW" => "Botswana",
		"BV" => "Bouvet Island",
		"BR" => "Brazil",
		"BQ" => "British Antarctic Territory",
		"IO" => "British Indian Ocean Territory",
		"VG" => "British Virgin Islands",
		"BN" => "Brunei",
		"BG" => "Bulgaria",
		"BF" => "Burkina Faso",
		"BI" => "Burundi",
		"KH" => "Cambodia",
		"CM" => "Cameroon",
		"CA" => "Canada",
		"CT" => "Canton and Enderbury Islands",
		"CV" => "Cape Verde",
		"KY" => "Cayman Islands",
		"CF" => "Central African Republic",
		"TD" => "Chad",
		"CL" => "Chile",
		"CN" => "China",
		"CX" => "Christmas Island",
		"CC" => "Cocos [Keeling] Islands",
		"CO" => "Colombia",
		"KM" => "Comoros",
		"CG" => "Congo - Brazzaville",
		"CD" => "Congo - Kinshasa",
		"CK" => "Cook Islands",
		"CR" => "Costa Rica",
		"HR" => "Croatia",
		"CU" => "Cuba",
		"CY" => "Cyprus",
		"CZ" => "Czech Republic",
		"CI" => "Cote d'Ivoire",
		"DK" => "Denmark",
		"DJ" => "Djibouti",
		"DM" => "Dominica",
		"DO" => "Dominican Republic",
		"NQ" => "Dronning Maud Land",
		"DD" => "East Germany",
		"EC" => "Ecuador",
		"EG" => "Egypt",
		"SV" => "El Salvador",
		"GQ" => "Equatorial Guinea",
		"ER" => "Eritrea",
		"EE" => "Estonia",
		"ET" => "Ethiopia",
		"FK" => "Falkland Islands",
		"FO" => "Faroe Islands",
		"FJ" => "Fiji",
		"FI" => "Finland",
		"FR" => "France",
		"GF" => "French Guiana",
		"PF" => "French Polynesia",
		"TF" => "French Southern Territories",
		"FQ" => "French Southern and Antarctic Territories",
		"GA" => "Gabon",
		"GM" => "Gambia",
		"GE" => "Georgia",
		"DE" => "Germany",
		"GH" => "Ghana",
		"GI" => "Gibraltar",
		"GR" => "Greece",
		"GL" => "Greenland",
		"GD" => "Grenada",
		"GP" => "Guadeloupe",
		"GU" => "Guam",
		"GT" => "Guatemala",
		"GG" => "Guernsey",
		"GN" => "Guinea",
		"GW" => "Guinea-Bissau",
		"GY" => "Guyana",
		"HT" => "Haiti",
		"HM" => "Heard Island and McDonald Islands",
		"HN" => "Honduras",
		"HK" => "Hong Kong SAR China",
		"HU" => "Hungary",
		"IS" => "Iceland",
		"IN" => "India",
		"ID" => "Indonesia",
		"IR" => "Iran",
		"IQ" => "Iraq",
		"IE" => "Ireland",
		"IM" => "Isle of Man",
		"IL" => "Israel",
		"IT" => "Italy",
		"JM" => "Jamaica",
		"JP" => "Japan",
		"JE" => "Jersey",
		"JT" => "Johnston Island",
		"JO" => "Jordan",
		"KZ" => "Kazakhstan",
		"KE" => "Kenya",
		"KI" => "Kiribati",
		"KW" => "Kuwait",
		"KG" => "Kyrgyzstan",
		"LA" => "Laos",
		"LV" => "Latvia",
		"LB" => "Lebanon",
		"LS" => "Lesotho",
		"LR" => "Liberia",
		"LY" => "Libya",
		"LI" => "Liechtenstein",
		"LT" => "Lithuania",
		"LU" => "Luxembourg",
		"MO" => "Macau SAR China",
		"MK" => "Macedonia",
		"MG" => "Madagascar",
		"MW" => "Malawi",
		"MY" => "Malaysia",
		"MV" => "Maldives",
		"ML" => "Mali",
		"MT" => "Malta",
		"MH" => "Marshall Islands",
		"MQ" => "Martinique",
		"MR" => "Mauritania",
		"MU" => "Mauritius",
		"YT" => "Mayotte",
		"FX" => "Metropolitan France",
		"MX" => "Mexico",
		"FM" => "Micronesia",
		"MI" => "Midway Islands",
		"MD" => "Moldova",
		"MC" => "Monaco",
		"MN" => "Mongolia",
		"ME" => "Montenegro",
		"MS" => "Montserrat",
		"MA" => "Morocco",
		"MZ" => "Mozambique",
		"MM" => "Myanmar [Burma]",
		"NA" => "Namibia",
		"NR" => "Nauru",
		"NP" => "Nepal",
		"NL" => "Netherlands",
		"AN" => "Netherlands Antilles",
		"NT" => "Neutral Zone",
		"NC" => "New Caledonia",
		"NZ" => "New Zealand",
		"NI" => "Nicaragua",
		"NE" => "Niger",
		"NG" => "Nigeria",
		"NU" => "Niue",
		"NF" => "Norfolk Island",
		"KP" => "North Korea",
		"VD" => "North Vietnam",
		"MP" => "Northern Mariana Islands",
		"NO" => "Norway",
		"OM" => "Oman",
		"PC" => "Pacific Islands Trust Territory",
		"PK" => "Pakistan",
		"PW" => "Palau",
		"PS" => "Palestinian Territories",
		"PA" => "Panama",
		"PZ" => "Panama Canal Zone",
		"PG" => "Papua New Guinea",
		"PY" => "Paraguay",
		"YD" => "People's Democratic Republic of Yemen",
		"PE" => "Peru",
		"PH" => "Philippines",
		"PN" => "Pitcairn Islands",
		"PL" => "Poland",
		"PT" => "Portugal",
		"PR" => "Puerto Rico",
		"QA" => "Qatar",
		"RO" => "Romania",
		"RU" => "Russia",
		"RW" => "Rwanda",
		"RE" => "Reunion",
		"BL" => "Saint Barthelemy",
		"SH" => "Saint Helena",
		"KN" => "Saint Kitts and Nevis",
		"LC" => "Saint Lucia",
		"MF" => "Saint Martin",
		"PM" => "Saint Pierre and Miquelon",
		"VC" => "Saint Vincent and the Grenadines",
		"WS" => "Samoa",
		"SM" => "San Marino",
		"SA" => "Saudi Arabia",
		"SN" => "Senegal",
		"RS" => "Serbia",
		"CS" => "Serbia and Montenegro",
		"SC" => "Seychelles",
		"SL" => "Sierra Leone",
		"SG" => "Singapore",
		"SK" => "Slovakia",
		"SI" => "Slovenia",
		"SB" => "Solomon Islands",
		"SO" => "Somalia",
		"ZA" => "South Africa",
		"GS" => "South Georgia and the South Sandwich Islands",
		"KR" => "South Korea",
		"ES" => "Spain",
		"LK" => "Sri Lanka",
		"SD" => "Sudan",
		"SR" => "Suriname",
		"SJ" => "Svalbard and Jan Mayen",
		"SZ" => "Swaziland",
		"SE" => "Sweden",
		"CH" => "Switzerland",
		"SY" => "Syria",
		"ST" => "Sao Tome and Principe",
		"TW" => "Taiwan",
		"TJ" => "Tajikistan",
		"TZ" => "Tanzania",
		"TH" => "Thailand",
		"TL" => "Timor-Leste",
		"TG" => "Togo",
		"TK" => "Tokelau",
		"TO" => "Tonga",
		"TT" => "Trinidad and Tobago",
		"TN" => "Tunisia",
		"TR" => "Turkey",
		"TM" => "Turkmenistan",
		"TC" => "Turks and Caicos Islands",
		"TV" => "Tuvalu",
		"UM" => "U.S. Minor Outlying Islands",
		"PU" => "U.S. Miscellaneous Pacific Islands",
		"VI" => "U.S. Virgin Islands",
		"UG" => "Uganda",
		"UA" => "Ukraine",
		"SU" => "Union of Soviet Socialist Republics",
		"AE" => "United Arab Emirates",
		"GB" => "United Kingdom",
		"US" => "United States",
		"UY" => "Uruguay",
		"UZ" => "Uzbekistan",
		"VU" => "Vanuatu",
		"VA" => "Vatican City",
		"VE" => "Venezuela",
		"VN" => "Vietnam",
		"WK" => "Wake Island",
		"WF" => "Wallis and Futuna",
		"EH" => "Western Sahara",
		"YE" => "Yemen",
		"ZM" => "Zambia",
		"ZW" => "Zimbabwe",
		"AX" => "Aland Islands",
		);
	
	$country_array = apply_filters( 'extretion_countries_list' , $country_array );
	asort( $country_array );
	return $country_array;
}

function extretion_get_billing_country( $user_id ){

	$user_country = get_user_meta( $user_id, 'form_hotel_located_country' , true );

	foreach(  extretion_countries_list() as $short_name => $long_name ){

		echo '<option ';

		if( $long_name == $user_country ){
			echo 'selected="selected"';
		}

		echo ' value="';
		echo esc_html( $long_name );
		echo '">';
		echo esc_html( $long_name );
		echo '</option>';

	}

}

function extretion_check_active_booking_page( $template ){

	if( is_page_template( $template ) ){
		echo 'active';
	}

}

add_action( 'wp_ajax_send_booking_request' , 'extretion_send_booking_request' );
function extretion_send_booking_request(){

	$data = array_map( 'sanitize_text_field' , $_POST );
	$user_id = get_current_user_id();
	$invoice_id = '';

	$order_ids = get_post_meta( $data['post_id'],'order_ids',true );

	if( empty( $order_ids ) || !is_array( $order_ids ) ){
		
		echo wp_json_encode( 
			array( 
				'result' => 'error',
				'redirect_url' => site_url()
			) 
		);
		die;

	}

	foreach( $order_ids as $key => $order_id ){

		if( $order_id['attributes']['secret_key'] == $data['secret'] ){

			$room_id = $order_id['attributes']['post_id'];
			$room_details = get_post( $room_id );

			// Create post object
			$my_post = array(
				'post_type'     => 'lmh_invoice',
			  	'post_title'    => get_the_title( $room_id ),
			  	'post_status'   => 'publish',
			  	'post_author'   => $user_id,
			);
			 
			// Insert the post into the database
			$invoice_id = wp_insert_post( $my_post );

			// Until the hotel owner approves the request it wil be pending approval
			//$order_id['attributes']['payment_attributes']['status'] = 'pending_approval';

			update_post_meta( $invoice_id, 'invoice_details' , $order_id['attributes'] );
			update_post_meta( $invoice_id, 'related_room_id' , $order_id['attributes']['post_id'] );
			
			update_post_meta( $invoice_id, 'check_in_date' , $order_id['attributes']['check_in'] );
			update_post_meta( $invoice_id, 'check_out_date' , $order_id['attributes']['check_out'] );
			update_post_meta( $invoice_id, 'updated_at' , date( 'Y-m-d' ) );

			update_post_meta( $invoice_id, 'hotel_owner' , $room_details->post_author );
			update_post_meta( $invoice_id, 'payment_status' , 'pending_approval' );

			// Remove order id from the array
			unset( $order_ids[$key] );
			update_post_meta( $data['post_id'] , 'order_ids' , $order_ids );

		}

	}

	if( empty( $invoice_id ) ){
		echo wp_json_encode( 
			array( 
				'result' => 'error',
				'redirect_url' => site_url()
			) 
		);
		die;
	}

	do_action( 'extretion_after_booking_request_send' , $invoice_id );

	echo wp_json_encode( 
		array( 
			'result' => 'success',
			'redirect_url' => esc_url( extretion_get_my_trips_link() . '?status=success' ) 
		) 
	);

	die;

}

add_action( 'extretion_after_booking_request_send' , 'extretion_send_mail_to_hotel_owner' );
function extretion_send_mail_to_hotel_owner( $invoice_id ){

	$invoice_details = get_post_meta( $invoice_id, 'invoice_details', true ); // Get Invoice Details

	//print_r( $invoice_details );

	$room_object = get_post( $invoice_details['post_id'] ); // Get room object ( Hotel Owner )

	$to = get_the_author_meta( 'user_email' , $room_object->post_author ); // Get hotel owner's email

	/** 
	* Start Subject 
	*/

	$subject = get_option( 'options_booking_request_notification_subject' );
	if( empty( $subject ) ){
		$subject = 'You have received a booking request for [room_name] at [site_name].';
	}

	$subject = str_replace( '[site_name]' , get_bloginfo( 'name' ) , $subject );
	$subject = str_replace( '[room_name]' , get_the_title( $invoice_id ) , $subject );

	/** 
	* End Subject 
	*/

	/** 
	* Start Message 
	*/

	$message = get_option( 'options_booking_request_message_notification' );
	if( empty( $message ) ){
		$message = '<p>Hello [username],<br /> You have received a booking request for [room_name] at [site_name].</p><p>Read and reply the booking request, alternative follow all received booking requests in your reservations section at [site_link].</p><p>Check-in : [check_in]<br /> Check-out : [check_out]<br /> Guest : [guest]<br /> Your total rent : [fees]<br /> Payment at booking : [booking_fees]</p><p>If you accept the booking request the guest will be notified and asked to pay the fee within 48h to [site_name].</p><p>At payment the booking is confirmed and you will receive booking contract, contact information, instructions and other important information prior the rental. If you decline the booking request it will be deleted. If you choose not to answer on this booking request it will remain active for 14 days and then deleted.</p><p>IMPORTANT! When you approve a booking request the guest need to confirm the booking within 48h, during this period of time you are not able to withdraw your approval and are committed to rent the valid time period. You cannot accept other booking request during same time period. If the guest does not confirm the booking within said time, your approval is automaticaly cancelled. You can choose to approve someone elses booking request.</p>';
	}

	$username = get_the_author_meta( 'user_login' , $room_object->post_author );
	$room_name = get_the_title( $room_object );
	$check_in = date( 'd M, Y' , strtotime( $invoice_details['check_in'] ) );
	$check_out = date( 'd M, Y' , strtotime( $invoice_details['check_out'] ) );
	$guest = $invoice_details['guests'];

	/* In Traveller chosen currency */
	$security_deposit = !empty( $invoice_details['security_deposit'] ) ? $invoice_details['security_deposit'] : 0; 
	$total_price = $invoice_details['total_price'] + $security_deposit;

	$fees = $total_price . ' ' . $invoice_details['currency'];
	$extretion_get_first_installment_price = number_format( extretion_get_first_installment_price( $invoice_details ),2);
	$fee_at_booking = $extretion_get_first_installment_price . ' ' . $invoice_details['currency'];

	/* In Hotel Owner chosen currency */
	$hotel_owner_currency = get_post_meta( $room_object->ID, 'user_currency', true ); // Get the room currency
	if( $invoice_details['currency'] != $hotel_owner_currency ){
	
		$fees .= ' ( ' .extretion_exchange_currency( $total_price, $from = $invoice_details['currency'], $currency_only = NULL , $to_currency = $hotel_owner_currency , $commission = false ) . ' )';

		$filter_booking_price = str_replace(',', '', $extretion_get_first_installment_price);
		$fee_at_booking .= ' ( ' .extretion_exchange_currency( $filter_booking_price, $from = $invoice_details['currency'], $currency_only = NULL , $to_currency = $hotel_owner_currency , $commission = false ) . ' )';

	}

	$message = str_replace( '[username]' , $username , $message );
	$message = str_replace( '[room_name]' , $room_name , $message );
	$message = str_replace( '[site_name]' , get_bloginfo( 'name' ) , $message );
	$message = str_replace( '[site_link]' , site_url() , $message );
	$message = str_replace( '[check_in]' , $check_in , $message );
	$message = str_replace( '[check_out]' , $check_out , $message );
	$message = str_replace( '[guest]' , $guest , $message );
	$message = str_replace( '[fees]' , $fees , $message );
	$message = str_replace( '[booking_fees]' , $fee_at_booking , $message );
	
	/** 
	* End Message 
	*/

	/* Send mail to the hotel owner */
	wp_mail( $to, $subject, nl2br( $message ), extretion_mail_headers() );

}

function extretion_invoice_cpt_columns($columns) {

	$new_columns = array(
		'invoice_details' => esc_html__( 'Invoice Details', 'extretion' ),
		'payment_status' => esc_html__( 'Payment Status', 'extretion' ),
		//'price' => esc_html__( 'Price', 'extretion' ),
		'additional_notes' => esc_html__( 'Additional Notes', 'extretion' ),
	);

	$date = $columns['date'];
	unset( $columns['date'] );
    $new_column = array_merge( $columns, $new_columns );
    $new_column['date'] = $date;
    return $new_column;

}
add_filter('manage_lmh_invoice_posts_columns' , 'extretion_invoice_cpt_columns');

add_action( 'manage_lmh_invoice_posts_custom_column' , 'extretion_invoice_cpt_custom_columns', 10, 2 );
function extretion_invoice_cpt_custom_columns( $column, $post_id ){

	$order_id = get_post_meta( $post_id, 'invoice_details', true );

	switch ( $column ) {

		case 'invoice_details':

			$traveller = get_post_meta( $post_id , 'hotel_owner' , true );
			$post = get_post( $post_id );
			$payment_method = get_post_meta( $post_id, 'payment_method' , true );
			$payment_method = ( $payment_method == 'stripe' ? 'Stripe' : 'PayPal' );

			$duration = date( 'd M, Y' , strtotime( $order_id['check_in'] ) ) . ' - ' . date( 'd M, Y' , strtotime( $order_id['check_out'] ) );
            
            echo '<p><strong>' . esc_html( 'Invoice ID' , 'extretion' ) . ' : </strong>' . (int) $post_id . '</p>';
			echo '<p><strong>' . esc_html( 'Host' , 'extretion' ) . ' : </strong>';
			the_author_meta( 'user_login' , $traveller );
			echo '</p><p><strong>' . esc_html( 'Traveler' , 'extretion' ) . ' : </strong>';
			the_author_meta( 'user_login' , $post->post_author );
			echo '</p><p><strong>' . esc_html( 'Payment Method' , 'extretion' ) . ' : </strong>' . $payment_method . '</p>';
			echo '</p><p><strong>' . esc_html( 'Duration' , 'extretion' ) . ' : </strong>' . $duration . '</p>';
			echo '<p><strong>' . esc_html( 'Price' , 'extretion' ) . ' : </strong>' . extretion_get_total_price_backend( $order_id ) . '</p>';

			break;

		case 'payment_status':

			$payment_status = get_post_meta( $post_id, 'payment_status' , true );	
			
			switch ( $payment_status ) {

				case 'payment_successful':
					echo '<span class="extretion_success_btn">' . esc_html__( 'Payment Successful', 'extretion' ) . '</span>';
					break;

				case 'booking_request_accepted':
					echo '<span class="extretion_pending_btn">' . esc_html__( 'Pending Payment', 'extretion' ) . '</span>';
					break;
				
				default:
					echo '<span class="extretion_pending_approval_btn">' . esc_html__( 'Pending Approval', 'extretion' ) . '</span>';
					break;
			}		

			break;

        // case 'price' :

        // 	$security_deposit = !empty( $order_id['security_deposit'] ) ? $order_id['security_deposit'] : 0;
        // 	$total_price = $order_id['total_price'] + $security_deposit;

        // 	echo esc_html( $order_id['currency'] ) . ' ' . number_format( $total_price,2,'.',',' );
        	
        // 	break;

        case 'additional_notes':

        	$additional_note = get_post_meta( $post_id, 'additional_note' , true );
        	echo '<textarea class="invoice_details_additional_info" rows="8" >' . $additional_note . '</textarea>';
        	echo '<a href="javascript:void(0)" class="button button-primary extretion_save_invoice_notes" post_id="' . $post_id . '">' . esc_html__( 'Save' , 'extretion' ) . '</a>';

        	break;

    }

}

function extretion_get_total_price_backend( $order_id ){

	$security_deposit = !empty( $order_id['security_deposit'] ) ? $order_id['security_deposit'] : 0;
	$total_price = $order_id['total_price'] + $security_deposit;

	return esc_html( $order_id['currency'] ) . ' ' . number_format( $total_price,2,'.',',' );

}

add_action( 'wp_ajax_cancel_booking_by_traveller' , 'extretion_cancel_booking_by_traveller' );
function extretion_cancel_booking_by_traveller(){

	$data = array_map( 'sanitize_text_field' , $_POST ); // Sannitize array
	$invoice_id = $data['invoice_id']; // Invoice id
	$traveller_id = get_current_user_id(); // Get the traveller id
	$invoice_object = get_post( $invoice_id ); // Get invoice object or post object

	$payment_status = get_post_meta( $invoice_id, 'payment_status', true );

	if( $invoice_object->post_author != $traveller_id || $payment_status != 'pending_approval' ){
		echo wp_json_encode(
			array(
				'redirect_url' => extretion_get_my_trips_link()
			)
		);
		die;
	}

	$invoice_details = get_post_meta( $invoice_id , 'invoice_details' , true );
	$room_id = $invoice_details['post_id'];

	wp_delete_post( $invoice_id );

	do_action( 'extretion_after_cancelled_booking_by_traveller' , $room_id , $traveller_id );

	echo wp_json_encode(
		array(
			'redirect_url' => extretion_get_my_trips_link() . '?status=trash'
		)
	);

	die;

}

add_action( 'wp_ajax_cancel_booking_by_hotel' , 'extretion_cancel_booking_by_hotel' );
function extretion_cancel_booking_by_hotel(){

	$data = array_map( 'sanitize_text_field' , $_POST ); // Sannitize array
	$invoice_id = $data['invoice_id']; // Invoice id
	$hotel_id = get_current_user_id(); // Get the hotel id
	$hotel_owner_invoice = get_post_meta( $invoice_id , 'hotel_owner' , true ); 

	$payment_status = get_post_meta( $invoice_id, 'payment_status', true );

	/* To get traveller id */
	$invoice_object = get_post( $invoice_id ); // Get invoice object or post object
	
	if( !is_object($invoice_object) || $hotel_owner_invoice != $hotel_id || $payment_status != 'pending_approval' ){
		echo wp_json_encode(
			array(
				'redirect_url' => site_ur()
			)
		);
		die;
	}

	$traveller_id = $invoice_object->post_author;

	$invoice_details = get_post_meta( $invoice_id , 'invoice_details' , true );
	$room_id = $invoice_details['post_id'];

	wp_delete_post( $invoice_id );

	do_action( 'extretion_after_cancelled_booking_by_hotel' , $room_id , $traveller_id );

	echo wp_json_encode(
		array(
			'redirect_url' => extretion_get_reservation_link() . '?status=reject'
		)
	);

	die;

}

add_action( 'extretion_after_cancelled_booking_by_hotel' , 'extretion_send_mail_to_traveller_after_cancelled_booking_by_hotel' , 10 , 2 );

function extretion_send_mail_to_traveller_after_cancelled_booking_by_hotel( $room_id , $traveller_id ){

	$to = get_the_author_meta( 'user_email' , $traveller_id );

	/* start get mail subject */

	$subject = get_option( 'options_cancel_booking_by_hotel_subject' );
	if( empty( $subject ) ){
		$subject = 'Your booking request [invoice_name] at [site_name] is denied by host';
	}

	$subject = str_replace( '[site_name]' , get_bloginfo( 'name' ) , $subject );
	$subject = str_replace( '[invoice_name]' , get_the_title( $room_id ) , $subject );

	/* End get mail subject */

	/* Start get mail maessage */

	$message = get_option( 'options_cancel_booking_by_hotel_message' );
	if( empty( $message ) ){
		$message = "<p>Hello [traveller],</p><p>Your booking request [invoice_name] at [site_name] is denied by the host.</p><p>The host has chosen not to give more information, but don't give up! You are more than welcome to search other exciting rental objects that can meet your needs, search at [site_url].</p><p>Did you know that several booking requests will increase your chances to rent that perfect vacation?</p>";
	}

	$message = str_replace( '[site_name]' , get_bloginfo( 'name' ) , $message );
	$message = str_replace( '[invoice_name]' , get_the_title( $room_id ) , $message );
	$message = str_replace( '[traveller]' , get_the_author_meta( 'user_login' , $traveller_id ) , $message );
	$message = str_replace( '[site_url]' , site_url() , $message );

	/* End get mail maessage */

	wp_mail( $to, $subject, nl2br( $message ), extretion_mail_headers() );

}

add_action( 'extretion_after_cancelled_booking_by_traveller' , 'extretion_send_mail_to_hotel_owner_after_cancelled_booking_by_traveller' , 10 , 2 );

function extretion_send_mail_to_hotel_owner_after_cancelled_booking_by_traveller( $room_id , $traveller_id ){

	$room_object = get_post( $room_id );
	$hotel_id = $room_object->post_author;

	$to = get_the_author_meta( 'user_email' , $hotel_id );

	/* start get mail subject */
	
	$subject = get_option( 'options_cancel_booking_by_traveller_subject' );
	if( empty( $subject ) ){
		$subject = 'Booking request [invoice_name] at [site_name] is cancelled by traveler';
	}

	$subject = str_replace( '[site_name]' , get_bloginfo( 'name' ) , $subject );
	$subject = str_replace( '[invoice_name]' , get_the_title( $room_id ) , $subject );

	/* End get mail subject */

	/* start get mail maessage */

	$message = get_option( 'options_cancel_booking_by_traveller_message' );
	if( empty( $message ) ){
		$message = '<p>Hello [hotel_owner],</p><p>Booking request [invoice_name] at [site_name] is cancelled by guest.</p><p>The guest has chosen not to give more information. The request has been removed from your inbox.</p>';
	}

	$message = str_replace( '[site_name]' , get_bloginfo( 'name' ) , $message );
	$message = str_replace( '[invoice_name]' , get_the_title( $room_id ) , $message );
	$message = str_replace( '[hotel_owner]' , get_the_author_meta( 'user_login' , $hotel_id ) , $message );

	/* End get mail maessage */

	wp_mail( $to, $subject, nl2br( $message ), extretion_mail_headers() );

}
function extretion_booking_page_privelage( $invoice_details , $user_id , $hotel_id ){

	/* Check traveller */
	if( $invoice_details->post_author == $user_id ){
		return true;
	} 
	/* Check hotel owner */
	elseif( $user_id == $hotel_id ){
		return true;
	}

	return false;

}

add_action( 'wp_ajax_approved_booking_by_hotel' , 'extretion_approved_booking_by_hotel' );
function extretion_approved_booking_by_hotel(){

	$data = array_map( 'sanitize_text_field' , $_POST );
	$invoice_id = $data['invoice_id'];
	$invoice_hotel_id = get_post_meta( $invoice_id, 'hotel_owner', true );
	$user_id = get_current_user_id();

	$invoice_object = get_post( $invoice_id );

	if( !is_object( $invoice_object ) ){
		echo wp_json_encode(
			array(
				'redirect_url' => site_url()
			)
		);
		die;
	}

	if( $user_id != $invoice_hotel_id ){
		echo wp_json_encode(
			array(
				'redirect_url' => site_url()
			)
		);
		die;
	}

	//$invoice_details = get_post_meta( $invoice_id, 'invoice_details', true );
	$payment_status = get_post_meta( $invoice_id, 'payment_status', true );

	if( $payment_status != 'pending_approval' ){
		echo wp_json_encode(
			array(
				'redirect_url' => site_url()
			)
		);
		die;
	}

	//$invoice_details['payment_attributes']['status'] = 'approved_booking_by_hotel';
	update_post_meta( $invoice_id, 'payment_status' , 'booking_request_accepted' );
	update_post_meta( $invoice_id, 'updated_at' , date( 'Y-m-d' ) );

	extretion_set_booking_unavailable_dates( $invoice_id );

	do_action( 'extretion_after_booking_request_accept' , $invoice_hotel_id , $traveller_id = $invoice_object->post_author , $invoice_id );

	echo wp_json_encode(
		array(
			'redirect_url' => extretion_get_reservation_link() . '?status=approved'
		)
	);

	die;

}

function extretion_set_booking_unavailable_dates( $invoice_id ){

	$room_id = get_post_meta( $invoice_id, 'related_room_id', true ); // get the related room id of the invoice

	$invoice_details = get_post_meta( $invoice_id , 'invoice_details' , true );

	$db_unavailable_dates = get_post_meta( $room_id, 'booking_unavailable_dates', true );

	$dates = extretion_date_range( $invoice_details['check_in'] , $invoice_details['check_out'] );

	if( empty( $db_unavailable_dates ) ){

		update_post_meta( $room_id, 'booking_unavailable_dates', $dates );

	} else {

		foreach( $db_unavailable_dates as $value ){

			if( !in_array( $value , $dates ) ){

				array_push( $dates , $value );

			}

		}

		update_post_meta( $room_id, 'booking_unavailable_dates', $dates );

	}

}

add_action( 'extretion_after_booking_request_accept' , 'extretion_after_booking_request_accept' , 10 , 3 );
function extretion_after_booking_request_accept( $hotel_id , $traveller_id , $invoice_id ){

	$to = get_the_author_meta( 'user_email' , $traveller_id );
	$traveller_name = get_the_author_meta( 'user_login' , $traveller_id );

	/* To get fees and currency */
	$invoice_details = get_post_meta( $invoice_id, 'invoice_details', true );

	$security_deposit = !empty( $invoice_details['security_deposit'] ) ? $invoice_details['security_deposit'] : 0; 
	$total_price = $invoice_details['total_price'] + $security_deposit;

	$fees = number_format($total_price,2,'.',',') . ' ' . $invoice_details['currency'];

	$extretion_get_first_installment_price = number_format( extretion_get_first_installment_price( $invoice_details ),2,'.',',');
	$fee_at_booking = $extretion_get_first_installment_price . ' ' . $invoice_details['currency'];
	/* To get fees and currency */

	//print_r($invoice_details);

	$subject = get_option( 'options_approved_booking_subject' );
	if( empty( $subject ) ){ 
		$subject = 'Your booking request [invoice_name] at [site_name] has been approved.';
	}

	$subject = str_replace( '[site_name]' , get_bloginfo( 'name' ) , $subject );
	$subject = str_replace( '[invoice_name]' , get_the_title( $invoice_id ) , $subject );

	$message = get_option( 'options_approved_booking_message' );
	if( empty( $message ) ){
		$message = "<p>Hello [traveller],</p><p>Your booking request [invoice_name] at [site_name] has been approved by the owner.</p><p>You need to confirm the booking by paying the booking fee within 48hrs after you receive this email.</p><p>At payment the booking is confirmed and you will receive booking contract, contact information, instructions and other important information prior the rental.</p><p>If you choose not to pay the booking fee, your booking request is cancelled. If you missed the deadline but still want to book, you have to make a new booking request.</p><p>Reference number: [reference_no]<br /> Booking Fee: [booking_fee]<br /> Total Price: [fees]</p><p>Please log into your [site_name] account to accept payments. All payments are made via [site_name]'s secure and trusted payment system.</p><p>For us at [site_name] it is important that you as customer always feel safe and secure.</p>";
	}

	$message = str_replace( '[traveller]' , $traveller_name , $message );
	$message = str_replace( '[invoice_name]' , get_the_title( $invoice_id ) , $message );
	$message = str_replace( '[site_name]' , get_bloginfo( 'name' ) , $message );
	$message = str_replace( '[reference_no]' , $invoice_id , $message );
	$message = str_replace( '[fees]' , $fees , $message );
	$message = str_replace( '[booking_fee]' , $fee_at_booking , $message );

	wp_mail( $to, $subject, nl2br( $message ), extretion_mail_headers() );

	//print_r( $hotel_id );
	//print_r( $traveller_id );
	//print_r( $invoice_id );

}

function extretion_get_paypal_credentials(){

	$status = get_option( 'options_enable_live_sandbox' ); // live or sandbox
	$data = array();

	if( empty( $status ) || $status == 'sandbox' ){

		$data['security_user_id'] = get_option( 'options_sandbox_security_user_id' );
		$data['security_password'] = get_option( 'options_sandbox_security_password' );
		$data['security_signature'] = get_option( 'options_sandbox_security_signature' );
		$data['application_id'] = 'APP-80W284485P519543T';
		$data['url'] = 'https://svcs.sandbox.paypal.com/AdaptivePayments/Pay';
		$data['redirect_url'] = "https://www.sandbox.paypal.com/cgi-bin/webscr?cmd=_ap-payment&paykey=";

	} else {

		$data['security_user_id'] = get_option( 'options_live_security_user_id' );
		$data['security_password'] = get_option( 'options_live_security_password' );
		$data['security_signature'] = get_option( 'options_live_security_signature' );
		$data['application_id'] = get_option( 'options_live_application_id' );
		$data['url'] = 'https://svcs.paypal.com/AdaptivePayments/Pay';
		$data['redirect_url'] = 'https://www.paypal.com/cgi-bin/webscr?cmd=_ap-payment&paykey=';

	}

	return $data;

}

// function extretion_get_commission_in_amount( $price ){

// 	$commision_rate = get_option( 'options_commision_rate' );

// 	if( empty( $commision_rate ) || !is_numeric( $commision_rate ) ){
// 		$commision_rate = 10;
// 	}

// 	$commission = (( $commision_rate / 100) * $price);
// 	return round( $commission );

// }

function extretion_get_total_price_in_usd( $invoice_details ){

	$traveller_chosen_currency = $invoice_details['currency'];

	$total_price = $invoice_details['total_price'];

	$partial_payment = (extretion_get_first_installment_percentage() / 100) * $total_price;

	// Convert price to USD
	$in_usd_amt = extretion_exchange_currency( 
		$partial_payment, 
		$from_currency = $traveller_chosen_currency, 
		$currency_only = NULL, 
		$to_currency = 'USD', 
		$commission = false,
		$round = false
	);

	// Get only price
	return preg_replace("/[^0-9\.]/", null, $in_usd_amt );

}

function extretion_get_success_url( $invoice_id ){

	$payment_confirmation_link = get_permalink( get_option( 'options_select_booking_confirmation_n_payment' ) );
	$payment_confirmation_link = esc_url( $payment_confirmation_link );
	$payment_successful_key = wp_generate_password( $length = 32 , false , false );

	update_post_meta( $invoice_id , 'payment_successful_key' , $payment_successful_key );

	return $payment_confirmation_link . $invoice_id . '/?paysecret=' . $payment_successful_key;

}

add_action( 'wp_ajax_get_paypal_payment_details' , 'extretion_get_paypal_payment_details' );
function extretion_get_paypal_payment_details(){

	$data = array_map( 'sanitize_text_field' , $_POST );
	$invoice_id = $data['invoice_id'];
	$user_id = get_current_user_id();
	$invoice_object = get_post( $invoice_id );
	$payment_status = get_post_meta( $invoice_id, 'payment_status', true );
	$invoice_details = get_post_meta( $invoice_id, 'invoice_details', true );
	$hotel_id = get_post_meta( $invoice_id, 'hotel_owner', true );

	if( empty( $invoice_id ) || !ctype_digit( $invoice_id ) || !is_object( $invoice_object ) || $user_id != $invoice_object->post_author || $payment_status != 'booking_request_accepted' ){
		die;
	}
	
	// Get price in USD
	$only_price = extretion_get_total_price_in_usd( $invoice_details ); 

	$commission = number_format( ($only_price / 2) , 2, '.', ''); // Price for the site owner
	$security_deposit = !empty( $invoice_details['security_deposit'] ) ? (int) $invoice_details['security_deposit'] : 0;

	$payment_hotel_owner = number_format( ($commission + $security_deposit) , 2, '.', '');

	$paypal_credentials = extretion_get_paypal_credentials();

	$headers = array(
        "X-PAYPAL-SECURITY-USERID" => $paypal_credentials['security_user_id'],
        "X-PAYPAL-SECURITY-PASSWORD" => $paypal_credentials['security_password'],
        "X-PAYPAL-SECURITY-SIGNATURE" => $paypal_credentials['security_signature'],
        "X-PAYPAL-REQUEST-DATA-FORMAT" => "JSON",
        "X-PAYPAL-RESPONSE-DATA-FORMAT" => "JSON",
        "X-PAYPAL-APPLICATION-ID" => $paypal_credentials['application_id'],
    );

    $returnUrl = extretion_get_success_url( $invoice_id );

    $cancelurl = site_url();

    $data = array(
        "actionType" => "PAY",
        "currencyCode" => "USD",
        // "receiverOptions" => array(
        // 	'description' => 'This is a test message',
        // 	'invoiceData' => array(
        // 		'item' => array(
        // 			'name' => 'test 123',
        // 			'price' => 250
        // 		)
        // 	)
        // ),
        "receiverList" => array(
            "receiver" => array(
                array(
                    "amount" => $commission,
                    "email" => esc_html( get_option( 'options_paypal_email_owner' ) ),
                ),
            	array(
                    "amount" => $payment_hotel_owner,
                    "email" => get_the_author_meta( 'paypal_email' , $hotel_id ),
                ),
            ),
        ),
        "returnUrl" => $returnUrl,
        "cancelUrl" => $cancelurl,
        "requestEnvelope" => array(
            "errorLanguage" => "en_US",
            "detailLevel" => "ReturnAll",
        ),
    );

    $url = $paypal_credentials['url'];

    $response = wp_remote_post( $url, array(
		'method' => 'POST',
		'timeout' => 45,
		'redirection' => 5,
		'httpversion' => '1.1',
		'sslverify' => false,
		'headers' => $headers,
		'blocking' => true,
		'body' => json_encode($data),
	    )
	);

    if( is_wp_error( $response ) ){
    	die;
    }
    
    $paypal_data = json_decode( $response['body'], true );
    $paykey = !empty( $paypal_data['payKey'] ) ? $paypal_data['payKey'] : '';

    echo wp_json_encode(
    	array(
    		'result' => 'success',
    		'redirect_url' => $paypal_credentials['redirect_url'] . $paykey
    	)
    );

	die;

}

add_action( 'wp_ajax_lmh_get_new_avatar' , 'extretion_get_new_avatar' );
function extretion_get_new_avatar(){

	$user_id = get_current_user_id();
	$avatar = get_avatar( $user_id , 50 , null , null , array( 'class' => 'hidden-sm hidden-xs user_avatar_header' ) );

	$current_user_info = get_userdata( $user_id );
	$current_user_name = get_the_author_meta( 'first_name' , $user_id );

	echo wp_json_encode( 
		array( 
			'image' => $avatar , 
			'name' => $current_user_name ? sprintf( esc_html__( 'Welcome, %s' , 'extretion' ) , $current_user_name ) : sprintf( esc_html__( 'Welcome, %s' , 'extretion' ) , $current_user_info->user_login )
		) 
	);

	die;

}

add_action( 'wp_ajax_lmh_delete_guide' , 'extretion_delete_guide' );
function extretion_delete_guide(){

 	$data = array_map( 'sanitize_text_field' , $_POST );
 	$post_id = $data['delete_id'];
 	$user_id = get_current_user_id();

 	$args = array(
 		'post_type' => 'guide',
 		'post_status' => 'publish',
 		'author' => $user_id,
 		'post__in' => array( $post_id )
 	);

 	$delete_query = new WP_Query( $args );

 	if( $delete_query->have_posts() ):

		while( $delete_query->have_posts() ): $delete_query->the_post();	
			
			global $post;
			$title = get_the_title();
			$image_id = get_post_thumbnail_id( $post->ID ); // Get image ID

			wp_delete_attachment( $image_id ); // Delete attachment
			wp_delete_post( $post->ID ); // delete guide post

			echo wp_json_encode( 
				array( 
					'status' => 'success' ,
					'message' => sprintf(
						esc_html__( '%s has been deleted.', 'extretion' ),
						'<strong>' . $title . '</strong>'
					)
				) 
			);

			die;

		endwhile;	

	else:

		echo wp_json_encode( array( 'status' => 'error' ) );
		die;

 	endif;

}

add_action( 'wp_ajax_lmh_get_guide_details' , 'extretion_get_guide_details' );
function extretion_get_guide_details(){

	$data = array_map( 'sanitize_text_field' , $_POST );
 	$post_id = $data['edit_id'];
 	$user_id = get_current_user_id();

 	$args = array(
 		'post_type' => 'guide',
 		'post_status' => 'publish',
 		'author' => $user_id,
 		'post__in' => array( $post_id )
 	);

 	$edit_query = new WP_Query( $args );

 	if( $edit_query->have_posts() ):

		while( $edit_query->have_posts() ): $edit_query->the_post();

			global $post;

			ob_start(); ?>

			<div class="form-group mb-0"> 
				<input id="edit_guide_title" class="form-control mb-5" placeholder="Title" type="text" value="<?php the_title(); ?>"> 
			</div>

			<div class="form-group mb-0">
				<select class="selectpicker form-control edit_guide_cat" autocomplete="off">
					<?php extretion_get_guide_categories(); ?>
				</select>
			</div>

			<div class="form-group mt-20 mb-0">
				<input type="file" class="edit_guide_image  mb-5">
				<span class="mt-5 mb-0 line14 font-italic text-muted">
					<?php 
					esc_html_e( 'Uploading new photo will replace the old one.' , 'extretion' ); ?>
				</span>
			</div>
				
			</div>

			<?php
			$content = ob_get_clean();

			$category = wp_get_object_terms( $post->ID, 'guide_cat' );

			echo wp_json_encode( 
				array(
					'status' => 'success',
					'content' => $content,
					'selected' => $category[0]->term_id
				) 
			);

			die;

		endwhile;

		wp_reset_postdata();

	else:

	endif;

}

add_action( 'wp_ajax_lmh_edit_guide_content' , 'extretion_edit_guide_content' );
function extretion_edit_guide_content(){

	$data = array_map( 'sanitize_text_field' , $_POST );
	$error_msg = '';
	$error_status = false;

	$args = array(
		'post_type' => 'guide',
		'post_status' => 'publish',
		'author' => get_current_user_id(),
		'post__in' => array( $data['guide_id'] )
	);

	$update_guide_query = new WP_Query( $args );

	if( $update_guide_query->have_posts() ):

		while( $update_guide_query->have_posts() ): $update_guide_query->the_post();

			$image_upload = !empty( $_FILES ) ? true : false;
			extretion_check_guide_errors( $data , $error_msg , $error_status , $image_upload );
			extretion_update_guide_fields( $data );

			echo wp_json_encode(
			array(
				'result' => 'success'
			)
		);

		endwhile;

	else:

		echo wp_json_encode(
			array(
				'result' => 'error_user'
			)
		);

	endif;

	//print_r( $data );
	//print_r( $_FILES );
	
	die;

}

function extretion_update_guide_fields( $data ){

	$title = $data['name'];
	$category = $data['category'];
	$post_id = $data['guide_id'];

	// Insert new image and delete previous one
	if( !empty( $_FILES ) ){

		// Get featured image
		$thumbnail_id = get_post_thumbnail_id( $post_id );
		// Delete the featured image
		wp_delete_attachment( $thumbnail_id );

		// Upload new image
		$image_id = extretion_upload_image( $_FILES['image'] , $post_id );
		// Set new image as featured image
		set_post_thumbnail( $post_id , $image_id );

	}

	$my_post = array(
      	'ID'           => $post_id,
      	'post_title'   => $title,
  	);
  	wp_update_post( $my_post );

  	// Update Category
  	wp_set_object_terms( $post_id, (int) $category , 'guide_cat' );

}

add_action( 'wp_ajax_confirm_delete_room' , 'extretion_confirm_delete_room' );
function extretion_confirm_delete_room(){

	$data = array_map( 'sanitize_text_field' , $_POST );
	$post_id = $data['room_id'];
	$user_id = get_current_user_id();

	$args = array(
		'post_type' => 'room',
		'post_status' => 'any',
		'author' => $user_id,
		'post__in' => array( $post_id )
	);

	$delete_query = new WP_Query( $args );

	if( $delete_query->have_posts() ):

		while( $delete_query->have_posts() ): $delete_query->the_post();

			global $post;

			$room_photos = get_post_meta( $post->ID , 'room_photos', true );
			
			if( !empty( $room_photos ) && is_array( $room_photos ) ){

				foreach( $room_photos as $value ){

					wp_delete_attachment( $value );

				}

			}

			wp_delete_post( $post->ID );

			echo wp_json_encode(
				array(
					'result' => 'success'
				)
			);	

		endwhile;

	else:

		echo wp_json_encode(
			array(
				'result' => 'error'
			)
		);

	endif;

	die;

}

function extretion_set_room_status_unpublish(){

	if( !is_user_logged_in() ){
		return;
	}

	$user_id = get_current_user_id();
	$paypal_email = get_user_meta( $user_id , 'paypal_email', true );
	$paypal_disable_staus = get_option( 'options_booking_form' ); // If true then paypal is disabled
	$db_strip_details = get_user_meta( $user_id, 'stripe_details', true );

	$args = array(
		'post_type' => 'room',
		'post_status' => array( 'publish' , 'pending' ),
		'author' => $user_id,
		'posts_per_page' => -1
	);

	$query = new WP_Query( $args );

	if( $query->have_posts() ):

		while( $query->have_posts() ): $query->the_post();

			global $post;
			
			if( $paypal_disable_staus == true ){

				$my_post = array(
				    'ID'           => $post->ID,
				    'post_status'   => 'publish',
				    'post_type' => 'room',
				);

				wp_update_post( $my_post );

			} elseif( ( !empty( $db_strip_details ) || is_email( $paypal_email ) ) && $post->post_status == 'pending' ){ 

				$my_post = array(
				    'ID'           => $post->ID,
				    'post_status'   => 'publish',
				    'post_type' => 'room',
				);

				wp_update_post( $my_post );

			} elseif( extretion_check_payment_method_on_profile_update( $paypal_email , $db_strip_details ) && $post->post_status == 'publish' ) {

				$my_post = array(
				    'ID'           => $post->ID,
				    'post_status'   => 'pending',
				    'post_type' => 'room',
				);

				wp_update_post( $my_post );

			}

		endwhile;

	endif;

	wp_reset_postdata();
	
}

function extretion_check_payment_method_on_profile_update( $paypal_email , $db_strip_details ){

	if( !empty( $db_strip_details ) || is_email( $paypal_email ) ){
		return false;
	}
	return true;

}

function extretion_paypal_email_error_message(){

	$paypal_disable_staus = get_option( 'options_booking_form' ); // If true paypal is disabled

	if( $paypal_disable_staus == true ){
		return;
	}

	$user_id = get_current_user_id();
	$paypal_email = get_user_meta( $user_id , 'paypal_email', true );
	$db_strip_details = get_user_meta( $user_id, 'stripe_details', true );

	$args = array(
		'post_type' => 'room',
		'post_status' => 'any',
		'author' => $user_id
	);

	$query = new WP_Query( $args );

	if( $query->have_posts() || is_page_template( 'page-templates/dashboard-listyourroom.php' ) ):
	
		if( is_email( $paypal_email ) || !empty( $db_strip_details ) ){ 
			return;
		} ?>

		<div class="alert alert-danger mb-30 paypal_warning">
			<div class="icon">
				<i class="fa fa-lightbulb-o font12"></i>
			</div>
			<div class="content">
				<h4 class="text-primary2">
					<?php esc_html_e( 'Notice', 'extretion' ); ?>
				</h4>
				<?php 
				esc_html_e( 'Your payment method is not defined. Please add PayPal email or connect to stripe. Until your payment method is not defined, travelers cannot book your rooms. Your all rooms will be disabled as well.', 'extretion' ); ?>
			</div>
		</div>

		<?php

	endif;
}

function extretion_get_homepage_destinations_categories(){

	add_filter( 'terms_clauses' , 'extretion_destination_clause' , 10 , 3 );
							
	$limit = get_option( 'options_no_of_destinations_home' );
	$limit = !empty( $limit ) ? $limit : 4;

	$categories = get_terms( 
		
		'destinations', array(
	    	'fields' => 'all',
	    	'hide_empty' => true,
	    	'order' => 'DESC',
	    	'orderby' => 'count',
	    	'number' => $limit
		) 

	); 

	remove_filter( 'terms_clauses' , 'extretion_destination_clause' );

	return $categories;

}

function extretion_set_post_type_404_error( $post ){

	$exclude_post_type = array( 'lmh_slider' , 'faqs' , 'testimonials' , 'guide' , 'lmh_invoice' );

	$exclude_post_type = apply_filters( 'extretion_exclude_post_type', $exclude_post_type );

	if( in_array( $post->post_type , $exclude_post_type ) ){
		extretion_set404Page();
		exit;
	}

}

function my_search_form( $form ) {
    $form = '<form role="search" method="get" id="searchform" class="searchform" action="' . esc_url( home_url( '/' ) ) . '" >
	    <div>
	    	<input autocomplete="off" class="form-control lmh_quick_search" type="text" value="" name="s" id="s" placeholder="' . esc_html__( 'Enter your place' , 'extretion' ) . '" />
	    	<input type="submit" value="Go" class="btn btn-danger"/>

	    	<div class="search_place_attr" style="display:none">

	        	<input data-geo="lat" name="lat" value="" type="hidden" >
		        <input data-geo="lng" name="lng" value="" type="hidden">
		        <input data-geo="formatted_address" name="formatted_address" value="" type="hidden">
		        <input data-geo="name" name="place" value="" type="hidden">
	
		    </div>

	    </div>
    </form>';

    return $form;
}

add_filter( 'get_search_form', 'my_search_form', 100 );

/**
* Fixed tgmpa css
*/

add_action( 'admin_head', 'extretion_fix_tgma');
function extretion_fix_tgma(){
	echo '<style>
		#setting-error-tgmpa {
		    display: table;
		    margin-bottom: 25px;
		}</style>';
}

add_filter( 'the_password_form', 'extretion_custom_password_form' );
function extretion_custom_password_form() {

    global $post;

    $label = 'pwbox-'.( empty( $post->ID ) ? rand() : $post->ID );

    $o = '<form class="protected-post-form" action="' . esc_url( site_url( 'wp-login.php?action=postpass', 'extretion' )) . '" method="post">
    ' . esc_html__( "This content is password protected. To view it please enter your password below:" , 'extretion' ) . '
    <div class="password_protected_wrap"><input name="post_password" placeholder="' . esc_html__( 'Password' , 'extretion' ) . '" class="form-control" id="' . $label . '" type="password"/><input type="submit" name="Submit" class="btn btn-primary" value="' . esc_html__( "Submit" , 'extretion' ) . '" /></div>
    </form>';
    return $o;
}

/* Add body class */
add_filter( 'body_class', 'extretion_custom_class' );
function extretion_custom_class( $classes ) {
    if ( !is_front_page() ) {
        $classes[] = 'not-home';
    }
    return $classes;
}